class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f32[100, 20, 3]", arg1_1: "f32[19, 100, 100]", arg2_1: "f32[100]", arg3_1: "f32[100, 128]", arg4_1: "f32[128]", arg5_1: "f32[128]", arg6_1: "f32[1725, 512]", arg7_1: "f32[512, 128]", arg8_1: "f32[128]", arg9_1: "f32[128]", arg10_1: "f32[100, 128]", arg11_1: "f32[128]", arg12_1: "f32[128]", arg13_1: "i64[100]", arg14_1: "i64[100]", arg15_1: "i64[100]", arg16_1: "b8[100]", arg17_1: "f32[100, 20, 3]", arg18_1: "f32[6, 66, 64]", arg19_1: "f32[6, 400, 64]", arg20_1: "f32[6, 60, 64]", arg21_1: "f32[6, 9, 64]", arg22_1: "f32[6, 240, 64]", arg23_1: "f32[6, 64]", arg24_1: "f32[6, 64]", arg25_1: "f32[6, 64, 128]", arg26_1: "f32[6, 128]", arg27_1: "f32[6, 128, 64]", arg28_1: "f32[6, 64]", arg29_1: "f32[66, 64]", arg30_1: "f32[400, 64]", arg31_1: "f32[60, 64]", arg32_1: "f32[9, 64]", arg33_1: "f32[240, 64]", arg34_1: "f32[64]", arg35_1: "f32[64]", arg36_1: "f32[64, 128]", arg37_1: "f32[128]", arg38_1: "f32[128, 64]", arg39_1: "f32[64]", arg40_1: "f32[128]", arg41_1: "f32[128]", arg42_1: "f32[128]", arg43_1: "f32[128]", arg44_1: "f32[128, 768]", arg45_1: "f32[32]", arg46_1: "f32[32]", arg47_1: "f32[32]", arg48_1: "f32[32]", arg49_1: "f32[128, 576]", arg50_1: "f32[64, 8]", arg51_1: "f32[8]", arg52_1: "f32[1024, 128]", arg53_1: "f32[128]", arg54_1: "f32[128]", arg55_1: "f32[128]", arg56_1: "f32[128]", arg57_1: "f32[128]", arg58_1: "f32[128, 768]", arg59_1: "f32[32]", arg60_1: "f32[32]", arg61_1: "f32[32]", arg62_1: "f32[32]", arg63_1: "f32[128, 576]", arg64_1: "f32[64, 8]", arg65_1: "f32[8]", arg66_1: "f32[1024, 128]", arg67_1: "f32[128]", arg68_1: "f32[128]", arg69_1: "f32[128]", arg70_1: "f32[128, 128]", arg71_1: "f32[60, 256]", arg72_1: "f32[256]", arg73_1: "f32[256, 128]", arg74_1: "f32[128]", arg75_1: "f32[128, 512]", arg76_1: "f32[128, 512]", arg77_1: "f32[128, 512]", arg78_1: "f32[128, 512]", arg79_1: "f32[512, 128]", arg80_1: "f32[128]", arg81_1: "f32[128]", arg82_1: "f32[128]", arg83_1: "f32[128, 60]", arg84_1: "f32[66, 64]", arg85_1: "f32[400, 64]", arg86_1: "f32[60, 64]", arg87_1: "f32[9, 64]", arg88_1: "f32[240, 64]", arg89_1: "f32[64]", arg90_1: "f32[64]", arg91_1: "f32[64, 128]", arg92_1: "f32[128]", arg93_1: "f32[128, 64]", arg94_1: "f32[64]", arg95_1: "f32[128]", arg96_1: "f32[128]", arg97_1: "f32[128]", arg98_1: "f32[128]", arg99_1: "f32[128, 768]", arg100_1: "f32[32]", arg101_1: "f32[32]", arg102_1: "f32[32]", arg103_1: "f32[32]", arg104_1: "f32[128, 576]", arg105_1: "f32[64, 8]", arg106_1: "f32[8]", arg107_1: "f32[1024, 128]", arg108_1: "f32[128]", arg109_1: "f32[128]", arg110_1: "f32[128]", arg111_1: "f32[128]", arg112_1: "f32[128]", arg113_1: "f32[128, 768]", arg114_1: "f32[32]", arg115_1: "f32[32]", arg116_1: "f32[32]", arg117_1: "f32[32]", arg118_1: "f32[128, 576]", arg119_1: "f32[64, 8]", arg120_1: "f32[8]", arg121_1: "f32[1024, 128]", arg122_1: "f32[128]", arg123_1: "f32[128]", arg124_1: "f32[128]", arg125_1: "f32[128, 128]", arg126_1: "f32[60, 256]", arg127_1: "f32[256]", arg128_1: "f32[256, 128]", arg129_1: "f32[128]", arg130_1: "f32[128, 512]", arg131_1: "f32[128, 512]", arg132_1: "f32[128, 512]", arg133_1: "f32[128, 512]", arg134_1: "f32[512, 128]", arg135_1: "f32[128]", arg136_1: "f32[128]", arg137_1: "f32[128]", arg138_1: "f32[128, 60]", arg139_1: "f32[66, 64]", arg140_1: "f32[400, 64]", arg141_1: "f32[60, 64]", arg142_1: "f32[9, 64]", arg143_1: "f32[240, 64]", arg144_1: "f32[64]", arg145_1: "f32[64]", arg146_1: "f32[64, 128]", arg147_1: "f32[128]", arg148_1: "f32[128, 64]", arg149_1: "f32[64]", arg150_1: "f32[128]", arg151_1: "f32[128]", arg152_1: "f32[128]", arg153_1: "f32[128]", arg154_1: "f32[128, 768]", arg155_1: "f32[32]", arg156_1: "f32[32]", arg157_1: "f32[32]", arg158_1: "f32[32]", arg159_1: "f32[128, 576]", arg160_1: "f32[64, 8]", arg161_1: "f32[8]", arg162_1: "f32[1024, 128]", arg163_1: "f32[128]", arg164_1: "f32[128]", arg165_1: "f32[128]", arg166_1: "f32[128]", arg167_1: "f32[128]", arg168_1: "f32[128, 768]", arg169_1: "f32[32]", arg170_1: "f32[32]", arg171_1: "f32[32]", arg172_1: "f32[32]", arg173_1: "f32[128, 576]", arg174_1: "f32[64, 8]", arg175_1: "f32[8]", arg176_1: "f32[1024, 128]", arg177_1: "f32[128]", arg178_1: "f32[128]", arg179_1: "f32[128]", arg180_1: "f32[128, 128]", arg181_1: "f32[60, 256]", arg182_1: "f32[256]", arg183_1: "f32[256, 128]", arg184_1: "f32[128]", arg185_1: "f32[128, 512]", arg186_1: "f32[128, 512]", arg187_1: "f32[128, 512]", arg188_1: "f32[128, 512]", arg189_1: "f32[512, 128]", arg190_1: "f32[128]", arg191_1: "f32[128]", arg192_1: "f32[128]", arg193_1: "f32[128, 60]", arg194_1: "f32[66, 64]", arg195_1: "f32[400, 64]", arg196_1: "f32[60, 64]", arg197_1: "f32[9, 64]", arg198_1: "f32[240, 64]", arg199_1: "f32[64]", arg200_1: "f32[64]", arg201_1: "f32[64, 128]", arg202_1: "f32[128]", arg203_1: "f32[128, 64]", arg204_1: "f32[64]", arg205_1: "f32[128]", arg206_1: "f32[128]", arg207_1: "f32[128]", arg208_1: "f32[128]", arg209_1: "f32[128, 768]", arg210_1: "f32[32]", arg211_1: "f32[32]", arg212_1: "f32[32]", arg213_1: "f32[32]", arg214_1: "f32[128, 576]", arg215_1: "f32[64, 8]", arg216_1: "f32[8]", arg217_1: "f32[1024, 128]", arg218_1: "f32[128]", arg219_1: "f32[128]", arg220_1: "f32[128]", arg221_1: "f32[128]", arg222_1: "f32[128]", arg223_1: "f32[128, 768]", arg224_1: "f32[32]", arg225_1: "f32[32]", arg226_1: "f32[32]", arg227_1: "f32[32]", arg228_1: "f32[128, 576]", arg229_1: "f32[64, 8]", arg230_1: "f32[8]", arg231_1: "f32[1024, 128]", arg232_1: "f32[128]", arg233_1: "f32[128]", arg234_1: "f32[128]", arg235_1: "f32[128, 128]", arg236_1: "f32[60, 256]", arg237_1: "f32[256]", arg238_1: "f32[256, 128]", arg239_1: "f32[128]", arg240_1: "f32[128, 512]", arg241_1: "f32[128, 512]", arg242_1: "f32[128, 512]", arg243_1: "f32[128, 512]", arg244_1: "f32[512, 128]", arg245_1: "f32[128]", arg246_1: "f32[128]", arg247_1: "f32[128]", arg248_1: "f32[128, 60]", arg249_1: "f32[66, 64]", arg250_1: "f32[400, 64]", arg251_1: "f32[60, 64]", arg252_1: "f32[9, 64]", arg253_1: "f32[240, 64]", arg254_1: "f32[64]", arg255_1: "f32[64]", arg256_1: "f32[64, 128]", arg257_1: "f32[128]", arg258_1: "f32[128, 64]", arg259_1: "f32[64]", arg260_1: "f32[128]", arg261_1: "f32[128]", arg262_1: "f32[128]", arg263_1: "f32[128]", arg264_1: "f32[128, 768]", arg265_1: "f32[32]", arg266_1: "f32[32]", arg267_1: "f32[32]", arg268_1: "f32[32]", arg269_1: "f32[128, 576]", arg270_1: "f32[64, 8]", arg271_1: "f32[8]", arg272_1: "f32[1024, 128]", arg273_1: "f32[128]", arg274_1: "f32[128]", arg275_1: "f32[128]", arg276_1: "f32[128]", arg277_1: "f32[128]", arg278_1: "f32[128, 768]", arg279_1: "f32[32]", arg280_1: "f32[32]", arg281_1: "f32[32]", arg282_1: "f32[32]", arg283_1: "f32[128, 576]", arg284_1: "f32[64, 8]", arg285_1: "f32[8]", arg286_1: "f32[1024, 128]", arg287_1: "f32[128]", arg288_1: "f32[128]", arg289_1: "f32[128]", arg290_1: "f32[128, 128]", arg291_1: "f32[60, 256]", arg292_1: "f32[256]", arg293_1: "f32[256, 128]", arg294_1: "f32[128]", arg295_1: "f32[128, 512]", arg296_1: "f32[128, 512]", arg297_1: "f32[128, 512]", arg298_1: "f32[128, 512]", arg299_1: "f32[512, 128]", arg300_1: "f32[128]", arg301_1: "f32[128]", arg302_1: "f32[128]", arg303_1: "f32[128, 60]", arg304_1: "f32[66, 64]", arg305_1: "f32[400, 64]", arg306_1: "f32[60, 64]", arg307_1: "f32[9, 64]", arg308_1: "f32[240, 64]", arg309_1: "f32[64]", arg310_1: "f32[64]", arg311_1: "f32[64, 128]", arg312_1: "f32[128]", arg313_1: "f32[128, 64]", arg314_1: "f32[64]", arg315_1: "f32[128]", arg316_1: "f32[128]", arg317_1: "f32[128]", arg318_1: "f32[128]", arg319_1: "f32[128, 768]", arg320_1: "f32[32]", arg321_1: "f32[32]", arg322_1: "f32[32]", arg323_1: "f32[32]", arg324_1: "f32[128, 576]", arg325_1: "f32[64, 8]", arg326_1: "f32[8]", arg327_1: "f32[1024, 128]", arg328_1: "f32[128]", arg329_1: "f32[128]", arg330_1: "f32[128]", arg331_1: "f32[128]", arg332_1: "f32[128]", arg333_1: "f32[128, 768]", arg334_1: "f32[32]", arg335_1: "f32[32]", arg336_1: "f32[32]", arg337_1: "f32[32]", arg338_1: "f32[128, 576]", arg339_1: "f32[64, 8]", arg340_1: "f32[8]", arg341_1: "f32[1024, 128]", arg342_1: "f32[128]", arg343_1: "f32[128]", arg344_1: "f32[128]", arg345_1: "f32[128, 128]", arg346_1: "f32[60, 256]", arg347_1: "f32[256]", arg348_1: "f32[256, 128]", arg349_1: "f32[128]", arg350_1: "f32[128, 512]", arg351_1: "f32[128, 512]", arg352_1: "f32[128, 512]", arg353_1: "f32[128, 512]", arg354_1: "f32[512, 128]", arg355_1: "f32[128]", arg356_1: "f32[128]", arg357_1: "f32[128]", arg358_1: "f32[128, 60]"):
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:55 in _unbind_draws, code: return list(torch.unbind(stack, dim=0))
        unbind = torch.ops.aten.unbind.int(arg1_1);  arg1_1 = None
        getitem: "f32[100, 100]" = unbind[0]
        getitem_1: "f32[100, 100]" = unbind[1]
        getitem_2: "f32[100, 100]" = unbind[2]
        getitem_3: "f32[100, 100]" = unbind[3]
        getitem_4: "f32[100, 100]" = unbind[4]
        getitem_5: "f32[100, 100]" = unbind[5]
        getitem_6: "f32[100, 100]" = unbind[6]
        getitem_7: "f32[100, 100]" = unbind[7]
        getitem_8: "f32[100, 100]" = unbind[8]
        getitem_9: "f32[100, 100]" = unbind[9]
        getitem_10: "f32[100, 100]" = unbind[10]
        getitem_11: "f32[100, 100]" = unbind[11]
        getitem_12: "f32[100, 100]" = unbind[12]
        getitem_13: "f32[100, 100]" = unbind[13]
        getitem_14: "f32[100, 100]" = unbind[14]
        getitem_15: "f32[100, 100]" = unbind[15]
        getitem_16: "f32[100, 100]" = unbind[16]
        getitem_17: "f32[100, 100]" = unbind[17]
        getitem_18: "f32[100, 100]" = unbind[18];  unbind = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select: "f32[100, 3]" = torch.ops.aten.select.int(arg0_1, 1, 0)
        select_1: "f32[100, 3]" = torch.ops.aten.select.int(arg0_1, 1, 1)
        select_2: "f32[100, 3]" = torch.ops.aten.select.int(arg0_1, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_2, select_1);  select_2 = None
        sub_1: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select, select_1);  select = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub, sub)
        sum_1: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul, [-1]);  mul = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min: "f32[100]" = torch.ops.aten.clamp_min.default(sum_1, 1e-12);  sum_1 = None
        sqrt: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min);  clamp_min = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt, -1);  sqrt = None
        div: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub, unsqueeze);  sub = unsqueeze = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_1: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_1, div)
        sum_2: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_1, [-1]);  mul_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_1: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_2, -1);  sum_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_2: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1, div);  unsqueeze_1 = None
        sub_2: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_1, mul_2);  sub_1 = mul_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_3: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_2, sub_2)
        sum_3: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_3, [-1]);  mul_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_1: "f32[100]" = torch.ops.aten.clamp_min.default(sum_3, 1e-12);  sum_3 = None
        sqrt_1: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_1);  clamp_min_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_2: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_1, -1);  sqrt_1 = None
        div_1: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_2, unsqueeze_2);  sub_2 = unsqueeze_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        iota: "i64[3]" = torch.ops.prims.iota.default(3, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        add: "i64[3]" = torch.ops.aten.add.Tensor(iota, 1)
        remainder: "i64[3]" = torch.ops.aten.remainder.Scalar(add, 3);  add = None
        index: "f32[100, 3]" = torch.ops.aten.index.Tensor(div, [None, remainder])
        add_1: "i64[3]" = torch.ops.aten.add.Tensor(iota, 2);  iota = None
        remainder_1: "i64[3]" = torch.ops.aten.remainder.Scalar(add_1, 3);  add_1 = None
        index_1: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_1, [None, remainder_1])
        mul_4: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index, index_1);  index = index_1 = None
        index_2: "f32[100, 3]" = torch.ops.aten.index.Tensor(div, [None, remainder_1])
        index_3: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_1, [None, remainder])
        mul_5: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_2, index_3);  index_2 = index_3 = None
        sub_3: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_4, mul_5);  mul_4 = mul_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_3: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div, 2);  div = None
        unsqueeze_4: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_1, 2);  div_1 = None
        unsqueeze_5: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_3, 2);  sub_3 = None
        cat: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_3, unsqueeze_4, unsqueeze_5], -1);  unsqueeze_3 = unsqueeze_4 = unsqueeze_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_6: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_7: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_1, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_4: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(arg0_1, unsqueeze_7)
        unsqueeze_8: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_4, -1);  sub_4 = None
        mul_6: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_6, unsqueeze_8);  unsqueeze_8 = None
        sum_4: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_6, [-2]);  mul_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:271 in forward_core, code: parts = [local_pos.reshape(n, -1),
        view: "f32[100, 60]" = torch.ops.aten.view.default(sum_4, [100, -1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_7: "f32[100, 20, 3]" = torch.ops.aten.mul.Tensor(sum_4, sum_4)
        sum_5: "f32[100, 20]" = torch.ops.aten.sum.dim_IntList(mul_7, [-1]);  mul_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_2: "f32[100, 20]" = torch.ops.aten.clamp_min.default(sum_5, 1e-12);  sum_5 = None
        sqrt_2: "f32[100, 20]" = torch.ops.aten.sqrt.default(clamp_min_2);  clamp_min_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:57 in _arange_centers, code: + torch.arange(bins, device=device, dtype=dtype) * step
        iota_1: "i64[64]" = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        mul_8: "i64[64]" = torch.ops.aten.mul.Tensor(iota_1, 1);  iota_1 = None
        add_4: "i64[64]" = torch.ops.aten.add.Tensor(mul_8, 0);  mul_8 = None
        convert_element_type: "f32[64]" = torch.ops.prims.convert_element_type.default(add_4, torch.float32);  add_4 = None
        mul_9: "f32[64]" = torch.ops.aten.mul.Tensor(convert_element_type, 0.34375);  convert_element_type = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:56 in _arange_centers, code: centers = (min_distance
        add_5: "f32[64]" = torch.ops.aten.add.Tensor(mul_9, 0.0);  mul_9 = None
        add_6: "f32[64]" = torch.ops.aten.add.Tensor(add_5, 0.171875);  add_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_9: "f32[100, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_2, 2);  sqrt_2 = None
        sub_5: "f32[100, 20, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_9, add_6);  unsqueeze_9 = add_6 = None
        pow_1: "f32[100, 20, 64]" = torch.ops.aten.pow.Tensor_Scalar(sub_5, 2);  sub_5 = None
        neg: "f32[100, 20, 64]" = torch.ops.aten.neg.default(pow_1);  pow_1 = None
        div_2: "f32[100, 20, 64]" = torch.ops.aten.div.Tensor(neg, 0.1181640625);  neg = None
        exp: "f32[100, 20, 64]" = torch.ops.aten.exp.default(div_2);  div_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:272 in forward_core, code: GF.distance_rbf(vec_norm(local_pos), 0.0, 22.0).reshape(n, -1)]
        view_1: "f32[100, 1280]" = torch.ops.aten.view.default(exp, [100, -1]);  exp = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:102 in vp_time_embedding, code: return torch.cat((t[:, None], GF.fourier_time_embedding(t, size=size)), dim=-1)
        unsqueeze_10: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(arg2_1, 1);  arg2_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:93 in fourier_time_embedding, code: exponent = 2.0 * torch.arange(size // 2, device=t.device, dtype=t.dtype) / size
        iota_2: "i64[128]" = torch.ops.prims.iota.default(128, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        mul_10: "i64[128]" = torch.ops.aten.mul.Tensor(iota_2, 1);  iota_2 = None
        add_7: "i64[128]" = torch.ops.aten.add.Tensor(mul_10, 0);  mul_10 = None
        convert_element_type_1: "f32[128]" = torch.ops.prims.convert_element_type.default(add_7, torch.float32);  add_7 = None
        mul_11: "f32[128]" = torch.ops.aten.mul.Tensor(convert_element_type_1, 2.0);  convert_element_type_1 = None
        div_3: "f32[128]" = torch.ops.aten.div.Tensor(mul_11, 256);  mul_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:94 in fourier_time_embedding, code: denom = base ** exponent
        pow_2: "f32[128]" = torch.ops.aten.pow.Scalar(10000.0, div_3);  div_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:95 in fourier_time_embedding, code: arg = scale * t[..., None] / denom
        mul_12: "f32[100, 1]" = torch.ops.aten.mul.Tensor(unsqueeze_10, 1.0)
        div_4: "f32[100, 128]" = torch.ops.aten.div.Tensor(mul_12, pow_2);  mul_12 = pow_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:96 in fourier_time_embedding, code: return torch.cat((torch.sin(arg), torch.cos(arg)), dim=-1)
        sin: "f32[100, 128]" = torch.ops.aten.sin.default(div_4)
        cos: "f32[100, 128]" = torch.ops.aten.cos.default(div_4);  div_4 = None
        cat_1: "f32[100, 256]" = torch.ops.aten.cat.default([sin, cos], -1);  sin = cos = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:102 in vp_time_embedding, code: return torch.cat((t[:, None], GF.fourier_time_embedding(t, size=size)), dim=-1)
        cat_2: "f32[100, 257]" = torch.ops.aten.cat.default([unsqueeze_10, cat_1], -1);  unsqueeze_10 = cat_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean: "f32[100, 1]" = torch.ops.aten.mean.dim(arg3_1, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var: "f32[100, 1]" = torch.ops.aten.var.correction(arg3_1, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_6: "f32[100, 128]" = torch.ops.aten.sub.Tensor(arg3_1, mean);  arg3_1 = mean = None
        add_8: "f32[100, 1]" = torch.ops.aten.add.Tensor(var, 1e-05);  var = None
        rsqrt: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_8);  add_8 = None
        mul_13: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_6, rsqrt);  sub_6 = rsqrt = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_14: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_13, arg4_1);  mul_13 = arg4_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_9: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_14, arg5_1);  mul_14 = arg5_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:280 in forward_core, code: local = self.prepare_layer_norm_local(self.prepare_mlp(torch.cat(parts, dim=-1)))
        cat_3: "f32[100, 1725]" = torch.ops.aten.cat.default([cat_2, view, view_1, add_9], -1);  cat_2 = view_1 = add_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_12: "f32[100, 1725, 1]" = torch.ops.aten.unsqueeze.default(cat_3, 2);  cat_3 = None
        permute: "f32[100, 1, 1725]" = torch.ops.aten.permute.default(unsqueeze_12, [0, 2, 1]);  unsqueeze_12 = None
        unsqueeze_13: "f32[1725, 512, 1]" = torch.ops.aten.unsqueeze.default(arg6_1, 2);  arg6_1 = None
        permute_1: "f32[1, 512, 1725]" = torch.ops.aten.permute.default(unsqueeze_13, [2, 1, 0]);  unsqueeze_13 = None
        permute_2: "f32[100, 1725, 1]" = torch.ops.aten.permute.default(permute, [0, 2, 1]);  permute = None
        view_2: "f32[1, 100, 1725]" = torch.ops.aten.view.default(permute_2, [1, 100, 1725]);  permute_2 = None
        permute_3: "f32[1725, 512, 1]" = torch.ops.aten.permute.default(permute_1, [2, 1, 0]);  permute_1 = None
        view_3: "f32[1, 1725, 512]" = torch.ops.aten.view.default(permute_3, [1, 1725, 512]);  permute_3 = None
        bmm: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_2, view_3);  view_2 = view_3 = None
        view_4: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm, [100, 1, 512]);  bmm = None
        permute_4: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_4, [0, 2, 1]);  view_4 = None
        view_5: "f32[100, 512]" = torch.ops.aten.view.default(permute_4, [100, 512]);  permute_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_15: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_5, view_5)
        mul_16: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_15, view_5);  mul_15 = None
        mul_17: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_16, 0.044715);  mul_16 = None
        add_10: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_5, mul_17);  mul_17 = None
        mul_18: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_10, 0.7978845608028654);  add_10 = None
        mul_19: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_5, 0.5);  view_5 = None
        tanh: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_18);  mul_18 = None
        add_11: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh, 1);  tanh = None
        mul_20: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_19, add_11);  mul_19 = add_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_14: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(mul_20, 2);  mul_20 = None
        permute_5: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_14, [0, 2, 1]);  unsqueeze_14 = None
        unsqueeze_15: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg7_1, 2);  arg7_1 = None
        permute_6: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_15, [2, 1, 0]);  unsqueeze_15 = None
        permute_7: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_5, [0, 2, 1]);  permute_5 = None
        view_6: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_7, [1, 100, 512]);  permute_7 = None
        permute_8: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_6, [2, 1, 0]);  permute_6 = None
        view_7: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_8, [1, 512, 128]);  permute_8 = None
        bmm_1: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_6, view_7);  view_6 = view_7 = None
        view_8: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_1, [100, 1, 128]);  bmm_1 = None
        permute_9: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_8, [0, 2, 1]);  view_8 = None
        view_9: "f32[100, 128]" = torch.ops.aten.view.default(permute_9, [100, 128]);  permute_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_1: "f32[100, 1]" = torch.ops.aten.mean.dim(view_9, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_1: "f32[100, 1]" = torch.ops.aten.var.correction(view_9, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_7: "f32[100, 128]" = torch.ops.aten.sub.Tensor(view_9, mean_1);  view_9 = mean_1 = None
        add_12: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_1, 1e-05);  var_1 = None
        rsqrt_1: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_12);  add_12 = None
        mul_21: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_7, rsqrt_1);  sub_7 = rsqrt_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_22: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_21, arg8_1);  mul_21 = arg8_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_13: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_22, arg9_1);  mul_22 = arg9_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_2: "f32[100, 1]" = torch.ops.aten.mean.dim(arg10_1, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_2: "f32[100, 1]" = torch.ops.aten.var.correction(arg10_1, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_8: "f32[100, 128]" = torch.ops.aten.sub.Tensor(arg10_1, mean_2);  arg10_1 = mean_2 = None
        add_14: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_2, 1e-05);  var_2 = None
        rsqrt_2: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_14);  add_14 = None
        mul_23: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_8, rsqrt_2);  sub_8 = rsqrt_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_24: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_23, arg11_1);  mul_23 = arg11_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_15: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_24, arg12_1);  mul_24 = arg12_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:83 in inner, code: same_item = batch[:, None] == batch[None, :]
        unsqueeze_16: "i64[100, 1]" = torch.ops.aten.unsqueeze.default(arg14_1, 1)
        unsqueeze_17: "i64[1, 100]" = torch.ops.aten.unsqueeze.default(arg14_1, 0)
        eq: "b8[100, 100]" = torch.ops.aten.eq.Tensor(unsqueeze_16, unsqueeze_17)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:84 in inner, code: same_chain = chain[:, None] == chain[None, :]
        unsqueeze_18: "i64[100, 1]" = torch.ops.aten.unsqueeze.default(arg15_1, 1)
        unsqueeze_19: "i64[1, 100]" = torch.ops.aten.unsqueeze.default(arg15_1, 0)
        eq_1: "b8[100, 100]" = torch.ops.aten.eq.Tensor(unsqueeze_18, unsqueeze_19)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:85 in inner, code: pair_mask = mask[:, None] & mask[None, :] & same_item & same_chain
        unsqueeze_20: "b8[100, 1]" = torch.ops.aten.unsqueeze.default(arg16_1, 1)
        unsqueeze_21: "b8[1, 100]" = torch.ops.aten.unsqueeze.default(arg16_1, 0)
        bitwise_and: "b8[100, 100]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, unsqueeze_21)
        bitwise_and_1: "b8[100, 100]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and, eq);  bitwise_and = None
        bitwise_and_2: "b8[100, 100]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_1, eq_1);  eq_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:86 in inner, code: distance = (resi[:, None] - resi[None, :]).abs().float()
        unsqueeze_22: "i64[100, 1]" = torch.ops.aten.unsqueeze.default(arg13_1, 1)
        unsqueeze_23: "i64[1, 100]" = torch.ops.aten.unsqueeze.default(arg13_1, 0)
        sub_9: "i64[100, 100]" = torch.ops.aten.sub.Tensor(unsqueeze_22, unsqueeze_23);  unsqueeze_23 = None
        abs_1: "i64[100, 100]" = torch.ops.aten.abs.default(sub_9);  sub_9 = None
        convert_element_type_2: "f32[100, 100]" = torch.ops.prims.convert_element_type.default(abs_1, torch.float32);  abs_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:53 in inner, code: index = torch.arange(n, device=distance.device)
        iota_3: "i64[100]" = torch.ops.prims.iota.default(100, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        full_default: "f32[100, 100]" = torch.ops.aten.full.default([100, 100], inf, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_2, convert_element_type_2, full_default);  bitwise_and_2 = convert_element_type_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort = torch.ops.aten.sort.stable(where, stable = True)
        getitem_20: "i64[100, 100]" = sort[1];  sort = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_17: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_20, 1, 0, 16);  getitem_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        unsqueeze_24: "i64[100, 1]" = torch.ops.aten.unsqueeze.default(iota_3, 1);  iota_3 = None
        index_4: "f32[100, 16]" = torch.ops.aten.index.Tensor(where, [unsqueeze_24, slice_17]);  where = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_4, inf);  index_4 = None
        full_default_1: "i64[100, 16]" = torch.ops.aten.full.default([100, 16], -1, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_1: "i64[100, 16]" = torch.ops.aten.where.self(lt, slice_17, full_default_1);  lt = slice_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:57 in inner, code: ca = pos[:, 1]
        select_3: "f32[100, 3]" = torch.ops.aten.select.int(arg17_1, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:59 in inner, code: ((ca[:, None] - ca[None, :]) ** 2).sum(-1), min=1e-12))
        unsqueeze_25: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_3, 1)
        unsqueeze_26: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_3, 0);  select_3 = None
        sub_10: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_25, unsqueeze_26);  unsqueeze_25 = unsqueeze_26 = None
        pow_3: "f32[100, 100, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_10, 2);  sub_10 = None
        sum_6: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(pow_3, [-1]);  pow_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:58 in inner, code: dist = torch.sqrt(torch.clamp(
        clamp_min_3: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_6, 1e-12);  sum_6 = None
        sqrt_3: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_3);  clamp_min_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_2: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, sqrt_3, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne: "b8[100, 16]" = torch.ops.aten.ne.Scalar(where_1, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:59 in inner, code: torch.full_like(distance[index[:, None], neighbours], _INF),
        full_default_3: "f32[100, 16]" = torch.ops.aten.full.default([100, 16], inf, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_6: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_2, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_3: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_6);  index_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put: "f32[100, 100]" = torch.ops.aten.index_put.default(where_2, [unsqueeze_24, where_1], where_3);  where_2 = where_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_1 = torch.ops.aten.sort.stable(index_put, stable = True)
        getitem_22: "i64[100, 100]" = sort_1[1];  sort_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_29: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_22, 1, 0, 16);  getitem_22 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_7: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put, [unsqueeze_24, slice_29]);  index_put = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_1: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_7, inf);  index_7 = None
        where_4: "i64[100, 16]" = torch.ops.aten.where.self(lt_1, slice_29, full_default_1);  lt_1 = slice_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_4: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_4], -1);  where_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_16: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_3, 1e-06)
        log: "f32[100, 100]" = torch.ops.aten.log.default(add_16);  add_16 = None
        mul_25: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log, -3.0);  log = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_1: "f32[100, 100]" = torch.ops.aten.log.default(getitem_2)
        neg_1: "f32[100, 100]" = torch.ops.aten.neg.default(log_1);  log_1 = None
        log_2: "f32[100, 100]" = torch.ops.aten.log.default(neg_1);  neg_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_11: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_25, log_2);  log_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_2: "f32[100, 100]" = torch.ops.aten.neg.default(sub_11);  sub_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_5: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_2, full_default);  neg_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_6: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_5, full_default);  where_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_1: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_4, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:59 in inner, code: torch.full_like(distance[index[:, None], neighbours], _INF),
        full_default_7: "f32[100, 32]" = torch.ops.aten.full.default([100, 32], inf, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_9: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_6, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_7: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_9);  index_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_1: "f32[100, 100]" = torch.ops.aten.index_put.default(where_6, [unsqueeze_24, cat_4], where_7);  where_6 = where_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_2 = torch.ops.aten.sort.stable(index_put_1, stable = True)
        getitem_24: "i64[100, 100]" = sort_2[1];  sort_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_38: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_24, 1, 0, 16);  getitem_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_10: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_1, [unsqueeze_24, slice_38]);  index_put_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_2: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_10, inf);  index_10 = None
        where_8: "i64[100, 16]" = torch.ops.aten.where.self(lt_2, slice_38, full_default_1);  lt_2 = slice_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_5: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_8], -1);  where_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_4: "f32[100, 100]" = torch.ops.aten.log.default(getitem_5)
        neg_3: "f32[100, 100]" = torch.ops.aten.neg.default(log_4);  log_4 = None
        log_5: "f32[100, 100]" = torch.ops.aten.log.default(neg_3);  neg_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_12: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_25, log_5);  log_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_4: "f32[100, 100]" = torch.ops.aten.neg.default(sub_12);  sub_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_9: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_4, full_default);  neg_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_10: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_9, full_default);  where_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_12: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_10, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_11: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_12);  index_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_2: "f32[100, 100]" = torch.ops.aten.index_put.default(where_10, [unsqueeze_24, cat_4], where_11);  where_10 = where_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_3 = torch.ops.aten.sort.stable(index_put_2, stable = True)
        getitem_26: "i64[100, 100]" = sort_3[1];  sort_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_47: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_26, 1, 0, 16);  getitem_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_13: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_2, [unsqueeze_24, slice_47]);  index_put_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_3: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_13, inf);  index_13 = None
        where_12: "i64[100, 16]" = torch.ops.aten.where.self(lt_3, slice_47, full_default_1);  lt_3 = slice_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_6: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_12], -1);  where_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_7: "f32[100, 100]" = torch.ops.aten.log.default(getitem_8)
        neg_5: "f32[100, 100]" = torch.ops.aten.neg.default(log_7);  log_7 = None
        log_8: "f32[100, 100]" = torch.ops.aten.log.default(neg_5);  neg_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_13: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_25, log_8);  log_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_6: "f32[100, 100]" = torch.ops.aten.neg.default(sub_13);  sub_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_13: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_6, full_default);  neg_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_14: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_13, full_default);  where_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_15: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_14, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_15: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_15);  index_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_3: "f32[100, 100]" = torch.ops.aten.index_put.default(where_14, [unsqueeze_24, cat_4], where_15);  where_14 = where_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_4 = torch.ops.aten.sort.stable(index_put_3, stable = True)
        getitem_28: "i64[100, 100]" = sort_4[1];  sort_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_56: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_28, 1, 0, 16);  getitem_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_16: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_3, [unsqueeze_24, slice_56]);  index_put_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_4: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_16, inf);  index_16 = None
        where_16: "i64[100, 16]" = torch.ops.aten.where.self(lt_4, slice_56, full_default_1);  lt_4 = slice_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_7: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_16], -1);  where_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_10: "f32[100, 100]" = torch.ops.aten.log.default(getitem_11)
        neg_7: "f32[100, 100]" = torch.ops.aten.neg.default(log_10);  log_10 = None
        log_11: "f32[100, 100]" = torch.ops.aten.log.default(neg_7);  neg_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_14: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_25, log_11);  log_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_8: "f32[100, 100]" = torch.ops.aten.neg.default(sub_14);  sub_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_17: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_8, full_default);  neg_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_18: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_17, full_default);  where_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_18: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_18, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_19: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_18);  index_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_4: "f32[100, 100]" = torch.ops.aten.index_put.default(where_18, [unsqueeze_24, cat_4], where_19);  where_18 = where_19 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_5 = torch.ops.aten.sort.stable(index_put_4, stable = True)
        getitem_30: "i64[100, 100]" = sort_5[1];  sort_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_65: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_30, 1, 0, 16);  getitem_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_19: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_4, [unsqueeze_24, slice_65]);  index_put_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_5: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_19, inf);  index_19 = None
        where_20: "i64[100, 16]" = torch.ops.aten.where.self(lt_5, slice_65, full_default_1);  lt_5 = slice_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_8: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_20], -1);  where_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_13: "f32[100, 100]" = torch.ops.aten.log.default(getitem_14)
        neg_9: "f32[100, 100]" = torch.ops.aten.neg.default(log_13);  log_13 = None
        log_14: "f32[100, 100]" = torch.ops.aten.log.default(neg_9);  neg_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_15: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_25, log_14);  log_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_10: "f32[100, 100]" = torch.ops.aten.neg.default(sub_15);  sub_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_21: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_10, full_default);  neg_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_22: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_21, full_default);  where_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_21: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_22, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_23: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_21);  index_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_5: "f32[100, 100]" = torch.ops.aten.index_put.default(where_22, [unsqueeze_24, cat_4], where_23);  where_22 = where_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_6 = torch.ops.aten.sort.stable(index_put_5, stable = True)
        getitem_32: "i64[100, 100]" = sort_6[1];  sort_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_74: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_32, 1, 0, 16);  getitem_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_22: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_5, [unsqueeze_24, slice_74]);  index_put_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_6: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_22, inf);  index_22 = None
        where_24: "i64[100, 16]" = torch.ops.aten.where.self(lt_6, slice_74, full_default_1);  lt_6 = slice_74 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_9: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_24], -1);  where_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_16: "f32[100, 100]" = torch.ops.aten.log.default(getitem_17)
        neg_11: "f32[100, 100]" = torch.ops.aten.neg.default(log_16);  log_16 = None
        log_17: "f32[100, 100]" = torch.ops.aten.log.default(neg_11);  neg_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_16: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_25, log_17);  mul_25 = log_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_12: "f32[100, 100]" = torch.ops.aten.neg.default(sub_16);  sub_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_25: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_12, full_default);  neg_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_26: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_25, full_default);  where_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_24: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_26, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_27: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_24);  ne_1 = index_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_6: "f32[100, 100]" = torch.ops.aten.index_put.default(where_26, [unsqueeze_24, cat_4], where_27);  where_26 = where_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_7 = torch.ops.aten.sort.stable(index_put_6, stable = True)
        getitem_34: "i64[100, 100]" = sort_7[1];  sort_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_83: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_34, 1, 0, 16);  getitem_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_25: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_6, [unsqueeze_24, slice_83]);  index_put_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_7: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_25, inf);  index_25 = None
        where_28: "i64[100, 16]" = torch.ops.aten.where.self(lt_7, slice_83, full_default_1);  lt_7 = slice_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_10: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_28], -1);  where_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:345 in forward_core, code: cond_nbr_stack = torch.stack(
        cat_11: "i64[600, 48]" = torch.ops.aten.cat.default([cat_5, cat_6, cat_7, cat_8, cat_9, cat_10]);  cat_5 = cat_6 = cat_7 = cat_8 = cat_9 = cat_10 = None
        view_10: "i64[6, 100, 48]" = torch.ops.aten.view.default(cat_11, [6, 100, 48]);  cat_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:148 in forward, code: pair_mask = mask[None, :, None] & mask[neighbours] & (neighbours != -1)
        unsqueeze_84: "b8[1, 100, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_21, 2);  unsqueeze_21 = None
        index_26: "b8[6, 100, 48]" = torch.ops.aten.index.Tensor(arg16_1, [view_10])
        bitwise_and_17: "b8[6, 100, 48]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_84, index_26);  unsqueeze_84 = index_26 = None
        ne_7: "b8[6, 100, 48]" = torch.ops.aten.ne.Scalar(view_10, -1)
        bitwise_and_18: "b8[6, 100, 48]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_17, ne_7);  bitwise_and_17 = ne_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:157 in forward, code: off = (torch.arange(b, device=neighbours.device) * n)[:, None, None]
        iota_11: "i64[6]" = torch.ops.prims.iota.default(6, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        mul_31: "i64[6]" = torch.ops.aten.mul.Tensor(iota_11, 100)
        unsqueeze_85: "i64[6, 1]" = torch.ops.aten.unsqueeze.default(mul_31, 1);  mul_31 = None
        unsqueeze_86: "i64[6, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_85, 2);  unsqueeze_85 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:158 in forward, code: nb = torch.where(neighbours >= 0, neighbours + off,
        ge: "b8[6, 100, 48]" = torch.ops.aten.ge.Scalar(view_10, 0)
        add_22: "i64[6, 100, 48]" = torch.ops.aten.add.Tensor(view_10, unsqueeze_86)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:159 in forward, code: off + (n - 1)).reshape(b * n, k)
        add_23: "i64[6, 1, 1]" = torch.ops.aten.add.Tensor(unsqueeze_86, 99)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:158 in forward, code: nb = torch.where(neighbours >= 0, neighbours + off,
        where_29: "i64[6, 100, 48]" = torch.ops.aten.where.self(ge, add_22, add_23);  ge = add_22 = add_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:159 in forward, code: off + (n - 1)).reshape(b * n, k)
        view_11: "i64[600, 48]" = torch.ops.aten.view.default(where_29, [600, 48]);  where_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/miniforge3/envs/triad/lib/python3.11/site-packages/torch/_library/custom_ops.py:669 in __call__, code: return self._opoverload(*args, **kwargs)
        p7_barrier: "i64[600, 48]" = torch.ops.salad.p7_barrier.default(view_11);  view_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:170 in forward, code: pos_t = prev_pos.repeat(b, 1, 1)
        repeat: "f32[600, 20, 3]" = torch.ops.aten.repeat.default(arg17_1, [6, 1, 1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:171 in forward, code: resi_t = resi.repeat(b)
        repeat_1: "i64[600]" = torch.ops.aten.repeat.default(arg13_1, [6])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:172 in forward, code: chain_t = (chain[None] + off[:, :, 0]).reshape(-1)
        select_4: "i64[6, 1]" = torch.ops.aten.select.int(unsqueeze_86, 2, 0);  unsqueeze_86 = None
        add_24: "i64[6, 100]" = torch.ops.aten.add.Tensor(unsqueeze_19, select_4);  unsqueeze_19 = None
        view_12: "i64[600]" = torch.ops.aten.view.default(add_24, [-1]);  add_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:173 in forward, code: batch_t = (batch[None] + off[:, :, 0]).reshape(-1)
        add_25: "i64[6, 100]" = torch.ops.aten.add.Tensor(unsqueeze_17, select_4);  unsqueeze_17 = select_4 = None
        view_13: "i64[600]" = torch.ops.aten.view.default(add_25, [-1]);  add_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        unsqueeze_89: "i64[600, 1]" = torch.ops.aten.unsqueeze.default(view_12, 1)
        index_27: "i64[600, 48]" = torch.ops.aten.index.Tensor(view_12, [p7_barrier]);  view_12 = None
        eq_9: "b8[600, 48]" = torch.ops.aten.eq.Tensor(unsqueeze_89, index_27);  unsqueeze_89 = index_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        unsqueeze_90: "i64[600, 1]" = torch.ops.aten.unsqueeze.default(view_13, 1)
        index_28: "i64[600, 48]" = torch.ops.aten.index.Tensor(view_13, [p7_barrier]);  view_13 = None
        eq_10: "b8[600, 48]" = torch.ops.aten.eq.Tensor(unsqueeze_90, index_28);  unsqueeze_90 = index_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        unsqueeze_91: "i64[600, 1]" = torch.ops.aten.unsqueeze.default(repeat_1, 1)
        index_29: "i64[600, 48]" = torch.ops.aten.index.Tensor(repeat_1, [p7_barrier]);  repeat_1 = None
        sub_17: "i64[600, 48]" = torch.ops.aten.sub.Tensor(unsqueeze_91, index_29);  unsqueeze_91 = index_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_4: "i64[600, 48]" = torch.ops.aten.clamp_min.default(sub_17, -32);  sub_17 = None
        clamp_max: "i64[600, 48]" = torch.ops.aten.clamp_max.default(clamp_min_4, 32);  clamp_min_4 = None
        add_26: "i64[600, 48]" = torch.ops.aten.add.Tensor(clamp_max, 32);  clamp_max = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:151 in inner, code: other = torch.full_like(binned, 2 * count + 1)
        full_default_29: "i64[600, 48]" = torch.ops.aten.full.default([600, 48], 65, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_30: "i64[600, 48]" = torch.ops.aten.where.self(eq_9, add_26, full_default_29);  eq_9 = add_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_31: "i64[600, 48]" = torch.ops.aten.where.self(eq_10, where_30, full_default_29);  eq_10 = where_30 = full_default_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:190 in forward, code: relpos = relpos.long().reshape(b, n * k)
        view_14: "i64[6, 4800]" = torch.ops.aten.view.default(where_31, [6, 4800]);  where_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_92: "f32[600, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(repeat, 1)
        slice_95: "f32[600, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_92, 2, 0, 5)
        unsqueeze_93: "f32[600, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_95, 3);  slice_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_30: "f32[600, 48, 20, 3]" = torch.ops.aten.index.Tensor(repeat, [p7_barrier])
        unsqueeze_94: "f32[600, 48, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_30, 2)
        slice_99: "f32[600, 48, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_94, 3, 0, 5);  unsqueeze_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_18: "f32[600, 48, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_93, slice_99);  unsqueeze_93 = slice_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_32: "f32[600, 48, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_18, sub_18);  sub_18 = None
        sum_7: "f32[600, 48, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_32, [-1]);  mul_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_5: "f32[600, 48, 5, 5]" = torch.ops.aten.clamp_min.default(sum_7, 1e-12);  sum_7 = None
        sqrt_4: "f32[600, 48, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_5);  clamp_min_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_15: "f32[600, 48, 25]" = torch.ops.aten.view.default(sqrt_4, [600, 48, 25]);  sqrt_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:57 in _arange_centers, code: + torch.arange(bins, device=device, dtype=dtype) * step
        iota_12: "i64[16]" = torch.ops.prims.iota.default(16, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        mul_33: "i64[16]" = torch.ops.aten.mul.Tensor(iota_12, 1);  iota_12 = None
        add_27: "i64[16]" = torch.ops.aten.add.Tensor(mul_33, 0);  mul_33 = None
        convert_element_type_3: "f32[16]" = torch.ops.prims.convert_element_type.default(add_27, torch.float32);  add_27 = None
        mul_34: "f32[16]" = torch.ops.aten.mul.Tensor(convert_element_type_3, 1.375);  convert_element_type_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:56 in _arange_centers, code: centers = (min_distance
        add_28: "f32[16]" = torch.ops.aten.add.Tensor(mul_34, 0.0);  mul_34 = None
        add_29: "f32[16]" = torch.ops.aten.add.Tensor(add_28, 0.6875);  add_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_95: "f32[600, 48, 25, 1]" = torch.ops.aten.unsqueeze.default(view_15, 3);  view_15 = None
        sub_19: "f32[600, 48, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_95, add_29);  unsqueeze_95 = None
        pow_4: "f32[600, 48, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_19, 2);  sub_19 = None
        neg_13: "f32[600, 48, 25, 16]" = torch.ops.aten.neg.default(pow_4);  pow_4 = None
        div_5: "f32[600, 48, 25, 16]" = torch.ops.aten.div.Tensor(neg_13, 1.890625);  neg_13 = None
        exp_1: "f32[600, 48, 25, 16]" = torch.ops.aten.exp.default(div_5);  div_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_16: "f32[600, 48, 400]" = torch.ops.aten.view.default(exp_1, [600, 48, 400]);  exp_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_6: "f32[600, 3]" = torch.ops.aten.select.int(repeat, 1, 0)
        select_7: "f32[600, 3]" = torch.ops.aten.select.int(repeat, 1, 1)
        select_8: "f32[600, 3]" = torch.ops.aten.select.int(repeat, 1, 2);  repeat = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_20: "f32[600, 3]" = torch.ops.aten.sub.Tensor(select_8, select_7);  select_8 = None
        sub_21: "f32[600, 3]" = torch.ops.aten.sub.Tensor(select_6, select_7);  select_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_35: "f32[600, 3]" = torch.ops.aten.mul.Tensor(sub_20, sub_20)
        sum_8: "f32[600]" = torch.ops.aten.sum.dim_IntList(mul_35, [-1]);  mul_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_6: "f32[600]" = torch.ops.aten.clamp_min.default(sum_8, 1e-12);  sum_8 = None
        sqrt_5: "f32[600]" = torch.ops.aten.sqrt.default(clamp_min_6);  clamp_min_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_96: "f32[600, 1]" = torch.ops.aten.unsqueeze.default(sqrt_5, -1);  sqrt_5 = None
        div_6: "f32[600, 3]" = torch.ops.aten.div.Tensor(sub_20, unsqueeze_96);  sub_20 = unsqueeze_96 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_36: "f32[600, 3]" = torch.ops.aten.mul.Tensor(sub_21, div_6)
        sum_9: "f32[600]" = torch.ops.aten.sum.dim_IntList(mul_36, [-1]);  mul_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_97: "f32[600, 1]" = torch.ops.aten.unsqueeze.default(sum_9, -1);  sum_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_37: "f32[600, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_97, div_6);  unsqueeze_97 = None
        sub_22: "f32[600, 3]" = torch.ops.aten.sub.Tensor(sub_21, mul_37);  sub_21 = mul_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_38: "f32[600, 3]" = torch.ops.aten.mul.Tensor(sub_22, sub_22)
        sum_10: "f32[600]" = torch.ops.aten.sum.dim_IntList(mul_38, [-1]);  mul_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_7: "f32[600]" = torch.ops.aten.clamp_min.default(sum_10, 1e-12);  sum_10 = None
        sqrt_6: "f32[600]" = torch.ops.aten.sqrt.default(clamp_min_7);  clamp_min_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_98: "f32[600, 1]" = torch.ops.aten.unsqueeze.default(sqrt_6, -1);  sqrt_6 = None
        div_7: "f32[600, 3]" = torch.ops.aten.div.Tensor(sub_22, unsqueeze_98);  sub_22 = unsqueeze_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_31: "f32[600, 3]" = torch.ops.aten.index.Tensor(div_6, [None, remainder])
        index_32: "f32[600, 3]" = torch.ops.aten.index.Tensor(div_7, [None, remainder_1])
        mul_39: "f32[600, 3]" = torch.ops.aten.mul.Tensor(index_31, index_32);  index_31 = index_32 = None
        index_33: "f32[600, 3]" = torch.ops.aten.index.Tensor(div_6, [None, remainder_1])
        index_34: "f32[600, 3]" = torch.ops.aten.index.Tensor(div_7, [None, remainder])
        mul_40: "f32[600, 3]" = torch.ops.aten.mul.Tensor(index_33, index_34);  index_33 = index_34 = None
        sub_23: "f32[600, 3]" = torch.ops.aten.sub.Tensor(mul_39, mul_40);  mul_39 = mul_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_99: "f32[600, 3, 1]" = torch.ops.aten.unsqueeze.default(div_6, 2);  div_6 = None
        unsqueeze_100: "f32[600, 3, 1]" = torch.ops.aten.unsqueeze.default(div_7, 2);  div_7 = None
        unsqueeze_101: "f32[600, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_23, 2);  sub_23 = None
        cat_12: "f32[600, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_99, unsqueeze_100, unsqueeze_101], -1);  unsqueeze_99 = unsqueeze_100 = unsqueeze_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_105: "f32[600, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_12, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_106: "f32[600, 1, 3]" = torch.ops.aten.unsqueeze.default(select_7, -2);  select_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_107: "f32[600, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_105, -3);  unsqueeze_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_108: "f32[600, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_106, -2);  unsqueeze_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_25: "f32[600, 48, 20, 3]" = torch.ops.aten.sub.Tensor(index_30, unsqueeze_108)
        unsqueeze_109: "f32[600, 48, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_25, -1);  sub_25 = None
        mul_42: "f32[600, 48, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_107, unsqueeze_109);  unsqueeze_109 = None
        sum_12: "f32[600, 48, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_42, [-2]);  mul_42 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_43: "f32[600, 48, 20, 3]" = torch.ops.aten.mul.Tensor(sum_12, sum_12)
        sum_13: "f32[600, 48, 20]" = torch.ops.aten.sum.dim_IntList(mul_43, [-1]);  mul_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_8: "f32[600, 48, 20]" = torch.ops.aten.clamp_min.default(sum_13, 1e-12);  sum_13 = None
        sqrt_7: "f32[600, 48, 20]" = torch.ops.aten.sqrt.default(clamp_min_8);  clamp_min_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_110: "f32[600, 48, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_7, -1);  sqrt_7 = None
        div_8: "f32[600, 48, 20, 3]" = torch.ops.aten.div.Tensor(sum_12, unsqueeze_110);  sum_12 = unsqueeze_110 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:184 in direction_features, code: return local.reshape(n, k, a * 3)
        view_17: "f32[600, 48, 60]" = torch.ops.aten.view.default(div_8, [600, 48, 60]);  div_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_120: "f32[600, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_12, 1)
        permute_10: "f32[600, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_120, [0, 1, 3, 2]);  unsqueeze_120 = None
        index_40: "f32[600, 48, 3, 3]" = torch.ops.aten.index.Tensor(cat_12, [p7_barrier]);  cat_12 = p7_barrier = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:77 in rot_compose, code: return (a.unsqueeze(-1) * b.unsqueeze(-3)).sum(-2)
        unsqueeze_121: "f32[600, 1, 3, 3, 1]" = torch.ops.aten.unsqueeze.default(permute_10, -1);  permute_10 = None
        unsqueeze_122: "f32[600, 48, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(index_40, -3);  index_40 = None
        mul_51: "f32[600, 48, 3, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_121, unsqueeze_122);  unsqueeze_121 = unsqueeze_122 = None
        sum_18: "f32[600, 48, 3, 3]" = torch.ops.aten.sum.dim_IntList(mul_51, [-2]);  mul_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_18: "f32[600, 48, 9]" = torch.ops.aten.view.default(sum_18, [600, 48, 9]);  sum_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:209 in pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand: "f32[600, 48, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_92, [600, 48, 20, 3]);  unsqueeze_92 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:211 in pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_15: "f32[600, 48, 40, 3]" = torch.ops.aten.cat.default([expand, index_30], -2);  expand = index_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_36: "f32[600, 48, 40, 3]" = torch.ops.aten.sub.Tensor(cat_15, unsqueeze_108);  cat_15 = unsqueeze_108 = None
        unsqueeze_137: "f32[600, 48, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_36, -1);  sub_36 = None
        mul_59: "f32[600, 48, 40, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_107, unsqueeze_137);  unsqueeze_107 = unsqueeze_137 = None
        sum_23: "f32[600, 48, 40, 3]" = torch.ops.aten.sum.dim_IntList(mul_59, [-2]);  mul_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_60: "f32[600, 48, 40, 3]" = torch.ops.aten.mul.Tensor(sum_23, sum_23)
        sum_24: "f32[600, 48, 40]" = torch.ops.aten.sum.dim_IntList(mul_60, [-1]);  mul_60 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_13: "f32[600, 48, 40]" = torch.ops.aten.clamp_min.default(sum_24, 1e-12);  sum_24 = None
        sqrt_12: "f32[600, 48, 40]" = torch.ops.aten.sqrt.default(clamp_min_13);  clamp_min_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_138: "f32[600, 48, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_12, -1);  sqrt_12 = None
        div_13: "f32[600, 48, 40, 3]" = torch.ops.aten.div.Tensor(sum_23, unsqueeze_138);  unsqueeze_138 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:213 in pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        view_19: "f32[600, 48, 120]" = torch.ops.aten.view.default(div_13, [600, 48, 120]);  div_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:214 in pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_61: "f32[600, 48, 40, 3]" = torch.ops.aten.mul.Tensor(sum_23, 0.1);  sum_23 = None
        view_20: "f32[600, 48, 120]" = torch.ops.aten.view.default(mul_61, [600, 48, 120]);  mul_61 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:215 in pair_vector_features, code: return torch.cat([directions, coords], dim=-1)
        cat_16: "f32[600, 48, 240]" = torch.ops.aten.cat.default([view_19, view_20], -1);  view_19 = view_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:217 in forward, code: ar_b = torch.arange(b, device=prev_pos.device)[:, None]
        unsqueeze_139: "i64[6, 1]" = torch.ops.aten.unsqueeze.default(iota_11, 1);  iota_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:218 in forward, code: pair = self.w_relpos[ar_b, relpos]
        index_46: "f32[6, 4800, 64]" = torch.ops.aten.index.Tensor(arg18_1, [unsqueeze_139, view_14]);  arg18_1 = unsqueeze_139 = view_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:225 in forward, code: pair = pair + torch.bmm(x.reshape(b, n * k, x.shape[-1]),
        view_21: "f32[6, 4800, 400]" = torch.ops.aten.view.default(view_16, [6, 4800, 400]);  view_16 = None
        bmm_2: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(view_21, arg19_1);  view_21 = arg19_1 = None
        add_42: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(index_46, bmm_2);  index_46 = bmm_2 = None
        view_22: "f32[6, 4800, 60]" = torch.ops.aten.view.default(view_17, [6, 4800, 60]);  view_17 = None
        bmm_3: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(view_22, arg20_1);  view_22 = arg20_1 = None
        add_43: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(add_42, bmm_3);  add_42 = bmm_3 = None
        view_23: "f32[6, 4800, 9]" = torch.ops.aten.view.default(view_18, [6, 4800, 9]);  view_18 = None
        bmm_4: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(view_23, arg21_1);  view_23 = arg21_1 = None
        add_44: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(add_43, bmm_4);  add_43 = bmm_4 = None
        view_24: "f32[6, 4800, 240]" = torch.ops.aten.view.default(cat_16, [6, 4800, 240]);  cat_16 = None
        bmm_5: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(view_24, arg22_1);  view_24 = arg22_1 = None
        add_45: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(add_44, bmm_5);  add_44 = bmm_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:228 in forward, code: mu = pair.mean(-1, keepdim=True)
        mean_3: "f32[6, 4800, 1]" = torch.ops.aten.mean.dim(add_45, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:229 in forward, code: var = pair.var(-1, unbiased=False, keepdim=True)
        var_3: "f32[6, 4800, 1]" = torch.ops.aten.var.correction(add_45, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:230 in forward, code: pair = (pair - mu) * torch.rsqrt(var + self.ln_eps)
        sub_37: "f32[6, 4800, 64]" = torch.ops.aten.sub.Tensor(add_45, mean_3);  add_45 = mean_3 = None
        add_46: "f32[6, 4800, 1]" = torch.ops.aten.add.Tensor(var_3, 1e-05);  var_3 = None
        rsqrt_3: "f32[6, 4800, 1]" = torch.ops.aten.rsqrt.default(add_46);  add_46 = None
        mul_62: "f32[6, 4800, 64]" = torch.ops.aten.mul.Tensor(sub_37, rsqrt_3);  sub_37 = rsqrt_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:231 in forward, code: pair = pair * self.ln_scale[:, None] + self.ln_offset[:, None]
        unsqueeze_140: "f32[6, 1, 64]" = torch.ops.aten.unsqueeze.default(arg23_1, 1);  arg23_1 = None
        mul_63: "f32[6, 4800, 64]" = torch.ops.aten.mul.Tensor(mul_62, unsqueeze_140);  mul_62 = unsqueeze_140 = None
        unsqueeze_141: "f32[6, 1, 64]" = torch.ops.aten.unsqueeze.default(arg24_1, 1);  arg24_1 = None
        add_47: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(mul_63, unsqueeze_141);  mul_63 = unsqueeze_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:232 in forward, code: pair = gelu(torch.bmm(pair, self.w_mlp0) + self.b_mlp0[:, None])
        bmm_6: "f32[6, 4800, 128]" = torch.ops.aten.bmm.default(add_47, arg25_1);  add_47 = arg25_1 = None
        unsqueeze_142: "f32[6, 1, 128]" = torch.ops.aten.unsqueeze.default(arg26_1, 1);  arg26_1 = None
        add_48: "f32[6, 4800, 128]" = torch.ops.aten.add.Tensor(bmm_6, unsqueeze_142);  bmm_6 = unsqueeze_142 = None
        mul_64: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(add_48, add_48)
        mul_65: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(mul_64, add_48);  mul_64 = None
        mul_66: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(mul_65, 0.044715);  mul_65 = None
        add_49: "f32[6, 4800, 128]" = torch.ops.aten.add.Tensor(add_48, mul_66);  mul_66 = None
        mul_67: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(add_49, 0.7978845608028654);  add_49 = None
        mul_68: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(add_48, 0.5);  add_48 = None
        tanh_1: "f32[6, 4800, 128]" = torch.ops.aten.tanh.default(mul_67);  mul_67 = None
        add_50: "f32[6, 4800, 128]" = torch.ops.aten.add.Tensor(tanh_1, 1);  tanh_1 = None
        mul_69: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(mul_68, add_50);  mul_68 = add_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:233 in forward, code: pair = torch.bmm(pair, self.w_mlp1) + self.b_mlp1[:, None]
        bmm_7: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(mul_69, arg27_1);  mul_69 = arg27_1 = None
        unsqueeze_143: "f32[6, 1, 64]" = torch.ops.aten.unsqueeze.default(arg28_1, 1);  arg28_1 = None
        add_51: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(bmm_7, unsqueeze_143);  bmm_7 = unsqueeze_143 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:234 in forward, code: return pair.reshape(b, n, k, self.pair_size), pair_mask
        view_25: "f32[6, 100, 48, 64]" = torch.ops.aten.view.default(add_51, [6, 100, 48, 64]);  add_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_144: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_1, 1)
        unsqueeze_145: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_1, 0);  select_1 = None
        sub_38: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_144, unsqueeze_145);  unsqueeze_144 = unsqueeze_145 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_70: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_38, sub_38);  sub_38 = None
        sum_25: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_70, [-1]);  mul_70 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_14: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_25, 1e-12);  sum_25 = None
        sqrt_13: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_14);  clamp_min_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_32: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_13, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_33: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_32, full_default);  where_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_48: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_33, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_34: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_48);  index_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_7: "f32[100, 100]" = torch.ops.aten.index_put.default(where_33, [unsqueeze_24, where_1], where_34);  where_33 = where_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_8 = torch.ops.aten.sort.stable(index_put_7, stable = True)
        getitem_36: "i64[100, 100]" = sort_8[1];  sort_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_141: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_36, 1, 0, 16);  getitem_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_49: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_7, [unsqueeze_24, slice_141]);  index_put_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_8: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_49, inf);  index_49 = None
        where_35: "i64[100, 16]" = torch.ops.aten.where.self(lt_8, slice_141, full_default_1);  lt_8 = slice_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_17: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_35], -1);  where_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_52: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_13, 1e-06);  sqrt_13 = None
        log_18: "f32[100, 100]" = torch.ops.aten.log.default(add_52);  add_52 = None
        mul_71: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_18, -3.0);  log_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_19: "f32[100, 100]" = torch.ops.aten.log.default(getitem_1)
        neg_14: "f32[100, 100]" = torch.ops.aten.neg.default(log_19);  log_19 = None
        log_20: "f32[100, 100]" = torch.ops.aten.log.default(neg_14);  neg_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_39: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_71, log_20);  mul_71 = log_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_15: "f32[100, 100]" = torch.ops.aten.neg.default(sub_39);  sub_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_36: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_15, full_default);  neg_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_37: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_36, full_default);  where_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_9: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_17, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_51: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_37, [unsqueeze_24, cat_17])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_38: "f32[100, 32]" = torch.ops.aten.where.self(ne_9, full_default_7, index_51);  ne_9 = index_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_8: "f32[100, 100]" = torch.ops.aten.index_put.default(where_37, [unsqueeze_24, cat_17], where_38);  where_37 = where_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_9 = torch.ops.aten.sort.stable(index_put_8, stable = True)
        getitem_38: "i64[100, 100]" = sort_9[1];  sort_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_150: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_38, 1, 0, 32);  getitem_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_52: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_8, [unsqueeze_24, slice_150]);  index_put_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_9: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_52, inf);  index_52 = None
        full_default_37: "i64[100, 32]" = torch.ops.aten.full.default([100, 32], -1, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_39: "i64[100, 32]" = torch.ops.aten.where.self(lt_9, slice_150, full_default_37);  lt_9 = slice_150 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_18: "i64[100, 64]" = torch.ops.aten.cat.default([cat_17, where_39], -1);  cat_17 = where_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_16: "i64[100, 48]" = torch.ops.aten.select.int(view_10, 0, 0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_17: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_25, 0, 0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_18: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_53: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_18])
        bitwise_and_23: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_53);  index_53 = None
        ne_10: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_18, -1)
        bitwise_and_24: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_23, ne_10);  bitwise_and_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_54: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_18])
        eq_13: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_54);  index_54 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_55: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_18])
        eq_14: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_55);  index_55 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_56: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_18])
        sub_40: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_56);  index_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_15: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_40, -32);  sub_40 = None
        clamp_max_1: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_15, 32);  clamp_min_15 = None
        add_53: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_1, 32);  clamp_max_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:151 in inner, code: other = torch.full_like(binned, 2 * count + 1)
        full_default_38: "i64[100, 64]" = torch.ops.aten.full.default([100, 64], 65, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_40: "i64[100, 64]" = torch.ops.aten.where.self(eq_13, add_53, full_default_38);  eq_13 = add_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_41: "i64[100, 64]" = torch.ops.aten.where.self(eq_14, where_40, full_default_38);  eq_14 = where_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_57: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg29_1, [where_41]);  arg29_1 = where_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_166: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(arg0_1, 1)
        slice_157: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_166, 2, 0, 5)
        unsqueeze_167: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_157, 3);  slice_157 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_58: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(arg0_1, [cat_18])
        unsqueeze_168: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_58, 2)
        slice_161: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_168, 3, 0, 5);  unsqueeze_168 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_41: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_167, slice_161);  unsqueeze_167 = slice_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_72: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_41, sub_41);  sub_41 = None
        sum_26: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_72, [-1]);  mul_72 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_16: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_26, 1e-12);  sum_26 = None
        sqrt_14: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_16);  clamp_min_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_26: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_14, [100, 64, 25]);  sqrt_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_169: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_26, 3);  view_26 = None
        sub_42: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_169, add_29);  unsqueeze_169 = None
        pow_5: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_42, 2);  sub_42 = None
        neg_16: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_5);  pow_5 = None
        div_14: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_16, 1.890625);  neg_16 = None
        exp_2: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_14);  div_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_27: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_2, [100, 64, 400]);  exp_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_170: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_27, 3);  view_27 = None
        permute_11: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_170, [0, 1, 3, 2]);  unsqueeze_170 = None
        unsqueeze_171: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg30_1, 2);  arg30_1 = None
        unsqueeze_172: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_171, 3);  unsqueeze_171 = None
        permute_12: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_172, [2, 3, 1, 0]);  unsqueeze_172 = None
        permute_13: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_11, [0, 1, 3, 2]);  permute_11 = None
        view_28: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_13, [1, 6400, 400]);  permute_13 = None
        permute_14: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_12, [3, 2, 0, 1]);  permute_12 = None
        view_29: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_14, [1, 400, 64]);  permute_14 = None
        bmm_8: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_28, view_29);  view_28 = view_29 = None
        view_30: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_8, [100, 64, 1, 64]);  bmm_8 = None
        permute_15: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_30, [0, 1, 3, 2]);  view_30 = None
        view_31: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_15, [100, 64, 64]);  permute_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_57: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_57, view_31);  index_57 = view_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_184: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_6, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_185: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_7, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_48: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_58, unsqueeze_185)
        unsqueeze_186: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_48, -1);  sub_48 = None
        mul_82: "f32[100, 64, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_184, unsqueeze_186);  unsqueeze_186 = None
        sum_31: "f32[100, 64, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_82, [-2]);  mul_82 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_83: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(sum_31, sum_31)
        sum_32: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_83, [-1]);  mul_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_19: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_32, 1e-12);  sum_32 = None
        sqrt_17: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_19);  clamp_min_19 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_187: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_17, -1);  sqrt_17 = None
        div_17: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(sum_31, unsqueeze_187);  sum_31 = unsqueeze_187 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        view_32: "f32[100, 64, 60]" = torch.ops.aten.view.default(div_17, [100, 64, 60]);  div_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_1: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_166, [100, 64, 20, 3]);  unsqueeze_166 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_20: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_1, index_58], -2);  expand_1 = index_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_49: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_20, unsqueeze_185);  cat_20 = unsqueeze_185 = None
        unsqueeze_193: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_49, -1);  sub_49 = None
        mul_84: "f32[100, 64, 40, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_184, unsqueeze_193);  unsqueeze_184 = unsqueeze_193 = None
        sum_33: "f32[100, 64, 40, 3]" = torch.ops.aten.sum.dim_IntList(mul_84, [-2]);  mul_84 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_85: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_33, sum_33)
        sum_34: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_85, [-1]);  mul_85 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_20: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_34, 1e-12);  sum_34 = None
        sqrt_18: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_20);  clamp_min_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_194: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_18, -1);  sqrt_18 = None
        div_18: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(sum_33, unsqueeze_194);  unsqueeze_194 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        view_33: "f32[100, 64, 120]" = torch.ops.aten.view.default(div_18, [100, 64, 120]);  div_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_86: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_33, 0.1);  sum_33 = None
        view_34: "f32[100, 64, 120]" = torch.ops.aten.view.default(mul_86, [100, 64, 120]);  mul_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_21: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_33, view_34], -1);  view_33 = view_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_195: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_32, 3);  view_32 = None
        permute_16: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_195, [0, 1, 3, 2]);  unsqueeze_195 = None
        unsqueeze_196: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg31_1, 2);  arg31_1 = None
        unsqueeze_197: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_196, 3);  unsqueeze_196 = None
        permute_17: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_197, [2, 3, 1, 0]);  unsqueeze_197 = None
        permute_18: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_16, [0, 1, 3, 2]);  permute_16 = None
        view_35: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_18, [1, 6400, 60]);  permute_18 = None
        permute_19: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_17, [3, 2, 0, 1]);  permute_17 = None
        view_36: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_19, [1, 60, 64]);  permute_19 = None
        bmm_9: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_35, view_36);  view_35 = view_36 = None
        view_37: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_9, [100, 64, 1, 64]);  bmm_9 = None
        permute_20: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_37, [0, 1, 3, 2]);  view_37 = None
        view_38: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_20, [100, 64, 64]);  permute_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_62: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_57, view_38);  add_57 = view_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_207: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat, 1)
        permute_21: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_207, [0, 1, 3, 2]);  unsqueeze_207 = None
        index_68: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat, [cat_18]);  cat = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:77 in rot_compose, code: return (a.unsqueeze(-1) * b.unsqueeze(-3)).sum(-2)
        unsqueeze_208: "f32[100, 1, 3, 3, 1]" = torch.ops.aten.unsqueeze.default(permute_21, -1);  permute_21 = None
        unsqueeze_209: "f32[100, 64, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(index_68, -3);  index_68 = None
        mul_94: "f32[100, 64, 3, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_208, unsqueeze_209);  unsqueeze_208 = unsqueeze_209 = None
        sum_39: "f32[100, 64, 3, 3]" = torch.ops.aten.sum.dim_IntList(mul_94, [-2]);  mul_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_39: "f32[100, 64, 9]" = torch.ops.aten.view.default(sum_39, [100, 64, 9]);  sum_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_210: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_39, 3);  view_39 = None
        permute_22: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_210, [0, 1, 3, 2]);  unsqueeze_210 = None
        unsqueeze_211: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg32_1, 2);  arg32_1 = None
        unsqueeze_212: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_211, 3);  unsqueeze_211 = None
        permute_23: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_212, [2, 3, 1, 0]);  unsqueeze_212 = None
        permute_24: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_22, [0, 1, 3, 2]);  permute_22 = None
        view_40: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_24, [1, 6400, 9]);  permute_24 = None
        permute_25: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_23, [3, 2, 0, 1]);  permute_23 = None
        view_41: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_25, [1, 9, 64]);  permute_25 = None
        bmm_10: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_40, view_41);  view_40 = view_41 = None
        view_42: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_10, [100, 64, 1, 64]);  bmm_10 = None
        permute_26: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_42, [0, 1, 3, 2]);  view_42 = None
        view_43: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_26, [100, 64, 64]);  permute_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_67: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_62, view_43);  add_62 = view_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_213: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_21, 3);  cat_21 = None
        permute_27: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_213, [0, 1, 3, 2]);  unsqueeze_213 = None
        unsqueeze_214: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg33_1, 2);  arg33_1 = None
        unsqueeze_215: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_214, 3);  unsqueeze_214 = None
        permute_28: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_215, [2, 3, 1, 0]);  unsqueeze_215 = None
        permute_29: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_27, [0, 1, 3, 2]);  permute_27 = None
        view_44: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_29, [1, 6400, 240]);  permute_29 = None
        permute_30: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_28, [3, 2, 0, 1]);  permute_28 = None
        view_45: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_30, [1, 240, 64]);  permute_30 = None
        bmm_11: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_44, view_45);  view_44 = view_45 = None
        view_46: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_11, [100, 64, 1, 64]);  bmm_11 = None
        permute_31: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_46, [0, 1, 3, 2]);  view_46 = None
        view_47: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_31, [100, 64, 64]);  permute_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_68: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_67, view_47);  add_67 = view_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_4: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_68, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_4: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_68, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_55: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_68, mean_4);  add_68 = mean_4 = None
        add_69: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_4, 1e-05);  var_4 = None
        rsqrt_4: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_69);  add_69 = None
        mul_95: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_55, rsqrt_4);  sub_55 = rsqrt_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_96: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_95, arg34_1);  mul_95 = arg34_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_70: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_96, arg35_1);  mul_96 = arg35_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_216: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_70, 3);  add_70 = None
        permute_32: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_216, [0, 1, 3, 2]);  unsqueeze_216 = None
        unsqueeze_217: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg36_1, 2);  arg36_1 = None
        unsqueeze_218: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_217, 3);  unsqueeze_217 = None
        permute_33: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_218, [2, 3, 1, 0]);  unsqueeze_218 = None
        permute_34: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_32, [0, 1, 3, 2]);  permute_32 = None
        view_48: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_34, [1, 6400, 64]);  permute_34 = None
        permute_35: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_33, [3, 2, 0, 1]);  permute_33 = None
        view_49: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_35, [1, 64, 128]);  permute_35 = None
        bmm_12: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_48, view_49);  view_48 = view_49 = None
        view_50: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_12, [100, 64, 1, 128]);  bmm_12 = None
        permute_36: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_50, [0, 1, 3, 2]);  view_50 = None
        view_51: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_36, [100, 64, 128]);  permute_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_71: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_51, arg37_1);  view_51 = arg37_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_97: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_71, add_71)
        mul_98: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_97, add_71);  mul_97 = None
        mul_99: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_98, 0.044715);  mul_98 = None
        add_72: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_71, mul_99);  mul_99 = None
        mul_100: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_72, 0.7978845608028654);  add_72 = None
        mul_101: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_71, 0.5);  add_71 = None
        tanh_2: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_100);  mul_100 = None
        add_73: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_2, 1);  tanh_2 = None
        mul_102: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_101, add_73);  mul_101 = add_73 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_219: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_102, 3);  mul_102 = None
        permute_37: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_219, [0, 1, 3, 2]);  unsqueeze_219 = None
        unsqueeze_220: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg38_1, 2);  arg38_1 = None
        unsqueeze_221: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_220, 3);  unsqueeze_220 = None
        permute_38: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_221, [2, 3, 1, 0]);  unsqueeze_221 = None
        permute_39: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_37, [0, 1, 3, 2]);  permute_37 = None
        view_52: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_39, [1, 6400, 128]);  permute_39 = None
        permute_40: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_38, [3, 2, 0, 1]);  permute_38 = None
        view_53: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_40, [1, 128, 64]);  permute_40 = None
        bmm_13: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_52, view_53);  view_52 = view_53 = None
        view_54: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_13, [100, 64, 1, 64]);  bmm_13 = None
        permute_41: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_54, [0, 1, 3, 2]);  view_54 = None
        view_55: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_41, [100, 64, 64]);  permute_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_74: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_55, arg39_1);  view_55 = arg39_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_5: "f32[100, 1]" = torch.ops.aten.mean.dim(add_13, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_5: "f32[100, 1]" = torch.ops.aten.var.correction(add_13, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_56: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_13, mean_5);  mean_5 = None
        add_75: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_5, 1e-05);  var_5 = None
        rsqrt_5: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_75);  add_75 = None
        mul_103: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_56, rsqrt_5);  sub_56 = rsqrt_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_104: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_103, arg40_1);  mul_103 = arg40_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_76: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_104, arg41_1);  mul_104 = arg41_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_21: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(arg0_1, 10.0);  arg0_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_25: "f32[100, 3]" = torch.ops.aten.select.int(div_21, 1, 0)
        select_26: "f32[100, 3]" = torch.ops.aten.select.int(div_21, 1, 1)
        select_27: "f32[100, 3]" = torch.ops.aten.select.int(div_21, 1, 2);  div_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_57: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_27, select_26);  select_27 = None
        sub_58: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_25, select_26);  select_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_105: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_57, sub_57)
        sum_40: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_105, [-1]);  mul_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_23: "f32[100]" = torch.ops.aten.clamp_min.default(sum_40, 1e-12);  sum_40 = None
        sqrt_21: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_23);  clamp_min_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_222: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_21, -1);  sqrt_21 = None
        div_22: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_57, unsqueeze_222);  sub_57 = unsqueeze_222 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_106: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_58, div_22)
        sum_41: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_106, [-1]);  mul_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_223: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_41, -1);  sum_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_107: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_223, div_22);  unsqueeze_223 = None
        sub_59: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_58, mul_107);  sub_58 = mul_107 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_108: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_59, sub_59)
        sum_42: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_108, [-1]);  mul_108 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_24: "f32[100]" = torch.ops.aten.clamp_min.default(sum_42, 1e-12);  sum_42 = None
        sqrt_22: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_24);  clamp_min_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_224: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_22, -1);  sqrt_22 = None
        div_23: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_59, unsqueeze_224);  sub_59 = unsqueeze_224 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_69: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_22, [None, remainder])
        index_70: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_23, [None, remainder_1])
        mul_109: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_69, index_70);  index_69 = index_70 = None
        index_71: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_22, [None, remainder_1])
        index_72: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_23, [None, remainder])
        mul_110: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_71, index_72);  index_71 = index_72 = None
        sub_60: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_109, mul_110);  mul_109 = mul_110 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_225: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_22, 2);  div_22 = None
        unsqueeze_226: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_23, 2);  div_23 = None
        unsqueeze_227: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_60, 2);  sub_60 = None
        cat_23: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_225, unsqueeze_226, unsqueeze_227], -1);  unsqueeze_225 = unsqueeze_226 = unsqueeze_227 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_6: "f32[100, 1]" = torch.ops.aten.mean.dim(add_76, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_6: "f32[100, 1]" = torch.ops.aten.var.correction(add_76, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_62: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_76, mean_6);  add_76 = mean_6 = None
        add_81: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_6, 1e-05);  var_6 = None
        rsqrt_6: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_81);  add_81 = None
        mul_112: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_62, rsqrt_6);  sub_62 = rsqrt_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_113: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_112, arg42_1);  mul_112 = arg42_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_82: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_113, arg43_1);  mul_113 = arg43_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_231: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_82, 2);  add_82 = None
        permute_42: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_231, [0, 2, 1]);  unsqueeze_231 = None
        unsqueeze_232: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg44_1, 2);  arg44_1 = None
        permute_43: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_232, [2, 1, 0]);  unsqueeze_232 = None
        permute_44: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_42, [0, 2, 1]);  permute_42 = None
        view_56: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_44, [1, 100, 128]);  permute_44 = None
        permute_45: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_43, [2, 1, 0]);  permute_43 = None
        view_57: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_45, [1, 128, 768]);  permute_45 = None
        bmm_14: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_56, view_57);  view_57 = None
        view_58: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_14, [100, 1, 768]);  bmm_14 = None
        permute_46: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_58, [0, 2, 1]);  view_58 = None
        view_59: "f32[100, 768]" = torch.ops.aten.view.default(permute_46, [100, 768]);  permute_46 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_60: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_59, [100, 8, 96]);  view_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split = torch.ops.aten.split.Tensor(view_60, 32, -1);  view_60 = None
        getitem_39: "f32[100, 8, 32]" = split[0]
        getitem_40: "f32[100, 8, 32]" = split[1]
        getitem_41: "f32[100, 8, 32]" = split[2];  split = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_7: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_39, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_7: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_39, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_63: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_39, mean_7);  getitem_39 = mean_7 = None
        add_83: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_7, 1e-05);  var_7 = None
        rsqrt_7: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_83);  add_83 = None
        mul_114: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_63, rsqrt_7);  sub_63 = rsqrt_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_115: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_114, arg45_1);  mul_114 = arg45_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_84: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_115, arg46_1);  mul_115 = arg46_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_8: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_40, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_8: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_40, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_64: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_40, mean_8);  getitem_40 = mean_8 = None
        add_85: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_8, 1e-05);  var_8 = None
        rsqrt_8: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_85);  add_85 = None
        mul_116: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_64, rsqrt_8);  sub_64 = rsqrt_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_117: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_116, arg47_1);  mul_116 = arg47_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_86: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_117, arg48_1);  mul_117 = arg48_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_234: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg49_1, 2);  arg49_1 = None
        permute_48: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_234, [2, 1, 0]);  unsqueeze_234 = None
        permute_50: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_48, [2, 1, 0]);  permute_48 = None
        view_62: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_50, [1, 128, 576]);  permute_50 = None
        bmm_15: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_56, view_62);  view_56 = view_62 = None
        view_63: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_15, [100, 1, 576]);  bmm_15 = None
        permute_51: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_63, [0, 2, 1]);  view_63 = None
        view_64: "f32[100, 576]" = torch.ops.aten.view.default(permute_51, [100, 576]);  permute_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_65: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_64, [100, 192, 3]);  view_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_235: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_23, -3);  cat_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_236: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_26, -2);  select_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_237: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_65, -2);  view_65 = None
        mul_118: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_235, unsqueeze_237);  unsqueeze_237 = None
        sum_44: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_118, [-1]);  mul_118 = None
        add_87: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_44, unsqueeze_236);  sum_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_66: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_87, [100, 8, 24, 3]);  add_87 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_188: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_66, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_191: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_66, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_194: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_66, 2, 16, 9223372036854775807);  view_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_238: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_74, 3)
        permute_52: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_238, [0, 1, 3, 2]);  unsqueeze_238 = None
        unsqueeze_239: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg50_1, 2);  arg50_1 = None
        unsqueeze_240: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_239, 3);  unsqueeze_239 = None
        permute_53: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_240, [2, 3, 1, 0]);  unsqueeze_240 = None
        permute_54: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_52, [0, 1, 3, 2]);  permute_52 = None
        view_67: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_54, [1, 6400, 64]);  permute_54 = None
        permute_55: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_53, [3, 2, 0, 1]);  permute_53 = None
        view_68: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_55, [1, 64, 8]);  permute_55 = None
        bmm_16: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_67, view_68);  view_67 = view_68 = None
        view_69: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_16, [100, 64, 1, 8]);  bmm_16 = None
        permute_56: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_69, [0, 1, 3, 2]);  view_69 = None
        view_70: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_56, [100, 64, 8]);  permute_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_3: "f32[8]" = torch.ops.aten.exp.default(arg51_1)
        log1p: "f32[8]" = torch.ops.aten.log1p.default(exp_3);  exp_3 = None
        gt: "b8[8]" = torch.ops.aten.gt.Scalar(arg51_1, 20)
        where_42: "f32[8]" = torch.ops.aten.where.self(gt, arg51_1, log1p);  gt = arg51_1 = log1p = None
        view_71: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_42, [1, 1, 8]);  where_42 = None
        mul_119: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_71, 0.16666666666666666);  view_71 = None
        div_24: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_119, 2);  mul_119 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_241: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_188, 1);  slice_188 = None
        index_73: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_191, [cat_18]);  slice_191 = None
        sub_65: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_241, index_73);  unsqueeze_241 = index_73 = None
        pow_6: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_65, 2);  sub_65 = None
        sum_45: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_6, [-1, -2]);  pow_6 = None
        mul_120: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_24, sum_45);  div_24 = sum_45 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_242: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_84, 1);  add_84 = None
        index_74: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_86, [cat_18]);  add_86 = None
        mul_121: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_242, index_74);  unsqueeze_242 = index_74 = None
        sum_46: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(mul_121, [-1]);  mul_121 = None
        mul_122: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sum_46, 0.1767766952966369);  sum_46 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_88: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_122, view_70);  mul_122 = view_70 = None
        sub_66: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_88, mul_120);  add_88 = mul_120 = None
        mul_123: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_66, 0.5773502691896257);  sub_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_25: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_24, ne_10);  bitwise_and_24 = ne_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_243: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_25, 2);  bitwise_and_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:120 in forward, code: torch.full_like(logits, -1e9))
        full_default_39: "f32[100, 64, 8]" = torch.ops.aten.full.default([100, 64, 8], -1000000000.0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        where_43: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_243, mul_123, full_default_39);  mul_123 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_43, [-2], True)
        sub_67: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(where_43, amax);  where_43 = amax = None
        exp_4: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_67);  sub_67 = None
        sum_47: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_4, [-2], True)
        div_25: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_4, sum_47);  exp_4 = sum_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        full_default_40: "f32[100, 64, 8]" = torch.ops.aten.full.default([100, 64, 8], 0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_44: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_243, div_25, full_default_40);  unsqueeze_243 = div_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_245: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_44, 3);  where_44 = None
        unsqueeze_246: "f32[100, 64, 1, 64]" = torch.ops.aten.unsqueeze.default(add_74, 2);  add_74 = None
        mul_124: "f32[100, 64, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_245, unsqueeze_246);  unsqueeze_246 = None
        sum_48: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_124, [1]);  mul_124 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_75: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_41, [cat_18]);  getitem_41 = None
        mul_125: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_245, index_75);  index_75 = None
        sum_49: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_125, [1]);  mul_125 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_249: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_245, 4);  unsqueeze_245 = None
        index_76: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_194, [cat_18]);  slice_194 = cat_18 = None
        mul_126: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_249, index_76);  unsqueeze_249 = index_76 = None
        sum_50: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_126, [1]);  mul_126 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_252: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_235, -3);  unsqueeze_235 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_253: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_236, -2);  unsqueeze_236 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_68: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_50, unsqueeze_253);  sum_50 = unsqueeze_253 = None
        unsqueeze_254: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_68, -1);  sub_68 = None
        mul_127: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_252, unsqueeze_254);  unsqueeze_252 = unsqueeze_254 = None
        sum_51: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_127, [-2]);  mul_127 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_128: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_51, sum_51)
        sum_52: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_128, [-1]);  mul_128 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_25: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_52, 1e-12);  sum_52 = None
        sqrt_23: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_25);  clamp_min_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_72: "f32[100, 512]" = torch.ops.aten.view.default(sum_48, [100, -1]);  sum_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_73: "f32[100, 256]" = torch.ops.aten.view.default(sum_49, [100, -1]);  sum_49 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_74: "f32[100, 192]" = torch.ops.aten.view.default(sum_51, [100, -1]);  sum_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_75: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_23, [100, -1]);  sqrt_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_24: "f32[100, 1024]" = torch.ops.aten.cat.default([view_72, view_73, view_74, view_75], -1);  view_72 = view_73 = view_74 = view_75 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_255: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_24, 2);  cat_24 = None
        permute_57: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_255, [0, 2, 1]);  unsqueeze_255 = None
        unsqueeze_256: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg52_1, 2);  arg52_1 = None
        permute_58: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_256, [2, 1, 0]);  unsqueeze_256 = None
        permute_59: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_57, [0, 2, 1]);  permute_57 = None
        view_76: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_59, [1, 100, 1024]);  permute_59 = None
        permute_60: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_58, [2, 1, 0]);  permute_58 = None
        view_77: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_60, [1, 1024, 128]);  permute_60 = None
        bmm_17: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_76, view_77);  view_76 = view_77 = None
        view_78: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_17, [100, 1, 128]);  bmm_17 = None
        permute_61: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_78, [0, 2, 1]);  view_78 = None
        view_79: "f32[100, 128]" = torch.ops.aten.view.default(permute_61, [100, 128]);  permute_61 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_89: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_79, arg53_1);  view_79 = arg53_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_90: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_13, add_89);  add_13 = add_89 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_9: "f32[100, 1]" = torch.ops.aten.mean.dim(add_90, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_9: "f32[100, 1]" = torch.ops.aten.var.correction(add_90, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_69: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_90, mean_9);  mean_9 = None
        add_91: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_9, 1e-05);  var_9 = None
        rsqrt_9: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_91);  add_91 = None
        mul_129: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_69, rsqrt_9);  sub_69 = rsqrt_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_130: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_129, arg54_1);  mul_129 = arg54_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_92: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_130, arg55_1);  mul_130 = arg55_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:372 in forward, code: self.layer_norm_3(features), prev_pos / sigma, pair, pair_mask, cond_neighbours)
        div_26: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(arg17_1, 10.0);  arg17_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_28: "f32[100, 3]" = torch.ops.aten.select.int(div_26, 1, 0)
        select_29: "f32[100, 3]" = torch.ops.aten.select.int(div_26, 1, 1)
        select_30: "f32[100, 3]" = torch.ops.aten.select.int(div_26, 1, 2);  div_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_70: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_30, select_29);  select_30 = None
        sub_71: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_28, select_29);  select_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_131: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_70, sub_70)
        sum_53: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_131, [-1]);  mul_131 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_26: "f32[100]" = torch.ops.aten.clamp_min.default(sum_53, 1e-12);  sum_53 = None
        sqrt_24: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_26);  clamp_min_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_257: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_24, -1);  sqrt_24 = None
        div_27: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_70, unsqueeze_257);  sub_70 = unsqueeze_257 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_132: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_71, div_27)
        sum_54: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_132, [-1]);  mul_132 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_258: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_54, -1);  sum_54 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_133: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_258, div_27);  unsqueeze_258 = None
        sub_72: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_71, mul_133);  sub_71 = mul_133 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_134: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_72, sub_72)
        sum_55: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_134, [-1]);  mul_134 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_27: "f32[100]" = torch.ops.aten.clamp_min.default(sum_55, 1e-12);  sum_55 = None
        sqrt_25: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_27);  clamp_min_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_259: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_25, -1);  sqrt_25 = None
        div_28: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_72, unsqueeze_259);  sub_72 = unsqueeze_259 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_77: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_27, [None, remainder])
        index_78: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_28, [None, remainder_1])
        mul_135: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_77, index_78);  index_77 = index_78 = None
        index_79: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_27, [None, remainder_1])
        index_80: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_28, [None, remainder])
        mul_136: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_79, index_80);  index_79 = index_80 = None
        sub_73: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_135, mul_136);  mul_135 = mul_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_260: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_27, 2);  div_27 = None
        unsqueeze_261: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_28, 2);  div_28 = None
        unsqueeze_262: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_73, 2);  sub_73 = None
        cat_25: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_260, unsqueeze_261, unsqueeze_262], -1);  unsqueeze_260 = unsqueeze_261 = unsqueeze_262 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_10: "f32[100, 1]" = torch.ops.aten.mean.dim(add_92, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_10: "f32[100, 1]" = torch.ops.aten.var.correction(add_92, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_75: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_92, mean_10);  add_92 = mean_10 = None
        add_97: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_10, 1e-05);  var_10 = None
        rsqrt_10: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_97);  add_97 = None
        mul_138: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_75, rsqrt_10);  sub_75 = rsqrt_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_139: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_138, arg56_1);  mul_138 = arg56_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_98: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_139, arg57_1);  mul_139 = arg57_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_266: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_98, 2);  add_98 = None
        permute_62: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_266, [0, 2, 1]);  unsqueeze_266 = None
        unsqueeze_267: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg58_1, 2);  arg58_1 = None
        permute_63: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_267, [2, 1, 0]);  unsqueeze_267 = None
        permute_64: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_62, [0, 2, 1]);  permute_62 = None
        view_80: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_64, [1, 100, 128]);  permute_64 = None
        permute_65: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_63, [2, 1, 0]);  permute_63 = None
        view_81: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_65, [1, 128, 768]);  permute_65 = None
        bmm_18: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_80, view_81);  view_81 = None
        view_82: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_18, [100, 1, 768]);  bmm_18 = None
        permute_66: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_82, [0, 2, 1]);  view_82 = None
        view_83: "f32[100, 768]" = torch.ops.aten.view.default(permute_66, [100, 768]);  permute_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_84: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_83, [100, 8, 96]);  view_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_1 = torch.ops.aten.split.Tensor(view_84, 32, -1);  view_84 = None
        getitem_42: "f32[100, 8, 32]" = split_1[0]
        getitem_43: "f32[100, 8, 32]" = split_1[1]
        getitem_44: "f32[100, 8, 32]" = split_1[2];  split_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_11: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_42, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_11: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_42, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_76: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_42, mean_11);  getitem_42 = mean_11 = None
        add_99: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_11, 1e-05);  var_11 = None
        rsqrt_11: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_99);  add_99 = None
        mul_140: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_76, rsqrt_11);  sub_76 = rsqrt_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_141: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_140, arg59_1);  mul_140 = arg59_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_100: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_141, arg60_1);  mul_141 = arg60_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_12: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_43, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_12: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_43, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_77: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_43, mean_12);  getitem_43 = mean_12 = None
        add_101: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_12, 1e-05);  var_12 = None
        rsqrt_12: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_101);  add_101 = None
        mul_142: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_77, rsqrt_12);  sub_77 = rsqrt_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_143: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_142, arg61_1);  mul_142 = arg61_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_102: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_143, arg62_1);  mul_143 = arg62_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_269: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg63_1, 2);  arg63_1 = None
        permute_68: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_269, [2, 1, 0]);  unsqueeze_269 = None
        permute_70: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_68, [2, 1, 0]);  permute_68 = None
        view_86: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_70, [1, 128, 576]);  permute_70 = None
        bmm_19: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_80, view_86);  view_80 = view_86 = None
        view_87: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_19, [100, 1, 576]);  bmm_19 = None
        permute_71: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_87, [0, 2, 1]);  view_87 = None
        view_88: "f32[100, 576]" = torch.ops.aten.view.default(permute_71, [100, 576]);  permute_71 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_89: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_88, [100, 192, 3]);  view_88 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_270: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_25, -3);  cat_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_271: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_29, -2);  select_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_272: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_89, -2);  view_89 = None
        mul_144: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_270, unsqueeze_272);  unsqueeze_272 = None
        sum_57: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_144, [-1]);  mul_144 = None
        add_103: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_57, unsqueeze_271);  sum_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_90: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_103, [100, 8, 24, 3]);  add_103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_209: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_90, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_212: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_90, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_215: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_90, 2, 16, 9223372036854775807);  view_90 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_273: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_17, 3)
        permute_72: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_273, [0, 1, 3, 2]);  unsqueeze_273 = None
        unsqueeze_274: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg64_1, 2);  arg64_1 = None
        unsqueeze_275: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_274, 3);  unsqueeze_274 = None
        permute_73: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_275, [2, 3, 1, 0]);  unsqueeze_275 = None
        permute_74: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_72, [0, 1, 3, 2]);  permute_72 = None
        view_91: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_74, [1, 4800, 64]);  permute_74 = None
        permute_75: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_73, [3, 2, 0, 1]);  permute_73 = None
        view_92: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_75, [1, 64, 8]);  permute_75 = None
        bmm_20: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_91, view_92);  view_91 = view_92 = None
        view_93: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_20, [100, 48, 1, 8]);  bmm_20 = None
        permute_76: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_93, [0, 1, 3, 2]);  view_93 = None
        view_94: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_76, [100, 48, 8]);  permute_76 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_5: "f32[8]" = torch.ops.aten.exp.default(arg65_1)
        log1p_1: "f32[8]" = torch.ops.aten.log1p.default(exp_5);  exp_5 = None
        gt_1: "b8[8]" = torch.ops.aten.gt.Scalar(arg65_1, 20)
        where_45: "f32[8]" = torch.ops.aten.where.self(gt_1, arg65_1, log1p_1);  gt_1 = arg65_1 = log1p_1 = None
        view_95: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_45, [1, 1, 8]);  where_45 = None
        mul_145: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_95, 0.16666666666666666);  view_95 = None
        div_29: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_145, 2);  mul_145 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_276: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_209, 1);  slice_209 = None
        index_81: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_212, [select_16]);  slice_212 = None
        sub_78: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_276, index_81);  unsqueeze_276 = index_81 = None
        pow_7: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_78, 2);  sub_78 = None
        sum_58: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_7, [-1, -2]);  pow_7 = None
        mul_146: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_29, sum_58);  div_29 = sum_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_277: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_100, 1);  add_100 = None
        index_82: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_102, [select_16]);  add_102 = None
        mul_147: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_277, index_82);  unsqueeze_277 = index_82 = None
        sum_59: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(mul_147, [-1]);  mul_147 = None
        mul_148: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sum_59, 0.1767766952966369);  sum_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_104: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_148, view_94);  mul_148 = view_94 = None
        sub_79: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_104, mul_146);  add_104 = mul_146 = None
        mul_149: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_79, 0.5773502691896257);  sub_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_12: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_16, -1)
        bitwise_and_26: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_18, ne_12);  select_18 = ne_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_278: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_26, 2);  bitwise_and_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:120 in forward, code: torch.full_like(logits, -1e9))
        full_default_41: "f32[100, 48, 8]" = torch.ops.aten.full.default([100, 48, 8], -1000000000.0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        where_46: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_278, mul_149, full_default_41);  mul_149 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_1: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_46, [-2], True)
        sub_80: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(where_46, amax_1);  where_46 = amax_1 = None
        exp_6: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_80);  sub_80 = None
        sum_60: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_6, [-2], True)
        div_30: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_6, sum_60);  exp_6 = sum_60 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        full_default_42: "f32[100, 48, 8]" = torch.ops.aten.full.default([100, 48, 8], 0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_47: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_278, div_30, full_default_42);  unsqueeze_278 = div_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_280: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_47, 3);  where_47 = None
        unsqueeze_281: "f32[100, 48, 1, 64]" = torch.ops.aten.unsqueeze.default(select_17, 2);  select_17 = None
        mul_150: "f32[100, 48, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_280, unsqueeze_281);  unsqueeze_281 = None
        sum_61: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_150, [1]);  mul_150 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_83: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_44, [select_16]);  getitem_44 = None
        mul_151: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_280, index_83);  index_83 = None
        sum_62: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_151, [1]);  mul_151 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_284: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_280, 4);  unsqueeze_280 = None
        index_84: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_215, [select_16]);  slice_215 = select_16 = None
        mul_152: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_284, index_84);  unsqueeze_284 = index_84 = None
        sum_63: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_152, [1]);  mul_152 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_287: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_270, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_288: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_271, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_81: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_63, unsqueeze_288);  sum_63 = None
        unsqueeze_289: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_81, -1);  sub_81 = None
        mul_153: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_287, unsqueeze_289);  unsqueeze_289 = None
        sum_64: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_153, [-2]);  mul_153 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_154: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_64, sum_64)
        sum_65: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_154, [-1]);  mul_154 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_28: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_65, 1e-12);  sum_65 = None
        sqrt_26: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_28);  clamp_min_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_96: "f32[100, 512]" = torch.ops.aten.view.default(sum_61, [100, -1]);  sum_61 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_97: "f32[100, 256]" = torch.ops.aten.view.default(sum_62, [100, -1]);  sum_62 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_98: "f32[100, 192]" = torch.ops.aten.view.default(sum_64, [100, -1]);  sum_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_99: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_26, [100, -1]);  sqrt_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_26: "f32[100, 1024]" = torch.ops.aten.cat.default([view_96, view_97, view_98, view_99], -1);  view_96 = view_97 = view_98 = view_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_290: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_26, 2);  cat_26 = None
        permute_77: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_290, [0, 2, 1]);  unsqueeze_290 = None
        unsqueeze_291: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg66_1, 2);  arg66_1 = None
        permute_78: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_291, [2, 1, 0]);  unsqueeze_291 = None
        permute_79: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_77, [0, 2, 1]);  permute_77 = None
        view_100: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_79, [1, 100, 1024]);  permute_79 = None
        permute_80: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_78, [2, 1, 0]);  permute_78 = None
        view_101: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_80, [1, 1024, 128]);  permute_80 = None
        bmm_21: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_100, view_101);  view_100 = view_101 = None
        view_102: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_21, [100, 1, 128]);  bmm_21 = None
        permute_81: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_102, [0, 2, 1]);  view_102 = None
        view_103: "f32[100, 128]" = torch.ops.aten.view.default(permute_81, [100, 128]);  permute_81 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_105: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_103, arg67_1);  view_103 = arg67_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_106: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_90, add_105);  add_90 = add_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_13: "f32[100, 1]" = torch.ops.aten.mean.dim(add_106, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_13: "f32[100, 1]" = torch.ops.aten.var.correction(add_106, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_82: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_106, mean_13);  mean_13 = None
        add_107: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_13, 1e-05);  var_13 = None
        rsqrt_13: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_107);  add_107 = None
        mul_155: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_82, rsqrt_13);  sub_82 = rsqrt_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_156: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_155, arg68_1);  mul_155 = arg68_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_108: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_156, arg69_1);  mul_156 = arg69_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_301: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_15, 2);  add_15 = None
        permute_82: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_301, [0, 2, 1]);  unsqueeze_301 = None
        unsqueeze_302: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg70_1, 2);  arg70_1 = None
        permute_83: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_302, [2, 1, 0]);  unsqueeze_302 = None
        permute_84: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_82, [0, 2, 1]);  permute_82 = None
        view_105: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_84, [1, 100, 128]);  permute_84 = None
        permute_85: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_83, [2, 1, 0]);  permute_83 = None
        view_106: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_85, [1, 128, 128]);  permute_85 = None
        bmm_22: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_105, view_106);  view_106 = None
        view_107: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_22, [100, 1, 128]);  bmm_22 = None
        permute_86: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_107, [0, 2, 1]);  view_107 = None
        view_108: "f32[100, 128]" = torch.ops.aten.view.default(permute_86, [100, 128]);  permute_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_113: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_108, view_108);  add_108 = view_108 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_303: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view, 2);  view = None
        permute_87: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_303, [0, 2, 1]);  unsqueeze_303 = None
        unsqueeze_304: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg71_1, 2);  arg71_1 = None
        permute_88: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_304, [2, 1, 0]);  unsqueeze_304 = None
        permute_89: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_87, [0, 2, 1]);  permute_87 = None
        view_109: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_89, [1, 100, 60]);  permute_89 = None
        permute_90: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_88, [2, 1, 0]);  permute_88 = None
        view_110: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_90, [1, 60, 256]);  permute_90 = None
        bmm_23: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_109, view_110);  view_109 = view_110 = None
        view_111: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_23, [100, 1, 256]);  bmm_23 = None
        permute_91: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_111, [0, 2, 1]);  view_111 = None
        view_112: "f32[100, 256]" = torch.ops.aten.view.default(permute_91, [100, 256]);  permute_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_114: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_112, arg72_1);  view_112 = arg72_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_164: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_114, add_114)
        mul_165: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_164, add_114);  mul_164 = None
        mul_166: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_165, 0.044715);  mul_165 = None
        add_115: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_114, mul_166);  mul_166 = None
        mul_167: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_115, 0.7978845608028654);  add_115 = None
        mul_168: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_114, 0.5);  add_114 = None
        tanh_3: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_167);  mul_167 = None
        add_116: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_3, 1);  tanh_3 = None
        mul_169: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_168, add_116);  mul_168 = add_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_305: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_169, 2);  mul_169 = None
        permute_92: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_305, [0, 2, 1]);  unsqueeze_305 = None
        unsqueeze_306: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg73_1, 2);  arg73_1 = None
        permute_93: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_306, [2, 1, 0]);  unsqueeze_306 = None
        permute_94: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_92, [0, 2, 1]);  permute_92 = None
        view_113: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_94, [1, 100, 256]);  permute_94 = None
        permute_95: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_93, [2, 1, 0]);  permute_93 = None
        view_114: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_95, [1, 256, 128]);  permute_95 = None
        bmm_24: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_113, view_114);  view_113 = view_114 = None
        view_115: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_24, [100, 1, 128]);  bmm_24 = None
        permute_96: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_115, [0, 2, 1]);  view_115 = None
        view_116: "f32[100, 128]" = torch.ops.aten.view.default(permute_96, [100, 128]);  permute_96 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_117: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_116, arg74_1);  view_116 = arg74_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_118: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_113, add_117);  add_113 = add_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_307: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_118, 2);  add_118 = None
        permute_97: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_307, [0, 2, 1]);  unsqueeze_307 = None
        unsqueeze_308: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg75_1, 2);  arg75_1 = None
        permute_98: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_308, [2, 1, 0]);  unsqueeze_308 = None
        permute_99: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_97, [0, 2, 1]);  permute_97 = None
        view_117: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_99, [1, 100, 128]);  permute_99 = None
        permute_100: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_98, [2, 1, 0]);  permute_98 = None
        view_118: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_100, [1, 128, 512]);  permute_100 = None
        bmm_25: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_117, view_118);  view_118 = None
        view_119: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_25, [100, 1, 512]);  bmm_25 = None
        permute_101: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_119, [0, 2, 1]);  view_119 = None
        view_120: "f32[100, 512]" = torch.ops.aten.view.default(permute_101, [100, 512]);  permute_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_310: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg76_1, 2);  arg76_1 = None
        permute_103: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_310, [2, 1, 0]);  unsqueeze_310 = None
        permute_105: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_103, [2, 1, 0]);  permute_103 = None
        view_122: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_105, [1, 128, 512]);  permute_105 = None
        bmm_26: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_117, view_122);  view_122 = None
        view_123: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_26, [100, 1, 512]);  bmm_26 = None
        permute_106: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_123, [0, 2, 1]);  view_123 = None
        view_124: "f32[100, 512]" = torch.ops.aten.view.default(permute_106, [100, 512]);  permute_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_170: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_124, view_124)
        mul_171: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_170, view_124);  mul_170 = None
        mul_172: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_171, 0.044715);  mul_171 = None
        add_119: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_124, mul_172);  mul_172 = None
        mul_173: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_119, 0.7978845608028654);  add_119 = None
        mul_174: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_124, 0.5);  view_124 = None
        tanh_4: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_173);  mul_173 = None
        add_120: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_4, 1);  tanh_4 = None
        mul_175: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_174, add_120);  mul_174 = add_120 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_176: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_175, view_120);  mul_175 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_312: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg77_1, 2);  arg77_1 = None
        permute_108: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_312, [2, 1, 0]);  unsqueeze_312 = None
        permute_110: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_108, [2, 1, 0]);  permute_108 = None
        view_126: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_110, [1, 128, 512]);  permute_110 = None
        bmm_27: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_117, view_126);  view_126 = None
        view_127: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_27, [100, 1, 512]);  bmm_27 = None
        permute_111: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_127, [0, 2, 1]);  view_127 = None
        view_128: "f32[100, 512]" = torch.ops.aten.view.default(permute_111, [100, 512]);  permute_111 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_177: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_128, view_128)
        mul_178: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_177, view_128);  mul_177 = None
        mul_179: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_178, 0.044715);  mul_178 = None
        add_121: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_128, mul_179);  mul_179 = None
        mul_180: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_121, 0.7978845608028654);  add_121 = None
        mul_181: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_128, 0.5);  view_128 = None
        tanh_5: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_180);  mul_180 = None
        add_122: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_5, 1);  tanh_5 = None
        mul_182: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_181, add_122);  mul_181 = add_122 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_314: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg78_1, 2);  arg78_1 = None
        permute_113: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_314, [2, 1, 0]);  unsqueeze_314 = None
        permute_115: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_113, [2, 1, 0]);  permute_113 = None
        view_130: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_115, [1, 128, 512]);  permute_115 = None
        bmm_28: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_117, view_130);  view_117 = view_130 = None
        view_131: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_28, [100, 1, 512]);  bmm_28 = None
        permute_116: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_131, [0, 2, 1]);  view_131 = None
        view_132: "f32[100, 512]" = torch.ops.aten.view.default(permute_116, [100, 512]);  permute_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_183: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_132, view_132)
        mul_184: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_183, view_132);  mul_183 = None
        mul_185: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_184, 0.044715);  mul_184 = None
        add_123: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_132, mul_185);  mul_185 = None
        mul_186: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_123, 0.7978845608028654);  add_123 = None
        mul_187: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_132, 0.5);  view_132 = None
        tanh_6: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_186);  mul_186 = None
        add_124: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_6, 1);  tanh_6 = None
        mul_188: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_187, add_124);  mul_187 = add_124 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_189: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_188, view_120);  mul_188 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:120 in index_mean, code: weight = torch.ones_like(data)
        full_default_43: "f32[100, 512]" = torch.ops.aten.full.default([100, 512], 1, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:72 in _normalise_index, code: valid = (index >= 0) & (index < size)
        ge_1: "b8[100]" = torch.ops.aten.ge.Scalar(arg14_1, 0)
        lt_10: "b8[100]" = torch.ops.aten.lt.Scalar(arg14_1, 100)
        bitwise_and_27: "b8[100]" = torch.ops.aten.bitwise_and.Tensor(ge_1, lt_10);  ge_1 = lt_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:73 in _normalise_index, code: return index.clamp(0, max(size - 1, 0)), valid
        clamp_min_31: "i64[100]" = torch.ops.aten.clamp_min.default(arg14_1, 0)
        clamp_max_2: "i64[100]" = torch.ops.aten.clamp_max.default(clamp_min_31, 99);  clamp_min_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        full_default_44: "f32[100, 512]" = torch.ops.aten.full.default([100, 512], 0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_48: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_189, full_default_44);  mul_189 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        view_133: "b8[100, 1]" = torch.ops.aten.view.default(bitwise_and_27, [-1, 1]);  bitwise_and_27 = None
        where_49: "f32[100, 512]" = torch.ops.aten.where.self(view_133, where_48, full_default_44);  where_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:87 in index_sum, code: idx = index.view(-1, *([1] * (data.dim() - 1))).expand_as(data)
        view_134: "i64[100, 1]" = torch.ops.aten.view.default(clamp_max_2, [-1, 1])
        expand_2: "i64[100, 512]" = torch.ops.aten.expand.default(view_134, [100, 512]);  view_134 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_2, where_49);  where_49 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_89: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add, [clamp_max_2]);  scatter_add = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_50: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, full_default_43, full_default_44);  full_default_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_51: "f32[100, 512]" = torch.ops.aten.where.self(view_133, where_50, full_default_44)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_1: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_2, where_51);  where_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_90: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_1, [clamp_max_2]);  scatter_add_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        clamp_min_33: "f32[100, 512]" = torch.ops.aten.clamp_min.default(index_90, 1e-06);  index_90 = None
        div_33: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_89, clamp_min_33);  index_89 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_52: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_33, full_default_44);  div_33 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_125: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_176, where_52);  mul_176 = where_52 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_191: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_182, view_120);  mul_182 = view_120 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:72 in _normalise_index, code: valid = (index >= 0) & (index < size)
        ge_3: "b8[100]" = torch.ops.aten.ge.Scalar(arg15_1, 0)
        lt_12: "b8[100]" = torch.ops.aten.lt.Scalar(arg15_1, 100)
        bitwise_and_29: "b8[100]" = torch.ops.aten.bitwise_and.Tensor(ge_3, lt_12);  ge_3 = lt_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:73 in _normalise_index, code: return index.clamp(0, max(size - 1, 0)), valid
        clamp_min_34: "i64[100]" = torch.ops.aten.clamp_min.default(arg15_1, 0)
        clamp_max_4: "i64[100]" = torch.ops.aten.clamp_max.default(clamp_min_34, 99);  clamp_min_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_53: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_191, full_default_44);  mul_191 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        view_137: "b8[100, 1]" = torch.ops.aten.view.default(bitwise_and_29, [-1, 1]);  bitwise_and_29 = None
        where_54: "f32[100, 512]" = torch.ops.aten.where.self(view_137, where_53, full_default_44);  where_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:87 in index_sum, code: idx = index.view(-1, *([1] * (data.dim() - 1))).expand_as(data)
        view_138: "i64[100, 1]" = torch.ops.aten.view.default(clamp_max_4, [-1, 1])
        expand_4: "i64[100, 512]" = torch.ops.aten.expand.default(view_138, [100, 512]);  view_138 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_2: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_4, where_54);  where_54 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_91: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_2, [clamp_max_4]);  scatter_add_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_56: "f32[100, 512]" = torch.ops.aten.where.self(view_137, where_50, full_default_44);  where_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_3: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_4, where_56);  where_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_92: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_3, [clamp_max_4]);  scatter_add_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        clamp_min_36: "f32[100, 512]" = torch.ops.aten.clamp_min.default(index_92, 1e-06);  index_92 = None
        div_34: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_91, clamp_min_36);  index_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_57: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_34, full_default_44);  div_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_126: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_125, where_57);  add_125 = where_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_316: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_126, 2);  add_126 = None
        permute_117: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_316, [0, 2, 1]);  unsqueeze_316 = None
        unsqueeze_317: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg79_1, 2);  arg79_1 = None
        permute_118: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_317, [2, 1, 0]);  unsqueeze_317 = None
        permute_119: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_117, [0, 2, 1]);  permute_117 = None
        view_141: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_119, [1, 100, 512]);  permute_119 = None
        permute_120: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_118, [2, 1, 0]);  permute_118 = None
        view_142: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_120, [1, 512, 128]);  permute_120 = None
        bmm_29: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_141, view_142);  view_141 = view_142 = None
        view_143: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_29, [100, 1, 128]);  bmm_29 = None
        permute_121: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_143, [0, 2, 1]);  view_143 = None
        view_144: "f32[100, 128]" = torch.ops.aten.view.default(permute_121, [100, 128]);  permute_121 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_127: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_144, arg80_1);  view_144 = arg80_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_128: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_106, add_127);  add_106 = add_127 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_14: "f32[100, 1]" = torch.ops.aten.mean.dim(add_128, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_14: "f32[100, 1]" = torch.ops.aten.var.correction(add_128, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_88: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_128, mean_14);  mean_14 = None
        add_129: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_14, 1e-05);  var_14 = None
        rsqrt_14: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_129);  add_129 = None
        mul_193: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_88, rsqrt_14);  sub_88 = rsqrt_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_194: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_193, arg81_1);  arg81_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_130: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_194, arg82_1);  mul_194 = arg82_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_327: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_130, 2);  add_130 = None
        permute_122: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_327, [0, 2, 1]);  unsqueeze_327 = None
        unsqueeze_328: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg83_1, 2);  arg83_1 = None
        permute_123: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_328, [2, 1, 0]);  unsqueeze_328 = None
        permute_124: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_122, [0, 2, 1]);  permute_122 = None
        view_145: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_124, [1, 100, 128]);  permute_124 = None
        permute_125: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_123, [2, 1, 0]);  permute_123 = None
        view_146: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_125, [1, 128, 60]);  permute_125 = None
        bmm_30: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_145, view_146);  view_145 = view_146 = None
        view_147: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_30, [100, 1, 60]);  bmm_30 = None
        permute_126: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_147, [0, 2, 1]);  view_147 = None
        view_148: "f32[100, 60]" = torch.ops.aten.view.default(permute_126, [100, 60]);  permute_126 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_202: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_148, 10.0);  view_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_149: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_202, [100, 20, 3]);  mul_202 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_135: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_4, view_149);  sum_4 = view_149 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_331: "f32[100, 20, 1, 3]" = torch.ops.aten.unsqueeze.default(add_135, -2);  add_135 = None
        mul_203: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_6, unsqueeze_331);  unsqueeze_6 = unsqueeze_331 = None
        sum_74: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_203, [-1]);  mul_203 = None
        add_136: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_74, unsqueeze_7);  sum_74 = unsqueeze_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_37: "f32[100, 3]" = torch.ops.aten.select.int(add_136, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_332: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_37, 1)
        unsqueeze_333: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_37, 0)
        sub_94: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_332, unsqueeze_333);  unsqueeze_332 = unsqueeze_333 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_204: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_94, sub_94);  sub_94 = None
        sum_75: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_204, [-1]);  mul_204 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_39: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_75, 1e-12);  sum_75 = None
        sqrt_31: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_39);  clamp_min_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_58: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_31, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_59: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_58, full_default);  where_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_98: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_59, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_60: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_98);  index_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_9: "f32[100, 100]" = torch.ops.aten.index_put.default(where_59, [unsqueeze_24, where_1], where_60);  where_59 = where_60 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_10 = torch.ops.aten.sort.stable(index_put_9, stable = True)
        getitem_46: "i64[100, 100]" = sort_10[1];  sort_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_247: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_46, 1, 0, 16);  getitem_46 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_99: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_9, [unsqueeze_24, slice_247]);  index_put_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_14: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_99, inf);  index_99 = None
        where_61: "i64[100, 16]" = torch.ops.aten.where.self(lt_14, slice_247, full_default_1);  lt_14 = slice_247 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_29: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_61], -1);  where_61 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_137: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_31, 1e-06);  sqrt_31 = None
        log_21: "f32[100, 100]" = torch.ops.aten.log.default(add_137);  add_137 = None
        mul_205: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_21, -3.0);  log_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_22: "f32[100, 100]" = torch.ops.aten.log.default(getitem_4)
        neg_17: "f32[100, 100]" = torch.ops.aten.neg.default(log_22);  log_22 = None
        log_23: "f32[100, 100]" = torch.ops.aten.log.default(neg_17);  neg_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_95: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_205, log_23);  mul_205 = log_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_18: "f32[100, 100]" = torch.ops.aten.neg.default(sub_95);  sub_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_62: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_18, full_default);  neg_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_63: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_62, full_default);  where_62 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_14: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_29, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_101: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_63, [unsqueeze_24, cat_29])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_64: "f32[100, 32]" = torch.ops.aten.where.self(ne_14, full_default_7, index_101);  ne_14 = index_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_10: "f32[100, 100]" = torch.ops.aten.index_put.default(where_63, [unsqueeze_24, cat_29], where_64);  where_63 = where_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_11 = torch.ops.aten.sort.stable(index_put_10, stable = True)
        getitem_48: "i64[100, 100]" = sort_11[1];  sort_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_256: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_48, 1, 0, 32);  getitem_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_102: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_10, [unsqueeze_24, slice_256]);  index_put_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_15: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_102, inf);  index_102 = None
        where_65: "i64[100, 32]" = torch.ops.aten.where.self(lt_15, slice_256, full_default_37);  lt_15 = slice_256 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_30: "i64[100, 64]" = torch.ops.aten.cat.default([cat_29, where_65], -1);  cat_29 = where_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_38: "i64[100, 48]" = torch.ops.aten.select.int(view_10, 0, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_39: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_25, 0, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_40: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_103: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_30])
        bitwise_and_35: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_103);  index_103 = None
        ne_15: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_30, -1)
        bitwise_and_36: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_35, ne_15);  bitwise_and_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_104: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_30])
        eq_17: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_104);  index_104 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_105: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_30])
        eq_18: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_105);  index_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_106: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_30])
        sub_96: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_106);  index_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_40: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_96, -32);  sub_96 = None
        clamp_max_6: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_40, 32);  clamp_min_40 = None
        add_138: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_6, 32);  clamp_max_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_66: "i64[100, 64]" = torch.ops.aten.where.self(eq_17, add_138, full_default_38);  eq_17 = add_138 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_67: "i64[100, 64]" = torch.ops.aten.where.self(eq_18, where_66, full_default_38);  eq_18 = where_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_107: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg84_1, [where_67]);  arg84_1 = where_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_354: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_136, 1)
        slice_263: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_354, 2, 0, 5)
        unsqueeze_355: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_263, 3);  slice_263 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_108: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_136, [cat_30])
        unsqueeze_356: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_108, 2)
        slice_267: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_356, 3, 0, 5);  unsqueeze_356 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_97: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_355, slice_267);  unsqueeze_355 = slice_267 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_206: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_97, sub_97);  sub_97 = None
        sum_76: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_206, [-1]);  mul_206 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_41: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_76, 1e-12);  sum_76 = None
        sqrt_32: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_41);  clamp_min_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_150: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_32, [100, 64, 25]);  sqrt_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_357: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_150, 3);  view_150 = None
        sub_98: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_357, add_29);  unsqueeze_357 = None
        pow_8: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_98, 2);  sub_98 = None
        neg_19: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_8);  pow_8 = None
        div_37: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_19, 1.890625);  neg_19 = None
        exp_7: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_37);  div_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_151: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_7, [100, 64, 400]);  exp_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_358: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_151, 3);  view_151 = None
        permute_127: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_358, [0, 1, 3, 2]);  unsqueeze_358 = None
        unsqueeze_359: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg85_1, 2);  arg85_1 = None
        unsqueeze_360: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_359, 3);  unsqueeze_359 = None
        permute_128: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_360, [2, 3, 1, 0]);  unsqueeze_360 = None
        permute_129: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_127, [0, 1, 3, 2]);  permute_127 = None
        view_152: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_129, [1, 6400, 400]);  permute_129 = None
        permute_130: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_128, [3, 2, 0, 1]);  permute_128 = None
        view_153: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_130, [1, 400, 64]);  permute_130 = None
        bmm_31: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_152, view_153);  view_152 = view_153 = None
        view_154: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_31, [100, 64, 1, 64]);  bmm_31 = None
        permute_131: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_154, [0, 1, 3, 2]);  view_154 = None
        view_155: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_131, [100, 64, 64]);  permute_131 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_142: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_107, view_155);  index_107 = view_155 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_41: "f32[100, 3]" = torch.ops.aten.select.int(add_136, 1, 0)
        select_43: "f32[100, 3]" = torch.ops.aten.select.int(add_136, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_99: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_43, select_37);  select_43 = None
        sub_100: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_41, select_37);  select_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_209: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_99, sub_99)
        sum_77: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_209, [-1]);  mul_209 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_42: "f32[100]" = torch.ops.aten.clamp_min.default(sum_77, 1e-12);  sum_77 = None
        sqrt_33: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_42);  clamp_min_42 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_361: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_33, -1);  sqrt_33 = None
        div_38: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_99, unsqueeze_361);  sub_99 = unsqueeze_361 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_210: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_100, div_38)
        sum_78: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_210, [-1]);  mul_210 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_362: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_78, -1);  sum_78 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_211: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_362, div_38);  unsqueeze_362 = None
        sub_101: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_100, mul_211);  sub_100 = mul_211 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_212: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_101, sub_101)
        sum_79: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_212, [-1]);  mul_212 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_43: "f32[100]" = torch.ops.aten.clamp_min.default(sum_79, 1e-12);  sum_79 = None
        sqrt_34: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_43);  clamp_min_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_363: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_34, -1);  sqrt_34 = None
        div_39: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_101, unsqueeze_363);  sub_101 = unsqueeze_363 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_109: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_38, [None, remainder])
        index_110: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_39, [None, remainder_1])
        mul_213: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_109, index_110);  index_109 = index_110 = None
        index_111: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_38, [None, remainder_1])
        index_112: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_39, [None, remainder])
        mul_214: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_111, index_112);  index_111 = index_112 = None
        sub_102: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_213, mul_214);  mul_213 = mul_214 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_364: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_38, 2);  div_38 = None
        unsqueeze_365: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_39, 2);  div_39 = None
        unsqueeze_366: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_102, 2);  sub_102 = None
        cat_31: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_364, unsqueeze_365, unsqueeze_366], -1);  unsqueeze_364 = unsqueeze_365 = unsqueeze_366 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_370: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_31, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_371: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_37, -2);  select_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_372: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_370, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_373: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_371, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_104: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_108, unsqueeze_373)
        unsqueeze_374: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_104, -1);  sub_104 = None
        mul_216: "f32[100, 64, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_372, unsqueeze_374);  unsqueeze_374 = None
        sum_81: "f32[100, 64, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_216, [-2]);  mul_216 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_217: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(sum_81, sum_81)
        sum_82: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_217, [-1]);  mul_217 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_44: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_82, 1e-12);  sum_82 = None
        sqrt_35: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_44);  clamp_min_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_375: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_35, -1);  sqrt_35 = None
        div_40: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(sum_81, unsqueeze_375);  sum_81 = unsqueeze_375 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        view_156: "f32[100, 64, 60]" = torch.ops.aten.view.default(div_40, [100, 64, 60]);  div_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_6: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_354, [100, 64, 20, 3]);  unsqueeze_354 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_32: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_6, index_108], -2);  expand_6 = index_108 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_105: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_32, unsqueeze_373);  cat_32 = unsqueeze_373 = None
        unsqueeze_381: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_105, -1);  sub_105 = None
        mul_218: "f32[100, 64, 40, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_372, unsqueeze_381);  unsqueeze_372 = unsqueeze_381 = None
        sum_83: "f32[100, 64, 40, 3]" = torch.ops.aten.sum.dim_IntList(mul_218, [-2]);  mul_218 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_219: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_83, sum_83)
        sum_84: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_219, [-1]);  mul_219 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_45: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_84, 1e-12);  sum_84 = None
        sqrt_36: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_45);  clamp_min_45 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_382: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_36, -1);  sqrt_36 = None
        div_41: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(sum_83, unsqueeze_382);  unsqueeze_382 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        view_157: "f32[100, 64, 120]" = torch.ops.aten.view.default(div_41, [100, 64, 120]);  div_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_220: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_83, 0.1);  sum_83 = None
        view_158: "f32[100, 64, 120]" = torch.ops.aten.view.default(mul_220, [100, 64, 120]);  mul_220 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_33: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_157, view_158], -1);  view_157 = view_158 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_383: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_156, 3);  view_156 = None
        permute_132: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_383, [0, 1, 3, 2]);  unsqueeze_383 = None
        unsqueeze_384: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg86_1, 2);  arg86_1 = None
        unsqueeze_385: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_384, 3);  unsqueeze_384 = None
        permute_133: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_385, [2, 3, 1, 0]);  unsqueeze_385 = None
        permute_134: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_132, [0, 1, 3, 2]);  permute_132 = None
        view_159: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_134, [1, 6400, 60]);  permute_134 = None
        permute_135: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_133, [3, 2, 0, 1]);  permute_133 = None
        view_160: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_135, [1, 60, 64]);  permute_135 = None
        bmm_32: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_159, view_160);  view_159 = view_160 = None
        view_161: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_32, [100, 64, 1, 64]);  bmm_32 = None
        permute_136: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_161, [0, 1, 3, 2]);  view_161 = None
        view_162: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_136, [100, 64, 64]);  permute_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_147: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_142, view_162);  add_142 = view_162 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_395: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_31, 1)
        permute_137: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_395, [0, 1, 3, 2]);  unsqueeze_395 = None
        index_118: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_31, [cat_30]);  cat_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:77 in rot_compose, code: return (a.unsqueeze(-1) * b.unsqueeze(-3)).sum(-2)
        unsqueeze_396: "f32[100, 1, 3, 3, 1]" = torch.ops.aten.unsqueeze.default(permute_137, -1);  permute_137 = None
        unsqueeze_397: "f32[100, 64, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(index_118, -3);  index_118 = None
        mul_228: "f32[100, 64, 3, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_396, unsqueeze_397);  unsqueeze_396 = unsqueeze_397 = None
        sum_89: "f32[100, 64, 3, 3]" = torch.ops.aten.sum.dim_IntList(mul_228, [-2]);  mul_228 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_163: "f32[100, 64, 9]" = torch.ops.aten.view.default(sum_89, [100, 64, 9]);  sum_89 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_398: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_163, 3);  view_163 = None
        permute_138: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_398, [0, 1, 3, 2]);  unsqueeze_398 = None
        unsqueeze_399: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg87_1, 2);  arg87_1 = None
        unsqueeze_400: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_399, 3);  unsqueeze_399 = None
        permute_139: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_400, [2, 3, 1, 0]);  unsqueeze_400 = None
        permute_140: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_138, [0, 1, 3, 2]);  permute_138 = None
        view_164: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_140, [1, 6400, 9]);  permute_140 = None
        permute_141: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_139, [3, 2, 0, 1]);  permute_139 = None
        view_165: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_141, [1, 9, 64]);  permute_141 = None
        bmm_33: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_164, view_165);  view_164 = view_165 = None
        view_166: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_33, [100, 64, 1, 64]);  bmm_33 = None
        permute_142: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_166, [0, 1, 3, 2]);  view_166 = None
        view_167: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_142, [100, 64, 64]);  permute_142 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_152: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_147, view_167);  add_147 = view_167 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_401: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_33, 3);  cat_33 = None
        permute_143: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_401, [0, 1, 3, 2]);  unsqueeze_401 = None
        unsqueeze_402: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg88_1, 2);  arg88_1 = None
        unsqueeze_403: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_402, 3);  unsqueeze_402 = None
        permute_144: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_403, [2, 3, 1, 0]);  unsqueeze_403 = None
        permute_145: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_143, [0, 1, 3, 2]);  permute_143 = None
        view_168: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_145, [1, 6400, 240]);  permute_145 = None
        permute_146: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_144, [3, 2, 0, 1]);  permute_144 = None
        view_169: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_146, [1, 240, 64]);  permute_146 = None
        bmm_34: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_168, view_169);  view_168 = view_169 = None
        view_170: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_34, [100, 64, 1, 64]);  bmm_34 = None
        permute_147: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_170, [0, 1, 3, 2]);  view_170 = None
        view_171: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_147, [100, 64, 64]);  permute_147 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_153: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_152, view_171);  add_152 = view_171 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_15: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_153, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_15: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_153, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_111: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_153, mean_15);  add_153 = mean_15 = None
        add_154: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_15, 1e-05);  var_15 = None
        rsqrt_15: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_154);  add_154 = None
        mul_229: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_111, rsqrt_15);  sub_111 = rsqrt_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_230: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_229, arg89_1);  mul_229 = arg89_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_155: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_230, arg90_1);  mul_230 = arg90_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_404: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_155, 3);  add_155 = None
        permute_148: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_404, [0, 1, 3, 2]);  unsqueeze_404 = None
        unsqueeze_405: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg91_1, 2);  arg91_1 = None
        unsqueeze_406: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_405, 3);  unsqueeze_405 = None
        permute_149: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_406, [2, 3, 1, 0]);  unsqueeze_406 = None
        permute_150: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_148, [0, 1, 3, 2]);  permute_148 = None
        view_172: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_150, [1, 6400, 64]);  permute_150 = None
        permute_151: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_149, [3, 2, 0, 1]);  permute_149 = None
        view_173: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_151, [1, 64, 128]);  permute_151 = None
        bmm_35: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_172, view_173);  view_172 = view_173 = None
        view_174: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_35, [100, 64, 1, 128]);  bmm_35 = None
        permute_152: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_174, [0, 1, 3, 2]);  view_174 = None
        view_175: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_152, [100, 64, 128]);  permute_152 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_156: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_175, arg92_1);  view_175 = arg92_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_231: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_156, add_156)
        mul_232: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_231, add_156);  mul_231 = None
        mul_233: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_232, 0.044715);  mul_232 = None
        add_157: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_156, mul_233);  mul_233 = None
        mul_234: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_157, 0.7978845608028654);  add_157 = None
        mul_235: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_156, 0.5);  add_156 = None
        tanh_7: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_234);  mul_234 = None
        add_158: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_7, 1);  tanh_7 = None
        mul_236: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_235, add_158);  mul_235 = add_158 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_407: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_236, 3);  mul_236 = None
        permute_153: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_407, [0, 1, 3, 2]);  unsqueeze_407 = None
        unsqueeze_408: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg93_1, 2);  arg93_1 = None
        unsqueeze_409: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_408, 3);  unsqueeze_408 = None
        permute_154: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_409, [2, 3, 1, 0]);  unsqueeze_409 = None
        permute_155: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_153, [0, 1, 3, 2]);  permute_153 = None
        view_176: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_155, [1, 6400, 128]);  permute_155 = None
        permute_156: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_154, [3, 2, 0, 1]);  permute_154 = None
        view_177: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_156, [1, 128, 64]);  permute_156 = None
        bmm_36: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_176, view_177);  view_176 = view_177 = None
        view_178: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_36, [100, 64, 1, 64]);  bmm_36 = None
        permute_157: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_178, [0, 1, 3, 2]);  view_178 = None
        view_179: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_157, [100, 64, 64]);  permute_157 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_159: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_179, arg94_1);  view_179 = arg94_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_238: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_193, arg95_1);  mul_193 = arg95_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_161: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_238, arg96_1);  mul_238 = arg96_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_44: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_136, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_47: "f32[100, 3]" = torch.ops.aten.select.int(div_44, 1, 0)
        select_48: "f32[100, 3]" = torch.ops.aten.select.int(div_44, 1, 1)
        select_49: "f32[100, 3]" = torch.ops.aten.select.int(div_44, 1, 2);  div_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_113: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_49, select_48);  select_49 = None
        sub_114: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_47, select_48);  select_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_239: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_113, sub_113)
        sum_90: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_239, [-1]);  mul_239 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_48: "f32[100]" = torch.ops.aten.clamp_min.default(sum_90, 1e-12);  sum_90 = None
        sqrt_39: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_48);  clamp_min_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_410: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_39, -1);  sqrt_39 = None
        div_45: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_113, unsqueeze_410);  sub_113 = unsqueeze_410 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_240: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_114, div_45)
        sum_91: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_240, [-1]);  mul_240 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_411: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_91, -1);  sum_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_241: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_411, div_45);  unsqueeze_411 = None
        sub_115: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_114, mul_241);  sub_114 = mul_241 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_242: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_115, sub_115)
        sum_92: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_242, [-1]);  mul_242 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_49: "f32[100]" = torch.ops.aten.clamp_min.default(sum_92, 1e-12);  sum_92 = None
        sqrt_40: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_49);  clamp_min_49 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_412: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_40, -1);  sqrt_40 = None
        div_46: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_115, unsqueeze_412);  sub_115 = unsqueeze_412 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_119: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_45, [None, remainder])
        index_120: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_46, [None, remainder_1])
        mul_243: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_119, index_120);  index_119 = index_120 = None
        index_121: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_45, [None, remainder_1])
        index_122: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_46, [None, remainder])
        mul_244: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_121, index_122);  index_121 = index_122 = None
        sub_116: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_243, mul_244);  mul_243 = mul_244 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_413: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_45, 2);  div_45 = None
        unsqueeze_414: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_46, 2);  div_46 = None
        unsqueeze_415: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_116, 2);  sub_116 = None
        cat_35: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_413, unsqueeze_414, unsqueeze_415], -1);  unsqueeze_413 = unsqueeze_414 = unsqueeze_415 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_17: "f32[100, 1]" = torch.ops.aten.mean.dim(add_161, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_17: "f32[100, 1]" = torch.ops.aten.var.correction(add_161, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_118: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_161, mean_17);  add_161 = mean_17 = None
        add_166: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_17, 1e-05);  var_17 = None
        rsqrt_17: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_166);  add_166 = None
        mul_246: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_118, rsqrt_17);  sub_118 = rsqrt_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_247: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_246, arg97_1);  mul_246 = arg97_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_167: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_247, arg98_1);  mul_247 = arg98_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_419: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_167, 2);  add_167 = None
        permute_158: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_419, [0, 2, 1]);  unsqueeze_419 = None
        unsqueeze_420: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg99_1, 2);  arg99_1 = None
        permute_159: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_420, [2, 1, 0]);  unsqueeze_420 = None
        permute_160: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_158, [0, 2, 1]);  permute_158 = None
        view_180: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_160, [1, 100, 128]);  permute_160 = None
        permute_161: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_159, [2, 1, 0]);  permute_159 = None
        view_181: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_161, [1, 128, 768]);  permute_161 = None
        bmm_37: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_180, view_181);  view_181 = None
        view_182: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_37, [100, 1, 768]);  bmm_37 = None
        permute_162: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_182, [0, 2, 1]);  view_182 = None
        view_183: "f32[100, 768]" = torch.ops.aten.view.default(permute_162, [100, 768]);  permute_162 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_184: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_183, [100, 8, 96]);  view_183 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_2 = torch.ops.aten.split.Tensor(view_184, 32, -1);  view_184 = None
        getitem_49: "f32[100, 8, 32]" = split_2[0]
        getitem_50: "f32[100, 8, 32]" = split_2[1]
        getitem_51: "f32[100, 8, 32]" = split_2[2];  split_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_18: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_49, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_18: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_49, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_119: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_49, mean_18);  getitem_49 = mean_18 = None
        add_168: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_18, 1e-05);  var_18 = None
        rsqrt_18: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_168);  add_168 = None
        mul_248: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_119, rsqrt_18);  sub_119 = rsqrt_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_249: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_248, arg100_1);  mul_248 = arg100_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_169: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_249, arg101_1);  mul_249 = arg101_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_19: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_50, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_19: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_50, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_120: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_50, mean_19);  getitem_50 = mean_19 = None
        add_170: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_19, 1e-05);  var_19 = None
        rsqrt_19: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_170);  add_170 = None
        mul_250: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_120, rsqrt_19);  sub_120 = rsqrt_19 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_251: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_250, arg102_1);  mul_250 = arg102_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_171: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_251, arg103_1);  mul_251 = arg103_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_422: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg104_1, 2);  arg104_1 = None
        permute_164: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_422, [2, 1, 0]);  unsqueeze_422 = None
        permute_166: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_164, [2, 1, 0]);  permute_164 = None
        view_186: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_166, [1, 128, 576]);  permute_166 = None
        bmm_38: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_180, view_186);  view_180 = view_186 = None
        view_187: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_38, [100, 1, 576]);  bmm_38 = None
        permute_167: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_187, [0, 2, 1]);  view_187 = None
        view_188: "f32[100, 576]" = torch.ops.aten.view.default(permute_167, [100, 576]);  permute_167 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_189: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_188, [100, 192, 3]);  view_188 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_423: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_35, -3);  cat_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_424: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_48, -2);  select_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_425: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_189, -2);  view_189 = None
        mul_252: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_423, unsqueeze_425);  unsqueeze_425 = None
        sum_94: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_252, [-1]);  mul_252 = None
        add_172: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_94, unsqueeze_424);  sum_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_190: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_172, [100, 8, 24, 3]);  add_172 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_294: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_190, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_297: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_190, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_300: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_190, 2, 16, 9223372036854775807);  view_190 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_426: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_159, 3)
        permute_168: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_426, [0, 1, 3, 2]);  unsqueeze_426 = None
        unsqueeze_427: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg105_1, 2);  arg105_1 = None
        unsqueeze_428: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_427, 3);  unsqueeze_427 = None
        permute_169: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_428, [2, 3, 1, 0]);  unsqueeze_428 = None
        permute_170: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_168, [0, 1, 3, 2]);  permute_168 = None
        view_191: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_170, [1, 6400, 64]);  permute_170 = None
        permute_171: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_169, [3, 2, 0, 1]);  permute_169 = None
        view_192: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_171, [1, 64, 8]);  permute_171 = None
        bmm_39: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_191, view_192);  view_191 = view_192 = None
        view_193: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_39, [100, 64, 1, 8]);  bmm_39 = None
        permute_172: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_193, [0, 1, 3, 2]);  view_193 = None
        view_194: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_172, [100, 64, 8]);  permute_172 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_8: "f32[8]" = torch.ops.aten.exp.default(arg106_1)
        log1p_2: "f32[8]" = torch.ops.aten.log1p.default(exp_8);  exp_8 = None
        gt_2: "b8[8]" = torch.ops.aten.gt.Scalar(arg106_1, 20)
        where_68: "f32[8]" = torch.ops.aten.where.self(gt_2, arg106_1, log1p_2);  gt_2 = arg106_1 = log1p_2 = None
        view_195: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_68, [1, 1, 8]);  where_68 = None
        mul_253: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_195, 0.16666666666666666);  view_195 = None
        div_47: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_253, 2);  mul_253 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_429: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_294, 1);  slice_294 = None
        index_123: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_297, [cat_30]);  slice_297 = None
        sub_121: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_429, index_123);  unsqueeze_429 = index_123 = None
        pow_9: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_121, 2);  sub_121 = None
        sum_95: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_9, [-1, -2]);  pow_9 = None
        mul_254: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_47, sum_95);  div_47 = sum_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_430: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_169, 1);  add_169 = None
        index_124: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_171, [cat_30]);  add_171 = None
        mul_255: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_430, index_124);  unsqueeze_430 = index_124 = None
        sum_96: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(mul_255, [-1]);  mul_255 = None
        mul_256: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sum_96, 0.1767766952966369);  sum_96 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_173: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_256, view_194);  mul_256 = view_194 = None
        sub_122: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_173, mul_254);  add_173 = mul_254 = None
        mul_257: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_122, 0.5773502691896257);  sub_122 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_37: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_36, ne_15);  bitwise_and_36 = ne_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_431: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_37, 2);  bitwise_and_37 = None
        where_69: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_431, mul_257, full_default_39);  mul_257 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_2: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_69, [-2], True)
        sub_123: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(where_69, amax_2);  where_69 = amax_2 = None
        exp_9: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_123);  sub_123 = None
        sum_97: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_9, [-2], True)
        div_48: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_9, sum_97);  exp_9 = sum_97 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_70: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_431, div_48, full_default_40);  unsqueeze_431 = div_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_433: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_70, 3);  where_70 = None
        unsqueeze_434: "f32[100, 64, 1, 64]" = torch.ops.aten.unsqueeze.default(add_159, 2);  add_159 = None
        mul_258: "f32[100, 64, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_433, unsqueeze_434);  unsqueeze_434 = None
        sum_98: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_258, [1]);  mul_258 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_125: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_51, [cat_30]);  getitem_51 = None
        mul_259: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_433, index_125);  index_125 = None
        sum_99: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_259, [1]);  mul_259 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_437: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_433, 4);  unsqueeze_433 = None
        index_126: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_300, [cat_30]);  slice_300 = cat_30 = None
        mul_260: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_437, index_126);  unsqueeze_437 = index_126 = None
        sum_100: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_260, [1]);  mul_260 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_440: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_423, -3);  unsqueeze_423 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_441: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_424, -2);  unsqueeze_424 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_124: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_100, unsqueeze_441);  sum_100 = unsqueeze_441 = None
        unsqueeze_442: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_124, -1);  sub_124 = None
        mul_261: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_440, unsqueeze_442);  unsqueeze_440 = unsqueeze_442 = None
        sum_101: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_261, [-2]);  mul_261 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_262: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_101, sum_101)
        sum_102: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_262, [-1]);  mul_262 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_50: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_102, 1e-12);  sum_102 = None
        sqrt_41: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_50);  clamp_min_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_196: "f32[100, 512]" = torch.ops.aten.view.default(sum_98, [100, -1]);  sum_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_197: "f32[100, 256]" = torch.ops.aten.view.default(sum_99, [100, -1]);  sum_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_198: "f32[100, 192]" = torch.ops.aten.view.default(sum_101, [100, -1]);  sum_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_199: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_41, [100, -1]);  sqrt_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_36: "f32[100, 1024]" = torch.ops.aten.cat.default([view_196, view_197, view_198, view_199], -1);  view_196 = view_197 = view_198 = view_199 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_443: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_36, 2);  cat_36 = None
        permute_173: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_443, [0, 2, 1]);  unsqueeze_443 = None
        unsqueeze_444: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg107_1, 2);  arg107_1 = None
        permute_174: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_444, [2, 1, 0]);  unsqueeze_444 = None
        permute_175: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_173, [0, 2, 1]);  permute_173 = None
        view_200: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_175, [1, 100, 1024]);  permute_175 = None
        permute_176: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_174, [2, 1, 0]);  permute_174 = None
        view_201: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_176, [1, 1024, 128]);  permute_176 = None
        bmm_40: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_200, view_201);  view_200 = view_201 = None
        view_202: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_40, [100, 1, 128]);  bmm_40 = None
        permute_177: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_202, [0, 2, 1]);  view_202 = None
        view_203: "f32[100, 128]" = torch.ops.aten.view.default(permute_177, [100, 128]);  permute_177 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_174: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_203, arg108_1);  view_203 = arg108_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_175: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_128, add_174);  add_128 = add_174 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_20: "f32[100, 1]" = torch.ops.aten.mean.dim(add_175, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_20: "f32[100, 1]" = torch.ops.aten.var.correction(add_175, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_125: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_175, mean_20);  mean_20 = None
        add_176: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_20, 1e-05);  var_20 = None
        rsqrt_20: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_176);  add_176 = None
        mul_263: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_125, rsqrt_20);  sub_125 = rsqrt_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_264: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_263, arg109_1);  mul_263 = arg109_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_177: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_264, arg110_1);  mul_264 = arg110_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_21: "f32[100, 1]" = torch.ops.aten.mean.dim(add_177, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_21: "f32[100, 1]" = torch.ops.aten.var.correction(add_177, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_131: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_177, mean_21);  add_177 = mean_21 = None
        add_182: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_21, 1e-05);  var_21 = None
        rsqrt_21: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_182);  add_182 = None
        mul_272: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_131, rsqrt_21);  sub_131 = rsqrt_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_273: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_272, arg111_1);  mul_272 = arg111_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_183: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_273, arg112_1);  mul_273 = arg112_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_454: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_183, 2);  add_183 = None
        permute_178: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_454, [0, 2, 1]);  unsqueeze_454 = None
        unsqueeze_455: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg113_1, 2);  arg113_1 = None
        permute_179: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_455, [2, 1, 0]);  unsqueeze_455 = None
        permute_180: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_178, [0, 2, 1]);  permute_178 = None
        view_204: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_180, [1, 100, 128]);  permute_180 = None
        permute_181: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_179, [2, 1, 0]);  permute_179 = None
        view_205: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_181, [1, 128, 768]);  permute_181 = None
        bmm_41: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_204, view_205);  view_205 = None
        view_206: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_41, [100, 1, 768]);  bmm_41 = None
        permute_182: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_206, [0, 2, 1]);  view_206 = None
        view_207: "f32[100, 768]" = torch.ops.aten.view.default(permute_182, [100, 768]);  permute_182 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_208: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_207, [100, 8, 96]);  view_207 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_3 = torch.ops.aten.split.Tensor(view_208, 32, -1);  view_208 = None
        getitem_52: "f32[100, 8, 32]" = split_3[0]
        getitem_53: "f32[100, 8, 32]" = split_3[1]
        getitem_54: "f32[100, 8, 32]" = split_3[2];  split_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_22: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_52, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_22: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_52, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_132: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_52, mean_22);  getitem_52 = mean_22 = None
        add_184: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_22, 1e-05);  var_22 = None
        rsqrt_22: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_184);  add_184 = None
        mul_274: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_132, rsqrt_22);  sub_132 = rsqrt_22 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_275: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_274, arg114_1);  mul_274 = arg114_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_185: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_275, arg115_1);  mul_275 = arg115_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_23: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_53, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_23: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_53, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_133: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_53, mean_23);  getitem_53 = mean_23 = None
        add_186: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_23, 1e-05);  var_23 = None
        rsqrt_23: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_186);  add_186 = None
        mul_276: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_133, rsqrt_23);  sub_133 = rsqrt_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_277: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_276, arg116_1);  mul_276 = arg116_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_187: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_277, arg117_1);  mul_277 = arg117_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_457: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg118_1, 2);  arg118_1 = None
        permute_184: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_457, [2, 1, 0]);  unsqueeze_457 = None
        permute_186: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_184, [2, 1, 0]);  permute_184 = None
        view_210: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_186, [1, 128, 576]);  permute_186 = None
        bmm_42: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_204, view_210);  view_204 = view_210 = None
        view_211: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_42, [100, 1, 576]);  bmm_42 = None
        permute_187: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_211, [0, 2, 1]);  view_211 = None
        view_212: "f32[100, 576]" = torch.ops.aten.view.default(permute_187, [100, 576]);  permute_187 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_213: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_212, [100, 192, 3]);  view_212 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_460: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_213, -2);  view_213 = None
        mul_278: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_270, unsqueeze_460);  unsqueeze_460 = None
        sum_107: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_278, [-1]);  mul_278 = None
        add_188: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_107, unsqueeze_271);  sum_107 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_214: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_188, [100, 8, 24, 3]);  add_188 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_315: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_214, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_318: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_214, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_321: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_214, 2, 16, 9223372036854775807);  view_214 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_461: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_39, 3)
        permute_188: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_461, [0, 1, 3, 2]);  unsqueeze_461 = None
        unsqueeze_462: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg119_1, 2);  arg119_1 = None
        unsqueeze_463: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_462, 3);  unsqueeze_462 = None
        permute_189: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_463, [2, 3, 1, 0]);  unsqueeze_463 = None
        permute_190: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_188, [0, 1, 3, 2]);  permute_188 = None
        view_215: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_190, [1, 4800, 64]);  permute_190 = None
        permute_191: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_189, [3, 2, 0, 1]);  permute_189 = None
        view_216: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_191, [1, 64, 8]);  permute_191 = None
        bmm_43: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_215, view_216);  view_215 = view_216 = None
        view_217: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_43, [100, 48, 1, 8]);  bmm_43 = None
        permute_192: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_217, [0, 1, 3, 2]);  view_217 = None
        view_218: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_192, [100, 48, 8]);  permute_192 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_10: "f32[8]" = torch.ops.aten.exp.default(arg120_1)
        log1p_3: "f32[8]" = torch.ops.aten.log1p.default(exp_10);  exp_10 = None
        gt_3: "b8[8]" = torch.ops.aten.gt.Scalar(arg120_1, 20)
        where_71: "f32[8]" = torch.ops.aten.where.self(gt_3, arg120_1, log1p_3);  gt_3 = arg120_1 = log1p_3 = None
        view_219: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_71, [1, 1, 8]);  where_71 = None
        mul_279: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_219, 0.16666666666666666);  view_219 = None
        div_52: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_279, 2);  mul_279 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_464: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_315, 1);  slice_315 = None
        index_131: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_318, [select_38]);  slice_318 = None
        sub_134: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_464, index_131);  unsqueeze_464 = index_131 = None
        pow_10: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_134, 2);  sub_134 = None
        sum_108: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_10, [-1, -2]);  pow_10 = None
        mul_280: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_52, sum_108);  div_52 = sum_108 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_465: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_185, 1);  add_185 = None
        index_132: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_187, [select_38]);  add_187 = None
        mul_281: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_465, index_132);  unsqueeze_465 = index_132 = None
        sum_109: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(mul_281, [-1]);  mul_281 = None
        mul_282: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sum_109, 0.1767766952966369);  sum_109 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_189: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_282, view_218);  mul_282 = view_218 = None
        sub_135: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_189, mul_280);  add_189 = mul_280 = None
        mul_283: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_135, 0.5773502691896257);  sub_135 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_17: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_38, -1)
        bitwise_and_38: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_40, ne_17);  select_40 = ne_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_466: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_38, 2);  bitwise_and_38 = None
        where_72: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_466, mul_283, full_default_41);  mul_283 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_3: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_72, [-2], True)
        sub_136: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(where_72, amax_3);  where_72 = amax_3 = None
        exp_11: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_136);  sub_136 = None
        sum_110: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_11, [-2], True)
        div_53: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_11, sum_110);  exp_11 = sum_110 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_73: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_466, div_53, full_default_42);  unsqueeze_466 = div_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_468: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_73, 3);  where_73 = None
        unsqueeze_469: "f32[100, 48, 1, 64]" = torch.ops.aten.unsqueeze.default(select_39, 2);  select_39 = None
        mul_284: "f32[100, 48, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_468, unsqueeze_469);  unsqueeze_469 = None
        sum_111: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_284, [1]);  mul_284 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_133: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_54, [select_38]);  getitem_54 = None
        mul_285: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_468, index_133);  index_133 = None
        sum_112: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_285, [1]);  mul_285 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_472: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_468, 4);  unsqueeze_468 = None
        index_134: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_321, [select_38]);  slice_321 = select_38 = None
        mul_286: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_472, index_134);  unsqueeze_472 = index_134 = None
        sum_113: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_286, [1]);  mul_286 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_137: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_113, unsqueeze_288);  sum_113 = None
        unsqueeze_477: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_137, -1);  sub_137 = None
        mul_287: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_287, unsqueeze_477);  unsqueeze_477 = None
        sum_114: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_287, [-2]);  mul_287 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_288: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_114, sum_114)
        sum_115: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_288, [-1]);  mul_288 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_53: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_115, 1e-12);  sum_115 = None
        sqrt_44: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_53);  clamp_min_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_220: "f32[100, 512]" = torch.ops.aten.view.default(sum_111, [100, -1]);  sum_111 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_221: "f32[100, 256]" = torch.ops.aten.view.default(sum_112, [100, -1]);  sum_112 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_222: "f32[100, 192]" = torch.ops.aten.view.default(sum_114, [100, -1]);  sum_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_223: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_44, [100, -1]);  sqrt_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_38: "f32[100, 1024]" = torch.ops.aten.cat.default([view_220, view_221, view_222, view_223], -1);  view_220 = view_221 = view_222 = view_223 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_478: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_38, 2);  cat_38 = None
        permute_193: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_478, [0, 2, 1]);  unsqueeze_478 = None
        unsqueeze_479: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg121_1, 2);  arg121_1 = None
        permute_194: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_479, [2, 1, 0]);  unsqueeze_479 = None
        permute_195: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_193, [0, 2, 1]);  permute_193 = None
        view_224: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_195, [1, 100, 1024]);  permute_195 = None
        permute_196: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_194, [2, 1, 0]);  permute_194 = None
        view_225: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_196, [1, 1024, 128]);  permute_196 = None
        bmm_44: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_224, view_225);  view_224 = view_225 = None
        view_226: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_44, [100, 1, 128]);  bmm_44 = None
        permute_197: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_226, [0, 2, 1]);  view_226 = None
        view_227: "f32[100, 128]" = torch.ops.aten.view.default(permute_197, [100, 128]);  permute_197 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_190: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_227, arg122_1);  view_227 = arg122_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_191: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_175, add_190);  add_175 = add_190 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_24: "f32[100, 1]" = torch.ops.aten.mean.dim(add_191, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_24: "f32[100, 1]" = torch.ops.aten.var.correction(add_191, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_138: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_191, mean_24);  mean_24 = None
        add_192: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_24, 1e-05);  var_24 = None
        rsqrt_24: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_192);  add_192 = None
        mul_289: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_138, rsqrt_24);  sub_138 = rsqrt_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_290: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_289, arg123_1);  mul_289 = arg123_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_193: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_290, arg124_1);  mul_290 = arg124_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_143: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_136, unsqueeze_371)
        unsqueeze_488: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_143, -1);  sub_143 = None
        mul_297: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_370, unsqueeze_488);  unsqueeze_488 = None
        sum_119: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_297, [-2]);  mul_297 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        view_228: "f32[100, 60]" = torch.ops.aten.view.default(sum_119, [100, -1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_490: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg125_1, 2);  arg125_1 = None
        permute_199: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_490, [2, 1, 0]);  unsqueeze_490 = None
        permute_201: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_199, [2, 1, 0]);  permute_199 = None
        view_230: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_201, [1, 128, 128]);  permute_201 = None
        bmm_45: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_105, view_230);  view_230 = None
        view_231: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_45, [100, 1, 128]);  bmm_45 = None
        permute_202: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_231, [0, 2, 1]);  view_231 = None
        view_232: "f32[100, 128]" = torch.ops.aten.view.default(permute_202, [100, 128]);  permute_202 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_198: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_193, view_232);  add_193 = view_232 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_491: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_228, 2);  view_228 = None
        permute_203: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_491, [0, 2, 1]);  unsqueeze_491 = None
        unsqueeze_492: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg126_1, 2);  arg126_1 = None
        permute_204: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_492, [2, 1, 0]);  unsqueeze_492 = None
        permute_205: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_203, [0, 2, 1]);  permute_203 = None
        view_233: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_205, [1, 100, 60]);  permute_205 = None
        permute_206: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_204, [2, 1, 0]);  permute_204 = None
        view_234: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_206, [1, 60, 256]);  permute_206 = None
        bmm_46: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_233, view_234);  view_233 = view_234 = None
        view_235: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_46, [100, 1, 256]);  bmm_46 = None
        permute_207: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_235, [0, 2, 1]);  view_235 = None
        view_236: "f32[100, 256]" = torch.ops.aten.view.default(permute_207, [100, 256]);  permute_207 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_199: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_236, arg127_1);  view_236 = arg127_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_298: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_199, add_199)
        mul_299: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_298, add_199);  mul_298 = None
        mul_300: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_299, 0.044715);  mul_299 = None
        add_200: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_199, mul_300);  mul_300 = None
        mul_301: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_200, 0.7978845608028654);  add_200 = None
        mul_302: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_199, 0.5);  add_199 = None
        tanh_8: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_301);  mul_301 = None
        add_201: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_8, 1);  tanh_8 = None
        mul_303: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_302, add_201);  mul_302 = add_201 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_493: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_303, 2);  mul_303 = None
        permute_208: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_493, [0, 2, 1]);  unsqueeze_493 = None
        unsqueeze_494: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg128_1, 2);  arg128_1 = None
        permute_209: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_494, [2, 1, 0]);  unsqueeze_494 = None
        permute_210: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_208, [0, 2, 1]);  permute_208 = None
        view_237: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_210, [1, 100, 256]);  permute_210 = None
        permute_211: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_209, [2, 1, 0]);  permute_209 = None
        view_238: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_211, [1, 256, 128]);  permute_211 = None
        bmm_47: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_237, view_238);  view_237 = view_238 = None
        view_239: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_47, [100, 1, 128]);  bmm_47 = None
        permute_212: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_239, [0, 2, 1]);  view_239 = None
        view_240: "f32[100, 128]" = torch.ops.aten.view.default(permute_212, [100, 128]);  permute_212 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_202: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_240, arg129_1);  view_240 = arg129_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_203: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_198, add_202);  add_198 = add_202 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_495: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_203, 2);  add_203 = None
        permute_213: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_495, [0, 2, 1]);  unsqueeze_495 = None
        unsqueeze_496: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg130_1, 2);  arg130_1 = None
        permute_214: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_496, [2, 1, 0]);  unsqueeze_496 = None
        permute_215: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_213, [0, 2, 1]);  permute_213 = None
        view_241: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_215, [1, 100, 128]);  permute_215 = None
        permute_216: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_214, [2, 1, 0]);  permute_214 = None
        view_242: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_216, [1, 128, 512]);  permute_216 = None
        bmm_48: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_241, view_242);  view_242 = None
        view_243: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_48, [100, 1, 512]);  bmm_48 = None
        permute_217: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_243, [0, 2, 1]);  view_243 = None
        view_244: "f32[100, 512]" = torch.ops.aten.view.default(permute_217, [100, 512]);  permute_217 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_498: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg131_1, 2);  arg131_1 = None
        permute_219: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_498, [2, 1, 0]);  unsqueeze_498 = None
        permute_221: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_219, [2, 1, 0]);  permute_219 = None
        view_246: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_221, [1, 128, 512]);  permute_221 = None
        bmm_49: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_241, view_246);  view_246 = None
        view_247: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_49, [100, 1, 512]);  bmm_49 = None
        permute_222: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_247, [0, 2, 1]);  view_247 = None
        view_248: "f32[100, 512]" = torch.ops.aten.view.default(permute_222, [100, 512]);  permute_222 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_304: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_248, view_248)
        mul_305: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_304, view_248);  mul_304 = None
        mul_306: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_305, 0.044715);  mul_305 = None
        add_204: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_248, mul_306);  mul_306 = None
        mul_307: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_204, 0.7978845608028654);  add_204 = None
        mul_308: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_248, 0.5);  view_248 = None
        tanh_9: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_307);  mul_307 = None
        add_205: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_9, 1);  tanh_9 = None
        mul_309: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_308, add_205);  mul_308 = add_205 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_310: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_309, view_244);  mul_309 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_500: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg132_1, 2);  arg132_1 = None
        permute_224: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_500, [2, 1, 0]);  unsqueeze_500 = None
        permute_226: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_224, [2, 1, 0]);  permute_224 = None
        view_250: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_226, [1, 128, 512]);  permute_226 = None
        bmm_50: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_241, view_250);  view_250 = None
        view_251: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_50, [100, 1, 512]);  bmm_50 = None
        permute_227: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_251, [0, 2, 1]);  view_251 = None
        view_252: "f32[100, 512]" = torch.ops.aten.view.default(permute_227, [100, 512]);  permute_227 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_311: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_252, view_252)
        mul_312: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_311, view_252);  mul_311 = None
        mul_313: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_312, 0.044715);  mul_312 = None
        add_206: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_252, mul_313);  mul_313 = None
        mul_314: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_206, 0.7978845608028654);  add_206 = None
        mul_315: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_252, 0.5);  view_252 = None
        tanh_10: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_314);  mul_314 = None
        add_207: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_10, 1);  tanh_10 = None
        mul_316: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_315, add_207);  mul_315 = add_207 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_502: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg133_1, 2);  arg133_1 = None
        permute_229: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_502, [2, 1, 0]);  unsqueeze_502 = None
        permute_231: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_229, [2, 1, 0]);  permute_229 = None
        view_254: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_231, [1, 128, 512]);  permute_231 = None
        bmm_51: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_241, view_254);  view_241 = view_254 = None
        view_255: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_51, [100, 1, 512]);  bmm_51 = None
        permute_232: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_255, [0, 2, 1]);  view_255 = None
        view_256: "f32[100, 512]" = torch.ops.aten.view.default(permute_232, [100, 512]);  permute_232 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_317: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_256, view_256)
        mul_318: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_317, view_256);  mul_317 = None
        mul_319: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_318, 0.044715);  mul_318 = None
        add_208: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_256, mul_319);  mul_319 = None
        mul_320: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_208, 0.7978845608028654);  add_208 = None
        mul_321: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_256, 0.5);  view_256 = None
        tanh_11: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_320);  mul_320 = None
        add_209: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_11, 1);  tanh_11 = None
        mul_322: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_321, add_209);  mul_321 = add_209 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_323: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_322, view_244);  mul_322 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_74: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_323, full_default_44);  mul_323 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_75: "f32[100, 512]" = torch.ops.aten.where.self(view_133, where_74, full_default_44);  where_74 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_4: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_2, where_75);  where_75 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_139: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_4, [clamp_max_2]);  scatter_add_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_56: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_139, clamp_min_33);  index_139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_78: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_56, full_default_44);  div_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_210: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_310, where_78);  mul_310 = where_78 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_325: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_316, view_244);  mul_316 = view_244 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_79: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_325, full_default_44);  mul_325 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_80: "f32[100, 512]" = torch.ops.aten.where.self(view_137, where_79, full_default_44);  where_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_6: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_4, where_80);  where_80 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_141: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_6, [clamp_max_4]);  scatter_add_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_57: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_141, clamp_min_36);  index_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_83: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_57, full_default_44);  div_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_211: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_210, where_83);  add_210 = where_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_504: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_211, 2);  add_211 = None
        permute_233: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_504, [0, 2, 1]);  unsqueeze_504 = None
        unsqueeze_505: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg134_1, 2);  arg134_1 = None
        permute_234: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_505, [2, 1, 0]);  unsqueeze_505 = None
        permute_235: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_233, [0, 2, 1]);  permute_233 = None
        view_265: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_235, [1, 100, 512]);  permute_235 = None
        permute_236: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_234, [2, 1, 0]);  permute_234 = None
        view_266: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_236, [1, 512, 128]);  permute_236 = None
        bmm_52: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_265, view_266);  view_265 = view_266 = None
        view_267: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_52, [100, 1, 128]);  bmm_52 = None
        permute_237: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_267, [0, 2, 1]);  view_267 = None
        view_268: "f32[100, 128]" = torch.ops.aten.view.default(permute_237, [100, 128]);  permute_237 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_212: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_268, arg135_1);  view_268 = arg135_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_213: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_191, add_212);  add_191 = add_212 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_25: "f32[100, 1]" = torch.ops.aten.mean.dim(add_213, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_25: "f32[100, 1]" = torch.ops.aten.var.correction(add_213, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_144: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_213, mean_25);  mean_25 = None
        add_214: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_25, 1e-05);  var_25 = None
        rsqrt_25: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_214);  add_214 = None
        mul_327: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_144, rsqrt_25);  sub_144 = rsqrt_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_328: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_327, arg136_1);  arg136_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_215: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_328, arg137_1);  mul_328 = arg137_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_515: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_215, 2);  add_215 = None
        permute_238: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_515, [0, 2, 1]);  unsqueeze_515 = None
        unsqueeze_516: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg138_1, 2);  arg138_1 = None
        permute_239: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_516, [2, 1, 0]);  unsqueeze_516 = None
        permute_240: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_238, [0, 2, 1]);  permute_238 = None
        view_269: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_240, [1, 100, 128]);  permute_240 = None
        permute_241: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_239, [2, 1, 0]);  permute_239 = None
        view_270: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_241, [1, 128, 60]);  permute_241 = None
        bmm_53: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_269, view_270);  view_269 = view_270 = None
        view_271: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_53, [100, 1, 60]);  bmm_53 = None
        permute_242: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_271, [0, 2, 1]);  view_271 = None
        view_272: "f32[100, 60]" = torch.ops.aten.view.default(permute_242, [100, 60]);  permute_242 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_336: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_272, 10.0);  view_272 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_273: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_336, [100, 20, 3]);  mul_336 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_220: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_119, view_273);  sum_119 = view_273 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_519: "f32[100, 20, 1, 3]" = torch.ops.aten.unsqueeze.default(add_220, -2);  add_220 = None
        mul_337: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_370, unsqueeze_519);  unsqueeze_370 = unsqueeze_519 = None
        sum_124: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_337, [-1]);  mul_337 = None
        add_221: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_124, unsqueeze_371);  sum_124 = unsqueeze_371 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_59: "f32[100, 3]" = torch.ops.aten.select.int(add_221, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_520: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_59, 1)
        unsqueeze_521: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_59, 0)
        sub_150: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_520, unsqueeze_521);  unsqueeze_520 = unsqueeze_521 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_338: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_150, sub_150);  sub_150 = None
        sum_125: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_338, [-1]);  mul_338 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_64: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_125, 1e-12);  sum_125 = None
        sqrt_49: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_64);  clamp_min_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_84: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_49, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_85: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_84, full_default);  where_84 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_148: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_85, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_86: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_148);  index_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_11: "f32[100, 100]" = torch.ops.aten.index_put.default(where_85, [unsqueeze_24, where_1], where_86);  where_85 = where_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_12 = torch.ops.aten.sort.stable(index_put_11, stable = True)
        getitem_56: "i64[100, 100]" = sort_12[1];  sort_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_353: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_56, 1, 0, 16);  getitem_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_149: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_11, [unsqueeze_24, slice_353]);  index_put_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_20: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_149, inf);  index_149 = None
        where_87: "i64[100, 16]" = torch.ops.aten.where.self(lt_20, slice_353, full_default_1);  lt_20 = slice_353 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_41: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_87], -1);  where_87 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_222: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_49, 1e-06);  sqrt_49 = None
        log_24: "f32[100, 100]" = torch.ops.aten.log.default(add_222);  add_222 = None
        mul_339: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_24, -3.0);  log_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_25: "f32[100, 100]" = torch.ops.aten.log.default(getitem_7)
        neg_20: "f32[100, 100]" = torch.ops.aten.neg.default(log_25);  log_25 = None
        log_26: "f32[100, 100]" = torch.ops.aten.log.default(neg_20);  neg_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_151: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_339, log_26);  mul_339 = log_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_21: "f32[100, 100]" = torch.ops.aten.neg.default(sub_151);  sub_151 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_88: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_21, full_default);  neg_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_89: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_88, full_default);  where_88 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_19: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_41, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_151: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_89, [unsqueeze_24, cat_41])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_90: "f32[100, 32]" = torch.ops.aten.where.self(ne_19, full_default_7, index_151);  ne_19 = index_151 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_12: "f32[100, 100]" = torch.ops.aten.index_put.default(where_89, [unsqueeze_24, cat_41], where_90);  where_89 = where_90 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_13 = torch.ops.aten.sort.stable(index_put_12, stable = True)
        getitem_58: "i64[100, 100]" = sort_13[1];  sort_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_362: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_58, 1, 0, 32);  getitem_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_152: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_12, [unsqueeze_24, slice_362]);  index_put_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_21: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_152, inf);  index_152 = None
        where_91: "i64[100, 32]" = torch.ops.aten.where.self(lt_21, slice_362, full_default_37);  lt_21 = slice_362 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_42: "i64[100, 64]" = torch.ops.aten.cat.default([cat_41, where_91], -1);  cat_41 = where_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_60: "i64[100, 48]" = torch.ops.aten.select.int(view_10, 0, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_61: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_25, 0, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_62: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_153: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_42])
        bitwise_and_47: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_153);  index_153 = None
        ne_20: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_42, -1)
        bitwise_and_48: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_47, ne_20);  bitwise_and_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_154: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_42])
        eq_21: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_154);  index_154 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_155: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_42])
        eq_22: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_155);  index_155 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_156: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_42])
        sub_152: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_156);  index_156 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_65: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_152, -32);  sub_152 = None
        clamp_max_11: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_65, 32);  clamp_min_65 = None
        add_223: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_11, 32);  clamp_max_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_92: "i64[100, 64]" = torch.ops.aten.where.self(eq_21, add_223, full_default_38);  eq_21 = add_223 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_93: "i64[100, 64]" = torch.ops.aten.where.self(eq_22, where_92, full_default_38);  eq_22 = where_92 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_157: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg139_1, [where_93]);  arg139_1 = where_93 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_542: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_221, 1)
        slice_369: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_542, 2, 0, 5)
        unsqueeze_543: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_369, 3);  slice_369 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_158: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_221, [cat_42])
        unsqueeze_544: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_158, 2)
        slice_373: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_544, 3, 0, 5);  unsqueeze_544 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_153: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_543, slice_373);  unsqueeze_543 = slice_373 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_340: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_153, sub_153);  sub_153 = None
        sum_126: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_340, [-1]);  mul_340 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_66: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_126, 1e-12);  sum_126 = None
        sqrt_50: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_66);  clamp_min_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_274: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_50, [100, 64, 25]);  sqrt_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_545: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_274, 3);  view_274 = None
        sub_154: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_545, add_29);  unsqueeze_545 = None
        pow_11: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_154, 2);  sub_154 = None
        neg_22: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_11);  pow_11 = None
        div_60: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_22, 1.890625);  neg_22 = None
        exp_12: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_60);  div_60 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_275: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_12, [100, 64, 400]);  exp_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_546: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_275, 3);  view_275 = None
        permute_243: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_546, [0, 1, 3, 2]);  unsqueeze_546 = None
        unsqueeze_547: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg140_1, 2);  arg140_1 = None
        unsqueeze_548: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_547, 3);  unsqueeze_547 = None
        permute_244: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_548, [2, 3, 1, 0]);  unsqueeze_548 = None
        permute_245: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_243, [0, 1, 3, 2]);  permute_243 = None
        view_276: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_245, [1, 6400, 400]);  permute_245 = None
        permute_246: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_244, [3, 2, 0, 1]);  permute_244 = None
        view_277: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_246, [1, 400, 64]);  permute_246 = None
        bmm_54: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_276, view_277);  view_276 = view_277 = None
        view_278: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_54, [100, 64, 1, 64]);  bmm_54 = None
        permute_247: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_278, [0, 1, 3, 2]);  view_278 = None
        view_279: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_247, [100, 64, 64]);  permute_247 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_227: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_157, view_279);  index_157 = view_279 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_63: "f32[100, 3]" = torch.ops.aten.select.int(add_221, 1, 0)
        select_65: "f32[100, 3]" = torch.ops.aten.select.int(add_221, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_155: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_65, select_59);  select_65 = None
        sub_156: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_63, select_59);  select_63 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_343: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_155, sub_155)
        sum_127: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_343, [-1]);  mul_343 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_67: "f32[100]" = torch.ops.aten.clamp_min.default(sum_127, 1e-12);  sum_127 = None
        sqrt_51: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_67);  clamp_min_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_549: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_51, -1);  sqrt_51 = None
        div_61: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_155, unsqueeze_549);  sub_155 = unsqueeze_549 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_344: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_156, div_61)
        sum_128: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_344, [-1]);  mul_344 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_550: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_128, -1);  sum_128 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_345: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_550, div_61);  unsqueeze_550 = None
        sub_157: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_156, mul_345);  sub_156 = mul_345 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_346: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_157, sub_157)
        sum_129: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_346, [-1]);  mul_346 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_68: "f32[100]" = torch.ops.aten.clamp_min.default(sum_129, 1e-12);  sum_129 = None
        sqrt_52: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_68);  clamp_min_68 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_551: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_52, -1);  sqrt_52 = None
        div_62: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_157, unsqueeze_551);  sub_157 = unsqueeze_551 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_159: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_61, [None, remainder])
        index_160: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_62, [None, remainder_1])
        mul_347: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_159, index_160);  index_159 = index_160 = None
        index_161: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_61, [None, remainder_1])
        index_162: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_62, [None, remainder])
        mul_348: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_161, index_162);  index_161 = index_162 = None
        sub_158: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_347, mul_348);  mul_347 = mul_348 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_552: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_61, 2);  div_61 = None
        unsqueeze_553: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_62, 2);  div_62 = None
        unsqueeze_554: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_158, 2);  sub_158 = None
        cat_43: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_552, unsqueeze_553, unsqueeze_554], -1);  unsqueeze_552 = unsqueeze_553 = unsqueeze_554 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_558: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_43, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_559: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_59, -2);  select_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_560: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_558, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_561: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_559, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_160: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_158, unsqueeze_561)
        unsqueeze_562: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_160, -1);  sub_160 = None
        mul_350: "f32[100, 64, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_560, unsqueeze_562);  unsqueeze_562 = None
        sum_131: "f32[100, 64, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_350, [-2]);  mul_350 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_351: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(sum_131, sum_131)
        sum_132: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_351, [-1]);  mul_351 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_69: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_132, 1e-12);  sum_132 = None
        sqrt_53: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_69);  clamp_min_69 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_563: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_53, -1);  sqrt_53 = None
        div_63: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(sum_131, unsqueeze_563);  sum_131 = unsqueeze_563 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        view_280: "f32[100, 64, 60]" = torch.ops.aten.view.default(div_63, [100, 64, 60]);  div_63 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_11: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_542, [100, 64, 20, 3]);  unsqueeze_542 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_44: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_11, index_158], -2);  expand_11 = index_158 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_161: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_44, unsqueeze_561);  cat_44 = unsqueeze_561 = None
        unsqueeze_569: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_161, -1);  sub_161 = None
        mul_352: "f32[100, 64, 40, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_560, unsqueeze_569);  unsqueeze_560 = unsqueeze_569 = None
        sum_133: "f32[100, 64, 40, 3]" = torch.ops.aten.sum.dim_IntList(mul_352, [-2]);  mul_352 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_353: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_133, sum_133)
        sum_134: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_353, [-1]);  mul_353 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_70: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_134, 1e-12);  sum_134 = None
        sqrt_54: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_70);  clamp_min_70 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_570: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_54, -1);  sqrt_54 = None
        div_64: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(sum_133, unsqueeze_570);  unsqueeze_570 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        view_281: "f32[100, 64, 120]" = torch.ops.aten.view.default(div_64, [100, 64, 120]);  div_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_354: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_133, 0.1);  sum_133 = None
        view_282: "f32[100, 64, 120]" = torch.ops.aten.view.default(mul_354, [100, 64, 120]);  mul_354 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_45: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_281, view_282], -1);  view_281 = view_282 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_571: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_280, 3);  view_280 = None
        permute_248: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_571, [0, 1, 3, 2]);  unsqueeze_571 = None
        unsqueeze_572: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg141_1, 2);  arg141_1 = None
        unsqueeze_573: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_572, 3);  unsqueeze_572 = None
        permute_249: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_573, [2, 3, 1, 0]);  unsqueeze_573 = None
        permute_250: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_248, [0, 1, 3, 2]);  permute_248 = None
        view_283: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_250, [1, 6400, 60]);  permute_250 = None
        permute_251: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_249, [3, 2, 0, 1]);  permute_249 = None
        view_284: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_251, [1, 60, 64]);  permute_251 = None
        bmm_55: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_283, view_284);  view_283 = view_284 = None
        view_285: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_55, [100, 64, 1, 64]);  bmm_55 = None
        permute_252: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_285, [0, 1, 3, 2]);  view_285 = None
        view_286: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_252, [100, 64, 64]);  permute_252 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_232: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_227, view_286);  add_227 = view_286 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_583: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_43, 1)
        permute_253: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_583, [0, 1, 3, 2]);  unsqueeze_583 = None
        index_168: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_43, [cat_42]);  cat_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:77 in rot_compose, code: return (a.unsqueeze(-1) * b.unsqueeze(-3)).sum(-2)
        unsqueeze_584: "f32[100, 1, 3, 3, 1]" = torch.ops.aten.unsqueeze.default(permute_253, -1);  permute_253 = None
        unsqueeze_585: "f32[100, 64, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(index_168, -3);  index_168 = None
        mul_362: "f32[100, 64, 3, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_584, unsqueeze_585);  unsqueeze_584 = unsqueeze_585 = None
        sum_139: "f32[100, 64, 3, 3]" = torch.ops.aten.sum.dim_IntList(mul_362, [-2]);  mul_362 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_287: "f32[100, 64, 9]" = torch.ops.aten.view.default(sum_139, [100, 64, 9]);  sum_139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_586: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_287, 3);  view_287 = None
        permute_254: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_586, [0, 1, 3, 2]);  unsqueeze_586 = None
        unsqueeze_587: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg142_1, 2);  arg142_1 = None
        unsqueeze_588: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_587, 3);  unsqueeze_587 = None
        permute_255: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_588, [2, 3, 1, 0]);  unsqueeze_588 = None
        permute_256: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_254, [0, 1, 3, 2]);  permute_254 = None
        view_288: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_256, [1, 6400, 9]);  permute_256 = None
        permute_257: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_255, [3, 2, 0, 1]);  permute_255 = None
        view_289: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_257, [1, 9, 64]);  permute_257 = None
        bmm_56: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_288, view_289);  view_288 = view_289 = None
        view_290: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_56, [100, 64, 1, 64]);  bmm_56 = None
        permute_258: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_290, [0, 1, 3, 2]);  view_290 = None
        view_291: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_258, [100, 64, 64]);  permute_258 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_237: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_232, view_291);  add_232 = view_291 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_589: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_45, 3);  cat_45 = None
        permute_259: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_589, [0, 1, 3, 2]);  unsqueeze_589 = None
        unsqueeze_590: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg143_1, 2);  arg143_1 = None
        unsqueeze_591: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_590, 3);  unsqueeze_590 = None
        permute_260: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_591, [2, 3, 1, 0]);  unsqueeze_591 = None
        permute_261: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_259, [0, 1, 3, 2]);  permute_259 = None
        view_292: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_261, [1, 6400, 240]);  permute_261 = None
        permute_262: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_260, [3, 2, 0, 1]);  permute_260 = None
        view_293: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_262, [1, 240, 64]);  permute_262 = None
        bmm_57: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_292, view_293);  view_292 = view_293 = None
        view_294: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_57, [100, 64, 1, 64]);  bmm_57 = None
        permute_263: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_294, [0, 1, 3, 2]);  view_294 = None
        view_295: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_263, [100, 64, 64]);  permute_263 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_238: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_237, view_295);  add_237 = view_295 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_26: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_238, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_26: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_238, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_167: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_238, mean_26);  add_238 = mean_26 = None
        add_239: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_26, 1e-05);  var_26 = None
        rsqrt_26: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_239);  add_239 = None
        mul_363: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_167, rsqrt_26);  sub_167 = rsqrt_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_364: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_363, arg144_1);  mul_363 = arg144_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_240: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_364, arg145_1);  mul_364 = arg145_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_592: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_240, 3);  add_240 = None
        permute_264: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_592, [0, 1, 3, 2]);  unsqueeze_592 = None
        unsqueeze_593: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg146_1, 2);  arg146_1 = None
        unsqueeze_594: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_593, 3);  unsqueeze_593 = None
        permute_265: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_594, [2, 3, 1, 0]);  unsqueeze_594 = None
        permute_266: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_264, [0, 1, 3, 2]);  permute_264 = None
        view_296: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_266, [1, 6400, 64]);  permute_266 = None
        permute_267: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_265, [3, 2, 0, 1]);  permute_265 = None
        view_297: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_267, [1, 64, 128]);  permute_267 = None
        bmm_58: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_296, view_297);  view_296 = view_297 = None
        view_298: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_58, [100, 64, 1, 128]);  bmm_58 = None
        permute_268: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_298, [0, 1, 3, 2]);  view_298 = None
        view_299: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_268, [100, 64, 128]);  permute_268 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_241: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_299, arg147_1);  view_299 = arg147_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_365: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_241, add_241)
        mul_366: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_365, add_241);  mul_365 = None
        mul_367: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_366, 0.044715);  mul_366 = None
        add_242: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_241, mul_367);  mul_367 = None
        mul_368: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_242, 0.7978845608028654);  add_242 = None
        mul_369: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_241, 0.5);  add_241 = None
        tanh_12: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_368);  mul_368 = None
        add_243: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_12, 1);  tanh_12 = None
        mul_370: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_369, add_243);  mul_369 = add_243 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_595: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_370, 3);  mul_370 = None
        permute_269: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_595, [0, 1, 3, 2]);  unsqueeze_595 = None
        unsqueeze_596: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg148_1, 2);  arg148_1 = None
        unsqueeze_597: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_596, 3);  unsqueeze_596 = None
        permute_270: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_597, [2, 3, 1, 0]);  unsqueeze_597 = None
        permute_271: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_269, [0, 1, 3, 2]);  permute_269 = None
        view_300: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_271, [1, 6400, 128]);  permute_271 = None
        permute_272: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_270, [3, 2, 0, 1]);  permute_270 = None
        view_301: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_272, [1, 128, 64]);  permute_272 = None
        bmm_59: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_300, view_301);  view_300 = view_301 = None
        view_302: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_59, [100, 64, 1, 64]);  bmm_59 = None
        permute_273: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_302, [0, 1, 3, 2]);  view_302 = None
        view_303: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_273, [100, 64, 64]);  permute_273 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_244: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_303, arg149_1);  view_303 = arg149_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_372: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_327, arg150_1);  mul_327 = arg150_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_246: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_372, arg151_1);  mul_372 = arg151_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_67: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_221, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_69: "f32[100, 3]" = torch.ops.aten.select.int(div_67, 1, 0)
        select_70: "f32[100, 3]" = torch.ops.aten.select.int(div_67, 1, 1)
        select_71: "f32[100, 3]" = torch.ops.aten.select.int(div_67, 1, 2);  div_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_169: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_71, select_70);  select_71 = None
        sub_170: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_69, select_70);  select_69 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_373: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_169, sub_169)
        sum_140: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_373, [-1]);  mul_373 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_73: "f32[100]" = torch.ops.aten.clamp_min.default(sum_140, 1e-12);  sum_140 = None
        sqrt_57: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_73);  clamp_min_73 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_598: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_57, -1);  sqrt_57 = None
        div_68: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_169, unsqueeze_598);  sub_169 = unsqueeze_598 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_374: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_170, div_68)
        sum_141: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_374, [-1]);  mul_374 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_599: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_141, -1);  sum_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_375: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_599, div_68);  unsqueeze_599 = None
        sub_171: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_170, mul_375);  sub_170 = mul_375 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_376: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_171, sub_171)
        sum_142: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_376, [-1]);  mul_376 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_74: "f32[100]" = torch.ops.aten.clamp_min.default(sum_142, 1e-12);  sum_142 = None
        sqrt_58: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_74);  clamp_min_74 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_600: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_58, -1);  sqrt_58 = None
        div_69: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_171, unsqueeze_600);  sub_171 = unsqueeze_600 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_169: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_68, [None, remainder])
        index_170: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_69, [None, remainder_1])
        mul_377: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_169, index_170);  index_169 = index_170 = None
        index_171: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_68, [None, remainder_1])
        index_172: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_69, [None, remainder])
        mul_378: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_171, index_172);  index_171 = index_172 = None
        sub_172: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_377, mul_378);  mul_377 = mul_378 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_601: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_68, 2);  div_68 = None
        unsqueeze_602: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_69, 2);  div_69 = None
        unsqueeze_603: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_172, 2);  sub_172 = None
        cat_47: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_601, unsqueeze_602, unsqueeze_603], -1);  unsqueeze_601 = unsqueeze_602 = unsqueeze_603 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_28: "f32[100, 1]" = torch.ops.aten.mean.dim(add_246, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_28: "f32[100, 1]" = torch.ops.aten.var.correction(add_246, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_174: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_246, mean_28);  add_246 = mean_28 = None
        add_251: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_28, 1e-05);  var_28 = None
        rsqrt_28: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_251);  add_251 = None
        mul_380: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_174, rsqrt_28);  sub_174 = rsqrt_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_381: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_380, arg152_1);  mul_380 = arg152_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_252: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_381, arg153_1);  mul_381 = arg153_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_607: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_252, 2);  add_252 = None
        permute_274: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_607, [0, 2, 1]);  unsqueeze_607 = None
        unsqueeze_608: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg154_1, 2);  arg154_1 = None
        permute_275: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_608, [2, 1, 0]);  unsqueeze_608 = None
        permute_276: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_274, [0, 2, 1]);  permute_274 = None
        view_304: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_276, [1, 100, 128]);  permute_276 = None
        permute_277: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_275, [2, 1, 0]);  permute_275 = None
        view_305: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_277, [1, 128, 768]);  permute_277 = None
        bmm_60: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_304, view_305);  view_305 = None
        view_306: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_60, [100, 1, 768]);  bmm_60 = None
        permute_278: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_306, [0, 2, 1]);  view_306 = None
        view_307: "f32[100, 768]" = torch.ops.aten.view.default(permute_278, [100, 768]);  permute_278 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_308: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_307, [100, 8, 96]);  view_307 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_4 = torch.ops.aten.split.Tensor(view_308, 32, -1);  view_308 = None
        getitem_59: "f32[100, 8, 32]" = split_4[0]
        getitem_60: "f32[100, 8, 32]" = split_4[1]
        getitem_61: "f32[100, 8, 32]" = split_4[2];  split_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_29: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_59, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_29: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_59, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_175: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_59, mean_29);  getitem_59 = mean_29 = None
        add_253: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_29, 1e-05);  var_29 = None
        rsqrt_29: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_253);  add_253 = None
        mul_382: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_175, rsqrt_29);  sub_175 = rsqrt_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_383: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_382, arg155_1);  mul_382 = arg155_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_254: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_383, arg156_1);  mul_383 = arg156_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_30: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_60, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_30: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_60, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_176: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_60, mean_30);  getitem_60 = mean_30 = None
        add_255: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_30, 1e-05);  var_30 = None
        rsqrt_30: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_255);  add_255 = None
        mul_384: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_176, rsqrt_30);  sub_176 = rsqrt_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_385: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_384, arg157_1);  mul_384 = arg157_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_256: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_385, arg158_1);  mul_385 = arg158_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_610: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg159_1, 2);  arg159_1 = None
        permute_280: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_610, [2, 1, 0]);  unsqueeze_610 = None
        permute_282: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_280, [2, 1, 0]);  permute_280 = None
        view_310: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_282, [1, 128, 576]);  permute_282 = None
        bmm_61: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_304, view_310);  view_304 = view_310 = None
        view_311: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_61, [100, 1, 576]);  bmm_61 = None
        permute_283: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_311, [0, 2, 1]);  view_311 = None
        view_312: "f32[100, 576]" = torch.ops.aten.view.default(permute_283, [100, 576]);  permute_283 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_313: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_312, [100, 192, 3]);  view_312 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_611: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_47, -3);  cat_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_612: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_70, -2);  select_70 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_613: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_313, -2);  view_313 = None
        mul_386: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_611, unsqueeze_613);  unsqueeze_613 = None
        sum_144: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_386, [-1]);  mul_386 = None
        add_257: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_144, unsqueeze_612);  sum_144 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_314: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_257, [100, 8, 24, 3]);  add_257 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_400: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_314, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_403: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_314, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_406: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_314, 2, 16, 9223372036854775807);  view_314 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_614: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_244, 3)
        permute_284: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_614, [0, 1, 3, 2]);  unsqueeze_614 = None
        unsqueeze_615: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg160_1, 2);  arg160_1 = None
        unsqueeze_616: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_615, 3);  unsqueeze_615 = None
        permute_285: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_616, [2, 3, 1, 0]);  unsqueeze_616 = None
        permute_286: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_284, [0, 1, 3, 2]);  permute_284 = None
        view_315: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_286, [1, 6400, 64]);  permute_286 = None
        permute_287: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_285, [3, 2, 0, 1]);  permute_285 = None
        view_316: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_287, [1, 64, 8]);  permute_287 = None
        bmm_62: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_315, view_316);  view_315 = view_316 = None
        view_317: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_62, [100, 64, 1, 8]);  bmm_62 = None
        permute_288: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_317, [0, 1, 3, 2]);  view_317 = None
        view_318: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_288, [100, 64, 8]);  permute_288 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_13: "f32[8]" = torch.ops.aten.exp.default(arg161_1)
        log1p_4: "f32[8]" = torch.ops.aten.log1p.default(exp_13);  exp_13 = None
        gt_4: "b8[8]" = torch.ops.aten.gt.Scalar(arg161_1, 20)
        where_94: "f32[8]" = torch.ops.aten.where.self(gt_4, arg161_1, log1p_4);  gt_4 = arg161_1 = log1p_4 = None
        view_319: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_94, [1, 1, 8]);  where_94 = None
        mul_387: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_319, 0.16666666666666666);  view_319 = None
        div_70: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_387, 2);  mul_387 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_617: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_400, 1);  slice_400 = None
        index_173: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_403, [cat_42]);  slice_403 = None
        sub_177: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_617, index_173);  unsqueeze_617 = index_173 = None
        pow_12: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_177, 2);  sub_177 = None
        sum_145: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_12, [-1, -2]);  pow_12 = None
        mul_388: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_70, sum_145);  div_70 = sum_145 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_618: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_254, 1);  add_254 = None
        index_174: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_256, [cat_42]);  add_256 = None
        mul_389: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_618, index_174);  unsqueeze_618 = index_174 = None
        sum_146: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(mul_389, [-1]);  mul_389 = None
        mul_390: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sum_146, 0.1767766952966369);  sum_146 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_258: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_390, view_318);  mul_390 = view_318 = None
        sub_178: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_258, mul_388);  add_258 = mul_388 = None
        mul_391: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_178, 0.5773502691896257);  sub_178 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_49: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_48, ne_20);  bitwise_and_48 = ne_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_619: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_49, 2);  bitwise_and_49 = None
        where_95: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_619, mul_391, full_default_39);  mul_391 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_4: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_95, [-2], True)
        sub_179: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(where_95, amax_4);  where_95 = amax_4 = None
        exp_14: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_179);  sub_179 = None
        sum_147: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_14, [-2], True)
        div_71: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_14, sum_147);  exp_14 = sum_147 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_96: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_619, div_71, full_default_40);  unsqueeze_619 = div_71 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_621: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_96, 3);  where_96 = None
        unsqueeze_622: "f32[100, 64, 1, 64]" = torch.ops.aten.unsqueeze.default(add_244, 2);  add_244 = None
        mul_392: "f32[100, 64, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_621, unsqueeze_622);  unsqueeze_622 = None
        sum_148: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_392, [1]);  mul_392 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_175: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_61, [cat_42]);  getitem_61 = None
        mul_393: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_621, index_175);  index_175 = None
        sum_149: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_393, [1]);  mul_393 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_625: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_621, 4);  unsqueeze_621 = None
        index_176: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_406, [cat_42]);  slice_406 = cat_42 = None
        mul_394: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_625, index_176);  unsqueeze_625 = index_176 = None
        sum_150: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_394, [1]);  mul_394 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_628: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_611, -3);  unsqueeze_611 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_629: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_612, -2);  unsqueeze_612 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_180: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_150, unsqueeze_629);  sum_150 = unsqueeze_629 = None
        unsqueeze_630: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_180, -1);  sub_180 = None
        mul_395: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_628, unsqueeze_630);  unsqueeze_628 = unsqueeze_630 = None
        sum_151: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_395, [-2]);  mul_395 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_396: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_151, sum_151)
        sum_152: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_396, [-1]);  mul_396 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_75: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_152, 1e-12);  sum_152 = None
        sqrt_59: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_75);  clamp_min_75 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_320: "f32[100, 512]" = torch.ops.aten.view.default(sum_148, [100, -1]);  sum_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_321: "f32[100, 256]" = torch.ops.aten.view.default(sum_149, [100, -1]);  sum_149 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_322: "f32[100, 192]" = torch.ops.aten.view.default(sum_151, [100, -1]);  sum_151 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_323: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_59, [100, -1]);  sqrt_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_48: "f32[100, 1024]" = torch.ops.aten.cat.default([view_320, view_321, view_322, view_323], -1);  view_320 = view_321 = view_322 = view_323 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_631: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_48, 2);  cat_48 = None
        permute_289: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_631, [0, 2, 1]);  unsqueeze_631 = None
        unsqueeze_632: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg162_1, 2);  arg162_1 = None
        permute_290: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_632, [2, 1, 0]);  unsqueeze_632 = None
        permute_291: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_289, [0, 2, 1]);  permute_289 = None
        view_324: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_291, [1, 100, 1024]);  permute_291 = None
        permute_292: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_290, [2, 1, 0]);  permute_290 = None
        view_325: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_292, [1, 1024, 128]);  permute_292 = None
        bmm_63: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_324, view_325);  view_324 = view_325 = None
        view_326: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_63, [100, 1, 128]);  bmm_63 = None
        permute_293: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_326, [0, 2, 1]);  view_326 = None
        view_327: "f32[100, 128]" = torch.ops.aten.view.default(permute_293, [100, 128]);  permute_293 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_259: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_327, arg163_1);  view_327 = arg163_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_260: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_213, add_259);  add_213 = add_259 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_31: "f32[100, 1]" = torch.ops.aten.mean.dim(add_260, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_31: "f32[100, 1]" = torch.ops.aten.var.correction(add_260, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_181: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_260, mean_31);  mean_31 = None
        add_261: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_31, 1e-05);  var_31 = None
        rsqrt_31: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_261);  add_261 = None
        mul_397: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_181, rsqrt_31);  sub_181 = rsqrt_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_398: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_397, arg164_1);  mul_397 = arg164_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_262: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_398, arg165_1);  mul_398 = arg165_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_32: "f32[100, 1]" = torch.ops.aten.mean.dim(add_262, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_32: "f32[100, 1]" = torch.ops.aten.var.correction(add_262, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_187: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_262, mean_32);  add_262 = mean_32 = None
        add_267: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_32, 1e-05);  var_32 = None
        rsqrt_32: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_267);  add_267 = None
        mul_406: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_187, rsqrt_32);  sub_187 = rsqrt_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_407: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_406, arg166_1);  mul_406 = arg166_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_268: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_407, arg167_1);  mul_407 = arg167_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_642: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_268, 2);  add_268 = None
        permute_294: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_642, [0, 2, 1]);  unsqueeze_642 = None
        unsqueeze_643: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg168_1, 2);  arg168_1 = None
        permute_295: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_643, [2, 1, 0]);  unsqueeze_643 = None
        permute_296: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_294, [0, 2, 1]);  permute_294 = None
        view_328: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_296, [1, 100, 128]);  permute_296 = None
        permute_297: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_295, [2, 1, 0]);  permute_295 = None
        view_329: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_297, [1, 128, 768]);  permute_297 = None
        bmm_64: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_328, view_329);  view_329 = None
        view_330: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_64, [100, 1, 768]);  bmm_64 = None
        permute_298: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_330, [0, 2, 1]);  view_330 = None
        view_331: "f32[100, 768]" = torch.ops.aten.view.default(permute_298, [100, 768]);  permute_298 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_332: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_331, [100, 8, 96]);  view_331 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_5 = torch.ops.aten.split.Tensor(view_332, 32, -1);  view_332 = None
        getitem_62: "f32[100, 8, 32]" = split_5[0]
        getitem_63: "f32[100, 8, 32]" = split_5[1]
        getitem_64: "f32[100, 8, 32]" = split_5[2];  split_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_33: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_62, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_33: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_62, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_188: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_62, mean_33);  getitem_62 = mean_33 = None
        add_269: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_33, 1e-05);  var_33 = None
        rsqrt_33: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_269);  add_269 = None
        mul_408: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_188, rsqrt_33);  sub_188 = rsqrt_33 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_409: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_408, arg169_1);  mul_408 = arg169_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_270: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_409, arg170_1);  mul_409 = arg170_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_34: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_63, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_34: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_63, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_189: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_63, mean_34);  getitem_63 = mean_34 = None
        add_271: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_34, 1e-05);  var_34 = None
        rsqrt_34: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_271);  add_271 = None
        mul_410: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_189, rsqrt_34);  sub_189 = rsqrt_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_411: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_410, arg171_1);  mul_410 = arg171_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_272: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_411, arg172_1);  mul_411 = arg172_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_645: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg173_1, 2);  arg173_1 = None
        permute_300: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_645, [2, 1, 0]);  unsqueeze_645 = None
        permute_302: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_300, [2, 1, 0]);  permute_300 = None
        view_334: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_302, [1, 128, 576]);  permute_302 = None
        bmm_65: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_328, view_334);  view_328 = view_334 = None
        view_335: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_65, [100, 1, 576]);  bmm_65 = None
        permute_303: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_335, [0, 2, 1]);  view_335 = None
        view_336: "f32[100, 576]" = torch.ops.aten.view.default(permute_303, [100, 576]);  permute_303 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_337: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_336, [100, 192, 3]);  view_336 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_648: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_337, -2);  view_337 = None
        mul_412: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_270, unsqueeze_648);  unsqueeze_648 = None
        sum_157: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_412, [-1]);  mul_412 = None
        add_273: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_157, unsqueeze_271);  sum_157 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_338: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_273, [100, 8, 24, 3]);  add_273 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_421: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_338, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_424: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_338, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_427: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_338, 2, 16, 9223372036854775807);  view_338 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_649: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_61, 3)
        permute_304: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_649, [0, 1, 3, 2]);  unsqueeze_649 = None
        unsqueeze_650: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg174_1, 2);  arg174_1 = None
        unsqueeze_651: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_650, 3);  unsqueeze_650 = None
        permute_305: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_651, [2, 3, 1, 0]);  unsqueeze_651 = None
        permute_306: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_304, [0, 1, 3, 2]);  permute_304 = None
        view_339: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_306, [1, 4800, 64]);  permute_306 = None
        permute_307: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_305, [3, 2, 0, 1]);  permute_305 = None
        view_340: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_307, [1, 64, 8]);  permute_307 = None
        bmm_66: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_339, view_340);  view_339 = view_340 = None
        view_341: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_66, [100, 48, 1, 8]);  bmm_66 = None
        permute_308: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_341, [0, 1, 3, 2]);  view_341 = None
        view_342: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_308, [100, 48, 8]);  permute_308 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_15: "f32[8]" = torch.ops.aten.exp.default(arg175_1)
        log1p_5: "f32[8]" = torch.ops.aten.log1p.default(exp_15);  exp_15 = None
        gt_5: "b8[8]" = torch.ops.aten.gt.Scalar(arg175_1, 20)
        where_97: "f32[8]" = torch.ops.aten.where.self(gt_5, arg175_1, log1p_5);  gt_5 = arg175_1 = log1p_5 = None
        view_343: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_97, [1, 1, 8]);  where_97 = None
        mul_413: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_343, 0.16666666666666666);  view_343 = None
        div_75: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_413, 2);  mul_413 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_652: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_421, 1);  slice_421 = None
        index_181: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_424, [select_60]);  slice_424 = None
        sub_190: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_652, index_181);  unsqueeze_652 = index_181 = None
        pow_13: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_190, 2);  sub_190 = None
        sum_158: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_13, [-1, -2]);  pow_13 = None
        mul_414: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_75, sum_158);  div_75 = sum_158 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_653: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_270, 1);  add_270 = None
        index_182: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_272, [select_60]);  add_272 = None
        mul_415: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_653, index_182);  unsqueeze_653 = index_182 = None
        sum_159: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(mul_415, [-1]);  mul_415 = None
        mul_416: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sum_159, 0.1767766952966369);  sum_159 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_274: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_416, view_342);  mul_416 = view_342 = None
        sub_191: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_274, mul_414);  add_274 = mul_414 = None
        mul_417: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_191, 0.5773502691896257);  sub_191 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_22: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_60, -1)
        bitwise_and_50: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_62, ne_22);  select_62 = ne_22 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_654: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_50, 2);  bitwise_and_50 = None
        where_98: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_654, mul_417, full_default_41);  mul_417 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_5: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_98, [-2], True)
        sub_192: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(where_98, amax_5);  where_98 = amax_5 = None
        exp_16: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_192);  sub_192 = None
        sum_160: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_16, [-2], True)
        div_76: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_16, sum_160);  exp_16 = sum_160 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_99: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_654, div_76, full_default_42);  unsqueeze_654 = div_76 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_656: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_99, 3);  where_99 = None
        unsqueeze_657: "f32[100, 48, 1, 64]" = torch.ops.aten.unsqueeze.default(select_61, 2);  select_61 = None
        mul_418: "f32[100, 48, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_656, unsqueeze_657);  unsqueeze_657 = None
        sum_161: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_418, [1]);  mul_418 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_183: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_64, [select_60]);  getitem_64 = None
        mul_419: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_656, index_183);  index_183 = None
        sum_162: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_419, [1]);  mul_419 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_660: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_656, 4);  unsqueeze_656 = None
        index_184: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_427, [select_60]);  slice_427 = select_60 = None
        mul_420: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_660, index_184);  unsqueeze_660 = index_184 = None
        sum_163: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_420, [1]);  mul_420 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_193: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_163, unsqueeze_288);  sum_163 = None
        unsqueeze_665: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_193, -1);  sub_193 = None
        mul_421: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_287, unsqueeze_665);  unsqueeze_665 = None
        sum_164: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_421, [-2]);  mul_421 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_422: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_164, sum_164)
        sum_165: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_422, [-1]);  mul_422 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_78: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_165, 1e-12);  sum_165 = None
        sqrt_62: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_78);  clamp_min_78 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_344: "f32[100, 512]" = torch.ops.aten.view.default(sum_161, [100, -1]);  sum_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_345: "f32[100, 256]" = torch.ops.aten.view.default(sum_162, [100, -1]);  sum_162 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_346: "f32[100, 192]" = torch.ops.aten.view.default(sum_164, [100, -1]);  sum_164 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_347: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_62, [100, -1]);  sqrt_62 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_50: "f32[100, 1024]" = torch.ops.aten.cat.default([view_344, view_345, view_346, view_347], -1);  view_344 = view_345 = view_346 = view_347 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_666: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_50, 2);  cat_50 = None
        permute_309: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_666, [0, 2, 1]);  unsqueeze_666 = None
        unsqueeze_667: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg176_1, 2);  arg176_1 = None
        permute_310: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_667, [2, 1, 0]);  unsqueeze_667 = None
        permute_311: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_309, [0, 2, 1]);  permute_309 = None
        view_348: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_311, [1, 100, 1024]);  permute_311 = None
        permute_312: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_310, [2, 1, 0]);  permute_310 = None
        view_349: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_312, [1, 1024, 128]);  permute_312 = None
        bmm_67: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_348, view_349);  view_348 = view_349 = None
        view_350: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_67, [100, 1, 128]);  bmm_67 = None
        permute_313: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_350, [0, 2, 1]);  view_350 = None
        view_351: "f32[100, 128]" = torch.ops.aten.view.default(permute_313, [100, 128]);  permute_313 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_275: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_351, arg177_1);  view_351 = arg177_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_276: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_260, add_275);  add_260 = add_275 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_35: "f32[100, 1]" = torch.ops.aten.mean.dim(add_276, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_35: "f32[100, 1]" = torch.ops.aten.var.correction(add_276, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_194: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_276, mean_35);  mean_35 = None
        add_277: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_35, 1e-05);  var_35 = None
        rsqrt_35: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_277);  add_277 = None
        mul_423: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_194, rsqrt_35);  sub_194 = rsqrt_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_424: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_423, arg178_1);  mul_423 = arg178_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_278: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_424, arg179_1);  mul_424 = arg179_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_199: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_221, unsqueeze_559)
        unsqueeze_676: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_199, -1);  sub_199 = None
        mul_431: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_558, unsqueeze_676);  unsqueeze_676 = None
        sum_169: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_431, [-2]);  mul_431 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        view_352: "f32[100, 60]" = torch.ops.aten.view.default(sum_169, [100, -1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_678: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg180_1, 2);  arg180_1 = None
        permute_315: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_678, [2, 1, 0]);  unsqueeze_678 = None
        permute_317: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_315, [2, 1, 0]);  permute_315 = None
        view_354: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_317, [1, 128, 128]);  permute_317 = None
        bmm_68: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_105, view_354);  view_354 = None
        view_355: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_68, [100, 1, 128]);  bmm_68 = None
        permute_318: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_355, [0, 2, 1]);  view_355 = None
        view_356: "f32[100, 128]" = torch.ops.aten.view.default(permute_318, [100, 128]);  permute_318 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_283: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_278, view_356);  add_278 = view_356 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_679: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_352, 2);  view_352 = None
        permute_319: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_679, [0, 2, 1]);  unsqueeze_679 = None
        unsqueeze_680: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg181_1, 2);  arg181_1 = None
        permute_320: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_680, [2, 1, 0]);  unsqueeze_680 = None
        permute_321: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_319, [0, 2, 1]);  permute_319 = None
        view_357: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_321, [1, 100, 60]);  permute_321 = None
        permute_322: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_320, [2, 1, 0]);  permute_320 = None
        view_358: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_322, [1, 60, 256]);  permute_322 = None
        bmm_69: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_357, view_358);  view_357 = view_358 = None
        view_359: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_69, [100, 1, 256]);  bmm_69 = None
        permute_323: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_359, [0, 2, 1]);  view_359 = None
        view_360: "f32[100, 256]" = torch.ops.aten.view.default(permute_323, [100, 256]);  permute_323 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_284: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_360, arg182_1);  view_360 = arg182_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_432: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_284, add_284)
        mul_433: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_432, add_284);  mul_432 = None
        mul_434: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_433, 0.044715);  mul_433 = None
        add_285: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_284, mul_434);  mul_434 = None
        mul_435: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_285, 0.7978845608028654);  add_285 = None
        mul_436: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_284, 0.5);  add_284 = None
        tanh_13: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_435);  mul_435 = None
        add_286: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_13, 1);  tanh_13 = None
        mul_437: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_436, add_286);  mul_436 = add_286 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_681: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_437, 2);  mul_437 = None
        permute_324: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_681, [0, 2, 1]);  unsqueeze_681 = None
        unsqueeze_682: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg183_1, 2);  arg183_1 = None
        permute_325: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_682, [2, 1, 0]);  unsqueeze_682 = None
        permute_326: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_324, [0, 2, 1]);  permute_324 = None
        view_361: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_326, [1, 100, 256]);  permute_326 = None
        permute_327: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_325, [2, 1, 0]);  permute_325 = None
        view_362: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_327, [1, 256, 128]);  permute_327 = None
        bmm_70: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_361, view_362);  view_361 = view_362 = None
        view_363: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_70, [100, 1, 128]);  bmm_70 = None
        permute_328: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_363, [0, 2, 1]);  view_363 = None
        view_364: "f32[100, 128]" = torch.ops.aten.view.default(permute_328, [100, 128]);  permute_328 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_287: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_364, arg184_1);  view_364 = arg184_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_288: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_283, add_287);  add_283 = add_287 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_683: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_288, 2);  add_288 = None
        permute_329: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_683, [0, 2, 1]);  unsqueeze_683 = None
        unsqueeze_684: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg185_1, 2);  arg185_1 = None
        permute_330: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_684, [2, 1, 0]);  unsqueeze_684 = None
        permute_331: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_329, [0, 2, 1]);  permute_329 = None
        view_365: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_331, [1, 100, 128]);  permute_331 = None
        permute_332: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_330, [2, 1, 0]);  permute_330 = None
        view_366: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_332, [1, 128, 512]);  permute_332 = None
        bmm_71: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_365, view_366);  view_366 = None
        view_367: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_71, [100, 1, 512]);  bmm_71 = None
        permute_333: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_367, [0, 2, 1]);  view_367 = None
        view_368: "f32[100, 512]" = torch.ops.aten.view.default(permute_333, [100, 512]);  permute_333 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_686: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg186_1, 2);  arg186_1 = None
        permute_335: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_686, [2, 1, 0]);  unsqueeze_686 = None
        permute_337: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_335, [2, 1, 0]);  permute_335 = None
        view_370: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_337, [1, 128, 512]);  permute_337 = None
        bmm_72: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_365, view_370);  view_370 = None
        view_371: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_72, [100, 1, 512]);  bmm_72 = None
        permute_338: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_371, [0, 2, 1]);  view_371 = None
        view_372: "f32[100, 512]" = torch.ops.aten.view.default(permute_338, [100, 512]);  permute_338 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_438: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_372, view_372)
        mul_439: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_438, view_372);  mul_438 = None
        mul_440: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_439, 0.044715);  mul_439 = None
        add_289: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_372, mul_440);  mul_440 = None
        mul_441: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_289, 0.7978845608028654);  add_289 = None
        mul_442: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_372, 0.5);  view_372 = None
        tanh_14: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_441);  mul_441 = None
        add_290: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_14, 1);  tanh_14 = None
        mul_443: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_442, add_290);  mul_442 = add_290 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_444: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_443, view_368);  mul_443 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_688: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg187_1, 2);  arg187_1 = None
        permute_340: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_688, [2, 1, 0]);  unsqueeze_688 = None
        permute_342: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_340, [2, 1, 0]);  permute_340 = None
        view_374: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_342, [1, 128, 512]);  permute_342 = None
        bmm_73: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_365, view_374);  view_374 = None
        view_375: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_73, [100, 1, 512]);  bmm_73 = None
        permute_343: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_375, [0, 2, 1]);  view_375 = None
        view_376: "f32[100, 512]" = torch.ops.aten.view.default(permute_343, [100, 512]);  permute_343 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_445: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_376, view_376)
        mul_446: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_445, view_376);  mul_445 = None
        mul_447: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_446, 0.044715);  mul_446 = None
        add_291: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_376, mul_447);  mul_447 = None
        mul_448: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_291, 0.7978845608028654);  add_291 = None
        mul_449: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_376, 0.5);  view_376 = None
        tanh_15: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_448);  mul_448 = None
        add_292: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_15, 1);  tanh_15 = None
        mul_450: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_449, add_292);  mul_449 = add_292 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_690: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg188_1, 2);  arg188_1 = None
        permute_345: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_690, [2, 1, 0]);  unsqueeze_690 = None
        permute_347: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_345, [2, 1, 0]);  permute_345 = None
        view_378: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_347, [1, 128, 512]);  permute_347 = None
        bmm_74: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_365, view_378);  view_365 = view_378 = None
        view_379: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_74, [100, 1, 512]);  bmm_74 = None
        permute_348: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_379, [0, 2, 1]);  view_379 = None
        view_380: "f32[100, 512]" = torch.ops.aten.view.default(permute_348, [100, 512]);  permute_348 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_451: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_380, view_380)
        mul_452: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_451, view_380);  mul_451 = None
        mul_453: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_452, 0.044715);  mul_452 = None
        add_293: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_380, mul_453);  mul_453 = None
        mul_454: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_293, 0.7978845608028654);  add_293 = None
        mul_455: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_380, 0.5);  view_380 = None
        tanh_16: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_454);  mul_454 = None
        add_294: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_16, 1);  tanh_16 = None
        mul_456: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_455, add_294);  mul_455 = add_294 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_457: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_456, view_368);  mul_456 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_100: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_457, full_default_44);  mul_457 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_101: "f32[100, 512]" = torch.ops.aten.where.self(view_133, where_100, full_default_44);  where_100 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_8: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_2, where_101);  where_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_189: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_8, [clamp_max_2]);  scatter_add_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_79: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_189, clamp_min_33);  index_189 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_104: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_79, full_default_44);  div_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_295: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_444, where_104);  mul_444 = where_104 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_459: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_450, view_368);  mul_450 = view_368 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_105: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_459, full_default_44);  mul_459 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_106: "f32[100, 512]" = torch.ops.aten.where.self(view_137, where_105, full_default_44);  where_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_10: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_4, where_106);  where_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_191: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_10, [clamp_max_4]);  scatter_add_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_80: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_191, clamp_min_36);  index_191 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_109: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_80, full_default_44);  div_80 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_296: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_295, where_109);  add_295 = where_109 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_692: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_296, 2);  add_296 = None
        permute_349: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_692, [0, 2, 1]);  unsqueeze_692 = None
        unsqueeze_693: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg189_1, 2);  arg189_1 = None
        permute_350: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_693, [2, 1, 0]);  unsqueeze_693 = None
        permute_351: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_349, [0, 2, 1]);  permute_349 = None
        view_389: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_351, [1, 100, 512]);  permute_351 = None
        permute_352: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_350, [2, 1, 0]);  permute_350 = None
        view_390: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_352, [1, 512, 128]);  permute_352 = None
        bmm_75: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_389, view_390);  view_389 = view_390 = None
        view_391: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_75, [100, 1, 128]);  bmm_75 = None
        permute_353: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_391, [0, 2, 1]);  view_391 = None
        view_392: "f32[100, 128]" = torch.ops.aten.view.default(permute_353, [100, 128]);  permute_353 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_297: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_392, arg190_1);  view_392 = arg190_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_298: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_276, add_297);  add_276 = add_297 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_36: "f32[100, 1]" = torch.ops.aten.mean.dim(add_298, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_36: "f32[100, 1]" = torch.ops.aten.var.correction(add_298, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_200: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_298, mean_36);  mean_36 = None
        add_299: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_36, 1e-05);  var_36 = None
        rsqrt_36: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_299);  add_299 = None
        mul_461: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_200, rsqrt_36);  sub_200 = rsqrt_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_462: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_461, arg191_1);  arg191_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_300: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_462, arg192_1);  mul_462 = arg192_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_703: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_300, 2);  add_300 = None
        permute_354: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_703, [0, 2, 1]);  unsqueeze_703 = None
        unsqueeze_704: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg193_1, 2);  arg193_1 = None
        permute_355: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_704, [2, 1, 0]);  unsqueeze_704 = None
        permute_356: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_354, [0, 2, 1]);  permute_354 = None
        view_393: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_356, [1, 100, 128]);  permute_356 = None
        permute_357: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_355, [2, 1, 0]);  permute_355 = None
        view_394: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_357, [1, 128, 60]);  permute_357 = None
        bmm_76: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_393, view_394);  view_393 = view_394 = None
        view_395: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_76, [100, 1, 60]);  bmm_76 = None
        permute_358: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_395, [0, 2, 1]);  view_395 = None
        view_396: "f32[100, 60]" = torch.ops.aten.view.default(permute_358, [100, 60]);  permute_358 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_470: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_396, 10.0);  view_396 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_397: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_470, [100, 20, 3]);  mul_470 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_305: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_169, view_397);  sum_169 = view_397 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_707: "f32[100, 20, 1, 3]" = torch.ops.aten.unsqueeze.default(add_305, -2);  add_305 = None
        mul_471: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_558, unsqueeze_707);  unsqueeze_558 = unsqueeze_707 = None
        sum_174: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_471, [-1]);  mul_471 = None
        add_306: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_174, unsqueeze_559);  sum_174 = unsqueeze_559 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_81: "f32[100, 3]" = torch.ops.aten.select.int(add_306, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_708: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_81, 1)
        unsqueeze_709: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_81, 0)
        sub_206: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_708, unsqueeze_709);  unsqueeze_708 = unsqueeze_709 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_472: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_206, sub_206);  sub_206 = None
        sum_175: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_472, [-1]);  mul_472 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_89: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_175, 1e-12);  sum_175 = None
        sqrt_67: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_89);  clamp_min_89 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_110: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_67, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_111: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_110, full_default);  where_110 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_198: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_111, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_112: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_198);  index_198 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_13: "f32[100, 100]" = torch.ops.aten.index_put.default(where_111, [unsqueeze_24, where_1], where_112);  where_111 = where_112 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_14 = torch.ops.aten.sort.stable(index_put_13, stable = True)
        getitem_66: "i64[100, 100]" = sort_14[1];  sort_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_459: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_66, 1, 0, 16);  getitem_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_199: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_13, [unsqueeze_24, slice_459]);  index_put_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_26: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_199, inf);  index_199 = None
        where_113: "i64[100, 16]" = torch.ops.aten.where.self(lt_26, slice_459, full_default_1);  lt_26 = slice_459 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_53: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_113], -1);  where_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_307: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_67, 1e-06);  sqrt_67 = None
        log_27: "f32[100, 100]" = torch.ops.aten.log.default(add_307);  add_307 = None
        mul_473: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_27, -3.0);  log_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_28: "f32[100, 100]" = torch.ops.aten.log.default(getitem_10)
        neg_23: "f32[100, 100]" = torch.ops.aten.neg.default(log_28);  log_28 = None
        log_29: "f32[100, 100]" = torch.ops.aten.log.default(neg_23);  neg_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_207: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_473, log_29);  mul_473 = log_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_24: "f32[100, 100]" = torch.ops.aten.neg.default(sub_207);  sub_207 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_114: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_24, full_default);  neg_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_115: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_114, full_default);  where_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_24: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_53, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_201: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_115, [unsqueeze_24, cat_53])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_116: "f32[100, 32]" = torch.ops.aten.where.self(ne_24, full_default_7, index_201);  ne_24 = index_201 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_14: "f32[100, 100]" = torch.ops.aten.index_put.default(where_115, [unsqueeze_24, cat_53], where_116);  where_115 = where_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_15 = torch.ops.aten.sort.stable(index_put_14, stable = True)
        getitem_68: "i64[100, 100]" = sort_15[1];  sort_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_468: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_68, 1, 0, 32);  getitem_68 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_202: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_14, [unsqueeze_24, slice_468]);  index_put_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_27: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_202, inf);  index_202 = None
        where_117: "i64[100, 32]" = torch.ops.aten.where.self(lt_27, slice_468, full_default_37);  lt_27 = slice_468 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_54: "i64[100, 64]" = torch.ops.aten.cat.default([cat_53, where_117], -1);  cat_53 = where_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_82: "i64[100, 48]" = torch.ops.aten.select.int(view_10, 0, 3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_83: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_25, 0, 3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_84: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_203: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_54])
        bitwise_and_59: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_203);  index_203 = None
        ne_25: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_54, -1)
        bitwise_and_60: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_59, ne_25);  bitwise_and_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_204: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_54])
        eq_25: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_204);  index_204 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_205: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_54])
        eq_26: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_205);  index_205 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_206: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_54])
        sub_208: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_206);  index_206 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_90: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_208, -32);  sub_208 = None
        clamp_max_16: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_90, 32);  clamp_min_90 = None
        add_308: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_16, 32);  clamp_max_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_118: "i64[100, 64]" = torch.ops.aten.where.self(eq_25, add_308, full_default_38);  eq_25 = add_308 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_119: "i64[100, 64]" = torch.ops.aten.where.self(eq_26, where_118, full_default_38);  eq_26 = where_118 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_207: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg194_1, [where_119]);  arg194_1 = where_119 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_730: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_306, 1)
        slice_475: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_730, 2, 0, 5)
        unsqueeze_731: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_475, 3);  slice_475 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_208: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_306, [cat_54])
        unsqueeze_732: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_208, 2)
        slice_479: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_732, 3, 0, 5);  unsqueeze_732 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_209: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_731, slice_479);  unsqueeze_731 = slice_479 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_474: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_209, sub_209);  sub_209 = None
        sum_176: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_474, [-1]);  mul_474 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_91: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_176, 1e-12);  sum_176 = None
        sqrt_68: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_91);  clamp_min_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_398: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_68, [100, 64, 25]);  sqrt_68 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_733: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_398, 3);  view_398 = None
        sub_210: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_733, add_29);  unsqueeze_733 = None
        pow_14: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_210, 2);  sub_210 = None
        neg_25: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_14);  pow_14 = None
        div_83: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_25, 1.890625);  neg_25 = None
        exp_17: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_83);  div_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_399: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_17, [100, 64, 400]);  exp_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_734: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_399, 3);  view_399 = None
        permute_359: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_734, [0, 1, 3, 2]);  unsqueeze_734 = None
        unsqueeze_735: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg195_1, 2);  arg195_1 = None
        unsqueeze_736: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_735, 3);  unsqueeze_735 = None
        permute_360: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_736, [2, 3, 1, 0]);  unsqueeze_736 = None
        permute_361: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_359, [0, 1, 3, 2]);  permute_359 = None
        view_400: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_361, [1, 6400, 400]);  permute_361 = None
        permute_362: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_360, [3, 2, 0, 1]);  permute_360 = None
        view_401: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_362, [1, 400, 64]);  permute_362 = None
        bmm_77: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_400, view_401);  view_400 = view_401 = None
        view_402: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_77, [100, 64, 1, 64]);  bmm_77 = None
        permute_363: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_402, [0, 1, 3, 2]);  view_402 = None
        view_403: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_363, [100, 64, 64]);  permute_363 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_312: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_207, view_403);  index_207 = view_403 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_85: "f32[100, 3]" = torch.ops.aten.select.int(add_306, 1, 0)
        select_87: "f32[100, 3]" = torch.ops.aten.select.int(add_306, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_211: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_87, select_81);  select_87 = None
        sub_212: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_85, select_81);  select_85 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_477: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_211, sub_211)
        sum_177: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_477, [-1]);  mul_477 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_92: "f32[100]" = torch.ops.aten.clamp_min.default(sum_177, 1e-12);  sum_177 = None
        sqrt_69: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_92);  clamp_min_92 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_737: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_69, -1);  sqrt_69 = None
        div_84: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_211, unsqueeze_737);  sub_211 = unsqueeze_737 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_478: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_212, div_84)
        sum_178: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_478, [-1]);  mul_478 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_738: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_178, -1);  sum_178 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_479: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_738, div_84);  unsqueeze_738 = None
        sub_213: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_212, mul_479);  sub_212 = mul_479 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_480: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_213, sub_213)
        sum_179: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_480, [-1]);  mul_480 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_93: "f32[100]" = torch.ops.aten.clamp_min.default(sum_179, 1e-12);  sum_179 = None
        sqrt_70: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_93);  clamp_min_93 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_739: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_70, -1);  sqrt_70 = None
        div_85: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_213, unsqueeze_739);  sub_213 = unsqueeze_739 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_209: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_84, [None, remainder])
        index_210: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_85, [None, remainder_1])
        mul_481: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_209, index_210);  index_209 = index_210 = None
        index_211: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_84, [None, remainder_1])
        index_212: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_85, [None, remainder])
        mul_482: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_211, index_212);  index_211 = index_212 = None
        sub_214: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_481, mul_482);  mul_481 = mul_482 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_740: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_84, 2);  div_84 = None
        unsqueeze_741: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_85, 2);  div_85 = None
        unsqueeze_742: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_214, 2);  sub_214 = None
        cat_55: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_740, unsqueeze_741, unsqueeze_742], -1);  unsqueeze_740 = unsqueeze_741 = unsqueeze_742 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_746: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_55, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_747: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_81, -2);  select_81 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_748: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_746, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_749: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_747, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_216: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_208, unsqueeze_749)
        unsqueeze_750: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_216, -1);  sub_216 = None
        mul_484: "f32[100, 64, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_748, unsqueeze_750);  unsqueeze_750 = None
        sum_181: "f32[100, 64, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_484, [-2]);  mul_484 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_485: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(sum_181, sum_181)
        sum_182: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_485, [-1]);  mul_485 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_94: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_182, 1e-12);  sum_182 = None
        sqrt_71: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_94);  clamp_min_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_751: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_71, -1);  sqrt_71 = None
        div_86: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(sum_181, unsqueeze_751);  sum_181 = unsqueeze_751 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        view_404: "f32[100, 64, 60]" = torch.ops.aten.view.default(div_86, [100, 64, 60]);  div_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_16: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_730, [100, 64, 20, 3]);  unsqueeze_730 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_56: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_16, index_208], -2);  expand_16 = index_208 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_217: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_56, unsqueeze_749);  cat_56 = unsqueeze_749 = None
        unsqueeze_757: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_217, -1);  sub_217 = None
        mul_486: "f32[100, 64, 40, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_748, unsqueeze_757);  unsqueeze_748 = unsqueeze_757 = None
        sum_183: "f32[100, 64, 40, 3]" = torch.ops.aten.sum.dim_IntList(mul_486, [-2]);  mul_486 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_487: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_183, sum_183)
        sum_184: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_487, [-1]);  mul_487 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_95: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_184, 1e-12);  sum_184 = None
        sqrt_72: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_95);  clamp_min_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_758: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_72, -1);  sqrt_72 = None
        div_87: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(sum_183, unsqueeze_758);  unsqueeze_758 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        view_405: "f32[100, 64, 120]" = torch.ops.aten.view.default(div_87, [100, 64, 120]);  div_87 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_488: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_183, 0.1);  sum_183 = None
        view_406: "f32[100, 64, 120]" = torch.ops.aten.view.default(mul_488, [100, 64, 120]);  mul_488 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_57: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_405, view_406], -1);  view_405 = view_406 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_759: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_404, 3);  view_404 = None
        permute_364: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_759, [0, 1, 3, 2]);  unsqueeze_759 = None
        unsqueeze_760: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg196_1, 2);  arg196_1 = None
        unsqueeze_761: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_760, 3);  unsqueeze_760 = None
        permute_365: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_761, [2, 3, 1, 0]);  unsqueeze_761 = None
        permute_366: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_364, [0, 1, 3, 2]);  permute_364 = None
        view_407: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_366, [1, 6400, 60]);  permute_366 = None
        permute_367: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_365, [3, 2, 0, 1]);  permute_365 = None
        view_408: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_367, [1, 60, 64]);  permute_367 = None
        bmm_78: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_407, view_408);  view_407 = view_408 = None
        view_409: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_78, [100, 64, 1, 64]);  bmm_78 = None
        permute_368: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_409, [0, 1, 3, 2]);  view_409 = None
        view_410: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_368, [100, 64, 64]);  permute_368 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_317: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_312, view_410);  add_312 = view_410 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_771: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_55, 1)
        permute_369: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_771, [0, 1, 3, 2]);  unsqueeze_771 = None
        index_218: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_55, [cat_54]);  cat_55 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:77 in rot_compose, code: return (a.unsqueeze(-1) * b.unsqueeze(-3)).sum(-2)
        unsqueeze_772: "f32[100, 1, 3, 3, 1]" = torch.ops.aten.unsqueeze.default(permute_369, -1);  permute_369 = None
        unsqueeze_773: "f32[100, 64, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(index_218, -3);  index_218 = None
        mul_496: "f32[100, 64, 3, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_772, unsqueeze_773);  unsqueeze_772 = unsqueeze_773 = None
        sum_189: "f32[100, 64, 3, 3]" = torch.ops.aten.sum.dim_IntList(mul_496, [-2]);  mul_496 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_411: "f32[100, 64, 9]" = torch.ops.aten.view.default(sum_189, [100, 64, 9]);  sum_189 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_774: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_411, 3);  view_411 = None
        permute_370: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_774, [0, 1, 3, 2]);  unsqueeze_774 = None
        unsqueeze_775: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg197_1, 2);  arg197_1 = None
        unsqueeze_776: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_775, 3);  unsqueeze_775 = None
        permute_371: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_776, [2, 3, 1, 0]);  unsqueeze_776 = None
        permute_372: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_370, [0, 1, 3, 2]);  permute_370 = None
        view_412: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_372, [1, 6400, 9]);  permute_372 = None
        permute_373: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_371, [3, 2, 0, 1]);  permute_371 = None
        view_413: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_373, [1, 9, 64]);  permute_373 = None
        bmm_79: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_412, view_413);  view_412 = view_413 = None
        view_414: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_79, [100, 64, 1, 64]);  bmm_79 = None
        permute_374: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_414, [0, 1, 3, 2]);  view_414 = None
        view_415: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_374, [100, 64, 64]);  permute_374 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_322: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_317, view_415);  add_317 = view_415 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_777: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_57, 3);  cat_57 = None
        permute_375: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_777, [0, 1, 3, 2]);  unsqueeze_777 = None
        unsqueeze_778: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg198_1, 2);  arg198_1 = None
        unsqueeze_779: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_778, 3);  unsqueeze_778 = None
        permute_376: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_779, [2, 3, 1, 0]);  unsqueeze_779 = None
        permute_377: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_375, [0, 1, 3, 2]);  permute_375 = None
        view_416: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_377, [1, 6400, 240]);  permute_377 = None
        permute_378: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_376, [3, 2, 0, 1]);  permute_376 = None
        view_417: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_378, [1, 240, 64]);  permute_378 = None
        bmm_80: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_416, view_417);  view_416 = view_417 = None
        view_418: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_80, [100, 64, 1, 64]);  bmm_80 = None
        permute_379: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_418, [0, 1, 3, 2]);  view_418 = None
        view_419: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_379, [100, 64, 64]);  permute_379 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_323: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_322, view_419);  add_322 = view_419 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_37: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_323, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_37: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_323, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_223: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_323, mean_37);  add_323 = mean_37 = None
        add_324: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_37, 1e-05);  var_37 = None
        rsqrt_37: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_324);  add_324 = None
        mul_497: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_223, rsqrt_37);  sub_223 = rsqrt_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_498: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_497, arg199_1);  mul_497 = arg199_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_325: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_498, arg200_1);  mul_498 = arg200_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_780: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_325, 3);  add_325 = None
        permute_380: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_780, [0, 1, 3, 2]);  unsqueeze_780 = None
        unsqueeze_781: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg201_1, 2);  arg201_1 = None
        unsqueeze_782: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_781, 3);  unsqueeze_781 = None
        permute_381: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_782, [2, 3, 1, 0]);  unsqueeze_782 = None
        permute_382: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_380, [0, 1, 3, 2]);  permute_380 = None
        view_420: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_382, [1, 6400, 64]);  permute_382 = None
        permute_383: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_381, [3, 2, 0, 1]);  permute_381 = None
        view_421: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_383, [1, 64, 128]);  permute_383 = None
        bmm_81: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_420, view_421);  view_420 = view_421 = None
        view_422: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_81, [100, 64, 1, 128]);  bmm_81 = None
        permute_384: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_422, [0, 1, 3, 2]);  view_422 = None
        view_423: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_384, [100, 64, 128]);  permute_384 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_326: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_423, arg202_1);  view_423 = arg202_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_499: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_326, add_326)
        mul_500: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_499, add_326);  mul_499 = None
        mul_501: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_500, 0.044715);  mul_500 = None
        add_327: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_326, mul_501);  mul_501 = None
        mul_502: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_327, 0.7978845608028654);  add_327 = None
        mul_503: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_326, 0.5);  add_326 = None
        tanh_17: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_502);  mul_502 = None
        add_328: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_17, 1);  tanh_17 = None
        mul_504: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_503, add_328);  mul_503 = add_328 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_783: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_504, 3);  mul_504 = None
        permute_385: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_783, [0, 1, 3, 2]);  unsqueeze_783 = None
        unsqueeze_784: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg203_1, 2);  arg203_1 = None
        unsqueeze_785: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_784, 3);  unsqueeze_784 = None
        permute_386: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_785, [2, 3, 1, 0]);  unsqueeze_785 = None
        permute_387: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_385, [0, 1, 3, 2]);  permute_385 = None
        view_424: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_387, [1, 6400, 128]);  permute_387 = None
        permute_388: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_386, [3, 2, 0, 1]);  permute_386 = None
        view_425: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_388, [1, 128, 64]);  permute_388 = None
        bmm_82: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_424, view_425);  view_424 = view_425 = None
        view_426: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_82, [100, 64, 1, 64]);  bmm_82 = None
        permute_389: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_426, [0, 1, 3, 2]);  view_426 = None
        view_427: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_389, [100, 64, 64]);  permute_389 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_329: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_427, arg204_1);  view_427 = arg204_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_506: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_461, arg205_1);  mul_461 = arg205_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_331: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_506, arg206_1);  mul_506 = arg206_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_90: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_306, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_91: "f32[100, 3]" = torch.ops.aten.select.int(div_90, 1, 0)
        select_92: "f32[100, 3]" = torch.ops.aten.select.int(div_90, 1, 1)
        select_93: "f32[100, 3]" = torch.ops.aten.select.int(div_90, 1, 2);  div_90 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_225: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_93, select_92);  select_93 = None
        sub_226: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_91, select_92);  select_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_507: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_225, sub_225)
        sum_190: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_507, [-1]);  mul_507 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_98: "f32[100]" = torch.ops.aten.clamp_min.default(sum_190, 1e-12);  sum_190 = None
        sqrt_75: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_98);  clamp_min_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_786: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_75, -1);  sqrt_75 = None
        div_91: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_225, unsqueeze_786);  sub_225 = unsqueeze_786 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_508: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_226, div_91)
        sum_191: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_508, [-1]);  mul_508 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_787: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_191, -1);  sum_191 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_509: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_787, div_91);  unsqueeze_787 = None
        sub_227: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_226, mul_509);  sub_226 = mul_509 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_510: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_227, sub_227)
        sum_192: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_510, [-1]);  mul_510 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_99: "f32[100]" = torch.ops.aten.clamp_min.default(sum_192, 1e-12);  sum_192 = None
        sqrt_76: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_99);  clamp_min_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_788: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_76, -1);  sqrt_76 = None
        div_92: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_227, unsqueeze_788);  sub_227 = unsqueeze_788 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_219: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_91, [None, remainder])
        index_220: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_92, [None, remainder_1])
        mul_511: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_219, index_220);  index_219 = index_220 = None
        index_221: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_91, [None, remainder_1])
        index_222: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_92, [None, remainder])
        mul_512: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_221, index_222);  index_221 = index_222 = None
        sub_228: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_511, mul_512);  mul_511 = mul_512 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_789: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_91, 2);  div_91 = None
        unsqueeze_790: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_92, 2);  div_92 = None
        unsqueeze_791: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_228, 2);  sub_228 = None
        cat_59: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_789, unsqueeze_790, unsqueeze_791], -1);  unsqueeze_789 = unsqueeze_790 = unsqueeze_791 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_39: "f32[100, 1]" = torch.ops.aten.mean.dim(add_331, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_39: "f32[100, 1]" = torch.ops.aten.var.correction(add_331, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_230: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_331, mean_39);  add_331 = mean_39 = None
        add_336: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_39, 1e-05);  var_39 = None
        rsqrt_39: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_336);  add_336 = None
        mul_514: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_230, rsqrt_39);  sub_230 = rsqrt_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_515: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_514, arg207_1);  mul_514 = arg207_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_337: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_515, arg208_1);  mul_515 = arg208_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_795: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_337, 2);  add_337 = None
        permute_390: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_795, [0, 2, 1]);  unsqueeze_795 = None
        unsqueeze_796: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg209_1, 2);  arg209_1 = None
        permute_391: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_796, [2, 1, 0]);  unsqueeze_796 = None
        permute_392: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_390, [0, 2, 1]);  permute_390 = None
        view_428: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_392, [1, 100, 128]);  permute_392 = None
        permute_393: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_391, [2, 1, 0]);  permute_391 = None
        view_429: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_393, [1, 128, 768]);  permute_393 = None
        bmm_83: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_428, view_429);  view_429 = None
        view_430: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_83, [100, 1, 768]);  bmm_83 = None
        permute_394: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_430, [0, 2, 1]);  view_430 = None
        view_431: "f32[100, 768]" = torch.ops.aten.view.default(permute_394, [100, 768]);  permute_394 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_432: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_431, [100, 8, 96]);  view_431 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_6 = torch.ops.aten.split.Tensor(view_432, 32, -1);  view_432 = None
        getitem_69: "f32[100, 8, 32]" = split_6[0]
        getitem_70: "f32[100, 8, 32]" = split_6[1]
        getitem_71: "f32[100, 8, 32]" = split_6[2];  split_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_40: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_69, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_40: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_69, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_231: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_69, mean_40);  getitem_69 = mean_40 = None
        add_338: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_40, 1e-05);  var_40 = None
        rsqrt_40: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_338);  add_338 = None
        mul_516: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_231, rsqrt_40);  sub_231 = rsqrt_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_517: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_516, arg210_1);  mul_516 = arg210_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_339: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_517, arg211_1);  mul_517 = arg211_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_41: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_70, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_41: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_70, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_232: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_70, mean_41);  getitem_70 = mean_41 = None
        add_340: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_41, 1e-05);  var_41 = None
        rsqrt_41: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_340);  add_340 = None
        mul_518: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_232, rsqrt_41);  sub_232 = rsqrt_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_519: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_518, arg212_1);  mul_518 = arg212_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_341: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_519, arg213_1);  mul_519 = arg213_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_798: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg214_1, 2);  arg214_1 = None
        permute_396: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_798, [2, 1, 0]);  unsqueeze_798 = None
        permute_398: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_396, [2, 1, 0]);  permute_396 = None
        view_434: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_398, [1, 128, 576]);  permute_398 = None
        bmm_84: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_428, view_434);  view_428 = view_434 = None
        view_435: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_84, [100, 1, 576]);  bmm_84 = None
        permute_399: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_435, [0, 2, 1]);  view_435 = None
        view_436: "f32[100, 576]" = torch.ops.aten.view.default(permute_399, [100, 576]);  permute_399 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_437: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_436, [100, 192, 3]);  view_436 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_799: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_59, -3);  cat_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_800: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_92, -2);  select_92 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_801: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_437, -2);  view_437 = None
        mul_520: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_799, unsqueeze_801);  unsqueeze_801 = None
        sum_194: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_520, [-1]);  mul_520 = None
        add_342: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_194, unsqueeze_800);  sum_194 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_438: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_342, [100, 8, 24, 3]);  add_342 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_506: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_438, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_509: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_438, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_512: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_438, 2, 16, 9223372036854775807);  view_438 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_802: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_329, 3)
        permute_400: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_802, [0, 1, 3, 2]);  unsqueeze_802 = None
        unsqueeze_803: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg215_1, 2);  arg215_1 = None
        unsqueeze_804: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_803, 3);  unsqueeze_803 = None
        permute_401: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_804, [2, 3, 1, 0]);  unsqueeze_804 = None
        permute_402: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_400, [0, 1, 3, 2]);  permute_400 = None
        view_439: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_402, [1, 6400, 64]);  permute_402 = None
        permute_403: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_401, [3, 2, 0, 1]);  permute_401 = None
        view_440: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_403, [1, 64, 8]);  permute_403 = None
        bmm_85: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_439, view_440);  view_439 = view_440 = None
        view_441: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_85, [100, 64, 1, 8]);  bmm_85 = None
        permute_404: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_441, [0, 1, 3, 2]);  view_441 = None
        view_442: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_404, [100, 64, 8]);  permute_404 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_18: "f32[8]" = torch.ops.aten.exp.default(arg216_1)
        log1p_6: "f32[8]" = torch.ops.aten.log1p.default(exp_18);  exp_18 = None
        gt_6: "b8[8]" = torch.ops.aten.gt.Scalar(arg216_1, 20)
        where_120: "f32[8]" = torch.ops.aten.where.self(gt_6, arg216_1, log1p_6);  gt_6 = arg216_1 = log1p_6 = None
        view_443: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_120, [1, 1, 8]);  where_120 = None
        mul_521: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_443, 0.16666666666666666);  view_443 = None
        div_93: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_521, 2);  mul_521 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_805: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_506, 1);  slice_506 = None
        index_223: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_509, [cat_54]);  slice_509 = None
        sub_233: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_805, index_223);  unsqueeze_805 = index_223 = None
        pow_15: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_233, 2);  sub_233 = None
        sum_195: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_15, [-1, -2]);  pow_15 = None
        mul_522: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_93, sum_195);  div_93 = sum_195 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_806: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_339, 1);  add_339 = None
        index_224: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_341, [cat_54]);  add_341 = None
        mul_523: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_806, index_224);  unsqueeze_806 = index_224 = None
        sum_196: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(mul_523, [-1]);  mul_523 = None
        mul_524: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sum_196, 0.1767766952966369);  sum_196 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_343: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_524, view_442);  mul_524 = view_442 = None
        sub_234: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_343, mul_522);  add_343 = mul_522 = None
        mul_525: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_234, 0.5773502691896257);  sub_234 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_61: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_60, ne_25);  bitwise_and_60 = ne_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_807: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_61, 2);  bitwise_and_61 = None
        where_121: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_807, mul_525, full_default_39);  mul_525 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_6: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_121, [-2], True)
        sub_235: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(where_121, amax_6);  where_121 = amax_6 = None
        exp_19: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_235);  sub_235 = None
        sum_197: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_19, [-2], True)
        div_94: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_19, sum_197);  exp_19 = sum_197 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_122: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_807, div_94, full_default_40);  unsqueeze_807 = div_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_809: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_122, 3);  where_122 = None
        unsqueeze_810: "f32[100, 64, 1, 64]" = torch.ops.aten.unsqueeze.default(add_329, 2);  add_329 = None
        mul_526: "f32[100, 64, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_809, unsqueeze_810);  unsqueeze_810 = None
        sum_198: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_526, [1]);  mul_526 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_225: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_71, [cat_54]);  getitem_71 = None
        mul_527: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_809, index_225);  index_225 = None
        sum_199: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_527, [1]);  mul_527 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_813: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_809, 4);  unsqueeze_809 = None
        index_226: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_512, [cat_54]);  slice_512 = cat_54 = None
        mul_528: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_813, index_226);  unsqueeze_813 = index_226 = None
        sum_200: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_528, [1]);  mul_528 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_816: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_799, -3);  unsqueeze_799 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_817: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_800, -2);  unsqueeze_800 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_236: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_200, unsqueeze_817);  sum_200 = unsqueeze_817 = None
        unsqueeze_818: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_236, -1);  sub_236 = None
        mul_529: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_816, unsqueeze_818);  unsqueeze_816 = unsqueeze_818 = None
        sum_201: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_529, [-2]);  mul_529 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_530: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_201, sum_201)
        sum_202: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_530, [-1]);  mul_530 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_100: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_202, 1e-12);  sum_202 = None
        sqrt_77: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_100);  clamp_min_100 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_444: "f32[100, 512]" = torch.ops.aten.view.default(sum_198, [100, -1]);  sum_198 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_445: "f32[100, 256]" = torch.ops.aten.view.default(sum_199, [100, -1]);  sum_199 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_446: "f32[100, 192]" = torch.ops.aten.view.default(sum_201, [100, -1]);  sum_201 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_447: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_77, [100, -1]);  sqrt_77 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_60: "f32[100, 1024]" = torch.ops.aten.cat.default([view_444, view_445, view_446, view_447], -1);  view_444 = view_445 = view_446 = view_447 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_819: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_60, 2);  cat_60 = None
        permute_405: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_819, [0, 2, 1]);  unsqueeze_819 = None
        unsqueeze_820: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg217_1, 2);  arg217_1 = None
        permute_406: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_820, [2, 1, 0]);  unsqueeze_820 = None
        permute_407: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_405, [0, 2, 1]);  permute_405 = None
        view_448: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_407, [1, 100, 1024]);  permute_407 = None
        permute_408: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_406, [2, 1, 0]);  permute_406 = None
        view_449: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_408, [1, 1024, 128]);  permute_408 = None
        bmm_86: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_448, view_449);  view_448 = view_449 = None
        view_450: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_86, [100, 1, 128]);  bmm_86 = None
        permute_409: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_450, [0, 2, 1]);  view_450 = None
        view_451: "f32[100, 128]" = torch.ops.aten.view.default(permute_409, [100, 128]);  permute_409 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_344: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_451, arg218_1);  view_451 = arg218_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_345: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_298, add_344);  add_298 = add_344 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_42: "f32[100, 1]" = torch.ops.aten.mean.dim(add_345, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_42: "f32[100, 1]" = torch.ops.aten.var.correction(add_345, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_237: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_345, mean_42);  mean_42 = None
        add_346: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_42, 1e-05);  var_42 = None
        rsqrt_42: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_346);  add_346 = None
        mul_531: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_237, rsqrt_42);  sub_237 = rsqrt_42 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_532: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_531, arg219_1);  mul_531 = arg219_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_347: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_532, arg220_1);  mul_532 = arg220_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_43: "f32[100, 1]" = torch.ops.aten.mean.dim(add_347, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_43: "f32[100, 1]" = torch.ops.aten.var.correction(add_347, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_243: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_347, mean_43);  add_347 = mean_43 = None
        add_352: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_43, 1e-05);  var_43 = None
        rsqrt_43: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_352);  add_352 = None
        mul_540: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_243, rsqrt_43);  sub_243 = rsqrt_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_541: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_540, arg221_1);  mul_540 = arg221_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_353: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_541, arg222_1);  mul_541 = arg222_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_830: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_353, 2);  add_353 = None
        permute_410: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_830, [0, 2, 1]);  unsqueeze_830 = None
        unsqueeze_831: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg223_1, 2);  arg223_1 = None
        permute_411: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_831, [2, 1, 0]);  unsqueeze_831 = None
        permute_412: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_410, [0, 2, 1]);  permute_410 = None
        view_452: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_412, [1, 100, 128]);  permute_412 = None
        permute_413: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_411, [2, 1, 0]);  permute_411 = None
        view_453: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_413, [1, 128, 768]);  permute_413 = None
        bmm_87: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_452, view_453);  view_453 = None
        view_454: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_87, [100, 1, 768]);  bmm_87 = None
        permute_414: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_454, [0, 2, 1]);  view_454 = None
        view_455: "f32[100, 768]" = torch.ops.aten.view.default(permute_414, [100, 768]);  permute_414 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_456: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_455, [100, 8, 96]);  view_455 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_7 = torch.ops.aten.split.Tensor(view_456, 32, -1);  view_456 = None
        getitem_72: "f32[100, 8, 32]" = split_7[0]
        getitem_73: "f32[100, 8, 32]" = split_7[1]
        getitem_74: "f32[100, 8, 32]" = split_7[2];  split_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_44: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_72, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_44: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_72, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_244: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_72, mean_44);  getitem_72 = mean_44 = None
        add_354: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_44, 1e-05);  var_44 = None
        rsqrt_44: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_354);  add_354 = None
        mul_542: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_244, rsqrt_44);  sub_244 = rsqrt_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_543: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_542, arg224_1);  mul_542 = arg224_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_355: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_543, arg225_1);  mul_543 = arg225_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_45: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_73, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_45: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_73, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_245: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_73, mean_45);  getitem_73 = mean_45 = None
        add_356: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_45, 1e-05);  var_45 = None
        rsqrt_45: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_356);  add_356 = None
        mul_544: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_245, rsqrt_45);  sub_245 = rsqrt_45 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_545: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_544, arg226_1);  mul_544 = arg226_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_357: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_545, arg227_1);  mul_545 = arg227_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_833: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg228_1, 2);  arg228_1 = None
        permute_416: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_833, [2, 1, 0]);  unsqueeze_833 = None
        permute_418: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_416, [2, 1, 0]);  permute_416 = None
        view_458: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_418, [1, 128, 576]);  permute_418 = None
        bmm_88: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_452, view_458);  view_452 = view_458 = None
        view_459: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_88, [100, 1, 576]);  bmm_88 = None
        permute_419: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_459, [0, 2, 1]);  view_459 = None
        view_460: "f32[100, 576]" = torch.ops.aten.view.default(permute_419, [100, 576]);  permute_419 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_461: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_460, [100, 192, 3]);  view_460 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_836: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_461, -2);  view_461 = None
        mul_546: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_270, unsqueeze_836);  unsqueeze_836 = None
        sum_207: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_546, [-1]);  mul_546 = None
        add_358: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_207, unsqueeze_271);  sum_207 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_462: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_358, [100, 8, 24, 3]);  add_358 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_527: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_462, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_530: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_462, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_533: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_462, 2, 16, 9223372036854775807);  view_462 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_837: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_83, 3)
        permute_420: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_837, [0, 1, 3, 2]);  unsqueeze_837 = None
        unsqueeze_838: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg229_1, 2);  arg229_1 = None
        unsqueeze_839: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_838, 3);  unsqueeze_838 = None
        permute_421: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_839, [2, 3, 1, 0]);  unsqueeze_839 = None
        permute_422: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_420, [0, 1, 3, 2]);  permute_420 = None
        view_463: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_422, [1, 4800, 64]);  permute_422 = None
        permute_423: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_421, [3, 2, 0, 1]);  permute_421 = None
        view_464: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_423, [1, 64, 8]);  permute_423 = None
        bmm_89: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_463, view_464);  view_463 = view_464 = None
        view_465: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_89, [100, 48, 1, 8]);  bmm_89 = None
        permute_424: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_465, [0, 1, 3, 2]);  view_465 = None
        view_466: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_424, [100, 48, 8]);  permute_424 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_20: "f32[8]" = torch.ops.aten.exp.default(arg230_1)
        log1p_7: "f32[8]" = torch.ops.aten.log1p.default(exp_20);  exp_20 = None
        gt_7: "b8[8]" = torch.ops.aten.gt.Scalar(arg230_1, 20)
        where_123: "f32[8]" = torch.ops.aten.where.self(gt_7, arg230_1, log1p_7);  gt_7 = arg230_1 = log1p_7 = None
        view_467: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_123, [1, 1, 8]);  where_123 = None
        mul_547: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_467, 0.16666666666666666);  view_467 = None
        div_98: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_547, 2);  mul_547 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_840: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_527, 1);  slice_527 = None
        index_231: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_530, [select_82]);  slice_530 = None
        sub_246: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_840, index_231);  unsqueeze_840 = index_231 = None
        pow_16: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_246, 2);  sub_246 = None
        sum_208: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_16, [-1, -2]);  pow_16 = None
        mul_548: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_98, sum_208);  div_98 = sum_208 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_841: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_355, 1);  add_355 = None
        index_232: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_357, [select_82]);  add_357 = None
        mul_549: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_841, index_232);  unsqueeze_841 = index_232 = None
        sum_209: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(mul_549, [-1]);  mul_549 = None
        mul_550: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sum_209, 0.1767766952966369);  sum_209 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_359: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_550, view_466);  mul_550 = view_466 = None
        sub_247: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_359, mul_548);  add_359 = mul_548 = None
        mul_551: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_247, 0.5773502691896257);  sub_247 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_27: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_82, -1)
        bitwise_and_62: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_84, ne_27);  select_84 = ne_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_842: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_62, 2);  bitwise_and_62 = None
        where_124: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_842, mul_551, full_default_41);  mul_551 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_7: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_124, [-2], True)
        sub_248: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(where_124, amax_7);  where_124 = amax_7 = None
        exp_21: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_248);  sub_248 = None
        sum_210: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_21, [-2], True)
        div_99: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_21, sum_210);  exp_21 = sum_210 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_125: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_842, div_99, full_default_42);  unsqueeze_842 = div_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_844: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_125, 3);  where_125 = None
        unsqueeze_845: "f32[100, 48, 1, 64]" = torch.ops.aten.unsqueeze.default(select_83, 2);  select_83 = None
        mul_552: "f32[100, 48, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_844, unsqueeze_845);  unsqueeze_845 = None
        sum_211: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_552, [1]);  mul_552 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_233: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_74, [select_82]);  getitem_74 = None
        mul_553: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_844, index_233);  index_233 = None
        sum_212: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_553, [1]);  mul_553 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_848: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_844, 4);  unsqueeze_844 = None
        index_234: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_533, [select_82]);  slice_533 = select_82 = None
        mul_554: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_848, index_234);  unsqueeze_848 = index_234 = None
        sum_213: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_554, [1]);  mul_554 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_249: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_213, unsqueeze_288);  sum_213 = None
        unsqueeze_853: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_249, -1);  sub_249 = None
        mul_555: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_287, unsqueeze_853);  unsqueeze_853 = None
        sum_214: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_555, [-2]);  mul_555 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_556: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_214, sum_214)
        sum_215: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_556, [-1]);  mul_556 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_103: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_215, 1e-12);  sum_215 = None
        sqrt_80: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_103);  clamp_min_103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_468: "f32[100, 512]" = torch.ops.aten.view.default(sum_211, [100, -1]);  sum_211 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_469: "f32[100, 256]" = torch.ops.aten.view.default(sum_212, [100, -1]);  sum_212 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_470: "f32[100, 192]" = torch.ops.aten.view.default(sum_214, [100, -1]);  sum_214 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_471: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_80, [100, -1]);  sqrt_80 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_62: "f32[100, 1024]" = torch.ops.aten.cat.default([view_468, view_469, view_470, view_471], -1);  view_468 = view_469 = view_470 = view_471 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_854: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_62, 2);  cat_62 = None
        permute_425: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_854, [0, 2, 1]);  unsqueeze_854 = None
        unsqueeze_855: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg231_1, 2);  arg231_1 = None
        permute_426: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_855, [2, 1, 0]);  unsqueeze_855 = None
        permute_427: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_425, [0, 2, 1]);  permute_425 = None
        view_472: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_427, [1, 100, 1024]);  permute_427 = None
        permute_428: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_426, [2, 1, 0]);  permute_426 = None
        view_473: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_428, [1, 1024, 128]);  permute_428 = None
        bmm_90: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_472, view_473);  view_472 = view_473 = None
        view_474: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_90, [100, 1, 128]);  bmm_90 = None
        permute_429: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_474, [0, 2, 1]);  view_474 = None
        view_475: "f32[100, 128]" = torch.ops.aten.view.default(permute_429, [100, 128]);  permute_429 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_360: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_475, arg232_1);  view_475 = arg232_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_361: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_345, add_360);  add_345 = add_360 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_46: "f32[100, 1]" = torch.ops.aten.mean.dim(add_361, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_46: "f32[100, 1]" = torch.ops.aten.var.correction(add_361, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_250: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_361, mean_46);  mean_46 = None
        add_362: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_46, 1e-05);  var_46 = None
        rsqrt_46: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_362);  add_362 = None
        mul_557: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_250, rsqrt_46);  sub_250 = rsqrt_46 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_558: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_557, arg233_1);  mul_557 = arg233_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_363: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_558, arg234_1);  mul_558 = arg234_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_255: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_306, unsqueeze_747)
        unsqueeze_864: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_255, -1);  sub_255 = None
        mul_565: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_746, unsqueeze_864);  unsqueeze_864 = None
        sum_219: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_565, [-2]);  mul_565 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        view_476: "f32[100, 60]" = torch.ops.aten.view.default(sum_219, [100, -1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_866: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg235_1, 2);  arg235_1 = None
        permute_431: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_866, [2, 1, 0]);  unsqueeze_866 = None
        permute_433: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_431, [2, 1, 0]);  permute_431 = None
        view_478: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_433, [1, 128, 128]);  permute_433 = None
        bmm_91: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_105, view_478);  view_478 = None
        view_479: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_91, [100, 1, 128]);  bmm_91 = None
        permute_434: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_479, [0, 2, 1]);  view_479 = None
        view_480: "f32[100, 128]" = torch.ops.aten.view.default(permute_434, [100, 128]);  permute_434 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_368: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_363, view_480);  add_363 = view_480 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_867: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_476, 2);  view_476 = None
        permute_435: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_867, [0, 2, 1]);  unsqueeze_867 = None
        unsqueeze_868: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg236_1, 2);  arg236_1 = None
        permute_436: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_868, [2, 1, 0]);  unsqueeze_868 = None
        permute_437: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_435, [0, 2, 1]);  permute_435 = None
        view_481: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_437, [1, 100, 60]);  permute_437 = None
        permute_438: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_436, [2, 1, 0]);  permute_436 = None
        view_482: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_438, [1, 60, 256]);  permute_438 = None
        bmm_92: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_481, view_482);  view_481 = view_482 = None
        view_483: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_92, [100, 1, 256]);  bmm_92 = None
        permute_439: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_483, [0, 2, 1]);  view_483 = None
        view_484: "f32[100, 256]" = torch.ops.aten.view.default(permute_439, [100, 256]);  permute_439 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_369: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_484, arg237_1);  view_484 = arg237_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_566: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_369, add_369)
        mul_567: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_566, add_369);  mul_566 = None
        mul_568: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_567, 0.044715);  mul_567 = None
        add_370: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_369, mul_568);  mul_568 = None
        mul_569: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_370, 0.7978845608028654);  add_370 = None
        mul_570: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_369, 0.5);  add_369 = None
        tanh_18: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_569);  mul_569 = None
        add_371: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_18, 1);  tanh_18 = None
        mul_571: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_570, add_371);  mul_570 = add_371 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_869: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_571, 2);  mul_571 = None
        permute_440: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_869, [0, 2, 1]);  unsqueeze_869 = None
        unsqueeze_870: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg238_1, 2);  arg238_1 = None
        permute_441: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_870, [2, 1, 0]);  unsqueeze_870 = None
        permute_442: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_440, [0, 2, 1]);  permute_440 = None
        view_485: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_442, [1, 100, 256]);  permute_442 = None
        permute_443: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_441, [2, 1, 0]);  permute_441 = None
        view_486: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_443, [1, 256, 128]);  permute_443 = None
        bmm_93: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_485, view_486);  view_485 = view_486 = None
        view_487: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_93, [100, 1, 128]);  bmm_93 = None
        permute_444: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_487, [0, 2, 1]);  view_487 = None
        view_488: "f32[100, 128]" = torch.ops.aten.view.default(permute_444, [100, 128]);  permute_444 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_372: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_488, arg239_1);  view_488 = arg239_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_373: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_368, add_372);  add_368 = add_372 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_871: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_373, 2);  add_373 = None
        permute_445: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_871, [0, 2, 1]);  unsqueeze_871 = None
        unsqueeze_872: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg240_1, 2);  arg240_1 = None
        permute_446: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_872, [2, 1, 0]);  unsqueeze_872 = None
        permute_447: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_445, [0, 2, 1]);  permute_445 = None
        view_489: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_447, [1, 100, 128]);  permute_447 = None
        permute_448: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_446, [2, 1, 0]);  permute_446 = None
        view_490: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_448, [1, 128, 512]);  permute_448 = None
        bmm_94: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_489, view_490);  view_490 = None
        view_491: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_94, [100, 1, 512]);  bmm_94 = None
        permute_449: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_491, [0, 2, 1]);  view_491 = None
        view_492: "f32[100, 512]" = torch.ops.aten.view.default(permute_449, [100, 512]);  permute_449 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_874: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg241_1, 2);  arg241_1 = None
        permute_451: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_874, [2, 1, 0]);  unsqueeze_874 = None
        permute_453: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_451, [2, 1, 0]);  permute_451 = None
        view_494: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_453, [1, 128, 512]);  permute_453 = None
        bmm_95: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_489, view_494);  view_494 = None
        view_495: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_95, [100, 1, 512]);  bmm_95 = None
        permute_454: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_495, [0, 2, 1]);  view_495 = None
        view_496: "f32[100, 512]" = torch.ops.aten.view.default(permute_454, [100, 512]);  permute_454 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_572: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_496, view_496)
        mul_573: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_572, view_496);  mul_572 = None
        mul_574: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_573, 0.044715);  mul_573 = None
        add_374: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_496, mul_574);  mul_574 = None
        mul_575: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_374, 0.7978845608028654);  add_374 = None
        mul_576: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_496, 0.5);  view_496 = None
        tanh_19: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_575);  mul_575 = None
        add_375: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_19, 1);  tanh_19 = None
        mul_577: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_576, add_375);  mul_576 = add_375 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_578: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_577, view_492);  mul_577 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_876: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg242_1, 2);  arg242_1 = None
        permute_456: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_876, [2, 1, 0]);  unsqueeze_876 = None
        permute_458: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_456, [2, 1, 0]);  permute_456 = None
        view_498: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_458, [1, 128, 512]);  permute_458 = None
        bmm_96: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_489, view_498);  view_498 = None
        view_499: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_96, [100, 1, 512]);  bmm_96 = None
        permute_459: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_499, [0, 2, 1]);  view_499 = None
        view_500: "f32[100, 512]" = torch.ops.aten.view.default(permute_459, [100, 512]);  permute_459 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_579: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_500, view_500)
        mul_580: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_579, view_500);  mul_579 = None
        mul_581: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_580, 0.044715);  mul_580 = None
        add_376: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_500, mul_581);  mul_581 = None
        mul_582: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_376, 0.7978845608028654);  add_376 = None
        mul_583: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_500, 0.5);  view_500 = None
        tanh_20: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_582);  mul_582 = None
        add_377: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_20, 1);  tanh_20 = None
        mul_584: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_583, add_377);  mul_583 = add_377 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_878: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg243_1, 2);  arg243_1 = None
        permute_461: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_878, [2, 1, 0]);  unsqueeze_878 = None
        permute_463: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_461, [2, 1, 0]);  permute_461 = None
        view_502: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_463, [1, 128, 512]);  permute_463 = None
        bmm_97: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_489, view_502);  view_489 = view_502 = None
        view_503: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_97, [100, 1, 512]);  bmm_97 = None
        permute_464: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_503, [0, 2, 1]);  view_503 = None
        view_504: "f32[100, 512]" = torch.ops.aten.view.default(permute_464, [100, 512]);  permute_464 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_585: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_504, view_504)
        mul_586: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_585, view_504);  mul_585 = None
        mul_587: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_586, 0.044715);  mul_586 = None
        add_378: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_504, mul_587);  mul_587 = None
        mul_588: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_378, 0.7978845608028654);  add_378 = None
        mul_589: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_504, 0.5);  view_504 = None
        tanh_21: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_588);  mul_588 = None
        add_379: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_21, 1);  tanh_21 = None
        mul_590: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_589, add_379);  mul_589 = add_379 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_591: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_590, view_492);  mul_590 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_126: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_591, full_default_44);  mul_591 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_127: "f32[100, 512]" = torch.ops.aten.where.self(view_133, where_126, full_default_44);  where_126 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_12: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_2, where_127);  where_127 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_239: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_12, [clamp_max_2]);  scatter_add_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_102: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_239, clamp_min_33);  index_239 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_130: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_102, full_default_44);  div_102 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_380: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_578, where_130);  mul_578 = where_130 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_593: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_584, view_492);  mul_584 = view_492 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_131: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_593, full_default_44);  mul_593 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_132: "f32[100, 512]" = torch.ops.aten.where.self(view_137, where_131, full_default_44);  where_131 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_14: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_4, where_132);  where_132 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_241: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_14, [clamp_max_4]);  scatter_add_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_103: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_241, clamp_min_36);  index_241 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_135: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_103, full_default_44);  div_103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_381: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_380, where_135);  add_380 = where_135 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_880: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_381, 2);  add_381 = None
        permute_465: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_880, [0, 2, 1]);  unsqueeze_880 = None
        unsqueeze_881: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg244_1, 2);  arg244_1 = None
        permute_466: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_881, [2, 1, 0]);  unsqueeze_881 = None
        permute_467: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_465, [0, 2, 1]);  permute_465 = None
        view_513: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_467, [1, 100, 512]);  permute_467 = None
        permute_468: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_466, [2, 1, 0]);  permute_466 = None
        view_514: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_468, [1, 512, 128]);  permute_468 = None
        bmm_98: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_513, view_514);  view_513 = view_514 = None
        view_515: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_98, [100, 1, 128]);  bmm_98 = None
        permute_469: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_515, [0, 2, 1]);  view_515 = None
        view_516: "f32[100, 128]" = torch.ops.aten.view.default(permute_469, [100, 128]);  permute_469 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_382: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_516, arg245_1);  view_516 = arg245_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_383: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_361, add_382);  add_361 = add_382 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_47: "f32[100, 1]" = torch.ops.aten.mean.dim(add_383, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_47: "f32[100, 1]" = torch.ops.aten.var.correction(add_383, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_256: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_383, mean_47);  mean_47 = None
        add_384: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_47, 1e-05);  var_47 = None
        rsqrt_47: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_384);  add_384 = None
        mul_595: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_256, rsqrt_47);  sub_256 = rsqrt_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_596: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_595, arg246_1);  arg246_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_385: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_596, arg247_1);  mul_596 = arg247_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_891: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_385, 2);  add_385 = None
        permute_470: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_891, [0, 2, 1]);  unsqueeze_891 = None
        unsqueeze_892: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg248_1, 2);  arg248_1 = None
        permute_471: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_892, [2, 1, 0]);  unsqueeze_892 = None
        permute_472: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_470, [0, 2, 1]);  permute_470 = None
        view_517: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_472, [1, 100, 128]);  permute_472 = None
        permute_473: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_471, [2, 1, 0]);  permute_471 = None
        view_518: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_473, [1, 128, 60]);  permute_473 = None
        bmm_99: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_517, view_518);  view_517 = view_518 = None
        view_519: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_99, [100, 1, 60]);  bmm_99 = None
        permute_474: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_519, [0, 2, 1]);  view_519 = None
        view_520: "f32[100, 60]" = torch.ops.aten.view.default(permute_474, [100, 60]);  permute_474 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_604: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_520, 10.0);  view_520 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_521: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_604, [100, 20, 3]);  mul_604 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_390: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_219, view_521);  sum_219 = view_521 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_895: "f32[100, 20, 1, 3]" = torch.ops.aten.unsqueeze.default(add_390, -2);  add_390 = None
        mul_605: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_746, unsqueeze_895);  unsqueeze_746 = unsqueeze_895 = None
        sum_224: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_605, [-1]);  mul_605 = None
        add_391: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_224, unsqueeze_747);  sum_224 = unsqueeze_747 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_103: "f32[100, 3]" = torch.ops.aten.select.int(add_391, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_896: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_103, 1)
        unsqueeze_897: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_103, 0)
        sub_262: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_896, unsqueeze_897);  unsqueeze_896 = unsqueeze_897 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_606: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_262, sub_262);  sub_262 = None
        sum_225: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_606, [-1]);  mul_606 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_114: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_225, 1e-12);  sum_225 = None
        sqrt_85: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_114);  clamp_min_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_136: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_85, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_137: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_136, full_default);  where_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_248: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_137, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_138: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_248);  index_248 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_15: "f32[100, 100]" = torch.ops.aten.index_put.default(where_137, [unsqueeze_24, where_1], where_138);  where_137 = where_138 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_16 = torch.ops.aten.sort.stable(index_put_15, stable = True)
        getitem_76: "i64[100, 100]" = sort_16[1];  sort_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_565: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_76, 1, 0, 16);  getitem_76 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_249: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_15, [unsqueeze_24, slice_565]);  index_put_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_32: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_249, inf);  index_249 = None
        where_139: "i64[100, 16]" = torch.ops.aten.where.self(lt_32, slice_565, full_default_1);  lt_32 = slice_565 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_65: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_139], -1);  where_139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_392: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_85, 1e-06);  sqrt_85 = None
        log_30: "f32[100, 100]" = torch.ops.aten.log.default(add_392);  add_392 = None
        mul_607: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_30, -3.0);  log_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_31: "f32[100, 100]" = torch.ops.aten.log.default(getitem_13)
        neg_26: "f32[100, 100]" = torch.ops.aten.neg.default(log_31);  log_31 = None
        log_32: "f32[100, 100]" = torch.ops.aten.log.default(neg_26);  neg_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_263: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_607, log_32);  mul_607 = log_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_27: "f32[100, 100]" = torch.ops.aten.neg.default(sub_263);  sub_263 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_140: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_27, full_default);  neg_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_141: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_140, full_default);  where_140 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_29: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_65, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_251: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_141, [unsqueeze_24, cat_65])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_142: "f32[100, 32]" = torch.ops.aten.where.self(ne_29, full_default_7, index_251);  ne_29 = index_251 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_16: "f32[100, 100]" = torch.ops.aten.index_put.default(where_141, [unsqueeze_24, cat_65], where_142);  where_141 = where_142 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_17 = torch.ops.aten.sort.stable(index_put_16, stable = True)
        getitem_78: "i64[100, 100]" = sort_17[1];  sort_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_574: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_78, 1, 0, 32);  getitem_78 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_252: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_16, [unsqueeze_24, slice_574]);  index_put_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_33: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_252, inf);  index_252 = None
        where_143: "i64[100, 32]" = torch.ops.aten.where.self(lt_33, slice_574, full_default_37);  lt_33 = slice_574 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_66: "i64[100, 64]" = torch.ops.aten.cat.default([cat_65, where_143], -1);  cat_65 = where_143 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_104: "i64[100, 48]" = torch.ops.aten.select.int(view_10, 0, 4)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_105: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_25, 0, 4)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_106: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 4)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_253: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_66])
        bitwise_and_71: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_253);  index_253 = None
        ne_30: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_66, -1)
        bitwise_and_72: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_71, ne_30);  bitwise_and_71 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_254: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_66])
        eq_29: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_254);  index_254 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_255: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_66])
        eq_30: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_255);  index_255 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_256: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_66])
        sub_264: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_256);  index_256 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_115: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_264, -32);  sub_264 = None
        clamp_max_21: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_115, 32);  clamp_min_115 = None
        add_393: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_21, 32);  clamp_max_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_144: "i64[100, 64]" = torch.ops.aten.where.self(eq_29, add_393, full_default_38);  eq_29 = add_393 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_145: "i64[100, 64]" = torch.ops.aten.where.self(eq_30, where_144, full_default_38);  eq_30 = where_144 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_257: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg249_1, [where_145]);  arg249_1 = where_145 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_918: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_391, 1)
        slice_581: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_918, 2, 0, 5)
        unsqueeze_919: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_581, 3);  slice_581 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_258: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_391, [cat_66])
        unsqueeze_920: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_258, 2)
        slice_585: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_920, 3, 0, 5);  unsqueeze_920 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_265: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_919, slice_585);  unsqueeze_919 = slice_585 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_608: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_265, sub_265);  sub_265 = None
        sum_226: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_608, [-1]);  mul_608 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_116: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_226, 1e-12);  sum_226 = None
        sqrt_86: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_116);  clamp_min_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_522: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_86, [100, 64, 25]);  sqrt_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_921: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_522, 3);  view_522 = None
        sub_266: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_921, add_29);  unsqueeze_921 = None
        pow_17: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_266, 2);  sub_266 = None
        neg_28: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_17);  pow_17 = None
        div_106: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_28, 1.890625);  neg_28 = None
        exp_22: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_106);  div_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_523: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_22, [100, 64, 400]);  exp_22 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_922: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_523, 3);  view_523 = None
        permute_475: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_922, [0, 1, 3, 2]);  unsqueeze_922 = None
        unsqueeze_923: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg250_1, 2);  arg250_1 = None
        unsqueeze_924: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_923, 3);  unsqueeze_923 = None
        permute_476: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_924, [2, 3, 1, 0]);  unsqueeze_924 = None
        permute_477: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_475, [0, 1, 3, 2]);  permute_475 = None
        view_524: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_477, [1, 6400, 400]);  permute_477 = None
        permute_478: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_476, [3, 2, 0, 1]);  permute_476 = None
        view_525: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_478, [1, 400, 64]);  permute_478 = None
        bmm_100: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_524, view_525);  view_524 = view_525 = None
        view_526: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_100, [100, 64, 1, 64]);  bmm_100 = None
        permute_479: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_526, [0, 1, 3, 2]);  view_526 = None
        view_527: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_479, [100, 64, 64]);  permute_479 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_397: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_257, view_527);  index_257 = view_527 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_107: "f32[100, 3]" = torch.ops.aten.select.int(add_391, 1, 0)
        select_109: "f32[100, 3]" = torch.ops.aten.select.int(add_391, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_267: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_109, select_103);  select_109 = None
        sub_268: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_107, select_103);  select_107 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_611: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_267, sub_267)
        sum_227: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_611, [-1]);  mul_611 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_117: "f32[100]" = torch.ops.aten.clamp_min.default(sum_227, 1e-12);  sum_227 = None
        sqrt_87: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_117);  clamp_min_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_925: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_87, -1);  sqrt_87 = None
        div_107: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_267, unsqueeze_925);  sub_267 = unsqueeze_925 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_612: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_268, div_107)
        sum_228: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_612, [-1]);  mul_612 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_926: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_228, -1);  sum_228 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_613: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_926, div_107);  unsqueeze_926 = None
        sub_269: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_268, mul_613);  sub_268 = mul_613 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_614: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_269, sub_269)
        sum_229: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_614, [-1]);  mul_614 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_118: "f32[100]" = torch.ops.aten.clamp_min.default(sum_229, 1e-12);  sum_229 = None
        sqrt_88: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_118);  clamp_min_118 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_927: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_88, -1);  sqrt_88 = None
        div_108: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_269, unsqueeze_927);  sub_269 = unsqueeze_927 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_259: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_107, [None, remainder])
        index_260: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_108, [None, remainder_1])
        mul_615: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_259, index_260);  index_259 = index_260 = None
        index_261: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_107, [None, remainder_1])
        index_262: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_108, [None, remainder])
        mul_616: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_261, index_262);  index_261 = index_262 = None
        sub_270: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_615, mul_616);  mul_615 = mul_616 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_928: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_107, 2);  div_107 = None
        unsqueeze_929: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_108, 2);  div_108 = None
        unsqueeze_930: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_270, 2);  sub_270 = None
        cat_67: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_928, unsqueeze_929, unsqueeze_930], -1);  unsqueeze_928 = unsqueeze_929 = unsqueeze_930 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_934: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_67, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_935: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_103, -2);  select_103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_936: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_934, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_937: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_935, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_272: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_258, unsqueeze_937)
        unsqueeze_938: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_272, -1);  sub_272 = None
        mul_618: "f32[100, 64, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_936, unsqueeze_938);  unsqueeze_938 = None
        sum_231: "f32[100, 64, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_618, [-2]);  mul_618 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_619: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(sum_231, sum_231)
        sum_232: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_619, [-1]);  mul_619 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_119: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_232, 1e-12);  sum_232 = None
        sqrt_89: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_119);  clamp_min_119 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_939: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_89, -1);  sqrt_89 = None
        div_109: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(sum_231, unsqueeze_939);  sum_231 = unsqueeze_939 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        view_528: "f32[100, 64, 60]" = torch.ops.aten.view.default(div_109, [100, 64, 60]);  div_109 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_21: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_918, [100, 64, 20, 3]);  unsqueeze_918 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_68: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_21, index_258], -2);  expand_21 = index_258 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_273: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_68, unsqueeze_937);  cat_68 = unsqueeze_937 = None
        unsqueeze_945: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_273, -1);  sub_273 = None
        mul_620: "f32[100, 64, 40, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_936, unsqueeze_945);  unsqueeze_936 = unsqueeze_945 = None
        sum_233: "f32[100, 64, 40, 3]" = torch.ops.aten.sum.dim_IntList(mul_620, [-2]);  mul_620 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_621: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_233, sum_233)
        sum_234: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_621, [-1]);  mul_621 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_120: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_234, 1e-12);  sum_234 = None
        sqrt_90: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_120);  clamp_min_120 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_946: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_90, -1);  sqrt_90 = None
        div_110: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(sum_233, unsqueeze_946);  unsqueeze_946 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        view_529: "f32[100, 64, 120]" = torch.ops.aten.view.default(div_110, [100, 64, 120]);  div_110 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_622: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_233, 0.1);  sum_233 = None
        view_530: "f32[100, 64, 120]" = torch.ops.aten.view.default(mul_622, [100, 64, 120]);  mul_622 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_69: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_529, view_530], -1);  view_529 = view_530 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_947: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_528, 3);  view_528 = None
        permute_480: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_947, [0, 1, 3, 2]);  unsqueeze_947 = None
        unsqueeze_948: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg251_1, 2);  arg251_1 = None
        unsqueeze_949: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_948, 3);  unsqueeze_948 = None
        permute_481: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_949, [2, 3, 1, 0]);  unsqueeze_949 = None
        permute_482: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_480, [0, 1, 3, 2]);  permute_480 = None
        view_531: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_482, [1, 6400, 60]);  permute_482 = None
        permute_483: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_481, [3, 2, 0, 1]);  permute_481 = None
        view_532: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_483, [1, 60, 64]);  permute_483 = None
        bmm_101: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_531, view_532);  view_531 = view_532 = None
        view_533: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_101, [100, 64, 1, 64]);  bmm_101 = None
        permute_484: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_533, [0, 1, 3, 2]);  view_533 = None
        view_534: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_484, [100, 64, 64]);  permute_484 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_402: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_397, view_534);  add_397 = view_534 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_959: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_67, 1)
        permute_485: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_959, [0, 1, 3, 2]);  unsqueeze_959 = None
        index_268: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_67, [cat_66]);  cat_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:77 in rot_compose, code: return (a.unsqueeze(-1) * b.unsqueeze(-3)).sum(-2)
        unsqueeze_960: "f32[100, 1, 3, 3, 1]" = torch.ops.aten.unsqueeze.default(permute_485, -1);  permute_485 = None
        unsqueeze_961: "f32[100, 64, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(index_268, -3);  index_268 = None
        mul_630: "f32[100, 64, 3, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_960, unsqueeze_961);  unsqueeze_960 = unsqueeze_961 = None
        sum_239: "f32[100, 64, 3, 3]" = torch.ops.aten.sum.dim_IntList(mul_630, [-2]);  mul_630 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_535: "f32[100, 64, 9]" = torch.ops.aten.view.default(sum_239, [100, 64, 9]);  sum_239 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_962: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_535, 3);  view_535 = None
        permute_486: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_962, [0, 1, 3, 2]);  unsqueeze_962 = None
        unsqueeze_963: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg252_1, 2);  arg252_1 = None
        unsqueeze_964: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_963, 3);  unsqueeze_963 = None
        permute_487: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_964, [2, 3, 1, 0]);  unsqueeze_964 = None
        permute_488: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_486, [0, 1, 3, 2]);  permute_486 = None
        view_536: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_488, [1, 6400, 9]);  permute_488 = None
        permute_489: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_487, [3, 2, 0, 1]);  permute_487 = None
        view_537: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_489, [1, 9, 64]);  permute_489 = None
        bmm_102: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_536, view_537);  view_536 = view_537 = None
        view_538: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_102, [100, 64, 1, 64]);  bmm_102 = None
        permute_490: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_538, [0, 1, 3, 2]);  view_538 = None
        view_539: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_490, [100, 64, 64]);  permute_490 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_407: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_402, view_539);  add_402 = view_539 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_965: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_69, 3);  cat_69 = None
        permute_491: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_965, [0, 1, 3, 2]);  unsqueeze_965 = None
        unsqueeze_966: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg253_1, 2);  arg253_1 = None
        unsqueeze_967: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_966, 3);  unsqueeze_966 = None
        permute_492: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_967, [2, 3, 1, 0]);  unsqueeze_967 = None
        permute_493: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_491, [0, 1, 3, 2]);  permute_491 = None
        view_540: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_493, [1, 6400, 240]);  permute_493 = None
        permute_494: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_492, [3, 2, 0, 1]);  permute_492 = None
        view_541: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_494, [1, 240, 64]);  permute_494 = None
        bmm_103: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_540, view_541);  view_540 = view_541 = None
        view_542: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_103, [100, 64, 1, 64]);  bmm_103 = None
        permute_495: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_542, [0, 1, 3, 2]);  view_542 = None
        view_543: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_495, [100, 64, 64]);  permute_495 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_408: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_407, view_543);  add_407 = view_543 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_48: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_408, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_48: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_408, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_279: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_408, mean_48);  add_408 = mean_48 = None
        add_409: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_48, 1e-05);  var_48 = None
        rsqrt_48: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_409);  add_409 = None
        mul_631: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_279, rsqrt_48);  sub_279 = rsqrt_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_632: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_631, arg254_1);  mul_631 = arg254_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_410: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_632, arg255_1);  mul_632 = arg255_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_968: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_410, 3);  add_410 = None
        permute_496: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_968, [0, 1, 3, 2]);  unsqueeze_968 = None
        unsqueeze_969: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg256_1, 2);  arg256_1 = None
        unsqueeze_970: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_969, 3);  unsqueeze_969 = None
        permute_497: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_970, [2, 3, 1, 0]);  unsqueeze_970 = None
        permute_498: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_496, [0, 1, 3, 2]);  permute_496 = None
        view_544: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_498, [1, 6400, 64]);  permute_498 = None
        permute_499: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_497, [3, 2, 0, 1]);  permute_497 = None
        view_545: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_499, [1, 64, 128]);  permute_499 = None
        bmm_104: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_544, view_545);  view_544 = view_545 = None
        view_546: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_104, [100, 64, 1, 128]);  bmm_104 = None
        permute_500: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_546, [0, 1, 3, 2]);  view_546 = None
        view_547: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_500, [100, 64, 128]);  permute_500 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_411: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_547, arg257_1);  view_547 = arg257_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_633: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_411, add_411)
        mul_634: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_633, add_411);  mul_633 = None
        mul_635: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_634, 0.044715);  mul_634 = None
        add_412: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_411, mul_635);  mul_635 = None
        mul_636: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_412, 0.7978845608028654);  add_412 = None
        mul_637: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_411, 0.5);  add_411 = None
        tanh_22: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_636);  mul_636 = None
        add_413: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_22, 1);  tanh_22 = None
        mul_638: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_637, add_413);  mul_637 = add_413 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_971: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_638, 3);  mul_638 = None
        permute_501: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_971, [0, 1, 3, 2]);  unsqueeze_971 = None
        unsqueeze_972: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg258_1, 2);  arg258_1 = None
        unsqueeze_973: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_972, 3);  unsqueeze_972 = None
        permute_502: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_973, [2, 3, 1, 0]);  unsqueeze_973 = None
        permute_503: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_501, [0, 1, 3, 2]);  permute_501 = None
        view_548: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_503, [1, 6400, 128]);  permute_503 = None
        permute_504: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_502, [3, 2, 0, 1]);  permute_502 = None
        view_549: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_504, [1, 128, 64]);  permute_504 = None
        bmm_105: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_548, view_549);  view_548 = view_549 = None
        view_550: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_105, [100, 64, 1, 64]);  bmm_105 = None
        permute_505: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_550, [0, 1, 3, 2]);  view_550 = None
        view_551: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_505, [100, 64, 64]);  permute_505 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_414: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_551, arg259_1);  view_551 = arg259_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_640: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_595, arg260_1);  mul_595 = arg260_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_416: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_640, arg261_1);  mul_640 = arg261_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_113: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_391, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_113: "f32[100, 3]" = torch.ops.aten.select.int(div_113, 1, 0)
        select_114: "f32[100, 3]" = torch.ops.aten.select.int(div_113, 1, 1)
        select_115: "f32[100, 3]" = torch.ops.aten.select.int(div_113, 1, 2);  div_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_281: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_115, select_114);  select_115 = None
        sub_282: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_113, select_114);  select_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_641: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_281, sub_281)
        sum_240: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_641, [-1]);  mul_641 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_123: "f32[100]" = torch.ops.aten.clamp_min.default(sum_240, 1e-12);  sum_240 = None
        sqrt_93: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_123);  clamp_min_123 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_974: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_93, -1);  sqrt_93 = None
        div_114: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_281, unsqueeze_974);  sub_281 = unsqueeze_974 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_642: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_282, div_114)
        sum_241: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_642, [-1]);  mul_642 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_975: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_241, -1);  sum_241 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_643: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_975, div_114);  unsqueeze_975 = None
        sub_283: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_282, mul_643);  sub_282 = mul_643 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_644: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_283, sub_283)
        sum_242: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_644, [-1]);  mul_644 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_124: "f32[100]" = torch.ops.aten.clamp_min.default(sum_242, 1e-12);  sum_242 = None
        sqrt_94: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_124);  clamp_min_124 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_976: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_94, -1);  sqrt_94 = None
        div_115: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_283, unsqueeze_976);  sub_283 = unsqueeze_976 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_269: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_114, [None, remainder])
        index_270: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_115, [None, remainder_1])
        mul_645: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_269, index_270);  index_269 = index_270 = None
        index_271: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_114, [None, remainder_1])
        index_272: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_115, [None, remainder])
        mul_646: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_271, index_272);  index_271 = index_272 = None
        sub_284: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_645, mul_646);  mul_645 = mul_646 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_977: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_114, 2);  div_114 = None
        unsqueeze_978: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_115, 2);  div_115 = None
        unsqueeze_979: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_284, 2);  sub_284 = None
        cat_71: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_977, unsqueeze_978, unsqueeze_979], -1);  unsqueeze_977 = unsqueeze_978 = unsqueeze_979 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_50: "f32[100, 1]" = torch.ops.aten.mean.dim(add_416, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_50: "f32[100, 1]" = torch.ops.aten.var.correction(add_416, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_286: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_416, mean_50);  add_416 = mean_50 = None
        add_421: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_50, 1e-05);  var_50 = None
        rsqrt_50: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_421);  add_421 = None
        mul_648: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_286, rsqrt_50);  sub_286 = rsqrt_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_649: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_648, arg262_1);  mul_648 = arg262_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_422: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_649, arg263_1);  mul_649 = arg263_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_983: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_422, 2);  add_422 = None
        permute_506: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_983, [0, 2, 1]);  unsqueeze_983 = None
        unsqueeze_984: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg264_1, 2);  arg264_1 = None
        permute_507: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_984, [2, 1, 0]);  unsqueeze_984 = None
        permute_508: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_506, [0, 2, 1]);  permute_506 = None
        view_552: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_508, [1, 100, 128]);  permute_508 = None
        permute_509: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_507, [2, 1, 0]);  permute_507 = None
        view_553: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_509, [1, 128, 768]);  permute_509 = None
        bmm_106: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_552, view_553);  view_553 = None
        view_554: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_106, [100, 1, 768]);  bmm_106 = None
        permute_510: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_554, [0, 2, 1]);  view_554 = None
        view_555: "f32[100, 768]" = torch.ops.aten.view.default(permute_510, [100, 768]);  permute_510 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_556: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_555, [100, 8, 96]);  view_555 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_8 = torch.ops.aten.split.Tensor(view_556, 32, -1);  view_556 = None
        getitem_79: "f32[100, 8, 32]" = split_8[0]
        getitem_80: "f32[100, 8, 32]" = split_8[1]
        getitem_81: "f32[100, 8, 32]" = split_8[2];  split_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_51: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_79, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_51: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_79, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_287: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_79, mean_51);  getitem_79 = mean_51 = None
        add_423: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_51, 1e-05);  var_51 = None
        rsqrt_51: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_423);  add_423 = None
        mul_650: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_287, rsqrt_51);  sub_287 = rsqrt_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_651: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_650, arg265_1);  mul_650 = arg265_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_424: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_651, arg266_1);  mul_651 = arg266_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_52: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_80, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_52: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_80, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_288: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_80, mean_52);  getitem_80 = mean_52 = None
        add_425: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_52, 1e-05);  var_52 = None
        rsqrt_52: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_425);  add_425 = None
        mul_652: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_288, rsqrt_52);  sub_288 = rsqrt_52 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_653: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_652, arg267_1);  mul_652 = arg267_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_426: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_653, arg268_1);  mul_653 = arg268_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_986: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg269_1, 2);  arg269_1 = None
        permute_512: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_986, [2, 1, 0]);  unsqueeze_986 = None
        permute_514: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_512, [2, 1, 0]);  permute_512 = None
        view_558: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_514, [1, 128, 576]);  permute_514 = None
        bmm_107: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_552, view_558);  view_552 = view_558 = None
        view_559: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_107, [100, 1, 576]);  bmm_107 = None
        permute_515: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_559, [0, 2, 1]);  view_559 = None
        view_560: "f32[100, 576]" = torch.ops.aten.view.default(permute_515, [100, 576]);  permute_515 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_561: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_560, [100, 192, 3]);  view_560 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_987: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_71, -3);  cat_71 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_988: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_114, -2);  select_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_989: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_561, -2);  view_561 = None
        mul_654: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_987, unsqueeze_989);  unsqueeze_989 = None
        sum_244: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_654, [-1]);  mul_654 = None
        add_427: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_244, unsqueeze_988);  sum_244 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_562: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_427, [100, 8, 24, 3]);  add_427 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_612: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_562, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_615: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_562, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_618: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_562, 2, 16, 9223372036854775807);  view_562 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_990: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_414, 3)
        permute_516: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_990, [0, 1, 3, 2]);  unsqueeze_990 = None
        unsqueeze_991: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg270_1, 2);  arg270_1 = None
        unsqueeze_992: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_991, 3);  unsqueeze_991 = None
        permute_517: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_992, [2, 3, 1, 0]);  unsqueeze_992 = None
        permute_518: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_516, [0, 1, 3, 2]);  permute_516 = None
        view_563: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_518, [1, 6400, 64]);  permute_518 = None
        permute_519: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_517, [3, 2, 0, 1]);  permute_517 = None
        view_564: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_519, [1, 64, 8]);  permute_519 = None
        bmm_108: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_563, view_564);  view_563 = view_564 = None
        view_565: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_108, [100, 64, 1, 8]);  bmm_108 = None
        permute_520: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_565, [0, 1, 3, 2]);  view_565 = None
        view_566: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_520, [100, 64, 8]);  permute_520 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_23: "f32[8]" = torch.ops.aten.exp.default(arg271_1)
        log1p_8: "f32[8]" = torch.ops.aten.log1p.default(exp_23);  exp_23 = None
        gt_8: "b8[8]" = torch.ops.aten.gt.Scalar(arg271_1, 20)
        where_146: "f32[8]" = torch.ops.aten.where.self(gt_8, arg271_1, log1p_8);  gt_8 = arg271_1 = log1p_8 = None
        view_567: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_146, [1, 1, 8]);  where_146 = None
        mul_655: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_567, 0.16666666666666666);  view_567 = None
        div_116: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_655, 2);  mul_655 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_993: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_612, 1);  slice_612 = None
        index_273: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_615, [cat_66]);  slice_615 = None
        sub_289: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_993, index_273);  unsqueeze_993 = index_273 = None
        pow_18: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_289, 2);  sub_289 = None
        sum_245: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_18, [-1, -2]);  pow_18 = None
        mul_656: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_116, sum_245);  div_116 = sum_245 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_994: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_424, 1);  add_424 = None
        index_274: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_426, [cat_66]);  add_426 = None
        mul_657: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_994, index_274);  unsqueeze_994 = index_274 = None
        sum_246: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(mul_657, [-1]);  mul_657 = None
        mul_658: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sum_246, 0.1767766952966369);  sum_246 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_428: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_658, view_566);  mul_658 = view_566 = None
        sub_290: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_428, mul_656);  add_428 = mul_656 = None
        mul_659: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_290, 0.5773502691896257);  sub_290 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_73: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_72, ne_30);  bitwise_and_72 = ne_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_995: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_73, 2);  bitwise_and_73 = None
        where_147: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_995, mul_659, full_default_39);  mul_659 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_8: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_147, [-2], True)
        sub_291: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(where_147, amax_8);  where_147 = amax_8 = None
        exp_24: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_291);  sub_291 = None
        sum_247: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_24, [-2], True)
        div_117: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_24, sum_247);  exp_24 = sum_247 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_148: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_995, div_117, full_default_40);  unsqueeze_995 = div_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_997: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_148, 3);  where_148 = None
        unsqueeze_998: "f32[100, 64, 1, 64]" = torch.ops.aten.unsqueeze.default(add_414, 2);  add_414 = None
        mul_660: "f32[100, 64, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_997, unsqueeze_998);  unsqueeze_998 = None
        sum_248: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_660, [1]);  mul_660 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_275: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_81, [cat_66]);  getitem_81 = None
        mul_661: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_997, index_275);  index_275 = None
        sum_249: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_661, [1]);  mul_661 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_1001: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_997, 4);  unsqueeze_997 = None
        index_276: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_618, [cat_66]);  slice_618 = cat_66 = None
        mul_662: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1001, index_276);  unsqueeze_1001 = index_276 = None
        sum_250: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_662, [1]);  mul_662 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1004: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_987, -3);  unsqueeze_987 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1005: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_988, -2);  unsqueeze_988 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_292: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_250, unsqueeze_1005);  sum_250 = unsqueeze_1005 = None
        unsqueeze_1006: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_292, -1);  sub_292 = None
        mul_663: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1004, unsqueeze_1006);  unsqueeze_1004 = unsqueeze_1006 = None
        sum_251: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_663, [-2]);  mul_663 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_664: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_251, sum_251)
        sum_252: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_664, [-1]);  mul_664 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_125: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_252, 1e-12);  sum_252 = None
        sqrt_95: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_125);  clamp_min_125 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_568: "f32[100, 512]" = torch.ops.aten.view.default(sum_248, [100, -1]);  sum_248 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_569: "f32[100, 256]" = torch.ops.aten.view.default(sum_249, [100, -1]);  sum_249 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_570: "f32[100, 192]" = torch.ops.aten.view.default(sum_251, [100, -1]);  sum_251 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_571: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_95, [100, -1]);  sqrt_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_72: "f32[100, 1024]" = torch.ops.aten.cat.default([view_568, view_569, view_570, view_571], -1);  view_568 = view_569 = view_570 = view_571 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1007: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_72, 2);  cat_72 = None
        permute_521: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_1007, [0, 2, 1]);  unsqueeze_1007 = None
        unsqueeze_1008: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg272_1, 2);  arg272_1 = None
        permute_522: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_1008, [2, 1, 0]);  unsqueeze_1008 = None
        permute_523: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_521, [0, 2, 1]);  permute_521 = None
        view_572: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_523, [1, 100, 1024]);  permute_523 = None
        permute_524: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_522, [2, 1, 0]);  permute_522 = None
        view_573: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_524, [1, 1024, 128]);  permute_524 = None
        bmm_109: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_572, view_573);  view_572 = view_573 = None
        view_574: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_109, [100, 1, 128]);  bmm_109 = None
        permute_525: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_574, [0, 2, 1]);  view_574 = None
        view_575: "f32[100, 128]" = torch.ops.aten.view.default(permute_525, [100, 128]);  permute_525 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_429: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_575, arg273_1);  view_575 = arg273_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_430: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_383, add_429);  add_383 = add_429 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_53: "f32[100, 1]" = torch.ops.aten.mean.dim(add_430, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_53: "f32[100, 1]" = torch.ops.aten.var.correction(add_430, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_293: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_430, mean_53);  mean_53 = None
        add_431: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_53, 1e-05);  var_53 = None
        rsqrt_53: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_431);  add_431 = None
        mul_665: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_293, rsqrt_53);  sub_293 = rsqrt_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_666: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_665, arg274_1);  mul_665 = arg274_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_432: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_666, arg275_1);  mul_666 = arg275_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_54: "f32[100, 1]" = torch.ops.aten.mean.dim(add_432, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_54: "f32[100, 1]" = torch.ops.aten.var.correction(add_432, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_299: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_432, mean_54);  add_432 = mean_54 = None
        add_437: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_54, 1e-05);  var_54 = None
        rsqrt_54: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_437);  add_437 = None
        mul_674: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_299, rsqrt_54);  sub_299 = rsqrt_54 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_675: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_674, arg276_1);  mul_674 = arg276_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_438: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_675, arg277_1);  mul_675 = arg277_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1018: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_438, 2);  add_438 = None
        permute_526: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1018, [0, 2, 1]);  unsqueeze_1018 = None
        unsqueeze_1019: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg278_1, 2);  arg278_1 = None
        permute_527: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_1019, [2, 1, 0]);  unsqueeze_1019 = None
        permute_528: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_526, [0, 2, 1]);  permute_526 = None
        view_576: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_528, [1, 100, 128]);  permute_528 = None
        permute_529: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_527, [2, 1, 0]);  permute_527 = None
        view_577: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_529, [1, 128, 768]);  permute_529 = None
        bmm_110: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_576, view_577);  view_577 = None
        view_578: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_110, [100, 1, 768]);  bmm_110 = None
        permute_530: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_578, [0, 2, 1]);  view_578 = None
        view_579: "f32[100, 768]" = torch.ops.aten.view.default(permute_530, [100, 768]);  permute_530 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_580: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_579, [100, 8, 96]);  view_579 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_9 = torch.ops.aten.split.Tensor(view_580, 32, -1);  view_580 = None
        getitem_82: "f32[100, 8, 32]" = split_9[0]
        getitem_83: "f32[100, 8, 32]" = split_9[1]
        getitem_84: "f32[100, 8, 32]" = split_9[2];  split_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_55: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_82, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_55: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_82, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_300: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_82, mean_55);  getitem_82 = mean_55 = None
        add_439: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_55, 1e-05);  var_55 = None
        rsqrt_55: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_439);  add_439 = None
        mul_676: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_300, rsqrt_55);  sub_300 = rsqrt_55 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_677: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_676, arg279_1);  mul_676 = arg279_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_440: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_677, arg280_1);  mul_677 = arg280_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_56: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_83, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_56: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_83, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_301: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_83, mean_56);  getitem_83 = mean_56 = None
        add_441: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_56, 1e-05);  var_56 = None
        rsqrt_56: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_441);  add_441 = None
        mul_678: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_301, rsqrt_56);  sub_301 = rsqrt_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_679: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_678, arg281_1);  mul_678 = arg281_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_442: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_679, arg282_1);  mul_679 = arg282_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1021: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg283_1, 2);  arg283_1 = None
        permute_532: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_1021, [2, 1, 0]);  unsqueeze_1021 = None
        permute_534: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_532, [2, 1, 0]);  permute_532 = None
        view_582: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_534, [1, 128, 576]);  permute_534 = None
        bmm_111: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_576, view_582);  view_576 = view_582 = None
        view_583: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_111, [100, 1, 576]);  bmm_111 = None
        permute_535: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_583, [0, 2, 1]);  view_583 = None
        view_584: "f32[100, 576]" = torch.ops.aten.view.default(permute_535, [100, 576]);  permute_535 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_585: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_584, [100, 192, 3]);  view_584 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_1024: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_585, -2);  view_585 = None
        mul_680: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_270, unsqueeze_1024);  unsqueeze_1024 = None
        sum_257: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_680, [-1]);  mul_680 = None
        add_443: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_257, unsqueeze_271);  sum_257 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_586: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_443, [100, 8, 24, 3]);  add_443 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_633: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_586, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_636: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_586, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_639: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_586, 2, 16, 9223372036854775807);  view_586 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1025: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_105, 3)
        permute_536: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1025, [0, 1, 3, 2]);  unsqueeze_1025 = None
        unsqueeze_1026: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg284_1, 2);  arg284_1 = None
        unsqueeze_1027: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1026, 3);  unsqueeze_1026 = None
        permute_537: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_1027, [2, 3, 1, 0]);  unsqueeze_1027 = None
        permute_538: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_536, [0, 1, 3, 2]);  permute_536 = None
        view_587: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_538, [1, 4800, 64]);  permute_538 = None
        permute_539: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_537, [3, 2, 0, 1]);  permute_537 = None
        view_588: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_539, [1, 64, 8]);  permute_539 = None
        bmm_112: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_587, view_588);  view_587 = view_588 = None
        view_589: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_112, [100, 48, 1, 8]);  bmm_112 = None
        permute_540: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_589, [0, 1, 3, 2]);  view_589 = None
        view_590: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_540, [100, 48, 8]);  permute_540 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_25: "f32[8]" = torch.ops.aten.exp.default(arg285_1)
        log1p_9: "f32[8]" = torch.ops.aten.log1p.default(exp_25);  exp_25 = None
        gt_9: "b8[8]" = torch.ops.aten.gt.Scalar(arg285_1, 20)
        where_149: "f32[8]" = torch.ops.aten.where.self(gt_9, arg285_1, log1p_9);  gt_9 = arg285_1 = log1p_9 = None
        view_591: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_149, [1, 1, 8]);  where_149 = None
        mul_681: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_591, 0.16666666666666666);  view_591 = None
        div_121: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_681, 2);  mul_681 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_1028: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_633, 1);  slice_633 = None
        index_281: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_636, [select_104]);  slice_636 = None
        sub_302: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1028, index_281);  unsqueeze_1028 = index_281 = None
        pow_19: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_302, 2);  sub_302 = None
        sum_258: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_19, [-1, -2]);  pow_19 = None
        mul_682: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_121, sum_258);  div_121 = sum_258 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_1029: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_440, 1);  add_440 = None
        index_282: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_442, [select_104]);  add_442 = None
        mul_683: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_1029, index_282);  unsqueeze_1029 = index_282 = None
        sum_259: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(mul_683, [-1]);  mul_683 = None
        mul_684: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sum_259, 0.1767766952966369);  sum_259 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_444: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_684, view_590);  mul_684 = view_590 = None
        sub_303: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_444, mul_682);  add_444 = mul_682 = None
        mul_685: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_303, 0.5773502691896257);  sub_303 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_32: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_104, -1)
        bitwise_and_74: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_106, ne_32);  select_106 = ne_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_1030: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_74, 2);  bitwise_and_74 = None
        where_150: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_1030, mul_685, full_default_41);  mul_685 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_9: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_150, [-2], True)
        sub_304: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(where_150, amax_9);  where_150 = amax_9 = None
        exp_26: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_304);  sub_304 = None
        sum_260: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_26, [-2], True)
        div_122: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_26, sum_260);  exp_26 = sum_260 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_151: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_1030, div_122, full_default_42);  unsqueeze_1030 = div_122 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_1032: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_151, 3);  where_151 = None
        unsqueeze_1033: "f32[100, 48, 1, 64]" = torch.ops.aten.unsqueeze.default(select_105, 2);  select_105 = None
        mul_686: "f32[100, 48, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_1032, unsqueeze_1033);  unsqueeze_1033 = None
        sum_261: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_686, [1]);  mul_686 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_283: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_84, [select_104]);  getitem_84 = None
        mul_687: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_1032, index_283);  index_283 = None
        sum_262: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_687, [1]);  mul_687 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_1036: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1032, 4);  unsqueeze_1032 = None
        index_284: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_639, [select_104]);  slice_639 = select_104 = None
        mul_688: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1036, index_284);  unsqueeze_1036 = index_284 = None
        sum_263: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_688, [1]);  mul_688 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_305: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_263, unsqueeze_288);  sum_263 = None
        unsqueeze_1041: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_305, -1);  sub_305 = None
        mul_689: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_287, unsqueeze_1041);  unsqueeze_1041 = None
        sum_264: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_689, [-2]);  mul_689 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_690: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_264, sum_264)
        sum_265: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_690, [-1]);  mul_690 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_128: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_265, 1e-12);  sum_265 = None
        sqrt_98: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_128);  clamp_min_128 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_592: "f32[100, 512]" = torch.ops.aten.view.default(sum_261, [100, -1]);  sum_261 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_593: "f32[100, 256]" = torch.ops.aten.view.default(sum_262, [100, -1]);  sum_262 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_594: "f32[100, 192]" = torch.ops.aten.view.default(sum_264, [100, -1]);  sum_264 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_595: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_98, [100, -1]);  sqrt_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_74: "f32[100, 1024]" = torch.ops.aten.cat.default([view_592, view_593, view_594, view_595], -1);  view_592 = view_593 = view_594 = view_595 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1042: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_74, 2);  cat_74 = None
        permute_541: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_1042, [0, 2, 1]);  unsqueeze_1042 = None
        unsqueeze_1043: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg286_1, 2);  arg286_1 = None
        permute_542: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_1043, [2, 1, 0]);  unsqueeze_1043 = None
        permute_543: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_541, [0, 2, 1]);  permute_541 = None
        view_596: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_543, [1, 100, 1024]);  permute_543 = None
        permute_544: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_542, [2, 1, 0]);  permute_542 = None
        view_597: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_544, [1, 1024, 128]);  permute_544 = None
        bmm_113: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_596, view_597);  view_596 = view_597 = None
        view_598: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_113, [100, 1, 128]);  bmm_113 = None
        permute_545: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_598, [0, 2, 1]);  view_598 = None
        view_599: "f32[100, 128]" = torch.ops.aten.view.default(permute_545, [100, 128]);  permute_545 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_445: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_599, arg287_1);  view_599 = arg287_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_446: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_430, add_445);  add_430 = add_445 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_57: "f32[100, 1]" = torch.ops.aten.mean.dim(add_446, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_57: "f32[100, 1]" = torch.ops.aten.var.correction(add_446, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_306: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_446, mean_57);  mean_57 = None
        add_447: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_57, 1e-05);  var_57 = None
        rsqrt_57: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_447);  add_447 = None
        mul_691: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_306, rsqrt_57);  sub_306 = rsqrt_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_692: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_691, arg288_1);  mul_691 = arg288_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_448: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_692, arg289_1);  mul_692 = arg289_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_311: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_391, unsqueeze_935)
        unsqueeze_1052: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_311, -1);  sub_311 = None
        mul_699: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_934, unsqueeze_1052);  unsqueeze_1052 = None
        sum_269: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_699, [-2]);  mul_699 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        view_600: "f32[100, 60]" = torch.ops.aten.view.default(sum_269, [100, -1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1054: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg290_1, 2);  arg290_1 = None
        permute_547: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_1054, [2, 1, 0]);  unsqueeze_1054 = None
        permute_549: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_547, [2, 1, 0]);  permute_547 = None
        view_602: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_549, [1, 128, 128]);  permute_549 = None
        bmm_114: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_105, view_602);  view_602 = None
        view_603: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_114, [100, 1, 128]);  bmm_114 = None
        permute_550: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_603, [0, 2, 1]);  view_603 = None
        view_604: "f32[100, 128]" = torch.ops.aten.view.default(permute_550, [100, 128]);  permute_550 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_453: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_448, view_604);  add_448 = view_604 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1055: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_600, 2);  view_600 = None
        permute_551: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_1055, [0, 2, 1]);  unsqueeze_1055 = None
        unsqueeze_1056: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg291_1, 2);  arg291_1 = None
        permute_552: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_1056, [2, 1, 0]);  unsqueeze_1056 = None
        permute_553: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_551, [0, 2, 1]);  permute_551 = None
        view_605: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_553, [1, 100, 60]);  permute_553 = None
        permute_554: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_552, [2, 1, 0]);  permute_552 = None
        view_606: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_554, [1, 60, 256]);  permute_554 = None
        bmm_115: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_605, view_606);  view_605 = view_606 = None
        view_607: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_115, [100, 1, 256]);  bmm_115 = None
        permute_555: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_607, [0, 2, 1]);  view_607 = None
        view_608: "f32[100, 256]" = torch.ops.aten.view.default(permute_555, [100, 256]);  permute_555 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_454: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_608, arg292_1);  view_608 = arg292_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_700: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_454, add_454)
        mul_701: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_700, add_454);  mul_700 = None
        mul_702: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_701, 0.044715);  mul_701 = None
        add_455: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_454, mul_702);  mul_702 = None
        mul_703: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_455, 0.7978845608028654);  add_455 = None
        mul_704: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_454, 0.5);  add_454 = None
        tanh_23: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_703);  mul_703 = None
        add_456: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_23, 1);  tanh_23 = None
        mul_705: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_704, add_456);  mul_704 = add_456 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1057: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_705, 2);  mul_705 = None
        permute_556: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_1057, [0, 2, 1]);  unsqueeze_1057 = None
        unsqueeze_1058: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg293_1, 2);  arg293_1 = None
        permute_557: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_1058, [2, 1, 0]);  unsqueeze_1058 = None
        permute_558: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_556, [0, 2, 1]);  permute_556 = None
        view_609: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_558, [1, 100, 256]);  permute_558 = None
        permute_559: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_557, [2, 1, 0]);  permute_557 = None
        view_610: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_559, [1, 256, 128]);  permute_559 = None
        bmm_116: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_609, view_610);  view_609 = view_610 = None
        view_611: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_116, [100, 1, 128]);  bmm_116 = None
        permute_560: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_611, [0, 2, 1]);  view_611 = None
        view_612: "f32[100, 128]" = torch.ops.aten.view.default(permute_560, [100, 128]);  permute_560 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_457: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_612, arg294_1);  view_612 = arg294_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_458: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_453, add_457);  add_453 = add_457 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1059: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_458, 2);  add_458 = None
        permute_561: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1059, [0, 2, 1]);  unsqueeze_1059 = None
        unsqueeze_1060: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg295_1, 2);  arg295_1 = None
        permute_562: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1060, [2, 1, 0]);  unsqueeze_1060 = None
        permute_563: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_561, [0, 2, 1]);  permute_561 = None
        view_613: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_563, [1, 100, 128]);  permute_563 = None
        permute_564: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_562, [2, 1, 0]);  permute_562 = None
        view_614: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_564, [1, 128, 512]);  permute_564 = None
        bmm_117: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_613, view_614);  view_614 = None
        view_615: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_117, [100, 1, 512]);  bmm_117 = None
        permute_565: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_615, [0, 2, 1]);  view_615 = None
        view_616: "f32[100, 512]" = torch.ops.aten.view.default(permute_565, [100, 512]);  permute_565 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1062: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg296_1, 2);  arg296_1 = None
        permute_567: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1062, [2, 1, 0]);  unsqueeze_1062 = None
        permute_569: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_567, [2, 1, 0]);  permute_567 = None
        view_618: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_569, [1, 128, 512]);  permute_569 = None
        bmm_118: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_613, view_618);  view_618 = None
        view_619: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_118, [100, 1, 512]);  bmm_118 = None
        permute_570: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_619, [0, 2, 1]);  view_619 = None
        view_620: "f32[100, 512]" = torch.ops.aten.view.default(permute_570, [100, 512]);  permute_570 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_706: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_620, view_620)
        mul_707: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_706, view_620);  mul_706 = None
        mul_708: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_707, 0.044715);  mul_707 = None
        add_459: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_620, mul_708);  mul_708 = None
        mul_709: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_459, 0.7978845608028654);  add_459 = None
        mul_710: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_620, 0.5);  view_620 = None
        tanh_24: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_709);  mul_709 = None
        add_460: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_24, 1);  tanh_24 = None
        mul_711: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_710, add_460);  mul_710 = add_460 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_712: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_711, view_616);  mul_711 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1064: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg297_1, 2);  arg297_1 = None
        permute_572: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1064, [2, 1, 0]);  unsqueeze_1064 = None
        permute_574: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_572, [2, 1, 0]);  permute_572 = None
        view_622: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_574, [1, 128, 512]);  permute_574 = None
        bmm_119: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_613, view_622);  view_622 = None
        view_623: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_119, [100, 1, 512]);  bmm_119 = None
        permute_575: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_623, [0, 2, 1]);  view_623 = None
        view_624: "f32[100, 512]" = torch.ops.aten.view.default(permute_575, [100, 512]);  permute_575 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_713: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_624, view_624)
        mul_714: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_713, view_624);  mul_713 = None
        mul_715: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_714, 0.044715);  mul_714 = None
        add_461: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_624, mul_715);  mul_715 = None
        mul_716: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_461, 0.7978845608028654);  add_461 = None
        mul_717: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_624, 0.5);  view_624 = None
        tanh_25: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_716);  mul_716 = None
        add_462: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_25, 1);  tanh_25 = None
        mul_718: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_717, add_462);  mul_717 = add_462 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1066: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg298_1, 2);  arg298_1 = None
        permute_577: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1066, [2, 1, 0]);  unsqueeze_1066 = None
        permute_579: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_577, [2, 1, 0]);  permute_577 = None
        view_626: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_579, [1, 128, 512]);  permute_579 = None
        bmm_120: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_613, view_626);  view_613 = view_626 = None
        view_627: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_120, [100, 1, 512]);  bmm_120 = None
        permute_580: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_627, [0, 2, 1]);  view_627 = None
        view_628: "f32[100, 512]" = torch.ops.aten.view.default(permute_580, [100, 512]);  permute_580 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_719: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_628, view_628)
        mul_720: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_719, view_628);  mul_719 = None
        mul_721: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_720, 0.044715);  mul_720 = None
        add_463: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_628, mul_721);  mul_721 = None
        mul_722: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_463, 0.7978845608028654);  add_463 = None
        mul_723: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_628, 0.5);  view_628 = None
        tanh_26: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_722);  mul_722 = None
        add_464: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_26, 1);  tanh_26 = None
        mul_724: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_723, add_464);  mul_723 = add_464 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_725: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_724, view_616);  mul_724 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_152: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_725, full_default_44);  mul_725 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_153: "f32[100, 512]" = torch.ops.aten.where.self(view_133, where_152, full_default_44);  where_152 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_16: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_2, where_153);  where_153 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_289: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_16, [clamp_max_2]);  scatter_add_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_125: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_289, clamp_min_33);  index_289 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_156: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_125, full_default_44);  div_125 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_465: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_712, where_156);  mul_712 = where_156 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_727: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_718, view_616);  mul_718 = view_616 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_157: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_727, full_default_44);  mul_727 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_158: "f32[100, 512]" = torch.ops.aten.where.self(view_137, where_157, full_default_44);  where_157 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_18: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_4, where_158);  where_158 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_291: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_18, [clamp_max_4]);  scatter_add_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_126: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_291, clamp_min_36);  index_291 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_161: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_126, full_default_44);  div_126 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_466: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_465, where_161);  add_465 = where_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1068: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_466, 2);  add_466 = None
        permute_581: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_1068, [0, 2, 1]);  unsqueeze_1068 = None
        unsqueeze_1069: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg299_1, 2);  arg299_1 = None
        permute_582: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_1069, [2, 1, 0]);  unsqueeze_1069 = None
        permute_583: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_581, [0, 2, 1]);  permute_581 = None
        view_637: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_583, [1, 100, 512]);  permute_583 = None
        permute_584: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_582, [2, 1, 0]);  permute_582 = None
        view_638: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_584, [1, 512, 128]);  permute_584 = None
        bmm_121: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_637, view_638);  view_637 = view_638 = None
        view_639: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_121, [100, 1, 128]);  bmm_121 = None
        permute_585: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_639, [0, 2, 1]);  view_639 = None
        view_640: "f32[100, 128]" = torch.ops.aten.view.default(permute_585, [100, 128]);  permute_585 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_467: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_640, arg300_1);  view_640 = arg300_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_468: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_446, add_467);  add_446 = add_467 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_58: "f32[100, 1]" = torch.ops.aten.mean.dim(add_468, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_58: "f32[100, 1]" = torch.ops.aten.var.correction(add_468, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_312: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_468, mean_58);  mean_58 = None
        add_469: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_58, 1e-05);  var_58 = None
        rsqrt_58: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_469);  add_469 = None
        mul_729: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_312, rsqrt_58);  sub_312 = rsqrt_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_730: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_729, arg301_1);  arg301_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_470: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_730, arg302_1);  mul_730 = arg302_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1079: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_470, 2);  add_470 = None
        permute_586: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1079, [0, 2, 1]);  unsqueeze_1079 = None
        unsqueeze_1080: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg303_1, 2);  arg303_1 = None
        permute_587: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_1080, [2, 1, 0]);  unsqueeze_1080 = None
        permute_588: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_586, [0, 2, 1]);  permute_586 = None
        view_641: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_588, [1, 100, 128]);  permute_588 = None
        permute_589: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_587, [2, 1, 0]);  permute_587 = None
        view_642: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_589, [1, 128, 60]);  permute_589 = None
        bmm_122: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_641, view_642);  view_641 = view_642 = None
        view_643: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_122, [100, 1, 60]);  bmm_122 = None
        permute_590: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_643, [0, 2, 1]);  view_643 = None
        view_644: "f32[100, 60]" = torch.ops.aten.view.default(permute_590, [100, 60]);  permute_590 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_738: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_644, 10.0);  view_644 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_645: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_738, [100, 20, 3]);  mul_738 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_475: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_269, view_645);  sum_269 = view_645 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_1083: "f32[100, 20, 1, 3]" = torch.ops.aten.unsqueeze.default(add_475, -2);  add_475 = None
        mul_739: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_934, unsqueeze_1083);  unsqueeze_934 = unsqueeze_1083 = None
        sum_274: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_739, [-1]);  mul_739 = None
        add_476: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_274, unsqueeze_935);  sum_274 = unsqueeze_935 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_125: "f32[100, 3]" = torch.ops.aten.select.int(add_476, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_1084: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_125, 1)
        unsqueeze_1085: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_125, 0)
        sub_318: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1084, unsqueeze_1085);  unsqueeze_1084 = unsqueeze_1085 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_740: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_318, sub_318);  sub_318 = None
        sum_275: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_740, [-1]);  mul_740 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_139: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_275, 1e-12);  sum_275 = None
        sqrt_103: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_139);  clamp_min_139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_162: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_103, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_163: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_162, full_default);  where_162 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_298: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_163, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_164: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_298);  ne = full_default_3 = index_298 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_17: "f32[100, 100]" = torch.ops.aten.index_put.default(where_163, [unsqueeze_24, where_1], where_164);  where_163 = where_164 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_18 = torch.ops.aten.sort.stable(index_put_17, stable = True)
        getitem_86: "i64[100, 100]" = sort_18[1];  sort_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_671: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_86, 1, 0, 16);  getitem_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_299: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_17, [unsqueeze_24, slice_671]);  index_put_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_38: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_299, inf);  index_299 = None
        where_165: "i64[100, 16]" = torch.ops.aten.where.self(lt_38, slice_671, full_default_1);  lt_38 = slice_671 = full_default_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_77: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_165], -1);  where_165 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_477: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_103, 1e-06);  sqrt_103 = None
        log_33: "f32[100, 100]" = torch.ops.aten.log.default(add_477);  add_477 = None
        mul_741: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_33, -3.0);  log_33 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_34: "f32[100, 100]" = torch.ops.aten.log.default(getitem_16)
        neg_29: "f32[100, 100]" = torch.ops.aten.neg.default(log_34);  log_34 = None
        log_35: "f32[100, 100]" = torch.ops.aten.log.default(neg_29);  neg_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_319: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_741, log_35);  mul_741 = log_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_30: "f32[100, 100]" = torch.ops.aten.neg.default(sub_319);  sub_319 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_166: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_30, full_default);  eq = neg_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_167: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_166, full_default);  bitwise_and_1 = where_166 = full_default = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_34: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_77, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_301: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_167, [unsqueeze_24, cat_77])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_168: "f32[100, 32]" = torch.ops.aten.where.self(ne_34, full_default_7, index_301);  ne_34 = full_default_7 = index_301 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_18: "f32[100, 100]" = torch.ops.aten.index_put.default(where_167, [unsqueeze_24, cat_77], where_168);  where_167 = where_168 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_19 = torch.ops.aten.sort.stable(index_put_18, stable = True)
        getitem_88: "i64[100, 100]" = sort_19[1];  sort_19 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_680: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_88, 1, 0, 32);  getitem_88 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_302: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_18, [unsqueeze_24, slice_680]);  index_put_18 = unsqueeze_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_39: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_302, inf);  index_302 = None
        where_169: "i64[100, 32]" = torch.ops.aten.where.self(lt_39, slice_680, full_default_37);  lt_39 = slice_680 = full_default_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_78: "i64[100, 64]" = torch.ops.aten.cat.default([cat_77, where_169], -1);  cat_77 = where_169 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_126: "i64[100, 48]" = torch.ops.aten.select.int(view_10, 0, 5)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_127: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_25, 0, 5);  view_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_128: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 5);  bitwise_and_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_303: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_78]);  arg16_1 = None
        bitwise_and_83: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_303);  index_303 = None
        ne_35: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_78, -1)
        bitwise_and_84: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_83, ne_35);  bitwise_and_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_304: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_78]);  arg15_1 = None
        eq_33: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_304);  unsqueeze_18 = index_304 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_305: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_78]);  arg14_1 = None
        eq_34: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_305);  unsqueeze_16 = index_305 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_306: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_78]);  arg13_1 = None
        sub_320: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_306);  unsqueeze_22 = index_306 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_140: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_320, -32);  sub_320 = None
        clamp_max_26: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_140, 32);  clamp_min_140 = None
        add_478: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_26, 32);  clamp_max_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_170: "i64[100, 64]" = torch.ops.aten.where.self(eq_33, add_478, full_default_38);  eq_33 = add_478 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_171: "i64[100, 64]" = torch.ops.aten.where.self(eq_34, where_170, full_default_38);  eq_34 = where_170 = full_default_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_307: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg304_1, [where_171]);  arg304_1 = where_171 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_1106: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_476, 1)
        slice_687: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_1106, 2, 0, 5)
        unsqueeze_1107: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_687, 3);  slice_687 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_308: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_476, [cat_78])
        unsqueeze_1108: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_308, 2)
        slice_691: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_1108, 3, 0, 5);  unsqueeze_1108 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_321: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1107, slice_691);  unsqueeze_1107 = slice_691 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_742: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_321, sub_321);  sub_321 = None
        sum_276: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_742, [-1]);  mul_742 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_141: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_276, 1e-12);  sum_276 = None
        sqrt_104: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_141);  clamp_min_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_646: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_104, [100, 64, 25]);  sqrt_104 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_1109: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_646, 3);  view_646 = None
        sub_322: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_1109, add_29);  unsqueeze_1109 = add_29 = None
        pow_20: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_322, 2);  sub_322 = None
        neg_31: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_20);  pow_20 = None
        div_129: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_31, 1.890625);  neg_31 = None
        exp_27: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_129);  div_129 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_647: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_27, [100, 64, 400]);  exp_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1110: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_647, 3);  view_647 = None
        permute_591: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_1110, [0, 1, 3, 2]);  unsqueeze_1110 = None
        unsqueeze_1111: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg305_1, 2);  arg305_1 = None
        unsqueeze_1112: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1111, 3);  unsqueeze_1111 = None
        permute_592: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_1112, [2, 3, 1, 0]);  unsqueeze_1112 = None
        permute_593: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_591, [0, 1, 3, 2]);  permute_591 = None
        view_648: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_593, [1, 6400, 400]);  permute_593 = None
        permute_594: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_592, [3, 2, 0, 1]);  permute_592 = None
        view_649: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_594, [1, 400, 64]);  permute_594 = None
        bmm_123: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_648, view_649);  view_648 = view_649 = None
        view_650: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_123, [100, 64, 1, 64]);  bmm_123 = None
        permute_595: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_650, [0, 1, 3, 2]);  view_650 = None
        view_651: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_595, [100, 64, 64]);  permute_595 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_482: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_307, view_651);  index_307 = view_651 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_129: "f32[100, 3]" = torch.ops.aten.select.int(add_476, 1, 0)
        select_131: "f32[100, 3]" = torch.ops.aten.select.int(add_476, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_323: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_131, select_125);  select_131 = None
        sub_324: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_129, select_125);  select_129 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_745: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_323, sub_323)
        sum_277: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_745, [-1]);  mul_745 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_142: "f32[100]" = torch.ops.aten.clamp_min.default(sum_277, 1e-12);  sum_277 = None
        sqrt_105: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_142);  clamp_min_142 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1113: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_105, -1);  sqrt_105 = None
        div_130: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_323, unsqueeze_1113);  sub_323 = unsqueeze_1113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_746: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_324, div_130)
        sum_278: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_746, [-1]);  mul_746 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_1114: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_278, -1);  sum_278 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_747: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1114, div_130);  unsqueeze_1114 = None
        sub_325: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_324, mul_747);  sub_324 = mul_747 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_748: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_325, sub_325)
        sum_279: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_748, [-1]);  mul_748 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_143: "f32[100]" = torch.ops.aten.clamp_min.default(sum_279, 1e-12);  sum_279 = None
        sqrt_106: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_143);  clamp_min_143 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1115: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_106, -1);  sqrt_106 = None
        div_131: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_325, unsqueeze_1115);  sub_325 = unsqueeze_1115 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_309: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_130, [None, remainder])
        index_310: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_131, [None, remainder_1])
        mul_749: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_309, index_310);  index_309 = index_310 = None
        index_311: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_130, [None, remainder_1])
        index_312: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_131, [None, remainder])
        mul_750: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_311, index_312);  index_311 = index_312 = None
        sub_326: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_749, mul_750);  mul_749 = mul_750 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_1116: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_130, 2);  div_130 = None
        unsqueeze_1117: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_131, 2);  div_131 = None
        unsqueeze_1118: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_326, 2);  sub_326 = None
        cat_79: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_1116, unsqueeze_1117, unsqueeze_1118], -1);  unsqueeze_1116 = unsqueeze_1117 = unsqueeze_1118 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1122: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_79, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1123: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_125, -2);  select_125 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1124: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_1122, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1125: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_1123, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_328: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_308, unsqueeze_1125)
        unsqueeze_1126: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_328, -1);  sub_328 = None
        mul_752: "f32[100, 64, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1124, unsqueeze_1126);  unsqueeze_1126 = None
        sum_281: "f32[100, 64, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_752, [-2]);  mul_752 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_753: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(sum_281, sum_281)
        sum_282: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_753, [-1]);  mul_753 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_144: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_282, 1e-12);  sum_282 = None
        sqrt_107: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_144);  clamp_min_144 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1127: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_107, -1);  sqrt_107 = None
        div_132: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(sum_281, unsqueeze_1127);  sum_281 = unsqueeze_1127 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        view_652: "f32[100, 64, 60]" = torch.ops.aten.view.default(div_132, [100, 64, 60]);  div_132 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_26: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_1106, [100, 64, 20, 3]);  unsqueeze_1106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_80: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_26, index_308], -2);  expand_26 = index_308 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_329: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_80, unsqueeze_1125);  cat_80 = unsqueeze_1125 = None
        unsqueeze_1133: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_329, -1);  sub_329 = None
        mul_754: "f32[100, 64, 40, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1124, unsqueeze_1133);  unsqueeze_1124 = unsqueeze_1133 = None
        sum_283: "f32[100, 64, 40, 3]" = torch.ops.aten.sum.dim_IntList(mul_754, [-2]);  mul_754 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_755: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_283, sum_283)
        sum_284: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_755, [-1]);  mul_755 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_145: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_284, 1e-12);  sum_284 = None
        sqrt_108: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_145);  clamp_min_145 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1134: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_108, -1);  sqrt_108 = None
        div_133: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(sum_283, unsqueeze_1134);  unsqueeze_1134 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        view_653: "f32[100, 64, 120]" = torch.ops.aten.view.default(div_133, [100, 64, 120]);  div_133 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_756: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(sum_283, 0.1);  sum_283 = None
        view_654: "f32[100, 64, 120]" = torch.ops.aten.view.default(mul_756, [100, 64, 120]);  mul_756 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_81: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_653, view_654], -1);  view_653 = view_654 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1135: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_652, 3);  view_652 = None
        permute_596: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_1135, [0, 1, 3, 2]);  unsqueeze_1135 = None
        unsqueeze_1136: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg306_1, 2);  arg306_1 = None
        unsqueeze_1137: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1136, 3);  unsqueeze_1136 = None
        permute_597: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_1137, [2, 3, 1, 0]);  unsqueeze_1137 = None
        permute_598: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_596, [0, 1, 3, 2]);  permute_596 = None
        view_655: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_598, [1, 6400, 60]);  permute_598 = None
        permute_599: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_597, [3, 2, 0, 1]);  permute_597 = None
        view_656: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_599, [1, 60, 64]);  permute_599 = None
        bmm_124: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_655, view_656);  view_655 = view_656 = None
        view_657: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_124, [100, 64, 1, 64]);  bmm_124 = None
        permute_600: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_657, [0, 1, 3, 2]);  view_657 = None
        view_658: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_600, [100, 64, 64]);  permute_600 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_487: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_482, view_658);  add_482 = view_658 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_1147: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_79, 1)
        permute_601: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_1147, [0, 1, 3, 2]);  unsqueeze_1147 = None
        index_318: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_79, [cat_78]);  cat_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:77 in rot_compose, code: return (a.unsqueeze(-1) * b.unsqueeze(-3)).sum(-2)
        unsqueeze_1148: "f32[100, 1, 3, 3, 1]" = torch.ops.aten.unsqueeze.default(permute_601, -1);  permute_601 = None
        unsqueeze_1149: "f32[100, 64, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(index_318, -3);  index_318 = None
        mul_764: "f32[100, 64, 3, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1148, unsqueeze_1149);  unsqueeze_1148 = unsqueeze_1149 = None
        sum_289: "f32[100, 64, 3, 3]" = torch.ops.aten.sum.dim_IntList(mul_764, [-2]);  mul_764 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_659: "f32[100, 64, 9]" = torch.ops.aten.view.default(sum_289, [100, 64, 9]);  sum_289 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1150: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_659, 3);  view_659 = None
        permute_602: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_1150, [0, 1, 3, 2]);  unsqueeze_1150 = None
        unsqueeze_1151: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg307_1, 2);  arg307_1 = None
        unsqueeze_1152: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1151, 3);  unsqueeze_1151 = None
        permute_603: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_1152, [2, 3, 1, 0]);  unsqueeze_1152 = None
        permute_604: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_602, [0, 1, 3, 2]);  permute_602 = None
        view_660: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_604, [1, 6400, 9]);  permute_604 = None
        permute_605: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_603, [3, 2, 0, 1]);  permute_603 = None
        view_661: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_605, [1, 9, 64]);  permute_605 = None
        bmm_125: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_660, view_661);  view_660 = view_661 = None
        view_662: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_125, [100, 64, 1, 64]);  bmm_125 = None
        permute_606: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_662, [0, 1, 3, 2]);  view_662 = None
        view_663: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_606, [100, 64, 64]);  permute_606 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_492: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_487, view_663);  add_487 = view_663 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1153: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_81, 3);  cat_81 = None
        permute_607: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_1153, [0, 1, 3, 2]);  unsqueeze_1153 = None
        unsqueeze_1154: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg308_1, 2);  arg308_1 = None
        unsqueeze_1155: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1154, 3);  unsqueeze_1154 = None
        permute_608: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_1155, [2, 3, 1, 0]);  unsqueeze_1155 = None
        permute_609: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_607, [0, 1, 3, 2]);  permute_607 = None
        view_664: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_609, [1, 6400, 240]);  permute_609 = None
        permute_610: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_608, [3, 2, 0, 1]);  permute_608 = None
        view_665: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_610, [1, 240, 64]);  permute_610 = None
        bmm_126: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_664, view_665);  view_664 = view_665 = None
        view_666: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_126, [100, 64, 1, 64]);  bmm_126 = None
        permute_611: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_666, [0, 1, 3, 2]);  view_666 = None
        view_667: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_611, [100, 64, 64]);  permute_611 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_493: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_492, view_667);  add_492 = view_667 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_59: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_493, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_59: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_493, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_335: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_493, mean_59);  add_493 = mean_59 = None
        add_494: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_59, 1e-05);  var_59 = None
        rsqrt_59: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_494);  add_494 = None
        mul_765: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_335, rsqrt_59);  sub_335 = rsqrt_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_766: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_765, arg309_1);  mul_765 = arg309_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_495: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_766, arg310_1);  mul_766 = arg310_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1156: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_495, 3);  add_495 = None
        permute_612: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1156, [0, 1, 3, 2]);  unsqueeze_1156 = None
        unsqueeze_1157: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg311_1, 2);  arg311_1 = None
        unsqueeze_1158: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1157, 3);  unsqueeze_1157 = None
        permute_613: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_1158, [2, 3, 1, 0]);  unsqueeze_1158 = None
        permute_614: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_612, [0, 1, 3, 2]);  permute_612 = None
        view_668: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_614, [1, 6400, 64]);  permute_614 = None
        permute_615: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_613, [3, 2, 0, 1]);  permute_613 = None
        view_669: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_615, [1, 64, 128]);  permute_615 = None
        bmm_127: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_668, view_669);  view_668 = view_669 = None
        view_670: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_127, [100, 64, 1, 128]);  bmm_127 = None
        permute_616: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_670, [0, 1, 3, 2]);  view_670 = None
        view_671: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_616, [100, 64, 128]);  permute_616 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_496: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_671, arg312_1);  view_671 = arg312_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_767: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_496, add_496)
        mul_768: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_767, add_496);  mul_767 = None
        mul_769: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_768, 0.044715);  mul_768 = None
        add_497: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_496, mul_769);  mul_769 = None
        mul_770: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_497, 0.7978845608028654);  add_497 = None
        mul_771: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_496, 0.5);  add_496 = None
        tanh_27: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_770);  mul_770 = None
        add_498: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_27, 1);  tanh_27 = None
        mul_772: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_771, add_498);  mul_771 = add_498 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1159: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_772, 3);  mul_772 = None
        permute_617: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1159, [0, 1, 3, 2]);  unsqueeze_1159 = None
        unsqueeze_1160: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg313_1, 2);  arg313_1 = None
        unsqueeze_1161: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1160, 3);  unsqueeze_1160 = None
        permute_618: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_1161, [2, 3, 1, 0]);  unsqueeze_1161 = None
        permute_619: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_617, [0, 1, 3, 2]);  permute_617 = None
        view_672: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_619, [1, 6400, 128]);  permute_619 = None
        permute_620: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_618, [3, 2, 0, 1]);  permute_618 = None
        view_673: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_620, [1, 128, 64]);  permute_620 = None
        bmm_128: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_672, view_673);  view_672 = view_673 = None
        view_674: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_128, [100, 64, 1, 64]);  bmm_128 = None
        permute_621: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_674, [0, 1, 3, 2]);  view_674 = None
        view_675: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_621, [100, 64, 64]);  permute_621 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_499: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_675, arg314_1);  view_675 = arg314_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_774: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_729, arg315_1);  mul_729 = arg315_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_501: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_774, arg316_1);  mul_774 = arg316_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_136: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_476, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_135: "f32[100, 3]" = torch.ops.aten.select.int(div_136, 1, 0)
        select_136: "f32[100, 3]" = torch.ops.aten.select.int(div_136, 1, 1)
        select_137: "f32[100, 3]" = torch.ops.aten.select.int(div_136, 1, 2);  div_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_337: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_137, select_136);  select_137 = None
        sub_338: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_135, select_136);  select_135 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_775: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_337, sub_337)
        sum_290: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_775, [-1]);  mul_775 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_148: "f32[100]" = torch.ops.aten.clamp_min.default(sum_290, 1e-12);  sum_290 = None
        sqrt_111: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_148);  clamp_min_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1162: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_111, -1);  sqrt_111 = None
        div_137: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_337, unsqueeze_1162);  sub_337 = unsqueeze_1162 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_776: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_338, div_137)
        sum_291: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_776, [-1]);  mul_776 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_1163: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_291, -1);  sum_291 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_777: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1163, div_137);  unsqueeze_1163 = None
        sub_339: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_338, mul_777);  sub_338 = mul_777 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_778: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_339, sub_339)
        sum_292: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_778, [-1]);  mul_778 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_149: "f32[100]" = torch.ops.aten.clamp_min.default(sum_292, 1e-12);  sum_292 = None
        sqrt_112: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_149);  clamp_min_149 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1164: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_112, -1);  sqrt_112 = None
        div_138: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_339, unsqueeze_1164);  sub_339 = unsqueeze_1164 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_319: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_137, [None, remainder])
        index_320: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_138, [None, remainder_1])
        mul_779: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_319, index_320);  index_319 = index_320 = None
        index_321: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_137, [None, remainder_1]);  remainder_1 = None
        index_322: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_138, [None, remainder]);  remainder = None
        mul_780: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_321, index_322);  index_321 = index_322 = None
        sub_340: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_779, mul_780);  mul_779 = mul_780 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_1165: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_137, 2);  div_137 = None
        unsqueeze_1166: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_138, 2);  div_138 = None
        unsqueeze_1167: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_340, 2);  sub_340 = None
        cat_83: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_1165, unsqueeze_1166, unsqueeze_1167], -1);  unsqueeze_1165 = unsqueeze_1166 = unsqueeze_1167 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_61: "f32[100, 1]" = torch.ops.aten.mean.dim(add_501, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_61: "f32[100, 1]" = torch.ops.aten.var.correction(add_501, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_342: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_501, mean_61);  add_501 = mean_61 = None
        add_506: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_61, 1e-05);  var_61 = None
        rsqrt_61: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_506);  add_506 = None
        mul_782: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_342, rsqrt_61);  sub_342 = rsqrt_61 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_783: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_782, arg317_1);  mul_782 = arg317_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_507: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_783, arg318_1);  mul_783 = arg318_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1171: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_507, 2);  add_507 = None
        permute_622: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1171, [0, 2, 1]);  unsqueeze_1171 = None
        unsqueeze_1172: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg319_1, 2);  arg319_1 = None
        permute_623: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_1172, [2, 1, 0]);  unsqueeze_1172 = None
        permute_624: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_622, [0, 2, 1]);  permute_622 = None
        view_676: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_624, [1, 100, 128]);  permute_624 = None
        permute_625: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_623, [2, 1, 0]);  permute_623 = None
        view_677: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_625, [1, 128, 768]);  permute_625 = None
        bmm_129: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_676, view_677);  view_677 = None
        view_678: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_129, [100, 1, 768]);  bmm_129 = None
        permute_626: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_678, [0, 2, 1]);  view_678 = None
        view_679: "f32[100, 768]" = torch.ops.aten.view.default(permute_626, [100, 768]);  permute_626 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_680: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_679, [100, 8, 96]);  view_679 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_10 = torch.ops.aten.split.Tensor(view_680, 32, -1);  view_680 = None
        getitem_89: "f32[100, 8, 32]" = split_10[0]
        getitem_90: "f32[100, 8, 32]" = split_10[1]
        getitem_91: "f32[100, 8, 32]" = split_10[2];  split_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_62: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_89, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_62: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_89, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_343: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_89, mean_62);  getitem_89 = mean_62 = None
        add_508: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_62, 1e-05);  var_62 = None
        rsqrt_62: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_508);  add_508 = None
        mul_784: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_343, rsqrt_62);  sub_343 = rsqrt_62 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_785: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_784, arg320_1);  mul_784 = arg320_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_509: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_785, arg321_1);  mul_785 = arg321_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_63: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_90, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_63: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_90, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_344: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_90, mean_63);  getitem_90 = mean_63 = None
        add_510: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_63, 1e-05);  var_63 = None
        rsqrt_63: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_510);  add_510 = None
        mul_786: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_344, rsqrt_63);  sub_344 = rsqrt_63 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_787: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_786, arg322_1);  mul_786 = arg322_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_511: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_787, arg323_1);  mul_787 = arg323_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1174: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg324_1, 2);  arg324_1 = None
        permute_628: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_1174, [2, 1, 0]);  unsqueeze_1174 = None
        permute_630: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_628, [2, 1, 0]);  permute_628 = None
        view_682: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_630, [1, 128, 576]);  permute_630 = None
        bmm_130: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_676, view_682);  view_676 = view_682 = None
        view_683: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_130, [100, 1, 576]);  bmm_130 = None
        permute_631: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_683, [0, 2, 1]);  view_683 = None
        view_684: "f32[100, 576]" = torch.ops.aten.view.default(permute_631, [100, 576]);  permute_631 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_685: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_684, [100, 192, 3]);  view_684 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1175: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_83, -3);  cat_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1176: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_136, -2);  select_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_1177: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_685, -2);  view_685 = None
        mul_788: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1175, unsqueeze_1177);  unsqueeze_1177 = None
        sum_294: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_788, [-1]);  mul_788 = None
        add_512: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_294, unsqueeze_1176);  sum_294 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_686: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_512, [100, 8, 24, 3]);  add_512 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_718: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_686, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_721: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_686, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_724: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_686, 2, 16, 9223372036854775807);  view_686 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1178: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_499, 3)
        permute_632: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1178, [0, 1, 3, 2]);  unsqueeze_1178 = None
        unsqueeze_1179: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg325_1, 2);  arg325_1 = None
        unsqueeze_1180: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1179, 3);  unsqueeze_1179 = None
        permute_633: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_1180, [2, 3, 1, 0]);  unsqueeze_1180 = None
        permute_634: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_632, [0, 1, 3, 2]);  permute_632 = None
        view_687: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_634, [1, 6400, 64]);  permute_634 = None
        permute_635: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_633, [3, 2, 0, 1]);  permute_633 = None
        view_688: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_635, [1, 64, 8]);  permute_635 = None
        bmm_131: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_687, view_688);  view_687 = view_688 = None
        view_689: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_131, [100, 64, 1, 8]);  bmm_131 = None
        permute_636: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_689, [0, 1, 3, 2]);  view_689 = None
        view_690: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_636, [100, 64, 8]);  permute_636 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_28: "f32[8]" = torch.ops.aten.exp.default(arg326_1)
        log1p_10: "f32[8]" = torch.ops.aten.log1p.default(exp_28);  exp_28 = None
        gt_10: "b8[8]" = torch.ops.aten.gt.Scalar(arg326_1, 20)
        where_172: "f32[8]" = torch.ops.aten.where.self(gt_10, arg326_1, log1p_10);  gt_10 = arg326_1 = log1p_10 = None
        view_691: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_172, [1, 1, 8]);  where_172 = None
        mul_789: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_691, 0.16666666666666666);  view_691 = None
        div_139: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_789, 2);  mul_789 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_1181: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_718, 1);  slice_718 = None
        index_323: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_721, [cat_78]);  slice_721 = None
        sub_345: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1181, index_323);  unsqueeze_1181 = index_323 = None
        pow_21: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_345, 2);  sub_345 = None
        sum_295: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_21, [-1, -2]);  pow_21 = None
        mul_790: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_139, sum_295);  div_139 = sum_295 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_1182: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_509, 1);  add_509 = None
        index_324: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_511, [cat_78]);  add_511 = None
        mul_791: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_1182, index_324);  unsqueeze_1182 = index_324 = None
        sum_296: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(mul_791, [-1]);  mul_791 = None
        mul_792: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sum_296, 0.1767766952966369);  sum_296 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_513: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_792, view_690);  mul_792 = view_690 = None
        sub_346: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_513, mul_790);  add_513 = mul_790 = None
        mul_793: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_346, 0.5773502691896257);  sub_346 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_85: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_84, ne_35);  bitwise_and_84 = ne_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_1183: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_85, 2);  bitwise_and_85 = None
        where_173: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_1183, mul_793, full_default_39);  mul_793 = full_default_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_10: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_173, [-2], True)
        sub_347: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(where_173, amax_10);  where_173 = amax_10 = None
        exp_29: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_347);  sub_347 = None
        sum_297: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_29, [-2], True)
        div_140: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_29, sum_297);  exp_29 = sum_297 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_174: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_1183, div_140, full_default_40);  unsqueeze_1183 = div_140 = full_default_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_1185: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_174, 3);  where_174 = None
        unsqueeze_1186: "f32[100, 64, 1, 64]" = torch.ops.aten.unsqueeze.default(add_499, 2);  add_499 = None
        mul_794: "f32[100, 64, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_1185, unsqueeze_1186);  unsqueeze_1186 = None
        sum_298: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_794, [1]);  mul_794 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_325: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_91, [cat_78]);  getitem_91 = None
        mul_795: "f32[100, 64, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_1185, index_325);  index_325 = None
        sum_299: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_795, [1]);  mul_795 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_1189: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1185, 4);  unsqueeze_1185 = None
        index_326: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_724, [cat_78]);  slice_724 = cat_78 = None
        mul_796: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1189, index_326);  unsqueeze_1189 = index_326 = None
        sum_300: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_796, [1]);  mul_796 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1192: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_1175, -3);  unsqueeze_1175 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1193: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_1176, -2);  unsqueeze_1176 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_348: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_300, unsqueeze_1193);  sum_300 = unsqueeze_1193 = None
        unsqueeze_1194: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_348, -1);  sub_348 = None
        mul_797: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1192, unsqueeze_1194);  unsqueeze_1192 = unsqueeze_1194 = None
        sum_301: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_797, [-2]);  mul_797 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_798: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_301, sum_301)
        sum_302: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_798, [-1]);  mul_798 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_150: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_302, 1e-12);  sum_302 = None
        sqrt_113: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_150);  clamp_min_150 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_692: "f32[100, 512]" = torch.ops.aten.view.default(sum_298, [100, -1]);  sum_298 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_693: "f32[100, 256]" = torch.ops.aten.view.default(sum_299, [100, -1]);  sum_299 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_694: "f32[100, 192]" = torch.ops.aten.view.default(sum_301, [100, -1]);  sum_301 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_695: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_113, [100, -1]);  sqrt_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_84: "f32[100, 1024]" = torch.ops.aten.cat.default([view_692, view_693, view_694, view_695], -1);  view_692 = view_693 = view_694 = view_695 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1195: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_84, 2);  cat_84 = None
        permute_637: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_1195, [0, 2, 1]);  unsqueeze_1195 = None
        unsqueeze_1196: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg327_1, 2);  arg327_1 = None
        permute_638: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_1196, [2, 1, 0]);  unsqueeze_1196 = None
        permute_639: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_637, [0, 2, 1]);  permute_637 = None
        view_696: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_639, [1, 100, 1024]);  permute_639 = None
        permute_640: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_638, [2, 1, 0]);  permute_638 = None
        view_697: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_640, [1, 1024, 128]);  permute_640 = None
        bmm_132: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_696, view_697);  view_696 = view_697 = None
        view_698: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_132, [100, 1, 128]);  bmm_132 = None
        permute_641: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_698, [0, 2, 1]);  view_698 = None
        view_699: "f32[100, 128]" = torch.ops.aten.view.default(permute_641, [100, 128]);  permute_641 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_514: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_699, arg328_1);  view_699 = arg328_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_515: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_468, add_514);  add_468 = add_514 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_64: "f32[100, 1]" = torch.ops.aten.mean.dim(add_515, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_64: "f32[100, 1]" = torch.ops.aten.var.correction(add_515, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_349: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_515, mean_64);  mean_64 = None
        add_516: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_64, 1e-05);  var_64 = None
        rsqrt_64: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_516);  add_516 = None
        mul_799: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_349, rsqrt_64);  sub_349 = rsqrt_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_800: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_799, arg329_1);  mul_799 = arg329_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_517: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_800, arg330_1);  mul_800 = arg330_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_65: "f32[100, 1]" = torch.ops.aten.mean.dim(add_517, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_65: "f32[100, 1]" = torch.ops.aten.var.correction(add_517, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_355: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_517, mean_65);  add_517 = mean_65 = None
        add_522: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_65, 1e-05);  var_65 = None
        rsqrt_65: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_522);  add_522 = None
        mul_808: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_355, rsqrt_65);  sub_355 = rsqrt_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_809: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_808, arg331_1);  mul_808 = arg331_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_523: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_809, arg332_1);  mul_809 = arg332_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1206: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_523, 2);  add_523 = None
        permute_642: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1206, [0, 2, 1]);  unsqueeze_1206 = None
        unsqueeze_1207: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg333_1, 2);  arg333_1 = None
        permute_643: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_1207, [2, 1, 0]);  unsqueeze_1207 = None
        permute_644: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_642, [0, 2, 1]);  permute_642 = None
        view_700: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_644, [1, 100, 128]);  permute_644 = None
        permute_645: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_643, [2, 1, 0]);  permute_643 = None
        view_701: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_645, [1, 128, 768]);  permute_645 = None
        bmm_133: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_700, view_701);  view_701 = None
        view_702: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_133, [100, 1, 768]);  bmm_133 = None
        permute_646: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_702, [0, 2, 1]);  view_702 = None
        view_703: "f32[100, 768]" = torch.ops.aten.view.default(permute_646, [100, 768]);  permute_646 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_704: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_703, [100, 8, 96]);  view_703 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_11 = torch.ops.aten.split.Tensor(view_704, 32, -1);  view_704 = None
        getitem_92: "f32[100, 8, 32]" = split_11[0]
        getitem_93: "f32[100, 8, 32]" = split_11[1]
        getitem_94: "f32[100, 8, 32]" = split_11[2];  split_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_66: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_92, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_66: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_92, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_356: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_92, mean_66);  getitem_92 = mean_66 = None
        add_524: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_66, 1e-05);  var_66 = None
        rsqrt_66: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_524);  add_524 = None
        mul_810: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_356, rsqrt_66);  sub_356 = rsqrt_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_811: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_810, arg334_1);  mul_810 = arg334_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_525: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_811, arg335_1);  mul_811 = arg335_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_67: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_93, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_67: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_93, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_357: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_93, mean_67);  getitem_93 = mean_67 = None
        add_526: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_67, 1e-05);  var_67 = None
        rsqrt_67: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_526);  add_526 = None
        mul_812: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_357, rsqrt_67);  sub_357 = rsqrt_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_813: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_812, arg336_1);  mul_812 = arg336_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_527: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_813, arg337_1);  mul_813 = arg337_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1209: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg338_1, 2);  arg338_1 = None
        permute_648: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_1209, [2, 1, 0]);  unsqueeze_1209 = None
        permute_650: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_648, [2, 1, 0]);  permute_648 = None
        view_706: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_650, [1, 128, 576]);  permute_650 = None
        bmm_134: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_700, view_706);  view_700 = view_706 = None
        view_707: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_134, [100, 1, 576]);  bmm_134 = None
        permute_651: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_707, [0, 2, 1]);  view_707 = None
        view_708: "f32[100, 576]" = torch.ops.aten.view.default(permute_651, [100, 576]);  permute_651 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_709: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_708, [100, 192, 3]);  view_708 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_1212: "f32[100, 192, 1, 3]" = torch.ops.aten.unsqueeze.default(view_709, -2);  view_709 = None
        mul_814: "f32[100, 192, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_270, unsqueeze_1212);  unsqueeze_270 = unsqueeze_1212 = None
        sum_307: "f32[100, 192, 3]" = torch.ops.aten.sum.dim_IntList(mul_814, [-1]);  mul_814 = None
        add_528: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(sum_307, unsqueeze_271);  sum_307 = unsqueeze_271 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_710: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_528, [100, 8, 24, 3]);  add_528 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_739: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_710, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_742: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_710, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_745: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_710, 2, 16, 9223372036854775807);  view_710 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1213: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_127, 3)
        permute_652: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1213, [0, 1, 3, 2]);  unsqueeze_1213 = None
        unsqueeze_1214: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg339_1, 2);  arg339_1 = None
        unsqueeze_1215: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1214, 3);  unsqueeze_1214 = None
        permute_653: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_1215, [2, 3, 1, 0]);  unsqueeze_1215 = None
        permute_654: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_652, [0, 1, 3, 2]);  permute_652 = None
        view_711: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_654, [1, 4800, 64]);  permute_654 = None
        permute_655: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_653, [3, 2, 0, 1]);  permute_653 = None
        view_712: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_655, [1, 64, 8]);  permute_655 = None
        bmm_135: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_711, view_712);  view_711 = view_712 = None
        view_713: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_135, [100, 48, 1, 8]);  bmm_135 = None
        permute_656: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_713, [0, 1, 3, 2]);  view_713 = None
        view_714: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_656, [100, 48, 8]);  permute_656 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_30: "f32[8]" = torch.ops.aten.exp.default(arg340_1)
        log1p_11: "f32[8]" = torch.ops.aten.log1p.default(exp_30);  exp_30 = None
        gt_11: "b8[8]" = torch.ops.aten.gt.Scalar(arg340_1, 20)
        where_175: "f32[8]" = torch.ops.aten.where.self(gt_11, arg340_1, log1p_11);  gt_11 = arg340_1 = log1p_11 = None
        view_715: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_175, [1, 1, 8]);  where_175 = None
        mul_815: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_715, 0.16666666666666666);  view_715 = None
        div_144: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_815, 2);  mul_815 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_1216: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_739, 1);  slice_739 = None
        index_331: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_742, [select_126]);  slice_742 = None
        sub_358: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1216, index_331);  unsqueeze_1216 = index_331 = None
        pow_22: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_358, 2);  sub_358 = None
        sum_308: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_22, [-1, -2]);  pow_22 = None
        mul_816: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_144, sum_308);  div_144 = sum_308 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:113 in forward, code: dot = math.sqrt(1.0 / s) * (q[:, None] * k[neighbours]).sum(-1)
        unsqueeze_1217: "f32[100, 1, 8, 32]" = torch.ops.aten.unsqueeze.default(add_525, 1);  add_525 = None
        index_332: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_527, [select_126]);  add_527 = None
        mul_817: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_1217, index_332);  unsqueeze_1217 = index_332 = None
        sum_309: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(mul_817, [-1]);  mul_817 = None
        mul_818: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sum_309, 0.1767766952966369);  sum_309 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_529: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_818, view_714);  mul_818 = view_714 = None
        sub_359: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_529, mul_816);  add_529 = mul_816 = None
        mul_819: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_359, 0.5773502691896257);  sub_359 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_37: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_126, -1)
        bitwise_and_86: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_128, ne_37);  select_128 = ne_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_1218: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_86, 2);  bitwise_and_86 = None
        where_176: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_1218, mul_819, full_default_41);  mul_819 = full_default_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        amax_11: "f32[100, 1, 8]" = torch.ops.aten.amax.default(where_176, [-2], True)
        sub_360: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(where_176, amax_11);  where_176 = amax_11 = None
        exp_31: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_360);  sub_360 = None
        sum_310: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_31, [-2], True)
        div_145: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_31, sum_310);  exp_31 = sum_310 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_177: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_1218, div_145, full_default_42);  unsqueeze_1218 = div_145 = full_default_42 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:126 in forward, code: out_pair = (attn[..., None] * pair[:, :, None, :]).sum(1)
        unsqueeze_1220: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_177, 3);  where_177 = None
        unsqueeze_1221: "f32[100, 48, 1, 64]" = torch.ops.aten.unsqueeze.default(select_127, 2);  select_127 = None
        mul_820: "f32[100, 48, 8, 64]" = torch.ops.aten.mul.Tensor(unsqueeze_1220, unsqueeze_1221);  unsqueeze_1221 = None
        sum_311: "f32[100, 8, 64]" = torch.ops.aten.sum.dim_IntList(mul_820, [1]);  mul_820 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:127 in forward, code: out_scalar = (attn[..., None] * v[neighbours]).sum(1)
        index_333: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_94, [select_126]);  getitem_94 = None
        mul_821: "f32[100, 48, 8, 32]" = torch.ops.aten.mul.Tensor(unsqueeze_1220, index_333);  index_333 = None
        sum_312: "f32[100, 8, 32]" = torch.ops.aten.sum.dim_IntList(mul_821, [1]);  mul_821 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:128 in forward, code: out_point = (attn[..., None, None] * v_g[neighbours]).sum(1)
        unsqueeze_1224: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1220, 4);  unsqueeze_1220 = None
        index_334: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_745, [select_126]);  slice_745 = select_126 = None
        mul_822: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1224, index_334);  unsqueeze_1224 = index_334 = None
        sum_313: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_822, [1]);  mul_822 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_361: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(sum_313, unsqueeze_288);  sum_313 = unsqueeze_288 = None
        unsqueeze_1229: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_361, -1);  sub_361 = None
        mul_823: "f32[100, 8, 8, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_287, unsqueeze_1229);  unsqueeze_287 = unsqueeze_1229 = None
        sum_314: "f32[100, 8, 8, 3]" = torch.ops.aten.sum.dim_IntList(mul_823, [-2]);  mul_823 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_824: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(sum_314, sum_314)
        sum_315: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_824, [-1]);  mul_824 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_153: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_315, 1e-12);  sum_315 = None
        sqrt_116: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_153);  clamp_min_153 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_716: "f32[100, 512]" = torch.ops.aten.view.default(sum_311, [100, -1]);  sum_311 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_717: "f32[100, 256]" = torch.ops.aten.view.default(sum_312, [100, -1]);  sum_312 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        view_718: "f32[100, 192]" = torch.ops.aten.view.default(sum_314, [100, -1]);  sum_314 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_719: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_116, [100, -1]);  sqrt_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_86: "f32[100, 1024]" = torch.ops.aten.cat.default([view_716, view_717, view_718, view_719], -1);  view_716 = view_717 = view_718 = view_719 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1230: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_86, 2);  cat_86 = None
        permute_657: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_1230, [0, 2, 1]);  unsqueeze_1230 = None
        unsqueeze_1231: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg341_1, 2);  arg341_1 = None
        permute_658: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_1231, [2, 1, 0]);  unsqueeze_1231 = None
        permute_659: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_657, [0, 2, 1]);  permute_657 = None
        view_720: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_659, [1, 100, 1024]);  permute_659 = None
        permute_660: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_658, [2, 1, 0]);  permute_658 = None
        view_721: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_660, [1, 1024, 128]);  permute_660 = None
        bmm_136: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_720, view_721);  view_720 = view_721 = None
        view_722: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_136, [100, 1, 128]);  bmm_136 = None
        permute_661: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_722, [0, 2, 1]);  view_722 = None
        view_723: "f32[100, 128]" = torch.ops.aten.view.default(permute_661, [100, 128]);  permute_661 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_530: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_723, arg342_1);  view_723 = arg342_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_531: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_515, add_530);  add_515 = add_530 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_68: "f32[100, 1]" = torch.ops.aten.mean.dim(add_531, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_68: "f32[100, 1]" = torch.ops.aten.var.correction(add_531, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_362: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_531, mean_68);  mean_68 = None
        add_532: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_68, 1e-05);  var_68 = None
        rsqrt_68: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_532);  add_532 = None
        mul_825: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_362, rsqrt_68);  sub_362 = rsqrt_68 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_826: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_825, arg343_1);  mul_825 = arg343_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_533: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_826, arg344_1);  mul_826 = arg344_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:97 in apply_inverse_t, code: return (rot * (points - trans).unsqueeze(-1)).sum(-2)
        sub_367: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_476, unsqueeze_1123)
        unsqueeze_1240: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_367, -1);  sub_367 = None
        mul_833: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1122, unsqueeze_1240);  unsqueeze_1240 = None
        sum_319: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_833, [-2]);  mul_833 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        view_724: "f32[100, 60]" = torch.ops.aten.view.default(sum_319, [100, -1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1242: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg345_1, 2);  arg345_1 = None
        permute_663: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_1242, [2, 1, 0]);  unsqueeze_1242 = None
        permute_665: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_663, [2, 1, 0]);  permute_663 = None
        view_726: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_665, [1, 128, 128]);  permute_665 = None
        bmm_137: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_105, view_726);  view_105 = view_726 = None
        view_727: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_137, [100, 1, 128]);  bmm_137 = None
        permute_666: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_727, [0, 2, 1]);  view_727 = None
        view_728: "f32[100, 128]" = torch.ops.aten.view.default(permute_666, [100, 128]);  permute_666 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_538: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_533, view_728);  add_533 = view_728 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1243: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_724, 2);  view_724 = None
        permute_667: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_1243, [0, 2, 1]);  unsqueeze_1243 = None
        unsqueeze_1244: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg346_1, 2);  arg346_1 = None
        permute_668: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_1244, [2, 1, 0]);  unsqueeze_1244 = None
        permute_669: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_667, [0, 2, 1]);  permute_667 = None
        view_729: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_669, [1, 100, 60]);  permute_669 = None
        permute_670: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_668, [2, 1, 0]);  permute_668 = None
        view_730: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_670, [1, 60, 256]);  permute_670 = None
        bmm_138: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_729, view_730);  view_729 = view_730 = None
        view_731: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_138, [100, 1, 256]);  bmm_138 = None
        permute_671: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_731, [0, 2, 1]);  view_731 = None
        view_732: "f32[100, 256]" = torch.ops.aten.view.default(permute_671, [100, 256]);  permute_671 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_539: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_732, arg347_1);  view_732 = arg347_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_834: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_539, add_539)
        mul_835: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_834, add_539);  mul_834 = None
        mul_836: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_835, 0.044715);  mul_835 = None
        add_540: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_539, mul_836);  mul_836 = None
        mul_837: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_540, 0.7978845608028654);  add_540 = None
        mul_838: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_539, 0.5);  add_539 = None
        tanh_28: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_837);  mul_837 = None
        add_541: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_28, 1);  tanh_28 = None
        mul_839: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_838, add_541);  mul_838 = add_541 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1245: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_839, 2);  mul_839 = None
        permute_672: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_1245, [0, 2, 1]);  unsqueeze_1245 = None
        unsqueeze_1246: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg348_1, 2);  arg348_1 = None
        permute_673: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_1246, [2, 1, 0]);  unsqueeze_1246 = None
        permute_674: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_672, [0, 2, 1]);  permute_672 = None
        view_733: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_674, [1, 100, 256]);  permute_674 = None
        permute_675: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_673, [2, 1, 0]);  permute_673 = None
        view_734: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_675, [1, 256, 128]);  permute_675 = None
        bmm_139: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_733, view_734);  view_733 = view_734 = None
        view_735: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_139, [100, 1, 128]);  bmm_139 = None
        permute_676: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_735, [0, 2, 1]);  view_735 = None
        view_736: "f32[100, 128]" = torch.ops.aten.view.default(permute_676, [100, 128]);  permute_676 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_542: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_736, arg349_1);  view_736 = arg349_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_543: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_538, add_542);  add_538 = add_542 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1247: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_543, 2);  add_543 = None
        permute_677: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1247, [0, 2, 1]);  unsqueeze_1247 = None
        unsqueeze_1248: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg350_1, 2);  arg350_1 = None
        permute_678: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1248, [2, 1, 0]);  unsqueeze_1248 = None
        permute_679: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_677, [0, 2, 1]);  permute_677 = None
        view_737: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_679, [1, 100, 128]);  permute_679 = None
        permute_680: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_678, [2, 1, 0]);  permute_678 = None
        view_738: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_680, [1, 128, 512]);  permute_680 = None
        bmm_140: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_737, view_738);  view_738 = None
        view_739: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_140, [100, 1, 512]);  bmm_140 = None
        permute_681: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_739, [0, 2, 1]);  view_739 = None
        view_740: "f32[100, 512]" = torch.ops.aten.view.default(permute_681, [100, 512]);  permute_681 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1250: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg351_1, 2);  arg351_1 = None
        permute_683: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1250, [2, 1, 0]);  unsqueeze_1250 = None
        permute_685: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_683, [2, 1, 0]);  permute_683 = None
        view_742: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_685, [1, 128, 512]);  permute_685 = None
        bmm_141: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_737, view_742);  view_742 = None
        view_743: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_141, [100, 1, 512]);  bmm_141 = None
        permute_686: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_743, [0, 2, 1]);  view_743 = None
        view_744: "f32[100, 512]" = torch.ops.aten.view.default(permute_686, [100, 512]);  permute_686 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_840: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_744, view_744)
        mul_841: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_840, view_744);  mul_840 = None
        mul_842: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_841, 0.044715);  mul_841 = None
        add_544: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_744, mul_842);  mul_842 = None
        mul_843: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_544, 0.7978845608028654);  add_544 = None
        mul_844: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_744, 0.5);  view_744 = None
        tanh_29: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_843);  mul_843 = None
        add_545: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_29, 1);  tanh_29 = None
        mul_845: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_844, add_545);  mul_844 = add_545 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_846: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_845, view_740);  mul_845 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1252: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg352_1, 2);  arg352_1 = None
        permute_688: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1252, [2, 1, 0]);  unsqueeze_1252 = None
        permute_690: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_688, [2, 1, 0]);  permute_688 = None
        view_746: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_690, [1, 128, 512]);  permute_690 = None
        bmm_142: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_737, view_746);  view_746 = None
        view_747: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_142, [100, 1, 512]);  bmm_142 = None
        permute_691: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_747, [0, 2, 1]);  view_747 = None
        view_748: "f32[100, 512]" = torch.ops.aten.view.default(permute_691, [100, 512]);  permute_691 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_847: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_748, view_748)
        mul_848: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_847, view_748);  mul_847 = None
        mul_849: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_848, 0.044715);  mul_848 = None
        add_546: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_748, mul_849);  mul_849 = None
        mul_850: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_546, 0.7978845608028654);  add_546 = None
        mul_851: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_748, 0.5);  view_748 = None
        tanh_30: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_850);  mul_850 = None
        add_547: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_30, 1);  tanh_30 = None
        mul_852: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_851, add_547);  mul_851 = add_547 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1254: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg353_1, 2);  arg353_1 = None
        permute_693: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1254, [2, 1, 0]);  unsqueeze_1254 = None
        permute_695: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_693, [2, 1, 0]);  permute_693 = None
        view_750: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_695, [1, 128, 512]);  permute_695 = None
        bmm_143: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_737, view_750);  view_737 = view_750 = None
        view_751: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_143, [100, 1, 512]);  bmm_143 = None
        permute_696: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_751, [0, 2, 1]);  view_751 = None
        view_752: "f32[100, 512]" = torch.ops.aten.view.default(permute_696, [100, 512]);  permute_696 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_853: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_752, view_752)
        mul_854: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_853, view_752);  mul_853 = None
        mul_855: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_854, 0.044715);  mul_854 = None
        add_548: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_752, mul_855);  mul_855 = None
        mul_856: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_548, 0.7978845608028654);  add_548 = None
        mul_857: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_752, 0.5);  view_752 = None
        tanh_31: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_856);  mul_856 = None
        add_549: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_31, 1);  tanh_31 = None
        mul_858: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_857, add_549);  mul_857 = add_549 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_859: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_858, view_740);  mul_858 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_178: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_859, full_default_44);  mul_859 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_179: "f32[100, 512]" = torch.ops.aten.where.self(view_133, where_178, full_default_44);  view_133 = where_178 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_20: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_2, where_179);  expand_2 = where_179 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_339: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_20, [clamp_max_2]);  scatter_add_20 = clamp_max_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_148: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_339, clamp_min_33);  index_339 = clamp_min_33 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_182: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_148, full_default_44);  div_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_550: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_846, where_182);  mul_846 = where_182 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_861: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_852, view_740);  mul_852 = view_740 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_183: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_861, full_default_44);  mul_861 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_184: "f32[100, 512]" = torch.ops.aten.where.self(view_137, where_183, full_default_44);  view_137 = where_183 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_22: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_4, where_184);  expand_4 = where_184 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_341: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_22, [clamp_max_4]);  scatter_add_22 = clamp_max_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_149: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_341, clamp_min_36);  index_341 = clamp_min_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_187: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_149, full_default_44);  unsqueeze_20 = div_149 = full_default_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_551: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_550, where_187);  add_550 = where_187 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1256: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_551, 2);  add_551 = None
        permute_697: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_1256, [0, 2, 1]);  unsqueeze_1256 = None
        unsqueeze_1257: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg354_1, 2);  arg354_1 = None
        permute_698: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_1257, [2, 1, 0]);  unsqueeze_1257 = None
        permute_699: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_697, [0, 2, 1]);  permute_697 = None
        view_761: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_699, [1, 100, 512]);  permute_699 = None
        permute_700: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_698, [2, 1, 0]);  permute_698 = None
        view_762: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_700, [1, 512, 128]);  permute_700 = None
        bmm_144: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_761, view_762);  view_761 = view_762 = None
        view_763: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_144, [100, 1, 128]);  bmm_144 = None
        permute_701: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_763, [0, 2, 1]);  view_763 = None
        view_764: "f32[100, 128]" = torch.ops.aten.view.default(permute_701, [100, 128]);  permute_701 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_552: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_764, arg355_1);  view_764 = arg355_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_553: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_531, add_552);  add_531 = add_552 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_69: "f32[100, 1]" = torch.ops.aten.mean.dim(add_553, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_69: "f32[100, 1]" = torch.ops.aten.var.correction(add_553, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_368: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_553, mean_69);  mean_69 = None
        add_554: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_69, 1e-05);  var_69 = None
        rsqrt_69: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_554);  add_554 = None
        mul_863: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_368, rsqrt_69);  sub_368 = rsqrt_69 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_864: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_863, arg356_1);  mul_863 = arg356_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_555: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_864, arg357_1);  mul_864 = arg357_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1267: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_555, 2);  add_555 = None
        permute_702: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1267, [0, 2, 1]);  unsqueeze_1267 = None
        unsqueeze_1268: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg358_1, 2);  arg358_1 = None
        permute_703: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_1268, [2, 1, 0]);  unsqueeze_1268 = None
        permute_704: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_702, [0, 2, 1]);  permute_702 = None
        view_765: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_704, [1, 100, 128]);  permute_704 = None
        permute_705: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_703, [2, 1, 0]);  permute_703 = None
        view_766: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_705, [1, 128, 60]);  permute_705 = None
        bmm_145: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_765, view_766);  view_765 = view_766 = None
        view_767: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_145, [100, 1, 60]);  bmm_145 = None
        permute_706: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_767, [0, 2, 1]);  view_767 = None
        view_768: "f32[100, 60]" = torch.ops.aten.view.default(permute_706, [100, 60]);  permute_706 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_872: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_768, 10.0);  view_768 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_769: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_872, [100, 20, 3]);  mul_872 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_560: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_319, view_769);  sum_319 = view_769 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:89 in apply_t, code: return (rot * points.unsqueeze(-2)).sum(-1) + trans
        unsqueeze_1271: "f32[100, 20, 1, 3]" = torch.ops.aten.unsqueeze.default(add_560, -2);  add_560 = None
        mul_873: "f32[100, 20, 3, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1122, unsqueeze_1271);  unsqueeze_1122 = unsqueeze_1271 = None
        sum_324: "f32[100, 20, 3]" = torch.ops.aten.sum.dim_IntList(mul_873, [-1]);  mul_873 = None
        add_561: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(sum_324, unsqueeze_1123);  sum_324 = unsqueeze_1123 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:450 in forward, code: return local, pos, torch.stack(trajectory, dim=0)
        cat_89: "f32[600, 20, 3]" = torch.ops.aten.cat.default([add_136, add_221, add_306, add_391, add_476, add_561]);  add_136 = add_221 = add_306 = add_391 = add_476 = None
        view_770: "f32[6, 100, 20, 3]" = torch.ops.aten.view.default(cat_89, [6, 100, 20, 3]);  cat_89 = None
        return (add_561, add_553, view_770, getitem, getitem_1, getitem_2, getitem_3, getitem_4, getitem_5, getitem_6, getitem_7, getitem_8, getitem_9, getitem_10, getitem_11, getitem_12, getitem_13, getitem_14, getitem_15, getitem_16, getitem_17, getitem_18, where_1, sqrt_3, cat_4, view_10)
        