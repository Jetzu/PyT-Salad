class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f32[100, 20, 3]", arg1_1: "f32[19, 100, 100]", arg2_1: "f32[100]", arg3_1: "f32[100, 128]", arg4_1: "f32[128]", arg5_1: "f32[128]", arg6_1: "f32[1725, 512]", arg7_1: "f32[512, 128]", arg8_1: "f32[128]", arg9_1: "f32[128]", arg10_1: "f32[100, 128]", arg11_1: "f32[128]", arg12_1: "f32[128]", arg13_1: "i64[100]", arg14_1: "i64[100]", arg15_1: "i64[100]", arg16_1: "b8[100]", arg17_1: "f32[100, 20, 3]", arg18_1: "f32[6, 66, 64]", arg19_1: "f32[6, 400, 64]", arg20_1: "f32[6, 60, 64]", arg21_1: "f32[6, 9, 64]", arg22_1: "f32[6, 240, 64]", arg23_1: "f32[6, 64]", arg24_1: "f32[6, 64]", arg25_1: "f32[6, 64, 128]", arg26_1: "f32[6, 128]", arg27_1: "f32[6, 128, 64]", arg28_1: "f32[6, 64]", arg29_1: "f32[66, 64]", arg30_1: "f32[400, 64]", arg31_1: "f32[60, 64]", arg32_1: "f32[9, 64]", arg33_1: "f32[240, 64]", arg34_1: "f32[64]", arg35_1: "f32[64]", arg36_1: "f32[64, 128]", arg37_1: "f32[128]", arg38_1: "f32[128, 64]", arg39_1: "f32[64]", arg40_1: "f32[128]", arg41_1: "f32[128]", arg42_1: "f32[128]", arg43_1: "f32[128]", arg44_1: "f32[128, 768]", arg45_1: "f32[32]", arg46_1: "f32[32]", arg47_1: "f32[32]", arg48_1: "f32[32]", arg49_1: "f32[128, 576]", arg50_1: "f32[64, 8]", arg51_1: "f32[8]", arg52_1: "f32[1024, 128]", arg53_1: "f32[128]", arg54_1: "f32[128]", arg55_1: "f32[128]", arg56_1: "f32[128]", arg57_1: "f32[128]", arg58_1: "f32[128, 768]", arg59_1: "f32[32]", arg60_1: "f32[32]", arg61_1: "f32[32]", arg62_1: "f32[32]", arg63_1: "f32[128, 576]", arg64_1: "f32[64, 8]", arg65_1: "f32[8]", arg66_1: "f32[1024, 128]", arg67_1: "f32[128]", arg68_1: "f32[128]", arg69_1: "f32[128]", arg70_1: "f32[128, 128]", arg71_1: "f32[60, 256]", arg72_1: "f32[256]", arg73_1: "f32[256, 128]", arg74_1: "f32[128]", arg75_1: "f32[128, 512]", arg76_1: "f32[128, 512]", arg77_1: "f32[128, 512]", arg78_1: "f32[128, 512]", arg79_1: "f32[512, 128]", arg80_1: "f32[128]", arg81_1: "f32[128]", arg82_1: "f32[128]", arg83_1: "f32[128, 60]", arg84_1: "f32[66, 64]", arg85_1: "f32[400, 64]", arg86_1: "f32[60, 64]", arg87_1: "f32[9, 64]", arg88_1: "f32[240, 64]", arg89_1: "f32[64]", arg90_1: "f32[64]", arg91_1: "f32[64, 128]", arg92_1: "f32[128]", arg93_1: "f32[128, 64]", arg94_1: "f32[64]", arg95_1: "f32[128]", arg96_1: "f32[128]", arg97_1: "f32[128]", arg98_1: "f32[128]", arg99_1: "f32[128, 768]", arg100_1: "f32[32]", arg101_1: "f32[32]", arg102_1: "f32[32]", arg103_1: "f32[32]", arg104_1: "f32[128, 576]", arg105_1: "f32[64, 8]", arg106_1: "f32[8]", arg107_1: "f32[1024, 128]", arg108_1: "f32[128]", arg109_1: "f32[128]", arg110_1: "f32[128]", arg111_1: "f32[128]", arg112_1: "f32[128]", arg113_1: "f32[128, 768]", arg114_1: "f32[32]", arg115_1: "f32[32]", arg116_1: "f32[32]", arg117_1: "f32[32]", arg118_1: "f32[128, 576]", arg119_1: "f32[64, 8]", arg120_1: "f32[8]", arg121_1: "f32[1024, 128]", arg122_1: "f32[128]", arg123_1: "f32[128]", arg124_1: "f32[128]", arg125_1: "f32[128, 128]", arg126_1: "f32[60, 256]", arg127_1: "f32[256]", arg128_1: "f32[256, 128]", arg129_1: "f32[128]", arg130_1: "f32[128, 512]", arg131_1: "f32[128, 512]", arg132_1: "f32[128, 512]", arg133_1: "f32[128, 512]", arg134_1: "f32[512, 128]", arg135_1: "f32[128]", arg136_1: "f32[128]", arg137_1: "f32[128]", arg138_1: "f32[128, 60]", arg139_1: "f32[66, 64]", arg140_1: "f32[400, 64]", arg141_1: "f32[60, 64]", arg142_1: "f32[9, 64]", arg143_1: "f32[240, 64]", arg144_1: "f32[64]", arg145_1: "f32[64]", arg146_1: "f32[64, 128]", arg147_1: "f32[128]", arg148_1: "f32[128, 64]", arg149_1: "f32[64]", arg150_1: "f32[128]", arg151_1: "f32[128]", arg152_1: "f32[128]", arg153_1: "f32[128]", arg154_1: "f32[128, 768]", arg155_1: "f32[32]", arg156_1: "f32[32]", arg157_1: "f32[32]", arg158_1: "f32[32]", arg159_1: "f32[128, 576]", arg160_1: "f32[64, 8]", arg161_1: "f32[8]", arg162_1: "f32[1024, 128]", arg163_1: "f32[128]", arg164_1: "f32[128]", arg165_1: "f32[128]", arg166_1: "f32[128]", arg167_1: "f32[128]", arg168_1: "f32[128, 768]", arg169_1: "f32[32]", arg170_1: "f32[32]", arg171_1: "f32[32]", arg172_1: "f32[32]", arg173_1: "f32[128, 576]", arg174_1: "f32[64, 8]", arg175_1: "f32[8]", arg176_1: "f32[1024, 128]", arg177_1: "f32[128]", arg178_1: "f32[128]", arg179_1: "f32[128]", arg180_1: "f32[128, 128]", arg181_1: "f32[60, 256]", arg182_1: "f32[256]", arg183_1: "f32[256, 128]", arg184_1: "f32[128]", arg185_1: "f32[128, 512]", arg186_1: "f32[128, 512]", arg187_1: "f32[128, 512]", arg188_1: "f32[128, 512]", arg189_1: "f32[512, 128]", arg190_1: "f32[128]", arg191_1: "f32[128]", arg192_1: "f32[128]", arg193_1: "f32[128, 60]", arg194_1: "f32[66, 64]", arg195_1: "f32[400, 64]", arg196_1: "f32[60, 64]", arg197_1: "f32[9, 64]", arg198_1: "f32[240, 64]", arg199_1: "f32[64]", arg200_1: "f32[64]", arg201_1: "f32[64, 128]", arg202_1: "f32[128]", arg203_1: "f32[128, 64]", arg204_1: "f32[64]", arg205_1: "f32[128]", arg206_1: "f32[128]", arg207_1: "f32[128]", arg208_1: "f32[128]", arg209_1: "f32[128, 768]", arg210_1: "f32[32]", arg211_1: "f32[32]", arg212_1: "f32[32]", arg213_1: "f32[32]", arg214_1: "f32[128, 576]", arg215_1: "f32[64, 8]", arg216_1: "f32[8]", arg217_1: "f32[1024, 128]", arg218_1: "f32[128]", arg219_1: "f32[128]", arg220_1: "f32[128]", arg221_1: "f32[128]", arg222_1: "f32[128]", arg223_1: "f32[128, 768]", arg224_1: "f32[32]", arg225_1: "f32[32]", arg226_1: "f32[32]", arg227_1: "f32[32]", arg228_1: "f32[128, 576]", arg229_1: "f32[64, 8]", arg230_1: "f32[8]", arg231_1: "f32[1024, 128]", arg232_1: "f32[128]", arg233_1: "f32[128]", arg234_1: "f32[128]", arg235_1: "f32[128, 128]", arg236_1: "f32[60, 256]", arg237_1: "f32[256]", arg238_1: "f32[256, 128]", arg239_1: "f32[128]", arg240_1: "f32[128, 512]", arg241_1: "f32[128, 512]", arg242_1: "f32[128, 512]", arg243_1: "f32[128, 512]", arg244_1: "f32[512, 128]", arg245_1: "f32[128]", arg246_1: "f32[128]", arg247_1: "f32[128]", arg248_1: "f32[128, 60]", arg249_1: "f32[66, 64]", arg250_1: "f32[400, 64]", arg251_1: "f32[60, 64]", arg252_1: "f32[9, 64]", arg253_1: "f32[240, 64]", arg254_1: "f32[64]", arg255_1: "f32[64]", arg256_1: "f32[64, 128]", arg257_1: "f32[128]", arg258_1: "f32[128, 64]", arg259_1: "f32[64]", arg260_1: "f32[128]", arg261_1: "f32[128]", arg262_1: "f32[128]", arg263_1: "f32[128]", arg264_1: "f32[128, 768]", arg265_1: "f32[32]", arg266_1: "f32[32]", arg267_1: "f32[32]", arg268_1: "f32[32]", arg269_1: "f32[128, 576]", arg270_1: "f32[64, 8]", arg271_1: "f32[8]", arg272_1: "f32[1024, 128]", arg273_1: "f32[128]", arg274_1: "f32[128]", arg275_1: "f32[128]", arg276_1: "f32[128]", arg277_1: "f32[128]", arg278_1: "f32[128, 768]", arg279_1: "f32[32]", arg280_1: "f32[32]", arg281_1: "f32[32]", arg282_1: "f32[32]", arg283_1: "f32[128, 576]", arg284_1: "f32[64, 8]", arg285_1: "f32[8]", arg286_1: "f32[1024, 128]", arg287_1: "f32[128]", arg288_1: "f32[128]", arg289_1: "f32[128]", arg290_1: "f32[128, 128]", arg291_1: "f32[60, 256]", arg292_1: "f32[256]", arg293_1: "f32[256, 128]", arg294_1: "f32[128]", arg295_1: "f32[128, 512]", arg296_1: "f32[128, 512]", arg297_1: "f32[128, 512]", arg298_1: "f32[128, 512]", arg299_1: "f32[512, 128]", arg300_1: "f32[128]", arg301_1: "f32[128]", arg302_1: "f32[128]", arg303_1: "f32[128, 60]", arg304_1: "f32[66, 64]", arg305_1: "f32[400, 64]", arg306_1: "f32[60, 64]", arg307_1: "f32[9, 64]", arg308_1: "f32[240, 64]", arg309_1: "f32[64]", arg310_1: "f32[64]", arg311_1: "f32[64, 128]", arg312_1: "f32[128]", arg313_1: "f32[128, 64]", arg314_1: "f32[64]", arg315_1: "f32[128]", arg316_1: "f32[128]", arg317_1: "f32[128]", arg318_1: "f32[128]", arg319_1: "f32[128, 768]", arg320_1: "f32[32]", arg321_1: "f32[32]", arg322_1: "f32[32]", arg323_1: "f32[32]", arg324_1: "f32[128, 576]", arg325_1: "f32[64, 8]", arg326_1: "f32[8]", arg327_1: "f32[1024, 128]", arg328_1: "f32[128]", arg329_1: "f32[128]", arg330_1: "f32[128]", arg331_1: "f32[128]", arg332_1: "f32[128]", arg333_1: "f32[128, 768]", arg334_1: "f32[32]", arg335_1: "f32[32]", arg336_1: "f32[32]", arg337_1: "f32[32]", arg338_1: "f32[128, 576]", arg339_1: "f32[64, 8]", arg340_1: "f32[8]", arg341_1: "f32[1024, 128]", arg342_1: "f32[128]", arg343_1: "f32[128]", arg344_1: "f32[128]", arg345_1: "f32[128, 128]", arg346_1: "f32[60, 256]", arg347_1: "f32[256]", arg348_1: "f32[256, 128]", arg349_1: "f32[128]", arg350_1: "f32[128, 512]", arg351_1: "f32[128, 512]", arg352_1: "f32[128, 512]", arg353_1: "f32[128, 512]", arg354_1: "f32[512, 128]", arg355_1: "f32[128]", arg356_1: "f32[128]", arg357_1: "f32[128]", arg358_1: "f32[128, 60]"):
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:55 in _unbind_draws, code: return list(torch.unbind(stack, dim=0))
        unbind = torch.ops.aten.unbind.int(arg1_1);  arg1_1 = None
        getitem: "f32[100, 100]" = unbind[0]
        getitem_1: "f32[100, 100]" = unbind[1]
        getitem_2: "f32[100, 100]" = unbind[2]
        getitem_3: "f32[100, 100]" = unbind[3]
        getitem_4: "f32[100, 100]" = unbind[4]
        getitem_5: "f32[100, 100]" = unbind[5]
        getitem_6: "f32[100, 100]" = unbind[6]
        getitem_7: "f32[100, 100]" = unbind[7]
        getitem_8: "f32[100, 100]" = unbind[8]
        getitem_9: "f32[100, 100]" = unbind[9]
        getitem_10: "f32[100, 100]" = unbind[10]
        getitem_11: "f32[100, 100]" = unbind[11]
        getitem_12: "f32[100, 100]" = unbind[12]
        getitem_13: "f32[100, 100]" = unbind[13]
        getitem_14: "f32[100, 100]" = unbind[14]
        getitem_15: "f32[100, 100]" = unbind[15]
        getitem_16: "f32[100, 100]" = unbind[16]
        getitem_17: "f32[100, 100]" = unbind[17]
        getitem_18: "f32[100, 100]" = unbind[18];  unbind = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select: "f32[100, 3]" = torch.ops.aten.select.int(arg0_1, 1, 0)
        select_1: "f32[100, 3]" = torch.ops.aten.select.int(arg0_1, 1, 1)
        select_2: "f32[100, 3]" = torch.ops.aten.select.int(arg0_1, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_2, select_1);  select_2 = None
        sub_1: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select, select_1);  select = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub, sub)
        sum_1: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul, [-1]);  mul = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min: "f32[100]" = torch.ops.aten.clamp_min.default(sum_1, 1e-12);  sum_1 = None
        sqrt: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min);  clamp_min = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt, -1);  sqrt = None
        div: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub, unsqueeze);  sub = unsqueeze = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_1: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_1, div)
        sum_2: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_1, [-1]);  mul_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_1: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_2, -1);  sum_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_2: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1, div);  unsqueeze_1 = None
        sub_2: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_1, mul_2);  sub_1 = mul_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_3: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_2, sub_2)
        sum_3: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_3, [-1]);  mul_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_1: "f32[100]" = torch.ops.aten.clamp_min.default(sum_3, 1e-12);  sum_3 = None
        sqrt_1: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_1);  clamp_min_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_2: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_1, -1);  sqrt_1 = None
        div_1: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_2, unsqueeze_2);  sub_2 = unsqueeze_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        iota: "i64[3]" = torch.ops.prims.iota.default(3, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        add: "i64[3]" = torch.ops.aten.add.Tensor(iota, 1)
        remainder: "i64[3]" = torch.ops.aten.remainder.Scalar(add, 3);  add = None
        index: "f32[100, 3]" = torch.ops.aten.index.Tensor(div, [None, remainder])
        add_1: "i64[3]" = torch.ops.aten.add.Tensor(iota, 2);  iota = None
        remainder_1: "i64[3]" = torch.ops.aten.remainder.Scalar(add_1, 3);  add_1 = None
        index_1: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_1, [None, remainder_1])
        mul_4: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index, index_1);  index = index_1 = None
        index_2: "f32[100, 3]" = torch.ops.aten.index.Tensor(div, [None, remainder_1])
        index_3: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_1, [None, remainder])
        mul_5: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_2, index_3);  index_2 = index_3 = None
        sub_3: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_4, mul_5);  mul_4 = mul_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_3: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div, 2);  div = None
        unsqueeze_4: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_1, 2);  div_1 = None
        unsqueeze_5: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_3, 2);  sub_3 = None
        cat: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_3, unsqueeze_4, unsqueeze_5], -1);  unsqueeze_3 = unsqueeze_4 = unsqueeze_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_6: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_7: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_1, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_4: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(arg0_1, unsqueeze_7)
        permute: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_6, [0, 1, 3, 2])
        unsqueeze_8: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_4, 3);  sub_4 = None
        permute_1: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_8, [0, 1, 3, 2]);  unsqueeze_8 = None
        permute_2: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute, [0, 2, 3, 1]);  permute = None
        view: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_2, [100, 3, 3]);  permute_2 = None
        permute_3: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_1, [0, 3, 1, 2]);  permute_1 = None
        view_1: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_3, [100, 3, 20]);  permute_3 = None
        bmm: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view, view_1);  view = view_1 = None
        view_2: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm, [100, 3, 1, 20]);  bmm = None
        permute_4: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_2, [0, 3, 1, 2]);  view_2 = None
        view_3: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_4, [100, 20, 3]);  permute_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:271 in forward_core, code: parts = [local_pos.reshape(n, -1),
        clone: "f32[100, 20, 3]" = torch.ops.aten.clone.default(view_3, memory_format = torch.contiguous_format)
        view_4: "f32[100, 60]" = torch.ops.aten.view.default(clone, [100, 60]);  clone = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_6: "f32[100, 20, 3]" = torch.ops.aten.mul.Tensor(view_3, view_3)
        sum_4: "f32[100, 20]" = torch.ops.aten.sum.dim_IntList(mul_6, [-1]);  mul_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_2: "f32[100, 20]" = torch.ops.aten.clamp_min.default(sum_4, 1e-12);  sum_4 = None
        sqrt_2: "f32[100, 20]" = torch.ops.aten.sqrt.default(clamp_min_2);  clamp_min_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:57 in _arange_centers, code: + torch.arange(bins, device=device, dtype=dtype) * step
        iota_1: "i64[64]" = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        mul_7: "i64[64]" = torch.ops.aten.mul.Tensor(iota_1, 1);  iota_1 = None
        add_4: "i64[64]" = torch.ops.aten.add.Tensor(mul_7, 0);  mul_7 = None
        convert_element_type: "f32[64]" = torch.ops.prims.convert_element_type.default(add_4, torch.float32);  add_4 = None
        mul_8: "f32[64]" = torch.ops.aten.mul.Tensor(convert_element_type, 0.34375);  convert_element_type = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:56 in _arange_centers, code: centers = (min_distance
        add_5: "f32[64]" = torch.ops.aten.add.Tensor(mul_8, 0.0);  mul_8 = None
        add_6: "f32[64]" = torch.ops.aten.add.Tensor(add_5, 0.171875);  add_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_9: "f32[100, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_2, 2);  sqrt_2 = None
        sub_5: "f32[100, 20, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_9, add_6);  unsqueeze_9 = add_6 = None
        pow_1: "f32[100, 20, 64]" = torch.ops.aten.pow.Tensor_Scalar(sub_5, 2);  sub_5 = None
        neg: "f32[100, 20, 64]" = torch.ops.aten.neg.default(pow_1);  pow_1 = None
        div_2: "f32[100, 20, 64]" = torch.ops.aten.div.Tensor(neg, 0.1181640625);  neg = None
        exp: "f32[100, 20, 64]" = torch.ops.aten.exp.default(div_2);  div_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:272 in forward_core, code: GF.distance_rbf(vec_norm(local_pos), 0.0, 22.0).reshape(n, -1)]
        view_5: "f32[100, 1280]" = torch.ops.aten.view.default(exp, [100, -1]);  exp = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:102 in vp_time_embedding, code: return torch.cat((t[:, None], GF.fourier_time_embedding(t, size=size)), dim=-1)
        unsqueeze_10: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(arg2_1, 1);  arg2_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:93 in fourier_time_embedding, code: exponent = 2.0 * torch.arange(size // 2, device=t.device, dtype=t.dtype) / size
        iota_2: "i64[128]" = torch.ops.prims.iota.default(128, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        mul_9: "i64[128]" = torch.ops.aten.mul.Tensor(iota_2, 1);  iota_2 = None
        add_7: "i64[128]" = torch.ops.aten.add.Tensor(mul_9, 0);  mul_9 = None
        convert_element_type_1: "f32[128]" = torch.ops.prims.convert_element_type.default(add_7, torch.float32);  add_7 = None
        mul_10: "f32[128]" = torch.ops.aten.mul.Tensor(convert_element_type_1, 2.0);  convert_element_type_1 = None
        div_3: "f32[128]" = torch.ops.aten.div.Tensor(mul_10, 256);  mul_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:94 in fourier_time_embedding, code: denom = base ** exponent
        pow_2: "f32[128]" = torch.ops.aten.pow.Scalar(10000.0, div_3);  div_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:95 in fourier_time_embedding, code: arg = scale * t[..., None] / denom
        mul_11: "f32[100, 1]" = torch.ops.aten.mul.Tensor(unsqueeze_10, 1.0)
        div_4: "f32[100, 128]" = torch.ops.aten.div.Tensor(mul_11, pow_2);  mul_11 = pow_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:96 in fourier_time_embedding, code: return torch.cat((torch.sin(arg), torch.cos(arg)), dim=-1)
        sin: "f32[100, 128]" = torch.ops.aten.sin.default(div_4)
        cos: "f32[100, 128]" = torch.ops.aten.cos.default(div_4);  div_4 = None
        cat_1: "f32[100, 256]" = torch.ops.aten.cat.default([sin, cos], -1);  sin = cos = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:102 in vp_time_embedding, code: return torch.cat((t[:, None], GF.fourier_time_embedding(t, size=size)), dim=-1)
        cat_2: "f32[100, 257]" = torch.ops.aten.cat.default([unsqueeze_10, cat_1], -1);  unsqueeze_10 = cat_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean: "f32[100, 1]" = torch.ops.aten.mean.dim(arg3_1, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var: "f32[100, 1]" = torch.ops.aten.var.correction(arg3_1, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_6: "f32[100, 128]" = torch.ops.aten.sub.Tensor(arg3_1, mean);  arg3_1 = mean = None
        add_8: "f32[100, 1]" = torch.ops.aten.add.Tensor(var, 1e-05);  var = None
        rsqrt: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_8);  add_8 = None
        mul_12: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_6, rsqrt);  sub_6 = rsqrt = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_13: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_12, arg4_1);  mul_12 = arg4_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_9: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_13, arg5_1);  mul_13 = arg5_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:280 in forward_core, code: local = self.prepare_layer_norm_local(self.prepare_mlp(torch.cat(parts, dim=-1)))
        cat_3: "f32[100, 1725]" = torch.ops.aten.cat.default([cat_2, view_4, view_5, add_9], -1);  cat_2 = view_5 = add_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_12: "f32[100, 1725, 1]" = torch.ops.aten.unsqueeze.default(cat_3, 2);  cat_3 = None
        permute_5: "f32[100, 1, 1725]" = torch.ops.aten.permute.default(unsqueeze_12, [0, 2, 1]);  unsqueeze_12 = None
        unsqueeze_13: "f32[1725, 512, 1]" = torch.ops.aten.unsqueeze.default(arg6_1, 2);  arg6_1 = None
        permute_6: "f32[1, 512, 1725]" = torch.ops.aten.permute.default(unsqueeze_13, [2, 1, 0]);  unsqueeze_13 = None
        permute_7: "f32[100, 1725, 1]" = torch.ops.aten.permute.default(permute_5, [0, 2, 1]);  permute_5 = None
        view_6: "f32[1, 100, 1725]" = torch.ops.aten.view.default(permute_7, [1, 100, 1725]);  permute_7 = None
        permute_8: "f32[1725, 512, 1]" = torch.ops.aten.permute.default(permute_6, [2, 1, 0]);  permute_6 = None
        view_7: "f32[1, 1725, 512]" = torch.ops.aten.view.default(permute_8, [1, 1725, 512]);  permute_8 = None
        bmm_1: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_6, view_7);  view_6 = view_7 = None
        view_8: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_1, [100, 1, 512]);  bmm_1 = None
        permute_9: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_8, [0, 2, 1]);  view_8 = None
        view_9: "f32[100, 512]" = torch.ops.aten.view.default(permute_9, [100, 512]);  permute_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_14: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_9, view_9)
        mul_15: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_14, view_9);  mul_14 = None
        mul_16: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_15, 0.044715);  mul_15 = None
        add_10: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_9, mul_16);  mul_16 = None
        mul_17: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_10, 0.7978845608028654);  add_10 = None
        mul_18: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_9, 0.5);  view_9 = None
        tanh: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_17);  mul_17 = None
        add_11: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh, 1);  tanh = None
        mul_19: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_18, add_11);  mul_18 = add_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_14: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(mul_19, 2);  mul_19 = None
        permute_10: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_14, [0, 2, 1]);  unsqueeze_14 = None
        unsqueeze_15: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg7_1, 2);  arg7_1 = None
        permute_11: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_15, [2, 1, 0]);  unsqueeze_15 = None
        permute_12: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_10, [0, 2, 1]);  permute_10 = None
        view_10: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_12, [1, 100, 512]);  permute_12 = None
        permute_13: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_11, [2, 1, 0]);  permute_11 = None
        view_11: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_13, [1, 512, 128]);  permute_13 = None
        bmm_2: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_10, view_11);  view_10 = view_11 = None
        view_12: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_2, [100, 1, 128]);  bmm_2 = None
        permute_14: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_12, [0, 2, 1]);  view_12 = None
        view_13: "f32[100, 128]" = torch.ops.aten.view.default(permute_14, [100, 128]);  permute_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_1: "f32[100, 1]" = torch.ops.aten.mean.dim(view_13, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_1: "f32[100, 1]" = torch.ops.aten.var.correction(view_13, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_7: "f32[100, 128]" = torch.ops.aten.sub.Tensor(view_13, mean_1);  view_13 = mean_1 = None
        add_12: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_1, 1e-05);  var_1 = None
        rsqrt_1: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_12);  add_12 = None
        mul_20: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_7, rsqrt_1);  sub_7 = rsqrt_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_21: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_20, arg8_1);  mul_20 = arg8_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_13: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_21, arg9_1);  mul_21 = arg9_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_2: "f32[100, 1]" = torch.ops.aten.mean.dim(arg10_1, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_2: "f32[100, 1]" = torch.ops.aten.var.correction(arg10_1, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_8: "f32[100, 128]" = torch.ops.aten.sub.Tensor(arg10_1, mean_2);  arg10_1 = mean_2 = None
        add_14: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_2, 1e-05);  var_2 = None
        rsqrt_2: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_14);  add_14 = None
        mul_22: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_8, rsqrt_2);  sub_8 = rsqrt_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_23: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_22, arg11_1);  mul_22 = arg11_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_15: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_23, arg12_1);  mul_23 = arg12_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:83 in inner, code: same_item = batch[:, None] == batch[None, :]
        unsqueeze_16: "i64[100, 1]" = torch.ops.aten.unsqueeze.default(arg14_1, 1)
        unsqueeze_17: "i64[1, 100]" = torch.ops.aten.unsqueeze.default(arg14_1, 0)
        eq: "b8[100, 100]" = torch.ops.aten.eq.Tensor(unsqueeze_16, unsqueeze_17)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:84 in inner, code: same_chain = chain[:, None] == chain[None, :]
        unsqueeze_18: "i64[100, 1]" = torch.ops.aten.unsqueeze.default(arg15_1, 1)
        unsqueeze_19: "i64[1, 100]" = torch.ops.aten.unsqueeze.default(arg15_1, 0)
        eq_1: "b8[100, 100]" = torch.ops.aten.eq.Tensor(unsqueeze_18, unsqueeze_19)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:85 in inner, code: pair_mask = mask[:, None] & mask[None, :] & same_item & same_chain
        unsqueeze_20: "b8[100, 1]" = torch.ops.aten.unsqueeze.default(arg16_1, 1)
        unsqueeze_21: "b8[1, 100]" = torch.ops.aten.unsqueeze.default(arg16_1, 0)
        bitwise_and: "b8[100, 100]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, unsqueeze_21)
        bitwise_and_1: "b8[100, 100]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and, eq);  bitwise_and = None
        bitwise_and_2: "b8[100, 100]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_1, eq_1);  eq_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:86 in inner, code: distance = (resi[:, None] - resi[None, :]).abs().float()
        unsqueeze_22: "i64[100, 1]" = torch.ops.aten.unsqueeze.default(arg13_1, 1)
        unsqueeze_23: "i64[1, 100]" = torch.ops.aten.unsqueeze.default(arg13_1, 0)
        sub_9: "i64[100, 100]" = torch.ops.aten.sub.Tensor(unsqueeze_22, unsqueeze_23);  unsqueeze_23 = None
        abs_1: "i64[100, 100]" = torch.ops.aten.abs.default(sub_9);  sub_9 = None
        convert_element_type_2: "f32[100, 100]" = torch.ops.prims.convert_element_type.default(abs_1, torch.float32);  abs_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:53 in inner, code: index = torch.arange(n, device=distance.device)
        iota_3: "i64[100]" = torch.ops.prims.iota.default(100, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        full_default: "f32[100, 100]" = torch.ops.aten.full.default([100, 100], inf, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_2, convert_element_type_2, full_default);  bitwise_and_2 = convert_element_type_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort = torch.ops.aten.sort.stable(where, stable = True)
        getitem_20: "i64[100, 100]" = sort[1];  sort = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_17: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_20, 1, 0, 16);  getitem_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        unsqueeze_24: "i64[100, 1]" = torch.ops.aten.unsqueeze.default(iota_3, 1);  iota_3 = None
        index_4: "f32[100, 16]" = torch.ops.aten.index.Tensor(where, [unsqueeze_24, slice_17]);  where = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_4, inf);  index_4 = None
        full_default_1: "i64[100, 16]" = torch.ops.aten.full.default([100, 16], -1, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_1: "i64[100, 16]" = torch.ops.aten.where.self(lt, slice_17, full_default_1);  lt = slice_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:57 in inner, code: ca = pos[:, 1]
        select_3: "f32[100, 3]" = torch.ops.aten.select.int(arg17_1, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:59 in inner, code: ((ca[:, None] - ca[None, :]) ** 2).sum(-1), min=1e-12))
        unsqueeze_25: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_3, 1)
        unsqueeze_26: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_3, 0);  select_3 = None
        sub_10: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_25, unsqueeze_26);  unsqueeze_25 = unsqueeze_26 = None
        pow_3: "f32[100, 100, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_10, 2);  sub_10 = None
        sum_5: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(pow_3, [-1]);  pow_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:58 in inner, code: dist = torch.sqrt(torch.clamp(
        clamp_min_3: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_5, 1e-12);  sum_5 = None
        sqrt_3: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_3);  clamp_min_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_2: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, sqrt_3, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne: "b8[100, 16]" = torch.ops.aten.ne.Scalar(where_1, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:59 in inner, code: torch.full_like(distance[index[:, None], neighbours], _INF),
        full_default_3: "f32[100, 16]" = torch.ops.aten.full.default([100, 16], inf, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_6: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_2, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_3: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_6);  index_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put: "f32[100, 100]" = torch.ops.aten.index_put.default(where_2, [unsqueeze_24, where_1], where_3);  where_2 = where_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_1 = torch.ops.aten.sort.stable(index_put, stable = True)
        getitem_22: "i64[100, 100]" = sort_1[1];  sort_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_29: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_22, 1, 0, 16);  getitem_22 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_7: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put, [unsqueeze_24, slice_29]);  index_put = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_1: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_7, inf);  index_7 = None
        where_4: "i64[100, 16]" = torch.ops.aten.where.self(lt_1, slice_29, full_default_1);  lt_1 = slice_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_4: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_4], -1);  where_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_16: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_3, 1e-06)
        log: "f32[100, 100]" = torch.ops.aten.log.default(add_16);  add_16 = None
        mul_24: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log, -3.0);  log = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_1: "f32[100, 100]" = torch.ops.aten.log.default(getitem_2)
        neg_1: "f32[100, 100]" = torch.ops.aten.neg.default(log_1);  log_1 = None
        log_2: "f32[100, 100]" = torch.ops.aten.log.default(neg_1);  neg_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_11: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_24, log_2);  log_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_2: "f32[100, 100]" = torch.ops.aten.neg.default(sub_11);  sub_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_5: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_2, full_default);  neg_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_6: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_5, full_default);  where_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_1: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_4, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:59 in inner, code: torch.full_like(distance[index[:, None], neighbours], _INF),
        full_default_7: "f32[100, 32]" = torch.ops.aten.full.default([100, 32], inf, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_9: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_6, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_7: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_9);  index_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_1: "f32[100, 100]" = torch.ops.aten.index_put.default(where_6, [unsqueeze_24, cat_4], where_7);  where_6 = where_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_2 = torch.ops.aten.sort.stable(index_put_1, stable = True)
        getitem_24: "i64[100, 100]" = sort_2[1];  sort_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_38: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_24, 1, 0, 16);  getitem_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_10: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_1, [unsqueeze_24, slice_38]);  index_put_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_2: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_10, inf);  index_10 = None
        where_8: "i64[100, 16]" = torch.ops.aten.where.self(lt_2, slice_38, full_default_1);  lt_2 = slice_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_5: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_8], -1);  where_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_4: "f32[100, 100]" = torch.ops.aten.log.default(getitem_5)
        neg_3: "f32[100, 100]" = torch.ops.aten.neg.default(log_4);  log_4 = None
        log_5: "f32[100, 100]" = torch.ops.aten.log.default(neg_3);  neg_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_12: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_24, log_5);  log_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_4: "f32[100, 100]" = torch.ops.aten.neg.default(sub_12);  sub_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_9: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_4, full_default);  neg_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_10: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_9, full_default);  where_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_12: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_10, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_11: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_12);  index_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_2: "f32[100, 100]" = torch.ops.aten.index_put.default(where_10, [unsqueeze_24, cat_4], where_11);  where_10 = where_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_3 = torch.ops.aten.sort.stable(index_put_2, stable = True)
        getitem_26: "i64[100, 100]" = sort_3[1];  sort_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_47: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_26, 1, 0, 16);  getitem_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_13: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_2, [unsqueeze_24, slice_47]);  index_put_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_3: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_13, inf);  index_13 = None
        where_12: "i64[100, 16]" = torch.ops.aten.where.self(lt_3, slice_47, full_default_1);  lt_3 = slice_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_6: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_12], -1);  where_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_7: "f32[100, 100]" = torch.ops.aten.log.default(getitem_8)
        neg_5: "f32[100, 100]" = torch.ops.aten.neg.default(log_7);  log_7 = None
        log_8: "f32[100, 100]" = torch.ops.aten.log.default(neg_5);  neg_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_13: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_24, log_8);  log_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_6: "f32[100, 100]" = torch.ops.aten.neg.default(sub_13);  sub_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_13: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_6, full_default);  neg_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_14: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_13, full_default);  where_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_15: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_14, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_15: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_15);  index_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_3: "f32[100, 100]" = torch.ops.aten.index_put.default(where_14, [unsqueeze_24, cat_4], where_15);  where_14 = where_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_4 = torch.ops.aten.sort.stable(index_put_3, stable = True)
        getitem_28: "i64[100, 100]" = sort_4[1];  sort_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_56: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_28, 1, 0, 16);  getitem_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_16: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_3, [unsqueeze_24, slice_56]);  index_put_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_4: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_16, inf);  index_16 = None
        where_16: "i64[100, 16]" = torch.ops.aten.where.self(lt_4, slice_56, full_default_1);  lt_4 = slice_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_7: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_16], -1);  where_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_10: "f32[100, 100]" = torch.ops.aten.log.default(getitem_11)
        neg_7: "f32[100, 100]" = torch.ops.aten.neg.default(log_10);  log_10 = None
        log_11: "f32[100, 100]" = torch.ops.aten.log.default(neg_7);  neg_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_14: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_24, log_11);  log_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_8: "f32[100, 100]" = torch.ops.aten.neg.default(sub_14);  sub_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_17: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_8, full_default);  neg_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_18: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_17, full_default);  where_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_18: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_18, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_19: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_18);  index_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_4: "f32[100, 100]" = torch.ops.aten.index_put.default(where_18, [unsqueeze_24, cat_4], where_19);  where_18 = where_19 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_5 = torch.ops.aten.sort.stable(index_put_4, stable = True)
        getitem_30: "i64[100, 100]" = sort_5[1];  sort_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_65: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_30, 1, 0, 16);  getitem_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_19: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_4, [unsqueeze_24, slice_65]);  index_put_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_5: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_19, inf);  index_19 = None
        where_20: "i64[100, 16]" = torch.ops.aten.where.self(lt_5, slice_65, full_default_1);  lt_5 = slice_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_8: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_20], -1);  where_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_13: "f32[100, 100]" = torch.ops.aten.log.default(getitem_14)
        neg_9: "f32[100, 100]" = torch.ops.aten.neg.default(log_13);  log_13 = None
        log_14: "f32[100, 100]" = torch.ops.aten.log.default(neg_9);  neg_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_15: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_24, log_14);  log_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_10: "f32[100, 100]" = torch.ops.aten.neg.default(sub_15);  sub_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_21: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_10, full_default);  neg_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_22: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_21, full_default);  where_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_21: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_22, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_23: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_21);  index_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_5: "f32[100, 100]" = torch.ops.aten.index_put.default(where_22, [unsqueeze_24, cat_4], where_23);  where_22 = where_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_6 = torch.ops.aten.sort.stable(index_put_5, stable = True)
        getitem_32: "i64[100, 100]" = sort_6[1];  sort_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_74: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_32, 1, 0, 16);  getitem_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_22: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_5, [unsqueeze_24, slice_74]);  index_put_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_6: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_22, inf);  index_22 = None
        where_24: "i64[100, 16]" = torch.ops.aten.where.self(lt_6, slice_74, full_default_1);  lt_6 = slice_74 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_9: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_24], -1);  where_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_16: "f32[100, 100]" = torch.ops.aten.log.default(getitem_17)
        neg_11: "f32[100, 100]" = torch.ops.aten.neg.default(log_16);  log_16 = None
        log_17: "f32[100, 100]" = torch.ops.aten.log.default(neg_11);  neg_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_16: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_24, log_17);  mul_24 = log_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_12: "f32[100, 100]" = torch.ops.aten.neg.default(sub_16);  sub_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_25: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_12, full_default);  neg_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_26: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_25, full_default);  where_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_24: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_26, [unsqueeze_24, cat_4])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_27: "f32[100, 32]" = torch.ops.aten.where.self(ne_1, full_default_7, index_24);  ne_1 = index_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_6: "f32[100, 100]" = torch.ops.aten.index_put.default(where_26, [unsqueeze_24, cat_4], where_27);  where_26 = where_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_7 = torch.ops.aten.sort.stable(index_put_6, stable = True)
        getitem_34: "i64[100, 100]" = sort_7[1];  sort_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_83: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_34, 1, 0, 16);  getitem_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_25: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_6, [unsqueeze_24, slice_83]);  index_put_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_7: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_25, inf);  index_25 = None
        where_28: "i64[100, 16]" = torch.ops.aten.where.self(lt_7, slice_83, full_default_1);  lt_7 = slice_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_10: "i64[100, 48]" = torch.ops.aten.cat.default([cat_4, where_28], -1);  where_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:345 in forward_core, code: cond_nbr_stack = torch.stack(
        cat_11: "i64[600, 48]" = torch.ops.aten.cat.default([cat_5, cat_6, cat_7, cat_8, cat_9, cat_10]);  cat_5 = cat_6 = cat_7 = cat_8 = cat_9 = cat_10 = None
        view_14: "i64[6, 100, 48]" = torch.ops.aten.view.default(cat_11, [6, 100, 48]);  cat_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:148 in forward, code: pair_mask = mask[None, :, None] & mask[neighbours] & (neighbours != -1)
        unsqueeze_84: "b8[1, 100, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_21, 2);  unsqueeze_21 = None
        index_26: "b8[6, 100, 48]" = torch.ops.aten.index.Tensor(arg16_1, [view_14])
        bitwise_and_17: "b8[6, 100, 48]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_84, index_26);  unsqueeze_84 = index_26 = None
        ne_7: "b8[6, 100, 48]" = torch.ops.aten.ne.Scalar(view_14, -1)
        bitwise_and_18: "b8[6, 100, 48]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_17, ne_7);  bitwise_and_17 = ne_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:157 in forward, code: off = (torch.arange(b, device=neighbours.device) * n)[:, None, None]
        iota_11: "i64[6]" = torch.ops.prims.iota.default(6, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        mul_30: "i64[6]" = torch.ops.aten.mul.Tensor(iota_11, 100)
        unsqueeze_85: "i64[6, 1]" = torch.ops.aten.unsqueeze.default(mul_30, 1);  mul_30 = None
        unsqueeze_86: "i64[6, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_85, 2);  unsqueeze_85 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:158 in forward, code: nb = torch.where(neighbours >= 0, neighbours + off,
        ge: "b8[6, 100, 48]" = torch.ops.aten.ge.Scalar(view_14, 0)
        add_22: "i64[6, 100, 48]" = torch.ops.aten.add.Tensor(view_14, unsqueeze_86)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:159 in forward, code: off + (n - 1)).reshape(b * n, k)
        add_23: "i64[6, 1, 1]" = torch.ops.aten.add.Tensor(unsqueeze_86, 99)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:158 in forward, code: nb = torch.where(neighbours >= 0, neighbours + off,
        where_29: "i64[6, 100, 48]" = torch.ops.aten.where.self(ge, add_22, add_23);  ge = add_22 = add_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:159 in forward, code: off + (n - 1)).reshape(b * n, k)
        view_15: "i64[600, 48]" = torch.ops.aten.view.default(where_29, [600, 48]);  where_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/miniforge3/envs/triad/lib/python3.11/site-packages/torch/_library/custom_ops.py:669 in __call__, code: return self._opoverload(*args, **kwargs)
        p7_barrier: "i64[600, 48]" = torch.ops.salad.p7_barrier.default(view_15);  view_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:170 in forward, code: pos_t = prev_pos.repeat(b, 1, 1)
        repeat: "f32[600, 20, 3]" = torch.ops.aten.repeat.default(arg17_1, [6, 1, 1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:171 in forward, code: resi_t = resi.repeat(b)
        repeat_1: "i64[600]" = torch.ops.aten.repeat.default(arg13_1, [6])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:172 in forward, code: chain_t = (chain[None] + off[:, :, 0]).reshape(-1)
        select_4: "i64[6, 1]" = torch.ops.aten.select.int(unsqueeze_86, 2, 0);  unsqueeze_86 = None
        add_24: "i64[6, 100]" = torch.ops.aten.add.Tensor(unsqueeze_19, select_4);  unsqueeze_19 = None
        view_16: "i64[600]" = torch.ops.aten.view.default(add_24, [-1]);  add_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:173 in forward, code: batch_t = (batch[None] + off[:, :, 0]).reshape(-1)
        add_25: "i64[6, 100]" = torch.ops.aten.add.Tensor(unsqueeze_17, select_4);  unsqueeze_17 = select_4 = None
        view_17: "i64[600]" = torch.ops.aten.view.default(add_25, [-1]);  add_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        unsqueeze_89: "i64[600, 1]" = torch.ops.aten.unsqueeze.default(view_16, 1)
        index_27: "i64[600, 48]" = torch.ops.aten.index.Tensor(view_16, [p7_barrier]);  view_16 = None
        eq_9: "b8[600, 48]" = torch.ops.aten.eq.Tensor(unsqueeze_89, index_27);  unsqueeze_89 = index_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        unsqueeze_90: "i64[600, 1]" = torch.ops.aten.unsqueeze.default(view_17, 1)
        index_28: "i64[600, 48]" = torch.ops.aten.index.Tensor(view_17, [p7_barrier]);  view_17 = None
        eq_10: "b8[600, 48]" = torch.ops.aten.eq.Tensor(unsqueeze_90, index_28);  unsqueeze_90 = index_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        unsqueeze_91: "i64[600, 1]" = torch.ops.aten.unsqueeze.default(repeat_1, 1)
        index_29: "i64[600, 48]" = torch.ops.aten.index.Tensor(repeat_1, [p7_barrier]);  repeat_1 = None
        sub_17: "i64[600, 48]" = torch.ops.aten.sub.Tensor(unsqueeze_91, index_29);  unsqueeze_91 = index_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_4: "i64[600, 48]" = torch.ops.aten.clamp_min.default(sub_17, -32);  sub_17 = None
        clamp_max: "i64[600, 48]" = torch.ops.aten.clamp_max.default(clamp_min_4, 32);  clamp_min_4 = None
        add_26: "i64[600, 48]" = torch.ops.aten.add.Tensor(clamp_max, 32);  clamp_max = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:151 in inner, code: other = torch.full_like(binned, 2 * count + 1)
        full_default_29: "i64[600, 48]" = torch.ops.aten.full.default([600, 48], 65, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_30: "i64[600, 48]" = torch.ops.aten.where.self(eq_9, add_26, full_default_29);  eq_9 = add_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_31: "i64[600, 48]" = torch.ops.aten.where.self(eq_10, where_30, full_default_29);  eq_10 = where_30 = full_default_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:190 in forward, code: relpos = relpos.long().reshape(b, n * k)
        view_18: "i64[6, 4800]" = torch.ops.aten.view.default(where_31, [6, 4800]);  where_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_92: "f32[600, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(repeat, 1)
        slice_95: "f32[600, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_92, 2, 0, 5)
        unsqueeze_93: "f32[600, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_95, 3);  slice_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_30: "f32[600, 48, 20, 3]" = torch.ops.aten.index.Tensor(repeat, [p7_barrier])
        unsqueeze_94: "f32[600, 48, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_30, 2)
        slice_99: "f32[600, 48, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_94, 3, 0, 5);  unsqueeze_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_18: "f32[600, 48, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_93, slice_99);  unsqueeze_93 = slice_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_31: "f32[600, 48, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_18, sub_18);  sub_18 = None
        sum_6: "f32[600, 48, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_31, [-1]);  mul_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_5: "f32[600, 48, 5, 5]" = torch.ops.aten.clamp_min.default(sum_6, 1e-12);  sum_6 = None
        sqrt_4: "f32[600, 48, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_5);  clamp_min_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_19: "f32[600, 48, 25]" = torch.ops.aten.view.default(sqrt_4, [600, 48, 25]);  sqrt_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:57 in _arange_centers, code: + torch.arange(bins, device=device, dtype=dtype) * step
        iota_12: "i64[16]" = torch.ops.prims.iota.default(16, start = 0, step = 1, dtype = torch.int64, device = device(type='cuda', index=0), requires_grad = False)
        mul_32: "i64[16]" = torch.ops.aten.mul.Tensor(iota_12, 1);  iota_12 = None
        add_27: "i64[16]" = torch.ops.aten.add.Tensor(mul_32, 0);  mul_32 = None
        convert_element_type_3: "f32[16]" = torch.ops.prims.convert_element_type.default(add_27, torch.float32);  add_27 = None
        mul_33: "f32[16]" = torch.ops.aten.mul.Tensor(convert_element_type_3, 1.375);  convert_element_type_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:56 in _arange_centers, code: centers = (min_distance
        add_28: "f32[16]" = torch.ops.aten.add.Tensor(mul_33, 0.0);  mul_33 = None
        add_29: "f32[16]" = torch.ops.aten.add.Tensor(add_28, 0.6875);  add_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_95: "f32[600, 48, 25, 1]" = torch.ops.aten.unsqueeze.default(view_19, 3);  view_19 = None
        sub_19: "f32[600, 48, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_95, add_29);  unsqueeze_95 = None
        pow_4: "f32[600, 48, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_19, 2);  sub_19 = None
        neg_13: "f32[600, 48, 25, 16]" = torch.ops.aten.neg.default(pow_4);  pow_4 = None
        div_5: "f32[600, 48, 25, 16]" = torch.ops.aten.div.Tensor(neg_13, 1.890625);  neg_13 = None
        exp_1: "f32[600, 48, 25, 16]" = torch.ops.aten.exp.default(div_5);  div_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_20: "f32[600, 48, 400]" = torch.ops.aten.view.default(exp_1, [600, 48, 400]);  exp_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_6: "f32[600, 3]" = torch.ops.aten.select.int(repeat, 1, 0)
        select_7: "f32[600, 3]" = torch.ops.aten.select.int(repeat, 1, 1)
        select_8: "f32[600, 3]" = torch.ops.aten.select.int(repeat, 1, 2);  repeat = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_20: "f32[600, 3]" = torch.ops.aten.sub.Tensor(select_8, select_7);  select_8 = None
        sub_21: "f32[600, 3]" = torch.ops.aten.sub.Tensor(select_6, select_7);  select_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_34: "f32[600, 3]" = torch.ops.aten.mul.Tensor(sub_20, sub_20)
        sum_7: "f32[600]" = torch.ops.aten.sum.dim_IntList(mul_34, [-1]);  mul_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_6: "f32[600]" = torch.ops.aten.clamp_min.default(sum_7, 1e-12);  sum_7 = None
        sqrt_5: "f32[600]" = torch.ops.aten.sqrt.default(clamp_min_6);  clamp_min_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_96: "f32[600, 1]" = torch.ops.aten.unsqueeze.default(sqrt_5, -1);  sqrt_5 = None
        div_6: "f32[600, 3]" = torch.ops.aten.div.Tensor(sub_20, unsqueeze_96);  sub_20 = unsqueeze_96 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_35: "f32[600, 3]" = torch.ops.aten.mul.Tensor(sub_21, div_6)
        sum_8: "f32[600]" = torch.ops.aten.sum.dim_IntList(mul_35, [-1]);  mul_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_97: "f32[600, 1]" = torch.ops.aten.unsqueeze.default(sum_8, -1);  sum_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_36: "f32[600, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_97, div_6);  unsqueeze_97 = None
        sub_22: "f32[600, 3]" = torch.ops.aten.sub.Tensor(sub_21, mul_36);  sub_21 = mul_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_37: "f32[600, 3]" = torch.ops.aten.mul.Tensor(sub_22, sub_22)
        sum_9: "f32[600]" = torch.ops.aten.sum.dim_IntList(mul_37, [-1]);  mul_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_7: "f32[600]" = torch.ops.aten.clamp_min.default(sum_9, 1e-12);  sum_9 = None
        sqrt_6: "f32[600]" = torch.ops.aten.sqrt.default(clamp_min_7);  clamp_min_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_98: "f32[600, 1]" = torch.ops.aten.unsqueeze.default(sqrt_6, -1);  sqrt_6 = None
        div_7: "f32[600, 3]" = torch.ops.aten.div.Tensor(sub_22, unsqueeze_98);  sub_22 = unsqueeze_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_31: "f32[600, 3]" = torch.ops.aten.index.Tensor(div_6, [None, remainder])
        index_32: "f32[600, 3]" = torch.ops.aten.index.Tensor(div_7, [None, remainder_1])
        mul_38: "f32[600, 3]" = torch.ops.aten.mul.Tensor(index_31, index_32);  index_31 = index_32 = None
        index_33: "f32[600, 3]" = torch.ops.aten.index.Tensor(div_6, [None, remainder_1])
        index_34: "f32[600, 3]" = torch.ops.aten.index.Tensor(div_7, [None, remainder])
        mul_39: "f32[600, 3]" = torch.ops.aten.mul.Tensor(index_33, index_34);  index_33 = index_34 = None
        sub_23: "f32[600, 3]" = torch.ops.aten.sub.Tensor(mul_38, mul_39);  mul_38 = mul_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_99: "f32[600, 3, 1]" = torch.ops.aten.unsqueeze.default(div_6, 2);  div_6 = None
        unsqueeze_100: "f32[600, 3, 1]" = torch.ops.aten.unsqueeze.default(div_7, 2);  div_7 = None
        unsqueeze_101: "f32[600, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_23, 2);  sub_23 = None
        cat_12: "f32[600, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_99, unsqueeze_100, unsqueeze_101], -1);  unsqueeze_99 = unsqueeze_100 = unsqueeze_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_105: "f32[600, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_12, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_106: "f32[600, 1, 3]" = torch.ops.aten.unsqueeze.default(select_7, -2);  select_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_107: "f32[600, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_105, -3);  unsqueeze_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_108: "f32[600, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_106, -2);  unsqueeze_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_25: "f32[600, 48, 20, 3]" = torch.ops.aten.sub.Tensor(index_30, unsqueeze_108)
        permute_20: "f32[600, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_107, [0, 1, 2, 4, 3]);  unsqueeze_107 = None
        unsqueeze_109: "f32[600, 48, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_25, 4);  sub_25 = None
        permute_21: "f32[600, 48, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_109, [0, 1, 2, 4, 3]);  unsqueeze_109 = None
        permute_22: "f32[600, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_20, [0, 3, 4, 1, 2]);  permute_20 = None
        view_25: "f32[600, 3, 3]" = torch.ops.aten.view.default(permute_22, [600, 3, 3]);  permute_22 = None
        permute_23: "f32[600, 3, 48, 20, 1]" = torch.ops.aten.permute.default(permute_21, [0, 4, 1, 2, 3]);  permute_21 = None
        view_26: "f32[600, 3, 960]" = torch.ops.aten.view.default(permute_23, [600, 3, 960]);  permute_23 = None
        bmm_4: "f32[600, 3, 960]" = torch.ops.aten.bmm.default(view_25, view_26);  view_26 = None
        view_27: "f32[600, 3, 1, 48, 20]" = torch.ops.aten.view.default(bmm_4, [600, 3, 1, 48, 20]);  bmm_4 = None
        permute_24: "f32[600, 48, 20, 3, 1]" = torch.ops.aten.permute.default(view_27, [0, 3, 4, 1, 2]);  view_27 = None
        view_28: "f32[600, 48, 20, 3]" = torch.ops.aten.view.default(permute_24, [600, 48, 20, 3]);  permute_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_40: "f32[600, 48, 20, 3]" = torch.ops.aten.mul.Tensor(view_28, view_28)
        sum_10: "f32[600, 48, 20]" = torch.ops.aten.sum.dim_IntList(mul_40, [-1]);  mul_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_8: "f32[600, 48, 20]" = torch.ops.aten.clamp_min.default(sum_10, 1e-12);  sum_10 = None
        sqrt_7: "f32[600, 48, 20]" = torch.ops.aten.sqrt.default(clamp_min_8);  clamp_min_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_110: "f32[600, 48, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_7, -1);  sqrt_7 = None
        div_8: "f32[600, 48, 20, 3]" = torch.ops.aten.div.Tensor(view_28, unsqueeze_110);  view_28 = unsqueeze_110 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:184 in direction_features, code: return local.reshape(n, k, a * 3)
        clone_8: "f32[600, 48, 20, 3]" = torch.ops.aten.clone.default(div_8, memory_format = torch.contiguous_format);  div_8 = None
        view_29: "f32[600, 48, 60]" = torch.ops.aten.view.default(clone_8, [600, 48, 60]);  clone_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_120: "f32[600, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_12, 1)
        permute_30: "f32[600, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_120, [0, 1, 3, 2]);  unsqueeze_120 = None
        index_40: "f32[600, 48, 3, 3]" = torch.ops.aten.index.Tensor(cat_12, [p7_barrier]);  cat_12 = p7_barrier = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:78 in rot_compose, code: return a @ b
        expand: "f32[600, 48, 3, 3]" = torch.ops.aten.expand.default(permute_30, [600, 48, 3, 3]);  permute_30 = None
        clone_9: "f32[600, 48, 3, 3]" = torch.ops.aten.clone.default(expand, memory_format = torch.contiguous_format);  expand = None
        view_34: "f32[28800, 3, 3]" = torch.ops.aten.view.default(clone_9, [28800, 3, 3]);  clone_9 = None
        expand_1: "f32[600, 48, 3, 3]" = torch.ops.aten.expand.default(index_40, [600, 48, 3, 3]);  index_40 = None
        view_35: "f32[28800, 3, 3]" = torch.ops.aten.view.default(expand_1, [28800, 3, 3]);  expand_1 = None
        bmm_6: "f32[28800, 3, 3]" = torch.ops.aten.bmm.default(view_34, view_35);  view_34 = view_35 = None
        view_36: "f32[600, 48, 3, 3]" = torch.ops.aten.view.default(bmm_6, [600, 48, 3, 3]);  bmm_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_37: "f32[600, 48, 9]" = torch.ops.aten.view.default(view_36, [600, 48, 9]);  view_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:209 in pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_2: "f32[600, 48, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_92, [600, 48, 20, 3]);  unsqueeze_92 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:211 in pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_15: "f32[600, 48, 40, 3]" = torch.ops.aten.cat.default([expand_2, index_30], -2);  expand_2 = index_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_36: "f32[600, 48, 40, 3]" = torch.ops.aten.sub.Tensor(cat_15, unsqueeze_108);  cat_15 = unsqueeze_108 = None
        unsqueeze_135: "f32[600, 48, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_36, 4);  sub_36 = None
        permute_37: "f32[600, 48, 40, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_135, [0, 1, 2, 4, 3]);  unsqueeze_135 = None
        permute_39: "f32[600, 3, 48, 40, 1]" = torch.ops.aten.permute.default(permute_37, [0, 4, 1, 2, 3]);  permute_37 = None
        view_43: "f32[600, 3, 1920]" = torch.ops.aten.view.default(permute_39, [600, 3, 1920]);  permute_39 = None
        bmm_8: "f32[600, 3, 1920]" = torch.ops.aten.bmm.default(view_25, view_43);  view_25 = view_43 = None
        view_44: "f32[600, 3, 1, 48, 40]" = torch.ops.aten.view.default(bmm_8, [600, 3, 1, 48, 40]);  bmm_8 = None
        permute_40: "f32[600, 48, 40, 3, 1]" = torch.ops.aten.permute.default(view_44, [0, 3, 4, 1, 2]);  view_44 = None
        view_45: "f32[600, 48, 40, 3]" = torch.ops.aten.view.default(permute_40, [600, 48, 40, 3]);  permute_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_53: "f32[600, 48, 40, 3]" = torch.ops.aten.mul.Tensor(view_45, view_45)
        sum_17: "f32[600, 48, 40]" = torch.ops.aten.sum.dim_IntList(mul_53, [-1]);  mul_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_13: "f32[600, 48, 40]" = torch.ops.aten.clamp_min.default(sum_17, 1e-12);  sum_17 = None
        sqrt_12: "f32[600, 48, 40]" = torch.ops.aten.sqrt.default(clamp_min_13);  clamp_min_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_136: "f32[600, 48, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_12, -1);  sqrt_12 = None
        div_13: "f32[600, 48, 40, 3]" = torch.ops.aten.div.Tensor(view_45, unsqueeze_136);  unsqueeze_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:213 in pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        clone_10: "f32[600, 48, 40, 3]" = torch.ops.aten.clone.default(div_13, memory_format = torch.contiguous_format);  div_13 = None
        view_46: "f32[600, 48, 120]" = torch.ops.aten.view.default(clone_10, [600, 48, 120]);  clone_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:214 in pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_54: "f32[600, 48, 40, 3]" = torch.ops.aten.mul.Tensor(view_45, 0.1);  view_45 = None
        clone_11: "f32[600, 48, 40, 3]" = torch.ops.aten.clone.default(mul_54, memory_format = torch.contiguous_format);  mul_54 = None
        view_47: "f32[600, 48, 120]" = torch.ops.aten.view.default(clone_11, [600, 48, 120]);  clone_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:215 in pair_vector_features, code: return torch.cat([directions, coords], dim=-1)
        cat_16: "f32[600, 48, 240]" = torch.ops.aten.cat.default([view_46, view_47], -1);  view_46 = view_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:217 in forward, code: ar_b = torch.arange(b, device=prev_pos.device)[:, None]
        unsqueeze_137: "i64[6, 1]" = torch.ops.aten.unsqueeze.default(iota_11, 1);  iota_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:218 in forward, code: pair = self.w_relpos[ar_b, relpos]
        index_46: "f32[6, 4800, 64]" = torch.ops.aten.index.Tensor(arg18_1, [unsqueeze_137, view_18]);  arg18_1 = unsqueeze_137 = view_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:225 in forward, code: pair = pair + torch.bmm(x.reshape(b, n * k, x.shape[-1]),
        view_48: "f32[6, 4800, 400]" = torch.ops.aten.view.default(view_20, [6, 4800, 400]);  view_20 = None
        bmm_9: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(view_48, arg19_1);  view_48 = arg19_1 = None
        add_42: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(index_46, bmm_9);  index_46 = bmm_9 = None
        view_49: "f32[6, 4800, 60]" = torch.ops.aten.view.default(view_29, [6, 4800, 60]);  view_29 = None
        bmm_10: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(view_49, arg20_1);  view_49 = arg20_1 = None
        add_43: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(add_42, bmm_10);  add_42 = bmm_10 = None
        view_50: "f32[6, 4800, 9]" = torch.ops.aten.view.default(view_37, [6, 4800, 9]);  view_37 = None
        bmm_11: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(view_50, arg21_1);  view_50 = arg21_1 = None
        add_44: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(add_43, bmm_11);  add_43 = bmm_11 = None
        view_51: "f32[6, 4800, 240]" = torch.ops.aten.view.default(cat_16, [6, 4800, 240]);  cat_16 = None
        bmm_12: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(view_51, arg22_1);  view_51 = arg22_1 = None
        add_45: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(add_44, bmm_12);  add_44 = bmm_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:228 in forward, code: mu = pair.mean(-1, keepdim=True)
        mean_3: "f32[6, 4800, 1]" = torch.ops.aten.mean.dim(add_45, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:229 in forward, code: var = pair.var(-1, unbiased=False, keepdim=True)
        var_3: "f32[6, 4800, 1]" = torch.ops.aten.var.correction(add_45, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:230 in forward, code: pair = (pair - mu) * torch.rsqrt(var + self.ln_eps)
        sub_37: "f32[6, 4800, 64]" = torch.ops.aten.sub.Tensor(add_45, mean_3);  add_45 = mean_3 = None
        add_46: "f32[6, 4800, 1]" = torch.ops.aten.add.Tensor(var_3, 1e-05);  var_3 = None
        rsqrt_3: "f32[6, 4800, 1]" = torch.ops.aten.rsqrt.default(add_46);  add_46 = None
        mul_55: "f32[6, 4800, 64]" = torch.ops.aten.mul.Tensor(sub_37, rsqrt_3);  sub_37 = rsqrt_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:231 in forward, code: pair = pair * self.ln_scale[:, None] + self.ln_offset[:, None]
        unsqueeze_138: "f32[6, 1, 64]" = torch.ops.aten.unsqueeze.default(arg23_1, 1);  arg23_1 = None
        mul_56: "f32[6, 4800, 64]" = torch.ops.aten.mul.Tensor(mul_55, unsqueeze_138);  mul_55 = unsqueeze_138 = None
        unsqueeze_139: "f32[6, 1, 64]" = torch.ops.aten.unsqueeze.default(arg24_1, 1);  arg24_1 = None
        add_47: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(mul_56, unsqueeze_139);  mul_56 = unsqueeze_139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:232 in forward, code: pair = gelu(torch.bmm(pair, self.w_mlp0) + self.b_mlp0[:, None])
        bmm_13: "f32[6, 4800, 128]" = torch.ops.aten.bmm.default(add_47, arg25_1);  add_47 = arg25_1 = None
        unsqueeze_140: "f32[6, 1, 128]" = torch.ops.aten.unsqueeze.default(arg26_1, 1);  arg26_1 = None
        add_48: "f32[6, 4800, 128]" = torch.ops.aten.add.Tensor(bmm_13, unsqueeze_140);  bmm_13 = unsqueeze_140 = None
        mul_57: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(add_48, add_48)
        mul_58: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(mul_57, add_48);  mul_57 = None
        mul_59: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(mul_58, 0.044715);  mul_58 = None
        add_49: "f32[6, 4800, 128]" = torch.ops.aten.add.Tensor(add_48, mul_59);  mul_59 = None
        mul_60: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(add_49, 0.7978845608028654);  add_49 = None
        mul_61: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(add_48, 0.5);  add_48 = None
        tanh_1: "f32[6, 4800, 128]" = torch.ops.aten.tanh.default(mul_60);  mul_60 = None
        add_50: "f32[6, 4800, 128]" = torch.ops.aten.add.Tensor(tanh_1, 1);  tanh_1 = None
        mul_62: "f32[6, 4800, 128]" = torch.ops.aten.mul.Tensor(mul_61, add_50);  mul_61 = add_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:233 in forward, code: pair = torch.bmm(pair, self.w_mlp1) + self.b_mlp1[:, None]
        bmm_14: "f32[6, 4800, 64]" = torch.ops.aten.bmm.default(mul_62, arg27_1);  mul_62 = arg27_1 = None
        unsqueeze_141: "f32[6, 1, 64]" = torch.ops.aten.unsqueeze.default(arg28_1, 1);  arg28_1 = None
        add_51: "f32[6, 4800, 64]" = torch.ops.aten.add.Tensor(bmm_14, unsqueeze_141);  bmm_14 = unsqueeze_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/cond_prologue.py:234 in forward, code: return pair.reshape(b, n, k, self.pair_size), pair_mask
        view_52: "f32[6, 100, 48, 64]" = torch.ops.aten.view.default(add_51, [6, 100, 48, 64]);  add_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_142: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_1, 1)
        unsqueeze_143: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_1, 0);  select_1 = None
        sub_38: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_142, unsqueeze_143);  unsqueeze_142 = unsqueeze_143 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_63: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_38, sub_38);  sub_38 = None
        sum_18: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_63, [-1]);  mul_63 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_14: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_18, 1e-12);  sum_18 = None
        sqrt_13: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_14);  clamp_min_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_32: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_13, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_33: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_32, full_default);  where_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_48: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_33, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_34: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_48);  index_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_7: "f32[100, 100]" = torch.ops.aten.index_put.default(where_33, [unsqueeze_24, where_1], where_34);  where_33 = where_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_8 = torch.ops.aten.sort.stable(index_put_7, stable = True)
        getitem_36: "i64[100, 100]" = sort_8[1];  sort_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_141: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_36, 1, 0, 16);  getitem_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_49: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_7, [unsqueeze_24, slice_141]);  index_put_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_8: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_49, inf);  index_49 = None
        where_35: "i64[100, 16]" = torch.ops.aten.where.self(lt_8, slice_141, full_default_1);  lt_8 = slice_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_17: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_35], -1);  where_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_52: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_13, 1e-06);  sqrt_13 = None
        log_18: "f32[100, 100]" = torch.ops.aten.log.default(add_52);  add_52 = None
        mul_64: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_18, -3.0);  log_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_19: "f32[100, 100]" = torch.ops.aten.log.default(getitem_1)
        neg_14: "f32[100, 100]" = torch.ops.aten.neg.default(log_19);  log_19 = None
        log_20: "f32[100, 100]" = torch.ops.aten.log.default(neg_14);  neg_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_39: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_64, log_20);  mul_64 = log_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_15: "f32[100, 100]" = torch.ops.aten.neg.default(sub_39);  sub_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_36: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_15, full_default);  neg_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_37: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_36, full_default);  where_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_9: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_17, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_51: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_37, [unsqueeze_24, cat_17])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_38: "f32[100, 32]" = torch.ops.aten.where.self(ne_9, full_default_7, index_51);  ne_9 = index_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_8: "f32[100, 100]" = torch.ops.aten.index_put.default(where_37, [unsqueeze_24, cat_17], where_38);  where_37 = where_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_9 = torch.ops.aten.sort.stable(index_put_8, stable = True)
        getitem_38: "i64[100, 100]" = sort_9[1];  sort_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_150: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_38, 1, 0, 32);  getitem_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_52: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_8, [unsqueeze_24, slice_150]);  index_put_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_9: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_52, inf);  index_52 = None
        full_default_37: "i64[100, 32]" = torch.ops.aten.full.default([100, 32], -1, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_39: "i64[100, 32]" = torch.ops.aten.where.self(lt_9, slice_150, full_default_37);  lt_9 = slice_150 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_18: "i64[100, 64]" = torch.ops.aten.cat.default([cat_17, where_39], -1);  cat_17 = where_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_16: "i64[100, 48]" = torch.ops.aten.select.int(view_14, 0, 0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_17: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_52, 0, 0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_18: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_53: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_18])
        bitwise_and_23: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_53);  index_53 = None
        ne_10: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_18, -1)
        bitwise_and_24: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_23, ne_10);  bitwise_and_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_54: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_18])
        eq_13: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_54);  index_54 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_55: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_18])
        eq_14: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_55);  index_55 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_56: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_18])
        sub_40: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_56);  index_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_15: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_40, -32);  sub_40 = None
        clamp_max_1: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_15, 32);  clamp_min_15 = None
        add_53: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_1, 32);  clamp_max_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:151 in inner, code: other = torch.full_like(binned, 2 * count + 1)
        full_default_38: "i64[100, 64]" = torch.ops.aten.full.default([100, 64], 65, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_40: "i64[100, 64]" = torch.ops.aten.where.self(eq_13, add_53, full_default_38);  eq_13 = add_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_41: "i64[100, 64]" = torch.ops.aten.where.self(eq_14, where_40, full_default_38);  eq_14 = where_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_57: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg29_1, [where_41]);  arg29_1 = where_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_164: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(arg0_1, 1)
        slice_157: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_164, 2, 0, 5)
        unsqueeze_165: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_157, 3);  slice_157 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_58: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(arg0_1, [cat_18])
        unsqueeze_166: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_58, 2)
        slice_161: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_166, 3, 0, 5);  unsqueeze_166 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_41: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_165, slice_161);  unsqueeze_165 = slice_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_65: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_41, sub_41);  sub_41 = None
        sum_19: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_65, [-1]);  mul_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_16: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_19, 1e-12);  sum_19 = None
        sqrt_14: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_16);  clamp_min_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_53: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_14, [100, 64, 25]);  sqrt_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_167: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_53, 3);  view_53 = None
        sub_42: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_167, add_29);  unsqueeze_167 = None
        pow_5: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_42, 2);  sub_42 = None
        neg_16: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_5);  pow_5 = None
        div_14: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_16, 1.890625);  neg_16 = None
        exp_2: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_14);  div_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_54: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_2, [100, 64, 400]);  exp_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_168: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_54, 3);  view_54 = None
        permute_41: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_168, [0, 1, 3, 2]);  unsqueeze_168 = None
        unsqueeze_169: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg30_1, 2);  arg30_1 = None
        unsqueeze_170: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_169, 3);  unsqueeze_169 = None
        permute_42: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_170, [2, 3, 1, 0]);  unsqueeze_170 = None
        permute_43: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_41, [0, 1, 3, 2]);  permute_41 = None
        view_55: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_43, [1, 6400, 400]);  permute_43 = None
        permute_44: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_42, [3, 2, 0, 1]);  permute_42 = None
        view_56: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_44, [1, 400, 64]);  permute_44 = None
        bmm_15: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_55, view_56);  view_55 = view_56 = None
        view_57: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_15, [100, 64, 1, 64]);  bmm_15 = None
        permute_45: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_57, [0, 1, 3, 2]);  view_57 = None
        view_58: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_45, [100, 64, 64]);  permute_45 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_57: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_57, view_58);  index_57 = view_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_182: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_6, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_183: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_7, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_48: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_58, unsqueeze_183)
        permute_51: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_182, [0, 1, 2, 4, 3]);  unsqueeze_182 = None
        unsqueeze_184: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_48, 4);  sub_48 = None
        permute_52: "f32[100, 64, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_184, [0, 1, 2, 4, 3]);  unsqueeze_184 = None
        permute_53: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_51, [0, 3, 4, 1, 2]);  permute_51 = None
        view_63: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_53, [100, 3, 3]);  permute_53 = None
        permute_54: "f32[100, 3, 64, 20, 1]" = torch.ops.aten.permute.default(permute_52, [0, 4, 1, 2, 3]);  permute_52 = None
        view_64: "f32[100, 3, 1280]" = torch.ops.aten.view.default(permute_54, [100, 3, 1280]);  permute_54 = None
        bmm_17: "f32[100, 3, 1280]" = torch.ops.aten.bmm.default(view_63, view_64);  view_64 = None
        view_65: "f32[100, 3, 1, 64, 20]" = torch.ops.aten.view.default(bmm_17, [100, 3, 1, 64, 20]);  bmm_17 = None
        permute_55: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.permute.default(view_65, [0, 3, 4, 1, 2]);  view_65 = None
        view_66: "f32[100, 64, 20, 3]" = torch.ops.aten.view.default(permute_55, [100, 64, 20, 3]);  permute_55 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_74: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(view_66, view_66)
        sum_23: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_74, [-1]);  mul_74 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_19: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_23, 1e-12);  sum_23 = None
        sqrt_17: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_19);  clamp_min_19 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_185: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_17, -1);  sqrt_17 = None
        div_17: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(view_66, unsqueeze_185);  view_66 = unsqueeze_185 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        clone_14: "f32[100, 64, 20, 3]" = torch.ops.aten.clone.default(div_17, memory_format = torch.contiguous_format);  div_17 = None
        view_67: "f32[100, 64, 60]" = torch.ops.aten.view.default(clone_14, [100, 64, 60]);  clone_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_3: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_164, [100, 64, 20, 3]);  unsqueeze_164 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_20: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_3, index_58], -2);  expand_3 = index_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_49: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_20, unsqueeze_183);  cat_20 = unsqueeze_183 = None
        unsqueeze_191: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_49, 4);  sub_49 = None
        permute_57: "f32[100, 64, 40, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_191, [0, 1, 2, 4, 3]);  unsqueeze_191 = None
        permute_59: "f32[100, 3, 64, 40, 1]" = torch.ops.aten.permute.default(permute_57, [0, 4, 1, 2, 3]);  permute_57 = None
        view_69: "f32[100, 3, 2560]" = torch.ops.aten.view.default(permute_59, [100, 3, 2560]);  permute_59 = None
        bmm_18: "f32[100, 3, 2560]" = torch.ops.aten.bmm.default(view_63, view_69);  view_63 = view_69 = None
        view_70: "f32[100, 3, 1, 64, 40]" = torch.ops.aten.view.default(bmm_18, [100, 3, 1, 64, 40]);  bmm_18 = None
        permute_60: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.permute.default(view_70, [0, 3, 4, 1, 2]);  view_70 = None
        view_71: "f32[100, 64, 40, 3]" = torch.ops.aten.view.default(permute_60, [100, 64, 40, 3]);  permute_60 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_75: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_71, view_71)
        sum_24: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_75, [-1]);  mul_75 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_20: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_24, 1e-12);  sum_24 = None
        sqrt_18: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_20);  clamp_min_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_192: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_18, -1);  sqrt_18 = None
        div_18: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(view_71, unsqueeze_192);  unsqueeze_192 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        clone_15: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(div_18, memory_format = torch.contiguous_format);  div_18 = None
        view_72: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_15, [100, 64, 120]);  clone_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_76: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_71, 0.1);  view_71 = None
        clone_16: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(mul_76, memory_format = torch.contiguous_format);  mul_76 = None
        view_73: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_16, [100, 64, 120]);  clone_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_21: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_72, view_73], -1);  view_72 = view_73 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_193: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_67, 3);  view_67 = None
        permute_61: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_193, [0, 1, 3, 2]);  unsqueeze_193 = None
        unsqueeze_194: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg31_1, 2);  arg31_1 = None
        unsqueeze_195: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_194, 3);  unsqueeze_194 = None
        permute_62: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_195, [2, 3, 1, 0]);  unsqueeze_195 = None
        permute_63: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_61, [0, 1, 3, 2]);  permute_61 = None
        view_74: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_63, [1, 6400, 60]);  permute_63 = None
        permute_64: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_62, [3, 2, 0, 1]);  permute_62 = None
        view_75: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_64, [1, 60, 64]);  permute_64 = None
        bmm_19: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_74, view_75);  view_74 = view_75 = None
        view_76: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_19, [100, 64, 1, 64]);  bmm_19 = None
        permute_65: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_76, [0, 1, 3, 2]);  view_76 = None
        view_77: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_65, [100, 64, 64]);  permute_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_62: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_57, view_77);  add_57 = view_77 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_205: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat, 1)
        permute_71: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_205, [0, 1, 3, 2]);  unsqueeze_205 = None
        index_68: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat, [cat_18]);  cat = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:78 in rot_compose, code: return a @ b
        expand_4: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(permute_71, [100, 64, 3, 3]);  permute_71 = None
        clone_17: "f32[100, 64, 3, 3]" = torch.ops.aten.clone.default(expand_4, memory_format = torch.contiguous_format);  expand_4 = None
        view_82: "f32[6400, 3, 3]" = torch.ops.aten.view.default(clone_17, [6400, 3, 3]);  clone_17 = None
        expand_5: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(index_68, [100, 64, 3, 3]);  index_68 = None
        view_83: "f32[6400, 3, 3]" = torch.ops.aten.view.default(expand_5, [6400, 3, 3]);  expand_5 = None
        bmm_21: "f32[6400, 3, 3]" = torch.ops.aten.bmm.default(view_82, view_83);  view_82 = view_83 = None
        view_84: "f32[100, 64, 3, 3]" = torch.ops.aten.view.default(bmm_21, [100, 64, 3, 3]);  bmm_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_85: "f32[100, 64, 9]" = torch.ops.aten.view.default(view_84, [100, 64, 9]);  view_84 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_206: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_85, 3);  view_85 = None
        permute_72: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_206, [0, 1, 3, 2]);  unsqueeze_206 = None
        unsqueeze_207: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg32_1, 2);  arg32_1 = None
        unsqueeze_208: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_207, 3);  unsqueeze_207 = None
        permute_73: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_208, [2, 3, 1, 0]);  unsqueeze_208 = None
        permute_74: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_72, [0, 1, 3, 2]);  permute_72 = None
        view_86: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_74, [1, 6400, 9]);  permute_74 = None
        permute_75: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_73, [3, 2, 0, 1]);  permute_73 = None
        view_87: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_75, [1, 9, 64]);  permute_75 = None
        bmm_22: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_86, view_87);  view_86 = view_87 = None
        view_88: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_22, [100, 64, 1, 64]);  bmm_22 = None
        permute_76: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_88, [0, 1, 3, 2]);  view_88 = None
        view_89: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_76, [100, 64, 64]);  permute_76 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_67: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_62, view_89);  add_62 = view_89 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_209: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_21, 3);  cat_21 = None
        permute_77: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_209, [0, 1, 3, 2]);  unsqueeze_209 = None
        unsqueeze_210: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg33_1, 2);  arg33_1 = None
        unsqueeze_211: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_210, 3);  unsqueeze_210 = None
        permute_78: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_211, [2, 3, 1, 0]);  unsqueeze_211 = None
        permute_79: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_77, [0, 1, 3, 2]);  permute_77 = None
        view_90: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_79, [1, 6400, 240]);  permute_79 = None
        permute_80: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_78, [3, 2, 0, 1]);  permute_78 = None
        view_91: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_80, [1, 240, 64]);  permute_80 = None
        bmm_23: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_90, view_91);  view_90 = view_91 = None
        view_92: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_23, [100, 64, 1, 64]);  bmm_23 = None
        permute_81: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_92, [0, 1, 3, 2]);  view_92 = None
        view_93: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_81, [100, 64, 64]);  permute_81 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_68: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_67, view_93);  add_67 = view_93 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_4: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_68, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_4: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_68, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_55: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_68, mean_4);  add_68 = mean_4 = None
        add_69: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_4, 1e-05);  var_4 = None
        rsqrt_4: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_69);  add_69 = None
        mul_83: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_55, rsqrt_4);  sub_55 = rsqrt_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_84: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_83, arg34_1);  mul_83 = arg34_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_70: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_84, arg35_1);  mul_84 = arg35_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_212: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_70, 3);  add_70 = None
        permute_82: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_212, [0, 1, 3, 2]);  unsqueeze_212 = None
        unsqueeze_213: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg36_1, 2);  arg36_1 = None
        unsqueeze_214: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_213, 3);  unsqueeze_213 = None
        permute_83: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_214, [2, 3, 1, 0]);  unsqueeze_214 = None
        permute_84: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_82, [0, 1, 3, 2]);  permute_82 = None
        view_94: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_84, [1, 6400, 64]);  permute_84 = None
        permute_85: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_83, [3, 2, 0, 1]);  permute_83 = None
        view_95: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_85, [1, 64, 128]);  permute_85 = None
        bmm_24: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_94, view_95);  view_94 = view_95 = None
        view_96: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_24, [100, 64, 1, 128]);  bmm_24 = None
        permute_86: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_96, [0, 1, 3, 2]);  view_96 = None
        view_97: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_86, [100, 64, 128]);  permute_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_71: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_97, arg37_1);  view_97 = arg37_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_85: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_71, add_71)
        mul_86: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_85, add_71);  mul_85 = None
        mul_87: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_86, 0.044715);  mul_86 = None
        add_72: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_71, mul_87);  mul_87 = None
        mul_88: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_72, 0.7978845608028654);  add_72 = None
        mul_89: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_71, 0.5);  add_71 = None
        tanh_2: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_88);  mul_88 = None
        add_73: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_2, 1);  tanh_2 = None
        mul_90: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_89, add_73);  mul_89 = add_73 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_215: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_90, 3);  mul_90 = None
        permute_87: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_215, [0, 1, 3, 2]);  unsqueeze_215 = None
        unsqueeze_216: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg38_1, 2);  arg38_1 = None
        unsqueeze_217: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_216, 3);  unsqueeze_216 = None
        permute_88: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_217, [2, 3, 1, 0]);  unsqueeze_217 = None
        permute_89: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_87, [0, 1, 3, 2]);  permute_87 = None
        view_98: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_89, [1, 6400, 128]);  permute_89 = None
        permute_90: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_88, [3, 2, 0, 1]);  permute_88 = None
        view_99: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_90, [1, 128, 64]);  permute_90 = None
        bmm_25: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_98, view_99);  view_98 = view_99 = None
        view_100: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_25, [100, 64, 1, 64]);  bmm_25 = None
        permute_91: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_100, [0, 1, 3, 2]);  view_100 = None
        view_101: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_91, [100, 64, 64]);  permute_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_74: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_101, arg39_1);  view_101 = arg39_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_5: "f32[100, 1]" = torch.ops.aten.mean.dim(add_13, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_5: "f32[100, 1]" = torch.ops.aten.var.correction(add_13, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_56: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_13, mean_5);  mean_5 = None
        add_75: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_5, 1e-05);  var_5 = None
        rsqrt_5: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_75);  add_75 = None
        mul_91: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_56, rsqrt_5);  sub_56 = rsqrt_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_92: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_91, arg40_1);  mul_91 = arg40_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_76: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_92, arg41_1);  mul_92 = arg41_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_21: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(arg0_1, 10.0);  arg0_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_25: "f32[100, 3]" = torch.ops.aten.select.int(div_21, 1, 0)
        select_26: "f32[100, 3]" = torch.ops.aten.select.int(div_21, 1, 1)
        select_27: "f32[100, 3]" = torch.ops.aten.select.int(div_21, 1, 2);  div_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_57: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_27, select_26);  select_27 = None
        sub_58: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_25, select_26);  select_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_93: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_57, sub_57)
        sum_28: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_93, [-1]);  mul_93 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_23: "f32[100]" = torch.ops.aten.clamp_min.default(sum_28, 1e-12);  sum_28 = None
        sqrt_21: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_23);  clamp_min_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_218: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_21, -1);  sqrt_21 = None
        div_22: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_57, unsqueeze_218);  sub_57 = unsqueeze_218 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_94: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_58, div_22)
        sum_29: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_94, [-1]);  mul_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_219: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_29, -1);  sum_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_95: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_219, div_22);  unsqueeze_219 = None
        sub_59: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_58, mul_95);  sub_58 = mul_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_96: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_59, sub_59)
        sum_30: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_96, [-1]);  mul_96 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_24: "f32[100]" = torch.ops.aten.clamp_min.default(sum_30, 1e-12);  sum_30 = None
        sqrt_22: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_24);  clamp_min_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_220: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_22, -1);  sqrt_22 = None
        div_23: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_59, unsqueeze_220);  sub_59 = unsqueeze_220 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_69: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_22, [None, remainder])
        index_70: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_23, [None, remainder_1])
        mul_97: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_69, index_70);  index_69 = index_70 = None
        index_71: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_22, [None, remainder_1])
        index_72: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_23, [None, remainder])
        mul_98: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_71, index_72);  index_71 = index_72 = None
        sub_60: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_97, mul_98);  mul_97 = mul_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_221: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_22, 2);  div_22 = None
        unsqueeze_222: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_23, 2);  div_23 = None
        unsqueeze_223: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_60, 2);  sub_60 = None
        cat_23: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_221, unsqueeze_222, unsqueeze_223], -1);  unsqueeze_221 = unsqueeze_222 = unsqueeze_223 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_6: "f32[100, 1]" = torch.ops.aten.mean.dim(add_76, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_6: "f32[100, 1]" = torch.ops.aten.var.correction(add_76, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_62: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_76, mean_6);  add_76 = mean_6 = None
        add_81: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_6, 1e-05);  var_6 = None
        rsqrt_6: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_81);  add_81 = None
        mul_99: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_62, rsqrt_6);  sub_62 = rsqrt_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_100: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_99, arg42_1);  mul_99 = arg42_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_82: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_100, arg43_1);  mul_100 = arg43_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_227: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_82, 2);  add_82 = None
        permute_97: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_227, [0, 2, 1]);  unsqueeze_227 = None
        unsqueeze_228: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg44_1, 2);  arg44_1 = None
        permute_98: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_228, [2, 1, 0]);  unsqueeze_228 = None
        permute_99: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_97, [0, 2, 1]);  permute_97 = None
        view_106: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_99, [1, 100, 128]);  permute_99 = None
        permute_100: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_98, [2, 1, 0]);  permute_98 = None
        view_107: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_100, [1, 128, 768]);  permute_100 = None
        bmm_27: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_106, view_107);  view_107 = None
        view_108: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_27, [100, 1, 768]);  bmm_27 = None
        permute_101: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_108, [0, 2, 1]);  view_108 = None
        view_109: "f32[100, 768]" = torch.ops.aten.view.default(permute_101, [100, 768]);  permute_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_110: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_109, [100, 8, 96]);  view_109 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split = torch.ops.aten.split.Tensor(view_110, 32, -1);  view_110 = None
        getitem_39: "f32[100, 8, 32]" = split[0]
        getitem_40: "f32[100, 8, 32]" = split[1]
        getitem_41: "f32[100, 8, 32]" = split[2];  split = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_7: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_39, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_7: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_39, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_63: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_39, mean_7);  getitem_39 = mean_7 = None
        add_83: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_7, 1e-05);  var_7 = None
        rsqrt_7: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_83);  add_83 = None
        mul_101: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_63, rsqrt_7);  sub_63 = rsqrt_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_102: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_101, arg45_1);  mul_101 = arg45_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_84: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_102, arg46_1);  mul_102 = arg46_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_8: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_40, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_8: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_40, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_64: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_40, mean_8);  getitem_40 = mean_8 = None
        add_85: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_8, 1e-05);  var_8 = None
        rsqrt_8: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_85);  add_85 = None
        mul_103: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_64, rsqrt_8);  sub_64 = rsqrt_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_104: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_103, arg47_1);  mul_103 = arg47_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_86: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_104, arg48_1);  mul_104 = arg48_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_230: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg49_1, 2);  arg49_1 = None
        permute_103: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_230, [2, 1, 0]);  unsqueeze_230 = None
        permute_105: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_103, [2, 1, 0]);  permute_103 = None
        view_112: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_105, [1, 128, 576]);  permute_105 = None
        bmm_28: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_106, view_112);  view_106 = view_112 = None
        view_113: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_28, [100, 1, 576]);  bmm_28 = None
        permute_106: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_113, [0, 2, 1]);  view_113 = None
        view_114: "f32[100, 576]" = torch.ops.aten.view.default(permute_106, [100, 576]);  permute_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_115: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_114, [100, 192, 3]);  view_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_231: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_23, -3);  cat_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_232: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_26, -2);  select_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_107: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_231, [0, 1, 2, 3])
        unsqueeze_233: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_115, 3);  view_115 = None
        permute_108: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_233, [0, 1, 3, 2]);  unsqueeze_233 = None
        permute_109: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_107, [0, 2, 3, 1]);  permute_107 = None
        view_116: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_109, [100, 3, 3]);  permute_109 = None
        permute_110: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_108, [0, 3, 1, 2]);  permute_108 = None
        view_117: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_110, [100, 3, 192]);  permute_110 = None
        bmm_29: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_116, view_117);  view_116 = view_117 = None
        view_118: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_29, [100, 3, 1, 192]);  bmm_29 = None
        permute_111: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_118, [0, 3, 1, 2]);  view_118 = None
        view_119: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_111, [100, 192, 3]);  permute_111 = None
        add_87: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_119, unsqueeze_232);  view_119 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_120: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_87, [100, 8, 24, 3]);  add_87 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_188: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_120, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_191: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_120, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_194: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_120, 2, 16, 9223372036854775807);  view_120 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_234: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_74, 3);  add_74 = None
        permute_112: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_234, [0, 1, 3, 2])
        unsqueeze_235: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg50_1, 2);  arg50_1 = None
        unsqueeze_236: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_235, 3);  unsqueeze_235 = None
        permute_113: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_236, [2, 3, 1, 0]);  unsqueeze_236 = None
        permute_114: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_112, [0, 1, 3, 2]);  permute_112 = None
        view_121: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_114, [1, 6400, 64]);  permute_114 = None
        permute_115: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_113, [3, 2, 0, 1]);  permute_113 = None
        view_122: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_115, [1, 64, 8]);  permute_115 = None
        bmm_30: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_121, view_122);  view_121 = view_122 = None
        view_123: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_30, [100, 64, 1, 8]);  bmm_30 = None
        permute_116: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_123, [0, 1, 3, 2]);  view_123 = None
        view_124: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_116, [100, 64, 8]);  permute_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_3: "f32[8]" = torch.ops.aten.exp.default(arg51_1)
        log1p: "f32[8]" = torch.ops.aten.log1p.default(exp_3);  exp_3 = None
        gt: "b8[8]" = torch.ops.aten.gt.Scalar(arg51_1, 20)
        where_42: "f32[8]" = torch.ops.aten.where.self(gt, arg51_1, log1p);  gt = arg51_1 = log1p = None
        view_125: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_42, [1, 1, 8]);  where_42 = None
        mul_105: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_125, 0.16666666666666666);  view_125 = None
        div_24: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_105, 2);  mul_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_237: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_188, 1);  slice_188 = None
        index_73: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_191, [cat_18]);  slice_191 = None
        sub_65: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_237, index_73);  unsqueeze_237 = index_73 = None
        pow_6: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_65, 2);  sub_65 = None
        sum_31: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_6, [-1, -2]);  pow_6 = None
        mul_106: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_24, sum_31);  div_24 = sum_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_74: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_86, [cat_18]);  add_86 = None
        unsqueeze_238: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_84, 3);  add_84 = None
        permute_117: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_238, [0, 3, 1, 2]);  unsqueeze_238 = None
        permute_118: "f32[100, 64, 8, 32]" = torch.ops.aten.permute.default(index_74, [0, 1, 2, 3]);  index_74 = None
        permute_119: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_117, [0, 2, 3, 1]);  permute_117 = None
        view_126: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_119, [800, 1, 32]);  permute_119 = None
        permute_120: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(permute_118, [0, 2, 3, 1]);  permute_118 = None
        clone_18: "f32[100, 8, 32, 64]" = torch.ops.aten.clone.default(permute_120, memory_format = torch.contiguous_format);  permute_120 = None
        view_127: "f32[800, 32, 64]" = torch.ops.aten.view.default(clone_18, [800, 32, 64]);  clone_18 = None
        bmm_31: "f32[800, 1, 64]" = torch.ops.aten.bmm.default(view_126, view_127);  view_126 = view_127 = None
        view_128: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_31, [100, 8, 1, 64]);  bmm_31 = None
        permute_121: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_128, [0, 3, 1, 2]);  view_128 = None
        view_129: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_121, [100, 64, 8]);  permute_121 = None
        mul_107: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(view_129, 0.1767766952966369);  view_129 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_88: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_107, view_124);  mul_107 = view_124 = None
        sub_66: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_88, mul_106);  add_88 = mul_106 = None
        mul_108: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_66, 0.5773502691896257);  sub_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_25: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_24, ne_10);  bitwise_and_24 = ne_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_239: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_25, 2);  bitwise_and_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:120 in forward, code: torch.full_like(logits, -1e9))
        full_default_39: "f32[100, 64, 8]" = torch.ops.aten.full.default([100, 64, 8], -1000000000.0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        where_43: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_239, mul_108, full_default_39);  mul_108 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_19: "f32[100, 64, 8]" = torch.ops.aten.clone.default(where_43, memory_format = torch.contiguous_format);  where_43 = None
        amax: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_19, [-2], True)
        sub_67: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(clone_19, amax);  clone_19 = amax = None
        exp_4: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_67);  sub_67 = None
        sum_32: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_4, [-2], True)
        div_25: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_4, sum_32);  exp_4 = sum_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        full_default_40: "f32[100, 64, 8]" = torch.ops.aten.full.default([100, 64, 8], 0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_44: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_239, div_25, full_default_40);  unsqueeze_239 = div_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_241: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_44, 3);  where_44 = None
        permute_122: "f32[100, 8, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_241, [0, 2, 3, 1])
        permute_123: "f32[100, 1, 64, 64]" = torch.ops.aten.permute.default(unsqueeze_234, [0, 3, 2, 1]);  unsqueeze_234 = None
        permute_124: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(permute_122, [0, 1, 3, 2]);  permute_122 = None
        view_130: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_124, [100, 8, 64])
        permute_125: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_123, [0, 3, 2, 1]);  permute_123 = None
        view_131: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_125, [100, 64, 64]);  permute_125 = None
        bmm_32: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_130, view_131);  view_130 = view_131 = None
        view_132: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_32, [100, 8, 1, 64]);  bmm_32 = None
        permute_126: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_132, [0, 1, 3, 2]);  view_132 = None
        view_133: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_126, [100, 8, 64]);  permute_126 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_75: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_41, [cat_18]);  getitem_41 = None
        permute_128: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(index_75, [0, 2, 3, 1]);  index_75 = None
        clone_20: "f32[100, 8, 64, 1]" = torch.ops.aten.clone.default(permute_124, memory_format = torch.contiguous_format);  permute_124 = None
        view_134: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_20, [800, 1, 64]);  clone_20 = None
        permute_130: "f32[100, 8, 64, 32]" = torch.ops.aten.permute.default(permute_128, [0, 1, 3, 2]);  permute_128 = None
        clone_21: "f32[100, 8, 64, 32]" = torch.ops.aten.clone.default(permute_130, memory_format = torch.contiguous_format);  permute_130 = None
        view_135: "f32[800, 64, 32]" = torch.ops.aten.view.default(clone_21, [800, 64, 32]);  clone_21 = None
        bmm_33: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_134, view_135);  view_134 = view_135 = None
        view_136: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_33, [100, 8, 1, 32]);  bmm_33 = None
        permute_131: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_136, [0, 1, 3, 2]);  view_136 = None
        view_137: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_131, [100, 8, 32]);  permute_131 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_76: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_194, [cat_18]);  slice_194 = cat_18 = None
        unsqueeze_245: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_241, 4);  unsqueeze_241 = None
        permute_132: "f32[100, 8, 1, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_245, [0, 2, 3, 4, 1]);  unsqueeze_245 = None
        permute_133: "f32[100, 8, 8, 3, 64]" = torch.ops.aten.permute.default(index_76, [0, 2, 3, 4, 1]);  index_76 = None
        permute_134: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.permute.default(permute_132, [0, 1, 4, 2, 3]);  permute_132 = None
        clone_22: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.clone.default(permute_134, memory_format = torch.contiguous_format);  permute_134 = None
        view_138: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_22, [800, 1, 64]);  clone_22 = None
        permute_135: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.permute.default(permute_133, [0, 1, 4, 2, 3]);  permute_133 = None
        clone_23: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.clone.default(permute_135, memory_format = torch.contiguous_format);  permute_135 = None
        view_139: "f32[800, 64, 24]" = torch.ops.aten.view.default(clone_23, [800, 64, 24]);  clone_23 = None
        bmm_34: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_138, view_139);  view_138 = view_139 = None
        view_140: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_34, [100, 8, 1, 8, 3]);  bmm_34 = None
        permute_136: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_140, [0, 1, 3, 4, 2]);  view_140 = None
        view_141: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_136, [100, 8, 8, 3]);  permute_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_248: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_231, -3);  unsqueeze_231 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_249: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_232, -2);  unsqueeze_232 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_68: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_141, unsqueeze_249);  view_141 = unsqueeze_249 = None
        permute_137: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_248, [0, 1, 2, 4, 3]);  unsqueeze_248 = None
        unsqueeze_250: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_68, 4);  sub_68 = None
        permute_138: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_250, [0, 1, 2, 4, 3]);  unsqueeze_250 = None
        permute_139: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_137, [0, 3, 4, 1, 2]);  permute_137 = None
        view_142: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_139, [100, 3, 3]);  permute_139 = None
        permute_140: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_138, [0, 4, 1, 2, 3]);  permute_138 = None
        view_143: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_140, [100, 3, 64]);  permute_140 = None
        bmm_35: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_142, view_143);  view_142 = view_143 = None
        view_144: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_35, [100, 3, 1, 8, 8]);  bmm_35 = None
        permute_141: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_144, [0, 3, 4, 1, 2]);  view_144 = None
        view_145: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_141, [100, 8, 8, 3]);  permute_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_109: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_145, view_145)
        sum_33: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_109, [-1]);  mul_109 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_25: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_33, 1e-12);  sum_33 = None
        sqrt_23: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_25);  clamp_min_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_146: "f32[100, 512]" = torch.ops.aten.view.default(view_133, [100, -1]);  view_133 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_147: "f32[100, 256]" = torch.ops.aten.view.default(view_137, [100, -1]);  view_137 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_24: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_145, memory_format = torch.contiguous_format);  view_145 = None
        view_148: "f32[100, 192]" = torch.ops.aten.view.default(clone_24, [100, 192]);  clone_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_149: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_23, [100, -1]);  sqrt_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_24: "f32[100, 1024]" = torch.ops.aten.cat.default([view_146, view_147, view_148, view_149], -1);  view_146 = view_147 = view_148 = view_149 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_251: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_24, 2);  cat_24 = None
        permute_142: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_251, [0, 2, 1]);  unsqueeze_251 = None
        unsqueeze_252: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg52_1, 2);  arg52_1 = None
        permute_143: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_252, [2, 1, 0]);  unsqueeze_252 = None
        permute_144: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_142, [0, 2, 1]);  permute_142 = None
        view_150: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_144, [1, 100, 1024]);  permute_144 = None
        permute_145: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_143, [2, 1, 0]);  permute_143 = None
        view_151: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_145, [1, 1024, 128]);  permute_145 = None
        bmm_36: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_150, view_151);  view_150 = view_151 = None
        view_152: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_36, [100, 1, 128]);  bmm_36 = None
        permute_146: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_152, [0, 2, 1]);  view_152 = None
        view_153: "f32[100, 128]" = torch.ops.aten.view.default(permute_146, [100, 128]);  permute_146 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_89: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_153, arg53_1);  view_153 = arg53_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_90: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_13, add_89);  add_13 = add_89 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_9: "f32[100, 1]" = torch.ops.aten.mean.dim(add_90, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_9: "f32[100, 1]" = torch.ops.aten.var.correction(add_90, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_69: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_90, mean_9);  mean_9 = None
        add_91: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_9, 1e-05);  var_9 = None
        rsqrt_9: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_91);  add_91 = None
        mul_110: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_69, rsqrt_9);  sub_69 = rsqrt_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_111: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_110, arg54_1);  mul_110 = arg54_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_92: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_111, arg55_1);  mul_111 = arg55_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:372 in forward, code: self.layer_norm_3(features), prev_pos / sigma, pair, pair_mask, cond_neighbours)
        div_26: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(arg17_1, 10.0);  arg17_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_28: "f32[100, 3]" = torch.ops.aten.select.int(div_26, 1, 0)
        select_29: "f32[100, 3]" = torch.ops.aten.select.int(div_26, 1, 1)
        select_30: "f32[100, 3]" = torch.ops.aten.select.int(div_26, 1, 2);  div_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_70: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_30, select_29);  select_30 = None
        sub_71: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_28, select_29);  select_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_112: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_70, sub_70)
        sum_34: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_112, [-1]);  mul_112 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_26: "f32[100]" = torch.ops.aten.clamp_min.default(sum_34, 1e-12);  sum_34 = None
        sqrt_24: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_26);  clamp_min_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_253: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_24, -1);  sqrt_24 = None
        div_27: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_70, unsqueeze_253);  sub_70 = unsqueeze_253 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_113: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_71, div_27)
        sum_35: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_113, [-1]);  mul_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_254: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_35, -1);  sum_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_114: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_254, div_27);  unsqueeze_254 = None
        sub_72: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_71, mul_114);  sub_71 = mul_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_115: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_72, sub_72)
        sum_36: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_115, [-1]);  mul_115 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_27: "f32[100]" = torch.ops.aten.clamp_min.default(sum_36, 1e-12);  sum_36 = None
        sqrt_25: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_27);  clamp_min_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_255: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_25, -1);  sqrt_25 = None
        div_28: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_72, unsqueeze_255);  sub_72 = unsqueeze_255 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_77: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_27, [None, remainder])
        index_78: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_28, [None, remainder_1])
        mul_116: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_77, index_78);  index_77 = index_78 = None
        index_79: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_27, [None, remainder_1])
        index_80: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_28, [None, remainder])
        mul_117: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_79, index_80);  index_79 = index_80 = None
        sub_73: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_116, mul_117);  mul_116 = mul_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_256: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_27, 2);  div_27 = None
        unsqueeze_257: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_28, 2);  div_28 = None
        unsqueeze_258: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_73, 2);  sub_73 = None
        cat_25: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_256, unsqueeze_257, unsqueeze_258], -1);  unsqueeze_256 = unsqueeze_257 = unsqueeze_258 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_10: "f32[100, 1]" = torch.ops.aten.mean.dim(add_92, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_10: "f32[100, 1]" = torch.ops.aten.var.correction(add_92, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_75: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_92, mean_10);  add_92 = mean_10 = None
        add_97: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_10, 1e-05);  var_10 = None
        rsqrt_10: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_97);  add_97 = None
        mul_118: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_75, rsqrt_10);  sub_75 = rsqrt_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_119: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_118, arg56_1);  mul_118 = arg56_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_98: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_119, arg57_1);  mul_119 = arg57_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_262: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_98, 2);  add_98 = None
        permute_152: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_262, [0, 2, 1]);  unsqueeze_262 = None
        unsqueeze_263: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg58_1, 2);  arg58_1 = None
        permute_153: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_263, [2, 1, 0]);  unsqueeze_263 = None
        permute_154: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_152, [0, 2, 1]);  permute_152 = None
        view_158: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_154, [1, 100, 128]);  permute_154 = None
        permute_155: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_153, [2, 1, 0]);  permute_153 = None
        view_159: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_155, [1, 128, 768]);  permute_155 = None
        bmm_38: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_158, view_159);  view_159 = None
        view_160: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_38, [100, 1, 768]);  bmm_38 = None
        permute_156: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_160, [0, 2, 1]);  view_160 = None
        view_161: "f32[100, 768]" = torch.ops.aten.view.default(permute_156, [100, 768]);  permute_156 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_162: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_161, [100, 8, 96]);  view_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_1 = torch.ops.aten.split.Tensor(view_162, 32, -1);  view_162 = None
        getitem_42: "f32[100, 8, 32]" = split_1[0]
        getitem_43: "f32[100, 8, 32]" = split_1[1]
        getitem_44: "f32[100, 8, 32]" = split_1[2];  split_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_11: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_42, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_11: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_42, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_76: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_42, mean_11);  getitem_42 = mean_11 = None
        add_99: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_11, 1e-05);  var_11 = None
        rsqrt_11: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_99);  add_99 = None
        mul_120: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_76, rsqrt_11);  sub_76 = rsqrt_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_121: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_120, arg59_1);  mul_120 = arg59_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_100: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_121, arg60_1);  mul_121 = arg60_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_12: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_43, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_12: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_43, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_77: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_43, mean_12);  getitem_43 = mean_12 = None
        add_101: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_12, 1e-05);  var_12 = None
        rsqrt_12: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_101);  add_101 = None
        mul_122: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_77, rsqrt_12);  sub_77 = rsqrt_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_123: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_122, arg61_1);  mul_122 = arg61_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_102: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_123, arg62_1);  mul_123 = arg62_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_265: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg63_1, 2);  arg63_1 = None
        permute_158: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_265, [2, 1, 0]);  unsqueeze_265 = None
        permute_160: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_158, [2, 1, 0]);  permute_158 = None
        view_164: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_160, [1, 128, 576]);  permute_160 = None
        bmm_39: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_158, view_164);  view_158 = view_164 = None
        view_165: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_39, [100, 1, 576]);  bmm_39 = None
        permute_161: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_165, [0, 2, 1]);  view_165 = None
        view_166: "f32[100, 576]" = torch.ops.aten.view.default(permute_161, [100, 576]);  permute_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_167: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_166, [100, 192, 3]);  view_166 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_266: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_25, -3);  cat_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_267: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_29, -2);  select_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_162: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_266, [0, 1, 2, 3])
        unsqueeze_268: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_167, 3);  view_167 = None
        permute_163: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_268, [0, 1, 3, 2]);  unsqueeze_268 = None
        permute_164: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_162, [0, 2, 3, 1]);  permute_162 = None
        view_168: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_164, [100, 3, 3]);  permute_164 = None
        permute_165: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_163, [0, 3, 1, 2]);  permute_163 = None
        view_169: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_165, [100, 3, 192]);  permute_165 = None
        bmm_40: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_168, view_169);  view_169 = None
        view_170: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_40, [100, 3, 1, 192]);  bmm_40 = None
        permute_166: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_170, [0, 3, 1, 2]);  view_170 = None
        view_171: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_166, [100, 192, 3]);  permute_166 = None
        add_103: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_171, unsqueeze_267);  view_171 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_172: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_103, [100, 8, 24, 3]);  add_103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_205: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_172, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_208: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_172, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_211: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_172, 2, 16, 9223372036854775807);  view_172 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_269: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_17, 3);  select_17 = None
        permute_167: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_269, [0, 1, 3, 2])
        unsqueeze_270: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg64_1, 2);  arg64_1 = None
        unsqueeze_271: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_270, 3);  unsqueeze_270 = None
        permute_168: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_271, [2, 3, 1, 0]);  unsqueeze_271 = None
        permute_169: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_167, [0, 1, 3, 2]);  permute_167 = None
        view_173: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_169, [1, 4800, 64]);  permute_169 = None
        permute_170: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_168, [3, 2, 0, 1]);  permute_168 = None
        view_174: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_170, [1, 64, 8]);  permute_170 = None
        bmm_41: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_173, view_174);  view_173 = view_174 = None
        view_175: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_41, [100, 48, 1, 8]);  bmm_41 = None
        permute_171: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_175, [0, 1, 3, 2]);  view_175 = None
        view_176: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_171, [100, 48, 8]);  permute_171 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_5: "f32[8]" = torch.ops.aten.exp.default(arg65_1)
        log1p_1: "f32[8]" = torch.ops.aten.log1p.default(exp_5);  exp_5 = None
        gt_1: "b8[8]" = torch.ops.aten.gt.Scalar(arg65_1, 20)
        where_45: "f32[8]" = torch.ops.aten.where.self(gt_1, arg65_1, log1p_1);  gt_1 = arg65_1 = log1p_1 = None
        view_177: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_45, [1, 1, 8]);  where_45 = None
        mul_124: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_177, 0.16666666666666666);  view_177 = None
        div_29: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_124, 2);  mul_124 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_272: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_205, 1);  slice_205 = None
        index_81: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_208, [select_16]);  slice_208 = None
        sub_78: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_272, index_81);  unsqueeze_272 = index_81 = None
        pow_7: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_78, 2);  sub_78 = None
        sum_37: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_7, [-1, -2]);  pow_7 = None
        mul_125: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_29, sum_37);  div_29 = sum_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_82: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_102, [select_16]);  add_102 = None
        unsqueeze_273: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_100, 3);  add_100 = None
        permute_172: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_273, [0, 3, 1, 2]);  unsqueeze_273 = None
        permute_173: "f32[100, 48, 8, 32]" = torch.ops.aten.permute.default(index_82, [0, 1, 2, 3]);  index_82 = None
        permute_174: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_172, [0, 2, 3, 1]);  permute_172 = None
        view_178: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_174, [800, 1, 32]);  permute_174 = None
        permute_175: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(permute_173, [0, 2, 3, 1]);  permute_173 = None
        clone_25: "f32[100, 8, 32, 48]" = torch.ops.aten.clone.default(permute_175, memory_format = torch.contiguous_format);  permute_175 = None
        view_179: "f32[800, 32, 48]" = torch.ops.aten.view.default(clone_25, [800, 32, 48]);  clone_25 = None
        bmm_42: "f32[800, 1, 48]" = torch.ops.aten.bmm.default(view_178, view_179);  view_178 = view_179 = None
        view_180: "f32[100, 8, 1, 48]" = torch.ops.aten.view.default(bmm_42, [100, 8, 1, 48]);  bmm_42 = None
        permute_176: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_180, [0, 3, 1, 2]);  view_180 = None
        view_181: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_176, [100, 48, 8]);  permute_176 = None
        mul_126: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(view_181, 0.1767766952966369);  view_181 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_104: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_126, view_176);  mul_126 = view_176 = None
        sub_79: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_104, mul_125);  add_104 = mul_125 = None
        mul_127: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_79, 0.5773502691896257);  sub_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_12: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_16, -1)
        bitwise_and_26: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_18, ne_12);  select_18 = ne_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_274: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_26, 2);  bitwise_and_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:120 in forward, code: torch.full_like(logits, -1e9))
        full_default_41: "f32[100, 48, 8]" = torch.ops.aten.full.default([100, 48, 8], -1000000000.0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        where_46: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_274, mul_127, full_default_41);  mul_127 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_26: "f32[100, 48, 8]" = torch.ops.aten.clone.default(where_46, memory_format = torch.contiguous_format);  where_46 = None
        amax_1: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_26, [-2], True)
        sub_80: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(clone_26, amax_1);  clone_26 = amax_1 = None
        exp_6: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_80);  sub_80 = None
        sum_38: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_6, [-2], True)
        div_30: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_6, sum_38);  exp_6 = sum_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        full_default_42: "f32[100, 48, 8]" = torch.ops.aten.full.default([100, 48, 8], 0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_47: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_274, div_30, full_default_42);  unsqueeze_274 = div_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_276: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_47, 3);  where_47 = None
        permute_177: "f32[100, 8, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_276, [0, 2, 3, 1])
        permute_178: "f32[100, 1, 64, 48]" = torch.ops.aten.permute.default(unsqueeze_269, [0, 3, 2, 1]);  unsqueeze_269 = None
        permute_179: "f32[100, 8, 48, 1]" = torch.ops.aten.permute.default(permute_177, [0, 1, 3, 2]);  permute_177 = None
        view_182: "f32[100, 8, 48]" = torch.ops.aten.view.default(permute_179, [100, 8, 48])
        permute_180: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_178, [0, 3, 2, 1]);  permute_178 = None
        view_183: "f32[100, 48, 64]" = torch.ops.aten.view.default(permute_180, [100, 48, 64]);  permute_180 = None
        bmm_43: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_182, view_183);  view_182 = view_183 = None
        view_184: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_43, [100, 8, 1, 64]);  bmm_43 = None
        permute_181: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_184, [0, 1, 3, 2]);  view_184 = None
        view_185: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_181, [100, 8, 64]);  permute_181 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_83: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_44, [select_16]);  getitem_44 = None
        permute_183: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(index_83, [0, 2, 3, 1]);  index_83 = None
        clone_27: "f32[100, 8, 48, 1]" = torch.ops.aten.clone.default(permute_179, memory_format = torch.contiguous_format);  permute_179 = None
        view_186: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_27, [800, 1, 48]);  clone_27 = None
        permute_185: "f32[100, 8, 48, 32]" = torch.ops.aten.permute.default(permute_183, [0, 1, 3, 2]);  permute_183 = None
        clone_28: "f32[100, 8, 48, 32]" = torch.ops.aten.clone.default(permute_185, memory_format = torch.contiguous_format);  permute_185 = None
        view_187: "f32[800, 48, 32]" = torch.ops.aten.view.default(clone_28, [800, 48, 32]);  clone_28 = None
        bmm_44: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_186, view_187);  view_186 = view_187 = None
        view_188: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_44, [100, 8, 1, 32]);  bmm_44 = None
        permute_186: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_188, [0, 1, 3, 2]);  view_188 = None
        view_189: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_186, [100, 8, 32]);  permute_186 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_84: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_211, [select_16]);  slice_211 = select_16 = None
        unsqueeze_280: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_276, 4);  unsqueeze_276 = None
        permute_187: "f32[100, 8, 1, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_280, [0, 2, 3, 4, 1]);  unsqueeze_280 = None
        permute_188: "f32[100, 8, 8, 3, 48]" = torch.ops.aten.permute.default(index_84, [0, 2, 3, 4, 1]);  index_84 = None
        permute_189: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.permute.default(permute_187, [0, 1, 4, 2, 3]);  permute_187 = None
        clone_29: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.clone.default(permute_189, memory_format = torch.contiguous_format);  permute_189 = None
        view_190: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_29, [800, 1, 48]);  clone_29 = None
        permute_190: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.permute.default(permute_188, [0, 1, 4, 2, 3]);  permute_188 = None
        clone_30: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.clone.default(permute_190, memory_format = torch.contiguous_format);  permute_190 = None
        view_191: "f32[800, 48, 24]" = torch.ops.aten.view.default(clone_30, [800, 48, 24]);  clone_30 = None
        bmm_45: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_190, view_191);  view_190 = view_191 = None
        view_192: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_45, [100, 8, 1, 8, 3]);  bmm_45 = None
        permute_191: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_192, [0, 1, 3, 4, 2]);  view_192 = None
        view_193: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_191, [100, 8, 8, 3]);  permute_191 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_283: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_266, -3);  unsqueeze_266 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_284: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_267, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_81: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_193, unsqueeze_284);  view_193 = None
        permute_192: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_283, [0, 1, 2, 4, 3]);  unsqueeze_283 = None
        unsqueeze_285: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_81, 4);  sub_81 = None
        permute_193: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_285, [0, 1, 2, 4, 3]);  unsqueeze_285 = None
        permute_194: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_192, [0, 3, 4, 1, 2]);  permute_192 = None
        view_194: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_194, [100, 3, 3]);  permute_194 = None
        permute_195: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_193, [0, 4, 1, 2, 3]);  permute_193 = None
        view_195: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_195, [100, 3, 64]);  permute_195 = None
        bmm_46: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_194, view_195);  view_195 = None
        view_196: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_46, [100, 3, 1, 8, 8]);  bmm_46 = None
        permute_196: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_196, [0, 3, 4, 1, 2]);  view_196 = None
        view_197: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_196, [100, 8, 8, 3]);  permute_196 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_128: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_197, view_197)
        sum_39: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_128, [-1]);  mul_128 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_28: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_39, 1e-12);  sum_39 = None
        sqrt_26: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_28);  clamp_min_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_198: "f32[100, 512]" = torch.ops.aten.view.default(view_185, [100, -1]);  view_185 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_199: "f32[100, 256]" = torch.ops.aten.view.default(view_189, [100, -1]);  view_189 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_31: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_197, memory_format = torch.contiguous_format);  view_197 = None
        view_200: "f32[100, 192]" = torch.ops.aten.view.default(clone_31, [100, 192]);  clone_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_201: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_26, [100, -1]);  sqrt_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_26: "f32[100, 1024]" = torch.ops.aten.cat.default([view_198, view_199, view_200, view_201], -1);  view_198 = view_199 = view_200 = view_201 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_286: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_26, 2);  cat_26 = None
        permute_197: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_286, [0, 2, 1]);  unsqueeze_286 = None
        unsqueeze_287: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg66_1, 2);  arg66_1 = None
        permute_198: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_287, [2, 1, 0]);  unsqueeze_287 = None
        permute_199: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_197, [0, 2, 1]);  permute_197 = None
        view_202: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_199, [1, 100, 1024]);  permute_199 = None
        permute_200: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_198, [2, 1, 0]);  permute_198 = None
        view_203: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_200, [1, 1024, 128]);  permute_200 = None
        bmm_47: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_202, view_203);  view_202 = view_203 = None
        view_204: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_47, [100, 1, 128]);  bmm_47 = None
        permute_201: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_204, [0, 2, 1]);  view_204 = None
        view_205: "f32[100, 128]" = torch.ops.aten.view.default(permute_201, [100, 128]);  permute_201 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_105: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_205, arg67_1);  view_205 = arg67_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_106: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_90, add_105);  add_90 = add_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_13: "f32[100, 1]" = torch.ops.aten.mean.dim(add_106, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_13: "f32[100, 1]" = torch.ops.aten.var.correction(add_106, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_82: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_106, mean_13);  mean_13 = None
        add_107: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_13, 1e-05);  var_13 = None
        rsqrt_13: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_107);  add_107 = None
        mul_129: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_82, rsqrt_13);  sub_82 = rsqrt_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_130: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_129, arg68_1);  mul_129 = arg68_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_108: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_130, arg69_1);  mul_130 = arg69_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_297: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_15, 2);  add_15 = None
        permute_207: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_297, [0, 2, 1]);  unsqueeze_297 = None
        unsqueeze_298: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg70_1, 2);  arg70_1 = None
        permute_208: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_298, [2, 1, 0]);  unsqueeze_298 = None
        permute_209: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_207, [0, 2, 1]);  permute_207 = None
        view_211: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_209, [1, 100, 128]);  permute_209 = None
        permute_210: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_208, [2, 1, 0]);  permute_208 = None
        view_212: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_210, [1, 128, 128]);  permute_210 = None
        bmm_49: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_211, view_212);  view_212 = None
        view_213: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_49, [100, 1, 128]);  bmm_49 = None
        permute_211: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_213, [0, 2, 1]);  view_213 = None
        view_214: "f32[100, 128]" = torch.ops.aten.view.default(permute_211, [100, 128]);  permute_211 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_113: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_108, view_214);  add_108 = view_214 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_299: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_4, 2);  view_4 = None
        permute_212: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_299, [0, 2, 1]);  unsqueeze_299 = None
        unsqueeze_300: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg71_1, 2);  arg71_1 = None
        permute_213: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_300, [2, 1, 0]);  unsqueeze_300 = None
        permute_214: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_212, [0, 2, 1]);  permute_212 = None
        view_215: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_214, [1, 100, 60]);  permute_214 = None
        permute_215: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_213, [2, 1, 0]);  permute_213 = None
        view_216: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_215, [1, 60, 256]);  permute_215 = None
        bmm_50: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_215, view_216);  view_215 = view_216 = None
        view_217: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_50, [100, 1, 256]);  bmm_50 = None
        permute_216: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_217, [0, 2, 1]);  view_217 = None
        view_218: "f32[100, 256]" = torch.ops.aten.view.default(permute_216, [100, 256]);  permute_216 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_114: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_218, arg72_1);  view_218 = arg72_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_137: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_114, add_114)
        mul_138: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_137, add_114);  mul_137 = None
        mul_139: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_138, 0.044715);  mul_138 = None
        add_115: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_114, mul_139);  mul_139 = None
        mul_140: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_115, 0.7978845608028654);  add_115 = None
        mul_141: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_114, 0.5);  add_114 = None
        tanh_3: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_140);  mul_140 = None
        add_116: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_3, 1);  tanh_3 = None
        mul_142: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_141, add_116);  mul_141 = add_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_301: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_142, 2);  mul_142 = None
        permute_217: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_301, [0, 2, 1]);  unsqueeze_301 = None
        unsqueeze_302: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg73_1, 2);  arg73_1 = None
        permute_218: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_302, [2, 1, 0]);  unsqueeze_302 = None
        permute_219: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_217, [0, 2, 1]);  permute_217 = None
        view_219: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_219, [1, 100, 256]);  permute_219 = None
        permute_220: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_218, [2, 1, 0]);  permute_218 = None
        view_220: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_220, [1, 256, 128]);  permute_220 = None
        bmm_51: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_219, view_220);  view_219 = view_220 = None
        view_221: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_51, [100, 1, 128]);  bmm_51 = None
        permute_221: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_221, [0, 2, 1]);  view_221 = None
        view_222: "f32[100, 128]" = torch.ops.aten.view.default(permute_221, [100, 128]);  permute_221 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_117: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_222, arg74_1);  view_222 = arg74_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_118: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_113, add_117);  add_113 = add_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_303: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_118, 2);  add_118 = None
        permute_222: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_303, [0, 2, 1]);  unsqueeze_303 = None
        unsqueeze_304: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg75_1, 2);  arg75_1 = None
        permute_223: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_304, [2, 1, 0]);  unsqueeze_304 = None
        permute_224: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_222, [0, 2, 1]);  permute_222 = None
        view_223: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_224, [1, 100, 128]);  permute_224 = None
        permute_225: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_223, [2, 1, 0]);  permute_223 = None
        view_224: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_225, [1, 128, 512]);  permute_225 = None
        bmm_52: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_223, view_224);  view_224 = None
        view_225: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_52, [100, 1, 512]);  bmm_52 = None
        permute_226: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_225, [0, 2, 1]);  view_225 = None
        view_226: "f32[100, 512]" = torch.ops.aten.view.default(permute_226, [100, 512]);  permute_226 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_306: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg76_1, 2);  arg76_1 = None
        permute_228: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_306, [2, 1, 0]);  unsqueeze_306 = None
        permute_230: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_228, [2, 1, 0]);  permute_228 = None
        view_228: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_230, [1, 128, 512]);  permute_230 = None
        bmm_53: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_223, view_228);  view_228 = None
        view_229: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_53, [100, 1, 512]);  bmm_53 = None
        permute_231: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_229, [0, 2, 1]);  view_229 = None
        view_230: "f32[100, 512]" = torch.ops.aten.view.default(permute_231, [100, 512]);  permute_231 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_143: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_230, view_230)
        mul_144: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_143, view_230);  mul_143 = None
        mul_145: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_144, 0.044715);  mul_144 = None
        add_119: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_230, mul_145);  mul_145 = None
        mul_146: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_119, 0.7978845608028654);  add_119 = None
        mul_147: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_230, 0.5);  view_230 = None
        tanh_4: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_146);  mul_146 = None
        add_120: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_4, 1);  tanh_4 = None
        mul_148: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_147, add_120);  mul_147 = add_120 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_149: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_148, view_226);  mul_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_308: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg77_1, 2);  arg77_1 = None
        permute_233: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_308, [2, 1, 0]);  unsqueeze_308 = None
        permute_235: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_233, [2, 1, 0]);  permute_233 = None
        view_232: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_235, [1, 128, 512]);  permute_235 = None
        bmm_54: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_223, view_232);  view_232 = None
        view_233: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_54, [100, 1, 512]);  bmm_54 = None
        permute_236: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_233, [0, 2, 1]);  view_233 = None
        view_234: "f32[100, 512]" = torch.ops.aten.view.default(permute_236, [100, 512]);  permute_236 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_150: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_234, view_234)
        mul_151: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_150, view_234);  mul_150 = None
        mul_152: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_151, 0.044715);  mul_151 = None
        add_121: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_234, mul_152);  mul_152 = None
        mul_153: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_121, 0.7978845608028654);  add_121 = None
        mul_154: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_234, 0.5);  view_234 = None
        tanh_5: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_153);  mul_153 = None
        add_122: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_5, 1);  tanh_5 = None
        mul_155: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_154, add_122);  mul_154 = add_122 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_310: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg78_1, 2);  arg78_1 = None
        permute_238: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_310, [2, 1, 0]);  unsqueeze_310 = None
        permute_240: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_238, [2, 1, 0]);  permute_238 = None
        view_236: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_240, [1, 128, 512]);  permute_240 = None
        bmm_55: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_223, view_236);  view_223 = view_236 = None
        view_237: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_55, [100, 1, 512]);  bmm_55 = None
        permute_241: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_237, [0, 2, 1]);  view_237 = None
        view_238: "f32[100, 512]" = torch.ops.aten.view.default(permute_241, [100, 512]);  permute_241 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_156: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_238, view_238)
        mul_157: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_156, view_238);  mul_156 = None
        mul_158: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_157, 0.044715);  mul_157 = None
        add_123: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_238, mul_158);  mul_158 = None
        mul_159: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_123, 0.7978845608028654);  add_123 = None
        mul_160: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_238, 0.5);  view_238 = None
        tanh_6: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_159);  mul_159 = None
        add_124: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_6, 1);  tanh_6 = None
        mul_161: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_160, add_124);  mul_160 = add_124 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_162: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_161, view_226);  mul_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:120 in index_mean, code: weight = torch.ones_like(data)
        full_default_43: "f32[100, 512]" = torch.ops.aten.full.default([100, 512], 1, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:72 in _normalise_index, code: valid = (index >= 0) & (index < size)
        ge_1: "b8[100]" = torch.ops.aten.ge.Scalar(arg14_1, 0)
        lt_10: "b8[100]" = torch.ops.aten.lt.Scalar(arg14_1, 100)
        bitwise_and_27: "b8[100]" = torch.ops.aten.bitwise_and.Tensor(ge_1, lt_10);  ge_1 = lt_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:73 in _normalise_index, code: return index.clamp(0, max(size - 1, 0)), valid
        clamp_min_31: "i64[100]" = torch.ops.aten.clamp_min.default(arg14_1, 0)
        clamp_max_2: "i64[100]" = torch.ops.aten.clamp_max.default(clamp_min_31, 99);  clamp_min_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        full_default_44: "f32[100, 512]" = torch.ops.aten.full.default([100, 512], 0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        where_48: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_162, full_default_44);  mul_162 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        view_239: "b8[100, 1]" = torch.ops.aten.view.default(bitwise_and_27, [-1, 1]);  bitwise_and_27 = None
        where_49: "f32[100, 512]" = torch.ops.aten.where.self(view_239, where_48, full_default_44);  where_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:87 in index_sum, code: idx = index.view(-1, *([1] * (data.dim() - 1))).expand_as(data)
        view_240: "i64[100, 1]" = torch.ops.aten.view.default(clamp_max_2, [-1, 1])
        expand_6: "i64[100, 512]" = torch.ops.aten.expand.default(view_240, [100, 512]);  view_240 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_6, where_49);  where_49 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_89: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add, [clamp_max_2]);  scatter_add = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_50: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, full_default_43, full_default_44);  full_default_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_51: "f32[100, 512]" = torch.ops.aten.where.self(view_239, where_50, full_default_44)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_1: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_6, where_51);  where_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_90: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_1, [clamp_max_2]);  scatter_add_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        clamp_min_33: "f32[100, 512]" = torch.ops.aten.clamp_min.default(index_90, 1e-06);  index_90 = None
        div_33: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_89, clamp_min_33);  index_89 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_52: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_33, full_default_44);  div_33 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_125: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_149, where_52);  mul_149 = where_52 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_164: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_155, view_226);  mul_155 = view_226 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:72 in _normalise_index, code: valid = (index >= 0) & (index < size)
        ge_3: "b8[100]" = torch.ops.aten.ge.Scalar(arg15_1, 0)
        lt_12: "b8[100]" = torch.ops.aten.lt.Scalar(arg15_1, 100)
        bitwise_and_29: "b8[100]" = torch.ops.aten.bitwise_and.Tensor(ge_3, lt_12);  ge_3 = lt_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:73 in _normalise_index, code: return index.clamp(0, max(size - 1, 0)), valid
        clamp_min_34: "i64[100]" = torch.ops.aten.clamp_min.default(arg15_1, 0)
        clamp_max_4: "i64[100]" = torch.ops.aten.clamp_max.default(clamp_min_34, 99);  clamp_min_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_53: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_164, full_default_44);  mul_164 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        view_243: "b8[100, 1]" = torch.ops.aten.view.default(bitwise_and_29, [-1, 1]);  bitwise_and_29 = None
        where_54: "f32[100, 512]" = torch.ops.aten.where.self(view_243, where_53, full_default_44);  where_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:87 in index_sum, code: idx = index.view(-1, *([1] * (data.dim() - 1))).expand_as(data)
        view_244: "i64[100, 1]" = torch.ops.aten.view.default(clamp_max_4, [-1, 1])
        expand_8: "i64[100, 512]" = torch.ops.aten.expand.default(view_244, [100, 512]);  view_244 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_2: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_8, where_54);  where_54 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_91: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_2, [clamp_max_4]);  scatter_add_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_56: "f32[100, 512]" = torch.ops.aten.where.self(view_243, where_50, full_default_44);  where_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_3: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_8, where_56);  where_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_92: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_3, [clamp_max_4]);  scatter_add_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        clamp_min_36: "f32[100, 512]" = torch.ops.aten.clamp_min.default(index_92, 1e-06);  index_92 = None
        div_34: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_91, clamp_min_36);  index_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_57: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_34, full_default_44);  div_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_126: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_125, where_57);  add_125 = where_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_312: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_126, 2);  add_126 = None
        permute_242: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_312, [0, 2, 1]);  unsqueeze_312 = None
        unsqueeze_313: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg79_1, 2);  arg79_1 = None
        permute_243: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_313, [2, 1, 0]);  unsqueeze_313 = None
        permute_244: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_242, [0, 2, 1]);  permute_242 = None
        view_247: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_244, [1, 100, 512]);  permute_244 = None
        permute_245: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_243, [2, 1, 0]);  permute_243 = None
        view_248: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_245, [1, 512, 128]);  permute_245 = None
        bmm_56: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_247, view_248);  view_247 = view_248 = None
        view_249: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_56, [100, 1, 128]);  bmm_56 = None
        permute_246: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_249, [0, 2, 1]);  view_249 = None
        view_250: "f32[100, 128]" = torch.ops.aten.view.default(permute_246, [100, 128]);  permute_246 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_127: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_250, arg80_1);  view_250 = arg80_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_128: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_106, add_127);  add_106 = add_127 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_14: "f32[100, 1]" = torch.ops.aten.mean.dim(add_128, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_14: "f32[100, 1]" = torch.ops.aten.var.correction(add_128, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_88: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_128, mean_14);  mean_14 = None
        add_129: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_14, 1e-05);  var_14 = None
        rsqrt_14: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_129);  add_129 = None
        mul_166: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_88, rsqrt_14);  sub_88 = rsqrt_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_167: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_166, arg81_1);  arg81_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_130: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_167, arg82_1);  mul_167 = arg82_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_323: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_130, 2);  add_130 = None
        permute_252: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_323, [0, 2, 1]);  unsqueeze_323 = None
        unsqueeze_324: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg83_1, 2);  arg83_1 = None
        permute_253: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_324, [2, 1, 0]);  unsqueeze_324 = None
        permute_254: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_252, [0, 2, 1]);  permute_252 = None
        view_255: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_254, [1, 100, 128]);  permute_254 = None
        permute_255: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_253, [2, 1, 0]);  permute_253 = None
        view_256: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_255, [1, 128, 60]);  permute_255 = None
        bmm_58: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_255, view_256);  view_255 = view_256 = None
        view_257: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_58, [100, 1, 60]);  bmm_58 = None
        permute_256: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_257, [0, 2, 1]);  view_257 = None
        view_258: "f32[100, 60]" = torch.ops.aten.view.default(permute_256, [100, 60]);  permute_256 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_174: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_258, 10.0);  view_258 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_259: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_174, [100, 20, 3]);  mul_174 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_135: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_3, view_259);  view_3 = view_259 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_257: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_6, [0, 1, 2, 3]);  unsqueeze_6 = None
        unsqueeze_327: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(add_135, 3);  add_135 = None
        permute_258: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_327, [0, 1, 3, 2]);  unsqueeze_327 = None
        permute_259: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_257, [0, 2, 3, 1]);  permute_257 = None
        view_260: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_259, [100, 3, 3]);  permute_259 = None
        permute_260: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_258, [0, 3, 1, 2]);  permute_258 = None
        view_261: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_260, [100, 3, 20]);  permute_260 = None
        bmm_59: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_260, view_261);  view_260 = view_261 = None
        view_262: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_59, [100, 3, 1, 20]);  bmm_59 = None
        permute_261: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_262, [0, 3, 1, 2]);  view_262 = None
        view_263: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_261, [100, 20, 3]);  permute_261 = None
        add_136: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_263, unsqueeze_7);  view_263 = unsqueeze_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_37: "f32[100, 3]" = torch.ops.aten.select.int(add_136, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_328: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_37, 1)
        unsqueeze_329: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_37, 0)
        sub_94: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_328, unsqueeze_329);  unsqueeze_328 = unsqueeze_329 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_175: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_94, sub_94);  sub_94 = None
        sum_46: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_175, [-1]);  mul_175 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_39: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_46, 1e-12);  sum_46 = None
        sqrt_31: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_39);  clamp_min_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_58: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_31, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_59: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_58, full_default);  where_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_98: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_59, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_60: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_98);  index_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_9: "f32[100, 100]" = torch.ops.aten.index_put.default(where_59, [unsqueeze_24, where_1], where_60);  where_59 = where_60 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_10 = torch.ops.aten.sort.stable(index_put_9, stable = True)
        getitem_46: "i64[100, 100]" = sort_10[1];  sort_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_239: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_46, 1, 0, 16);  getitem_46 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_99: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_9, [unsqueeze_24, slice_239]);  index_put_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_14: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_99, inf);  index_99 = None
        where_61: "i64[100, 16]" = torch.ops.aten.where.self(lt_14, slice_239, full_default_1);  lt_14 = slice_239 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_29: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_61], -1);  where_61 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_137: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_31, 1e-06);  sqrt_31 = None
        log_21: "f32[100, 100]" = torch.ops.aten.log.default(add_137);  add_137 = None
        mul_176: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_21, -3.0);  log_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_22: "f32[100, 100]" = torch.ops.aten.log.default(getitem_4)
        neg_17: "f32[100, 100]" = torch.ops.aten.neg.default(log_22);  log_22 = None
        log_23: "f32[100, 100]" = torch.ops.aten.log.default(neg_17);  neg_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_95: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_176, log_23);  mul_176 = log_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_18: "f32[100, 100]" = torch.ops.aten.neg.default(sub_95);  sub_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_62: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_18, full_default);  neg_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_63: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_62, full_default);  where_62 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_14: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_29, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_101: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_63, [unsqueeze_24, cat_29])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_64: "f32[100, 32]" = torch.ops.aten.where.self(ne_14, full_default_7, index_101);  ne_14 = index_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_10: "f32[100, 100]" = torch.ops.aten.index_put.default(where_63, [unsqueeze_24, cat_29], where_64);  where_63 = where_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_11 = torch.ops.aten.sort.stable(index_put_10, stable = True)
        getitem_48: "i64[100, 100]" = sort_11[1];  sort_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_248: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_48, 1, 0, 32);  getitem_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_102: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_10, [unsqueeze_24, slice_248]);  index_put_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_15: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_102, inf);  index_102 = None
        where_65: "i64[100, 32]" = torch.ops.aten.where.self(lt_15, slice_248, full_default_37);  lt_15 = slice_248 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_30: "i64[100, 64]" = torch.ops.aten.cat.default([cat_29, where_65], -1);  cat_29 = where_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_38: "i64[100, 48]" = torch.ops.aten.select.int(view_14, 0, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_39: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_52, 0, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_40: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_103: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_30])
        bitwise_and_35: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_103);  index_103 = None
        ne_15: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_30, -1)
        bitwise_and_36: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_35, ne_15);  bitwise_and_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_104: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_30])
        eq_17: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_104);  index_104 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_105: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_30])
        eq_18: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_105);  index_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_106: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_30])
        sub_96: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_106);  index_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_40: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_96, -32);  sub_96 = None
        clamp_max_6: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_40, 32);  clamp_min_40 = None
        add_138: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_6, 32);  clamp_max_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_66: "i64[100, 64]" = torch.ops.aten.where.self(eq_17, add_138, full_default_38);  eq_17 = add_138 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_67: "i64[100, 64]" = torch.ops.aten.where.self(eq_18, where_66, full_default_38);  eq_18 = where_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_107: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg84_1, [where_67]);  arg84_1 = where_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_350: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_136, 1)
        slice_255: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_350, 2, 0, 5)
        unsqueeze_351: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_255, 3);  slice_255 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_108: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_136, [cat_30])
        unsqueeze_352: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_108, 2)
        slice_259: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_352, 3, 0, 5);  unsqueeze_352 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_97: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_351, slice_259);  unsqueeze_351 = slice_259 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_177: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_97, sub_97);  sub_97 = None
        sum_47: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_177, [-1]);  mul_177 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_41: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_47, 1e-12);  sum_47 = None
        sqrt_32: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_41);  clamp_min_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_264: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_32, [100, 64, 25]);  sqrt_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_353: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_264, 3);  view_264 = None
        sub_98: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_353, add_29);  unsqueeze_353 = None
        pow_8: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_98, 2);  sub_98 = None
        neg_19: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_8);  pow_8 = None
        div_37: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_19, 1.890625);  neg_19 = None
        exp_7: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_37);  div_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_265: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_7, [100, 64, 400]);  exp_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_354: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_265, 3);  view_265 = None
        permute_262: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_354, [0, 1, 3, 2]);  unsqueeze_354 = None
        unsqueeze_355: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg85_1, 2);  arg85_1 = None
        unsqueeze_356: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_355, 3);  unsqueeze_355 = None
        permute_263: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_356, [2, 3, 1, 0]);  unsqueeze_356 = None
        permute_264: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_262, [0, 1, 3, 2]);  permute_262 = None
        view_266: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_264, [1, 6400, 400]);  permute_264 = None
        permute_265: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_263, [3, 2, 0, 1]);  permute_263 = None
        view_267: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_265, [1, 400, 64]);  permute_265 = None
        bmm_60: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_266, view_267);  view_266 = view_267 = None
        view_268: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_60, [100, 64, 1, 64]);  bmm_60 = None
        permute_266: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_268, [0, 1, 3, 2]);  view_268 = None
        view_269: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_266, [100, 64, 64]);  permute_266 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_142: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_107, view_269);  index_107 = view_269 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_41: "f32[100, 3]" = torch.ops.aten.select.int(add_136, 1, 0)
        select_43: "f32[100, 3]" = torch.ops.aten.select.int(add_136, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_99: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_43, select_37);  select_43 = None
        sub_100: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_41, select_37);  select_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_180: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_99, sub_99)
        sum_48: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_180, [-1]);  mul_180 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_42: "f32[100]" = torch.ops.aten.clamp_min.default(sum_48, 1e-12);  sum_48 = None
        sqrt_33: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_42);  clamp_min_42 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_357: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_33, -1);  sqrt_33 = None
        div_38: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_99, unsqueeze_357);  sub_99 = unsqueeze_357 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_181: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_100, div_38)
        sum_49: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_181, [-1]);  mul_181 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_358: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_49, -1);  sum_49 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_182: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_358, div_38);  unsqueeze_358 = None
        sub_101: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_100, mul_182);  sub_100 = mul_182 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_183: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_101, sub_101)
        sum_50: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_183, [-1]);  mul_183 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_43: "f32[100]" = torch.ops.aten.clamp_min.default(sum_50, 1e-12);  sum_50 = None
        sqrt_34: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_43);  clamp_min_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_359: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_34, -1);  sqrt_34 = None
        div_39: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_101, unsqueeze_359);  sub_101 = unsqueeze_359 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_109: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_38, [None, remainder])
        index_110: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_39, [None, remainder_1])
        mul_184: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_109, index_110);  index_109 = index_110 = None
        index_111: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_38, [None, remainder_1])
        index_112: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_39, [None, remainder])
        mul_185: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_111, index_112);  index_111 = index_112 = None
        sub_102: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_184, mul_185);  mul_184 = mul_185 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_360: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_38, 2);  div_38 = None
        unsqueeze_361: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_39, 2);  div_39 = None
        unsqueeze_362: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_102, 2);  sub_102 = None
        cat_31: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_360, unsqueeze_361, unsqueeze_362], -1);  unsqueeze_360 = unsqueeze_361 = unsqueeze_362 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_366: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_31, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_367: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_37, -2);  select_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_368: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_366, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_369: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_367, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_104: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_108, unsqueeze_369)
        permute_272: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_368, [0, 1, 2, 4, 3]);  unsqueeze_368 = None
        unsqueeze_370: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_104, 4);  sub_104 = None
        permute_273: "f32[100, 64, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_370, [0, 1, 2, 4, 3]);  unsqueeze_370 = None
        permute_274: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_272, [0, 3, 4, 1, 2]);  permute_272 = None
        view_274: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_274, [100, 3, 3]);  permute_274 = None
        permute_275: "f32[100, 3, 64, 20, 1]" = torch.ops.aten.permute.default(permute_273, [0, 4, 1, 2, 3]);  permute_273 = None
        view_275: "f32[100, 3, 1280]" = torch.ops.aten.view.default(permute_275, [100, 3, 1280]);  permute_275 = None
        bmm_62: "f32[100, 3, 1280]" = torch.ops.aten.bmm.default(view_274, view_275);  view_275 = None
        view_276: "f32[100, 3, 1, 64, 20]" = torch.ops.aten.view.default(bmm_62, [100, 3, 1, 64, 20]);  bmm_62 = None
        permute_276: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.permute.default(view_276, [0, 3, 4, 1, 2]);  view_276 = None
        view_277: "f32[100, 64, 20, 3]" = torch.ops.aten.view.default(permute_276, [100, 64, 20, 3]);  permute_276 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_186: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(view_277, view_277)
        sum_51: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_186, [-1]);  mul_186 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_44: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_51, 1e-12);  sum_51 = None
        sqrt_35: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_44);  clamp_min_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_371: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_35, -1);  sqrt_35 = None
        div_40: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(view_277, unsqueeze_371);  view_277 = unsqueeze_371 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        clone_35: "f32[100, 64, 20, 3]" = torch.ops.aten.clone.default(div_40, memory_format = torch.contiguous_format);  div_40 = None
        view_278: "f32[100, 64, 60]" = torch.ops.aten.view.default(clone_35, [100, 64, 60]);  clone_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_10: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_350, [100, 64, 20, 3]);  unsqueeze_350 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_32: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_10, index_108], -2);  expand_10 = index_108 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_105: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_32, unsqueeze_369);  cat_32 = unsqueeze_369 = None
        unsqueeze_377: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_105, 4);  sub_105 = None
        permute_278: "f32[100, 64, 40, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_377, [0, 1, 2, 4, 3]);  unsqueeze_377 = None
        permute_280: "f32[100, 3, 64, 40, 1]" = torch.ops.aten.permute.default(permute_278, [0, 4, 1, 2, 3]);  permute_278 = None
        view_280: "f32[100, 3, 2560]" = torch.ops.aten.view.default(permute_280, [100, 3, 2560]);  permute_280 = None
        bmm_63: "f32[100, 3, 2560]" = torch.ops.aten.bmm.default(view_274, view_280);  view_274 = view_280 = None
        view_281: "f32[100, 3, 1, 64, 40]" = torch.ops.aten.view.default(bmm_63, [100, 3, 1, 64, 40]);  bmm_63 = None
        permute_281: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.permute.default(view_281, [0, 3, 4, 1, 2]);  view_281 = None
        view_282: "f32[100, 64, 40, 3]" = torch.ops.aten.view.default(permute_281, [100, 64, 40, 3]);  permute_281 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_187: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_282, view_282)
        sum_52: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_187, [-1]);  mul_187 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_45: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_52, 1e-12);  sum_52 = None
        sqrt_36: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_45);  clamp_min_45 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_378: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_36, -1);  sqrt_36 = None
        div_41: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(view_282, unsqueeze_378);  unsqueeze_378 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        clone_36: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(div_41, memory_format = torch.contiguous_format);  div_41 = None
        view_283: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_36, [100, 64, 120]);  clone_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_188: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_282, 0.1);  view_282 = None
        clone_37: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(mul_188, memory_format = torch.contiguous_format);  mul_188 = None
        view_284: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_37, [100, 64, 120]);  clone_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_33: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_283, view_284], -1);  view_283 = view_284 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_379: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_278, 3);  view_278 = None
        permute_282: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_379, [0, 1, 3, 2]);  unsqueeze_379 = None
        unsqueeze_380: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg86_1, 2);  arg86_1 = None
        unsqueeze_381: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_380, 3);  unsqueeze_380 = None
        permute_283: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_381, [2, 3, 1, 0]);  unsqueeze_381 = None
        permute_284: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_282, [0, 1, 3, 2]);  permute_282 = None
        view_285: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_284, [1, 6400, 60]);  permute_284 = None
        permute_285: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_283, [3, 2, 0, 1]);  permute_283 = None
        view_286: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_285, [1, 60, 64]);  permute_285 = None
        bmm_64: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_285, view_286);  view_285 = view_286 = None
        view_287: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_64, [100, 64, 1, 64]);  bmm_64 = None
        permute_286: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_287, [0, 1, 3, 2]);  view_287 = None
        view_288: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_286, [100, 64, 64]);  permute_286 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_147: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_142, view_288);  add_142 = view_288 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_391: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_31, 1)
        permute_292: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_391, [0, 1, 3, 2]);  unsqueeze_391 = None
        index_118: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_31, [cat_30]);  cat_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:78 in rot_compose, code: return a @ b
        expand_11: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(permute_292, [100, 64, 3, 3]);  permute_292 = None
        clone_38: "f32[100, 64, 3, 3]" = torch.ops.aten.clone.default(expand_11, memory_format = torch.contiguous_format);  expand_11 = None
        view_293: "f32[6400, 3, 3]" = torch.ops.aten.view.default(clone_38, [6400, 3, 3]);  clone_38 = None
        expand_12: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(index_118, [100, 64, 3, 3]);  index_118 = None
        view_294: "f32[6400, 3, 3]" = torch.ops.aten.view.default(expand_12, [6400, 3, 3]);  expand_12 = None
        bmm_66: "f32[6400, 3, 3]" = torch.ops.aten.bmm.default(view_293, view_294);  view_293 = view_294 = None
        view_295: "f32[100, 64, 3, 3]" = torch.ops.aten.view.default(bmm_66, [100, 64, 3, 3]);  bmm_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_296: "f32[100, 64, 9]" = torch.ops.aten.view.default(view_295, [100, 64, 9]);  view_295 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_392: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_296, 3);  view_296 = None
        permute_293: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_392, [0, 1, 3, 2]);  unsqueeze_392 = None
        unsqueeze_393: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg87_1, 2);  arg87_1 = None
        unsqueeze_394: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_393, 3);  unsqueeze_393 = None
        permute_294: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_394, [2, 3, 1, 0]);  unsqueeze_394 = None
        permute_295: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_293, [0, 1, 3, 2]);  permute_293 = None
        view_297: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_295, [1, 6400, 9]);  permute_295 = None
        permute_296: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_294, [3, 2, 0, 1]);  permute_294 = None
        view_298: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_296, [1, 9, 64]);  permute_296 = None
        bmm_67: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_297, view_298);  view_297 = view_298 = None
        view_299: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_67, [100, 64, 1, 64]);  bmm_67 = None
        permute_297: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_299, [0, 1, 3, 2]);  view_299 = None
        view_300: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_297, [100, 64, 64]);  permute_297 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_152: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_147, view_300);  add_147 = view_300 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_395: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_33, 3);  cat_33 = None
        permute_298: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_395, [0, 1, 3, 2]);  unsqueeze_395 = None
        unsqueeze_396: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg88_1, 2);  arg88_1 = None
        unsqueeze_397: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_396, 3);  unsqueeze_396 = None
        permute_299: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_397, [2, 3, 1, 0]);  unsqueeze_397 = None
        permute_300: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_298, [0, 1, 3, 2]);  permute_298 = None
        view_301: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_300, [1, 6400, 240]);  permute_300 = None
        permute_301: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_299, [3, 2, 0, 1]);  permute_299 = None
        view_302: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_301, [1, 240, 64]);  permute_301 = None
        bmm_68: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_301, view_302);  view_301 = view_302 = None
        view_303: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_68, [100, 64, 1, 64]);  bmm_68 = None
        permute_302: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_303, [0, 1, 3, 2]);  view_303 = None
        view_304: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_302, [100, 64, 64]);  permute_302 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_153: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_152, view_304);  add_152 = view_304 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_15: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_153, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_15: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_153, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_111: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_153, mean_15);  add_153 = mean_15 = None
        add_154: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_15, 1e-05);  var_15 = None
        rsqrt_15: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_154);  add_154 = None
        mul_195: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_111, rsqrt_15);  sub_111 = rsqrt_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_196: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_195, arg89_1);  mul_195 = arg89_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_155: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_196, arg90_1);  mul_196 = arg90_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_398: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_155, 3);  add_155 = None
        permute_303: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_398, [0, 1, 3, 2]);  unsqueeze_398 = None
        unsqueeze_399: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg91_1, 2);  arg91_1 = None
        unsqueeze_400: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_399, 3);  unsqueeze_399 = None
        permute_304: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_400, [2, 3, 1, 0]);  unsqueeze_400 = None
        permute_305: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_303, [0, 1, 3, 2]);  permute_303 = None
        view_305: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_305, [1, 6400, 64]);  permute_305 = None
        permute_306: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_304, [3, 2, 0, 1]);  permute_304 = None
        view_306: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_306, [1, 64, 128]);  permute_306 = None
        bmm_69: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_305, view_306);  view_305 = view_306 = None
        view_307: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_69, [100, 64, 1, 128]);  bmm_69 = None
        permute_307: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_307, [0, 1, 3, 2]);  view_307 = None
        view_308: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_307, [100, 64, 128]);  permute_307 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_156: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_308, arg92_1);  view_308 = arg92_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_197: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_156, add_156)
        mul_198: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_197, add_156);  mul_197 = None
        mul_199: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_198, 0.044715);  mul_198 = None
        add_157: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_156, mul_199);  mul_199 = None
        mul_200: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_157, 0.7978845608028654);  add_157 = None
        mul_201: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_156, 0.5);  add_156 = None
        tanh_7: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_200);  mul_200 = None
        add_158: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_7, 1);  tanh_7 = None
        mul_202: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_201, add_158);  mul_201 = add_158 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_401: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_202, 3);  mul_202 = None
        permute_308: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_401, [0, 1, 3, 2]);  unsqueeze_401 = None
        unsqueeze_402: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg93_1, 2);  arg93_1 = None
        unsqueeze_403: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_402, 3);  unsqueeze_402 = None
        permute_309: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_403, [2, 3, 1, 0]);  unsqueeze_403 = None
        permute_310: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_308, [0, 1, 3, 2]);  permute_308 = None
        view_309: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_310, [1, 6400, 128]);  permute_310 = None
        permute_311: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_309, [3, 2, 0, 1]);  permute_309 = None
        view_310: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_311, [1, 128, 64]);  permute_311 = None
        bmm_70: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_309, view_310);  view_309 = view_310 = None
        view_311: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_70, [100, 64, 1, 64]);  bmm_70 = None
        permute_312: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_311, [0, 1, 3, 2]);  view_311 = None
        view_312: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_312, [100, 64, 64]);  permute_312 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_159: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_312, arg94_1);  view_312 = arg94_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_204: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_166, arg95_1);  mul_166 = arg95_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_161: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_204, arg96_1);  mul_204 = arg96_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_44: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_136, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_47: "f32[100, 3]" = torch.ops.aten.select.int(div_44, 1, 0)
        select_48: "f32[100, 3]" = torch.ops.aten.select.int(div_44, 1, 1)
        select_49: "f32[100, 3]" = torch.ops.aten.select.int(div_44, 1, 2);  div_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_113: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_49, select_48);  select_49 = None
        sub_114: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_47, select_48);  select_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_205: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_113, sub_113)
        sum_56: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_205, [-1]);  mul_205 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_48: "f32[100]" = torch.ops.aten.clamp_min.default(sum_56, 1e-12);  sum_56 = None
        sqrt_39: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_48);  clamp_min_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_404: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_39, -1);  sqrt_39 = None
        div_45: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_113, unsqueeze_404);  sub_113 = unsqueeze_404 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_206: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_114, div_45)
        sum_57: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_206, [-1]);  mul_206 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_405: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_57, -1);  sum_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_207: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_405, div_45);  unsqueeze_405 = None
        sub_115: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_114, mul_207);  sub_114 = mul_207 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_208: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_115, sub_115)
        sum_58: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_208, [-1]);  mul_208 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_49: "f32[100]" = torch.ops.aten.clamp_min.default(sum_58, 1e-12);  sum_58 = None
        sqrt_40: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_49);  clamp_min_49 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_406: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_40, -1);  sqrt_40 = None
        div_46: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_115, unsqueeze_406);  sub_115 = unsqueeze_406 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_119: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_45, [None, remainder])
        index_120: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_46, [None, remainder_1])
        mul_209: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_119, index_120);  index_119 = index_120 = None
        index_121: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_45, [None, remainder_1])
        index_122: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_46, [None, remainder])
        mul_210: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_121, index_122);  index_121 = index_122 = None
        sub_116: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_209, mul_210);  mul_209 = mul_210 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_407: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_45, 2);  div_45 = None
        unsqueeze_408: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_46, 2);  div_46 = None
        unsqueeze_409: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_116, 2);  sub_116 = None
        cat_35: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_407, unsqueeze_408, unsqueeze_409], -1);  unsqueeze_407 = unsqueeze_408 = unsqueeze_409 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_17: "f32[100, 1]" = torch.ops.aten.mean.dim(add_161, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_17: "f32[100, 1]" = torch.ops.aten.var.correction(add_161, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_118: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_161, mean_17);  add_161 = mean_17 = None
        add_166: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_17, 1e-05);  var_17 = None
        rsqrt_17: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_166);  add_166 = None
        mul_211: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_118, rsqrt_17);  sub_118 = rsqrt_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_212: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_211, arg97_1);  mul_211 = arg97_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_167: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_212, arg98_1);  mul_212 = arg98_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_413: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_167, 2);  add_167 = None
        permute_318: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_413, [0, 2, 1]);  unsqueeze_413 = None
        unsqueeze_414: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg99_1, 2);  arg99_1 = None
        permute_319: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_414, [2, 1, 0]);  unsqueeze_414 = None
        permute_320: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_318, [0, 2, 1]);  permute_318 = None
        view_317: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_320, [1, 100, 128]);  permute_320 = None
        permute_321: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_319, [2, 1, 0]);  permute_319 = None
        view_318: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_321, [1, 128, 768]);  permute_321 = None
        bmm_72: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_317, view_318);  view_318 = None
        view_319: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_72, [100, 1, 768]);  bmm_72 = None
        permute_322: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_319, [0, 2, 1]);  view_319 = None
        view_320: "f32[100, 768]" = torch.ops.aten.view.default(permute_322, [100, 768]);  permute_322 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_321: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_320, [100, 8, 96]);  view_320 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_2 = torch.ops.aten.split.Tensor(view_321, 32, -1);  view_321 = None
        getitem_49: "f32[100, 8, 32]" = split_2[0]
        getitem_50: "f32[100, 8, 32]" = split_2[1]
        getitem_51: "f32[100, 8, 32]" = split_2[2];  split_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_18: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_49, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_18: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_49, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_119: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_49, mean_18);  getitem_49 = mean_18 = None
        add_168: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_18, 1e-05);  var_18 = None
        rsqrt_18: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_168);  add_168 = None
        mul_213: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_119, rsqrt_18);  sub_119 = rsqrt_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_214: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_213, arg100_1);  mul_213 = arg100_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_169: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_214, arg101_1);  mul_214 = arg101_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_19: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_50, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_19: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_50, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_120: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_50, mean_19);  getitem_50 = mean_19 = None
        add_170: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_19, 1e-05);  var_19 = None
        rsqrt_19: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_170);  add_170 = None
        mul_215: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_120, rsqrt_19);  sub_120 = rsqrt_19 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_216: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_215, arg102_1);  mul_215 = arg102_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_171: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_216, arg103_1);  mul_216 = arg103_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_416: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg104_1, 2);  arg104_1 = None
        permute_324: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_416, [2, 1, 0]);  unsqueeze_416 = None
        permute_326: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_324, [2, 1, 0]);  permute_324 = None
        view_323: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_326, [1, 128, 576]);  permute_326 = None
        bmm_73: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_317, view_323);  view_317 = view_323 = None
        view_324: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_73, [100, 1, 576]);  bmm_73 = None
        permute_327: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_324, [0, 2, 1]);  view_324 = None
        view_325: "f32[100, 576]" = torch.ops.aten.view.default(permute_327, [100, 576]);  permute_327 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_326: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_325, [100, 192, 3]);  view_325 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_417: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_35, -3);  cat_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_418: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_48, -2);  select_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_328: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_417, [0, 1, 2, 3])
        unsqueeze_419: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_326, 3);  view_326 = None
        permute_329: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_419, [0, 1, 3, 2]);  unsqueeze_419 = None
        permute_330: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_328, [0, 2, 3, 1]);  permute_328 = None
        view_327: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_330, [100, 3, 3]);  permute_330 = None
        permute_331: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_329, [0, 3, 1, 2]);  permute_329 = None
        view_328: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_331, [100, 3, 192]);  permute_331 = None
        bmm_74: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_327, view_328);  view_327 = view_328 = None
        view_329: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_74, [100, 3, 1, 192]);  bmm_74 = None
        permute_332: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_329, [0, 3, 1, 2]);  view_329 = None
        view_330: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_332, [100, 192, 3]);  permute_332 = None
        add_172: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_330, unsqueeze_418);  view_330 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_331: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_172, [100, 8, 24, 3]);  add_172 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_286: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_331, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_289: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_331, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_292: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_331, 2, 16, 9223372036854775807);  view_331 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_420: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_159, 3);  add_159 = None
        permute_333: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_420, [0, 1, 3, 2])
        unsqueeze_421: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg105_1, 2);  arg105_1 = None
        unsqueeze_422: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_421, 3);  unsqueeze_421 = None
        permute_334: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_422, [2, 3, 1, 0]);  unsqueeze_422 = None
        permute_335: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_333, [0, 1, 3, 2]);  permute_333 = None
        view_332: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_335, [1, 6400, 64]);  permute_335 = None
        permute_336: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_334, [3, 2, 0, 1]);  permute_334 = None
        view_333: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_336, [1, 64, 8]);  permute_336 = None
        bmm_75: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_332, view_333);  view_332 = view_333 = None
        view_334: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_75, [100, 64, 1, 8]);  bmm_75 = None
        permute_337: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_334, [0, 1, 3, 2]);  view_334 = None
        view_335: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_337, [100, 64, 8]);  permute_337 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_8: "f32[8]" = torch.ops.aten.exp.default(arg106_1)
        log1p_2: "f32[8]" = torch.ops.aten.log1p.default(exp_8);  exp_8 = None
        gt_2: "b8[8]" = torch.ops.aten.gt.Scalar(arg106_1, 20)
        where_68: "f32[8]" = torch.ops.aten.where.self(gt_2, arg106_1, log1p_2);  gt_2 = arg106_1 = log1p_2 = None
        view_336: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_68, [1, 1, 8]);  where_68 = None
        mul_217: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_336, 0.16666666666666666);  view_336 = None
        div_47: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_217, 2);  mul_217 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_423: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_286, 1);  slice_286 = None
        index_123: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_289, [cat_30]);  slice_289 = None
        sub_121: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_423, index_123);  unsqueeze_423 = index_123 = None
        pow_9: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_121, 2);  sub_121 = None
        sum_59: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_9, [-1, -2]);  pow_9 = None
        mul_218: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_47, sum_59);  div_47 = sum_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_124: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_171, [cat_30]);  add_171 = None
        unsqueeze_424: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_169, 3);  add_169 = None
        permute_338: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_424, [0, 3, 1, 2]);  unsqueeze_424 = None
        permute_339: "f32[100, 64, 8, 32]" = torch.ops.aten.permute.default(index_124, [0, 1, 2, 3]);  index_124 = None
        permute_340: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_338, [0, 2, 3, 1]);  permute_338 = None
        view_337: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_340, [800, 1, 32]);  permute_340 = None
        permute_341: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(permute_339, [0, 2, 3, 1]);  permute_339 = None
        clone_39: "f32[100, 8, 32, 64]" = torch.ops.aten.clone.default(permute_341, memory_format = torch.contiguous_format);  permute_341 = None
        view_338: "f32[800, 32, 64]" = torch.ops.aten.view.default(clone_39, [800, 32, 64]);  clone_39 = None
        bmm_76: "f32[800, 1, 64]" = torch.ops.aten.bmm.default(view_337, view_338);  view_337 = view_338 = None
        view_339: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_76, [100, 8, 1, 64]);  bmm_76 = None
        permute_342: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_339, [0, 3, 1, 2]);  view_339 = None
        view_340: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_342, [100, 64, 8]);  permute_342 = None
        mul_219: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(view_340, 0.1767766952966369);  view_340 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_173: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_219, view_335);  mul_219 = view_335 = None
        sub_122: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_173, mul_218);  add_173 = mul_218 = None
        mul_220: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_122, 0.5773502691896257);  sub_122 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_37: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_36, ne_15);  bitwise_and_36 = ne_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_425: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_37, 2);  bitwise_and_37 = None
        where_69: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_425, mul_220, full_default_39);  mul_220 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_40: "f32[100, 64, 8]" = torch.ops.aten.clone.default(where_69, memory_format = torch.contiguous_format);  where_69 = None
        amax_2: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_40, [-2], True)
        sub_123: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(clone_40, amax_2);  clone_40 = amax_2 = None
        exp_9: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_123);  sub_123 = None
        sum_60: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_9, [-2], True)
        div_48: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_9, sum_60);  exp_9 = sum_60 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_70: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_425, div_48, full_default_40);  unsqueeze_425 = div_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_427: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_70, 3);  where_70 = None
        permute_343: "f32[100, 8, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_427, [0, 2, 3, 1])
        permute_344: "f32[100, 1, 64, 64]" = torch.ops.aten.permute.default(unsqueeze_420, [0, 3, 2, 1]);  unsqueeze_420 = None
        permute_345: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(permute_343, [0, 1, 3, 2]);  permute_343 = None
        view_341: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_345, [100, 8, 64])
        permute_346: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_344, [0, 3, 2, 1]);  permute_344 = None
        view_342: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_346, [100, 64, 64]);  permute_346 = None
        bmm_77: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_341, view_342);  view_341 = view_342 = None
        view_343: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_77, [100, 8, 1, 64]);  bmm_77 = None
        permute_347: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_343, [0, 1, 3, 2]);  view_343 = None
        view_344: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_347, [100, 8, 64]);  permute_347 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_125: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_51, [cat_30]);  getitem_51 = None
        permute_349: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(index_125, [0, 2, 3, 1]);  index_125 = None
        clone_41: "f32[100, 8, 64, 1]" = torch.ops.aten.clone.default(permute_345, memory_format = torch.contiguous_format);  permute_345 = None
        view_345: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_41, [800, 1, 64]);  clone_41 = None
        permute_351: "f32[100, 8, 64, 32]" = torch.ops.aten.permute.default(permute_349, [0, 1, 3, 2]);  permute_349 = None
        clone_42: "f32[100, 8, 64, 32]" = torch.ops.aten.clone.default(permute_351, memory_format = torch.contiguous_format);  permute_351 = None
        view_346: "f32[800, 64, 32]" = torch.ops.aten.view.default(clone_42, [800, 64, 32]);  clone_42 = None
        bmm_78: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_345, view_346);  view_345 = view_346 = None
        view_347: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_78, [100, 8, 1, 32]);  bmm_78 = None
        permute_352: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_347, [0, 1, 3, 2]);  view_347 = None
        view_348: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_352, [100, 8, 32]);  permute_352 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_126: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_292, [cat_30]);  slice_292 = cat_30 = None
        unsqueeze_431: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_427, 4);  unsqueeze_427 = None
        permute_353: "f32[100, 8, 1, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_431, [0, 2, 3, 4, 1]);  unsqueeze_431 = None
        permute_354: "f32[100, 8, 8, 3, 64]" = torch.ops.aten.permute.default(index_126, [0, 2, 3, 4, 1]);  index_126 = None
        permute_355: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.permute.default(permute_353, [0, 1, 4, 2, 3]);  permute_353 = None
        clone_43: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.clone.default(permute_355, memory_format = torch.contiguous_format);  permute_355 = None
        view_349: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_43, [800, 1, 64]);  clone_43 = None
        permute_356: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.permute.default(permute_354, [0, 1, 4, 2, 3]);  permute_354 = None
        clone_44: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.clone.default(permute_356, memory_format = torch.contiguous_format);  permute_356 = None
        view_350: "f32[800, 64, 24]" = torch.ops.aten.view.default(clone_44, [800, 64, 24]);  clone_44 = None
        bmm_79: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_349, view_350);  view_349 = view_350 = None
        view_351: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_79, [100, 8, 1, 8, 3]);  bmm_79 = None
        permute_357: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_351, [0, 1, 3, 4, 2]);  view_351 = None
        view_352: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_357, [100, 8, 8, 3]);  permute_357 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_434: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_417, -3);  unsqueeze_417 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_435: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_418, -2);  unsqueeze_418 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_124: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_352, unsqueeze_435);  view_352 = unsqueeze_435 = None
        permute_358: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_434, [0, 1, 2, 4, 3]);  unsqueeze_434 = None
        unsqueeze_436: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_124, 4);  sub_124 = None
        permute_359: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_436, [0, 1, 2, 4, 3]);  unsqueeze_436 = None
        permute_360: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_358, [0, 3, 4, 1, 2]);  permute_358 = None
        view_353: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_360, [100, 3, 3]);  permute_360 = None
        permute_361: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_359, [0, 4, 1, 2, 3]);  permute_359 = None
        view_354: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_361, [100, 3, 64]);  permute_361 = None
        bmm_80: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_353, view_354);  view_353 = view_354 = None
        view_355: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_80, [100, 3, 1, 8, 8]);  bmm_80 = None
        permute_362: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_355, [0, 3, 4, 1, 2]);  view_355 = None
        view_356: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_362, [100, 8, 8, 3]);  permute_362 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_221: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_356, view_356)
        sum_61: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_221, [-1]);  mul_221 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_50: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_61, 1e-12);  sum_61 = None
        sqrt_41: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_50);  clamp_min_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_357: "f32[100, 512]" = torch.ops.aten.view.default(view_344, [100, -1]);  view_344 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_358: "f32[100, 256]" = torch.ops.aten.view.default(view_348, [100, -1]);  view_348 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_45: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_356, memory_format = torch.contiguous_format);  view_356 = None
        view_359: "f32[100, 192]" = torch.ops.aten.view.default(clone_45, [100, 192]);  clone_45 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_360: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_41, [100, -1]);  sqrt_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_36: "f32[100, 1024]" = torch.ops.aten.cat.default([view_357, view_358, view_359, view_360], -1);  view_357 = view_358 = view_359 = view_360 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_437: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_36, 2);  cat_36 = None
        permute_363: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_437, [0, 2, 1]);  unsqueeze_437 = None
        unsqueeze_438: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg107_1, 2);  arg107_1 = None
        permute_364: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_438, [2, 1, 0]);  unsqueeze_438 = None
        permute_365: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_363, [0, 2, 1]);  permute_363 = None
        view_361: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_365, [1, 100, 1024]);  permute_365 = None
        permute_366: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_364, [2, 1, 0]);  permute_364 = None
        view_362: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_366, [1, 1024, 128]);  permute_366 = None
        bmm_81: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_361, view_362);  view_361 = view_362 = None
        view_363: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_81, [100, 1, 128]);  bmm_81 = None
        permute_367: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_363, [0, 2, 1]);  view_363 = None
        view_364: "f32[100, 128]" = torch.ops.aten.view.default(permute_367, [100, 128]);  permute_367 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_174: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_364, arg108_1);  view_364 = arg108_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_175: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_128, add_174);  add_128 = add_174 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_20: "f32[100, 1]" = torch.ops.aten.mean.dim(add_175, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_20: "f32[100, 1]" = torch.ops.aten.var.correction(add_175, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_125: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_175, mean_20);  mean_20 = None
        add_176: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_20, 1e-05);  var_20 = None
        rsqrt_20: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_176);  add_176 = None
        mul_222: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_125, rsqrt_20);  sub_125 = rsqrt_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_223: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_222, arg109_1);  mul_222 = arg109_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_177: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_223, arg110_1);  mul_223 = arg110_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_21: "f32[100, 1]" = torch.ops.aten.mean.dim(add_177, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_21: "f32[100, 1]" = torch.ops.aten.var.correction(add_177, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_131: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_177, mean_21);  add_177 = mean_21 = None
        add_182: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_21, 1e-05);  var_21 = None
        rsqrt_21: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_182);  add_182 = None
        mul_230: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_131, rsqrt_21);  sub_131 = rsqrt_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_231: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_230, arg111_1);  mul_230 = arg111_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_183: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_231, arg112_1);  mul_231 = arg112_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_448: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_183, 2);  add_183 = None
        permute_373: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_448, [0, 2, 1]);  unsqueeze_448 = None
        unsqueeze_449: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg113_1, 2);  arg113_1 = None
        permute_374: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_449, [2, 1, 0]);  unsqueeze_449 = None
        permute_375: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_373, [0, 2, 1]);  permute_373 = None
        view_369: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_375, [1, 100, 128]);  permute_375 = None
        permute_376: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_374, [2, 1, 0]);  permute_374 = None
        view_370: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_376, [1, 128, 768]);  permute_376 = None
        bmm_83: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_369, view_370);  view_370 = None
        view_371: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_83, [100, 1, 768]);  bmm_83 = None
        permute_377: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_371, [0, 2, 1]);  view_371 = None
        view_372: "f32[100, 768]" = torch.ops.aten.view.default(permute_377, [100, 768]);  permute_377 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_373: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_372, [100, 8, 96]);  view_372 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_3 = torch.ops.aten.split.Tensor(view_373, 32, -1);  view_373 = None
        getitem_52: "f32[100, 8, 32]" = split_3[0]
        getitem_53: "f32[100, 8, 32]" = split_3[1]
        getitem_54: "f32[100, 8, 32]" = split_3[2];  split_3 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_22: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_52, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_22: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_52, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_132: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_52, mean_22);  getitem_52 = mean_22 = None
        add_184: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_22, 1e-05);  var_22 = None
        rsqrt_22: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_184);  add_184 = None
        mul_232: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_132, rsqrt_22);  sub_132 = rsqrt_22 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_233: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_232, arg114_1);  mul_232 = arg114_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_185: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_233, arg115_1);  mul_233 = arg115_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_23: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_53, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_23: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_53, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_133: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_53, mean_23);  getitem_53 = mean_23 = None
        add_186: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_23, 1e-05);  var_23 = None
        rsqrt_23: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_186);  add_186 = None
        mul_234: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_133, rsqrt_23);  sub_133 = rsqrt_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_235: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_234, arg116_1);  mul_234 = arg116_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_187: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_235, arg117_1);  mul_235 = arg117_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_451: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg118_1, 2);  arg118_1 = None
        permute_379: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_451, [2, 1, 0]);  unsqueeze_451 = None
        permute_381: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_379, [2, 1, 0]);  permute_379 = None
        view_375: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_381, [1, 128, 576]);  permute_381 = None
        bmm_84: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_369, view_375);  view_369 = view_375 = None
        view_376: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_84, [100, 1, 576]);  bmm_84 = None
        permute_382: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_376, [0, 2, 1]);  view_376 = None
        view_377: "f32[100, 576]" = torch.ops.aten.view.default(permute_382, [100, 576]);  permute_382 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_378: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_377, [100, 192, 3]);  view_377 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        unsqueeze_454: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_378, 3);  view_378 = None
        permute_384: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_454, [0, 1, 3, 2]);  unsqueeze_454 = None
        permute_386: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_384, [0, 3, 1, 2]);  permute_384 = None
        view_380: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_386, [100, 3, 192]);  permute_386 = None
        bmm_85: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_168, view_380);  view_380 = None
        view_381: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_85, [100, 3, 1, 192]);  bmm_85 = None
        permute_387: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_381, [0, 3, 1, 2]);  view_381 = None
        view_382: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_387, [100, 192, 3]);  permute_387 = None
        add_188: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_382, unsqueeze_267);  view_382 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_383: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_188, [100, 8, 24, 3]);  add_188 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_303: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_383, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_306: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_383, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_309: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_383, 2, 16, 9223372036854775807);  view_383 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_455: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_39, 3);  select_39 = None
        permute_388: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_455, [0, 1, 3, 2])
        unsqueeze_456: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg119_1, 2);  arg119_1 = None
        unsqueeze_457: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_456, 3);  unsqueeze_456 = None
        permute_389: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_457, [2, 3, 1, 0]);  unsqueeze_457 = None
        permute_390: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_388, [0, 1, 3, 2]);  permute_388 = None
        view_384: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_390, [1, 4800, 64]);  permute_390 = None
        permute_391: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_389, [3, 2, 0, 1]);  permute_389 = None
        view_385: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_391, [1, 64, 8]);  permute_391 = None
        bmm_86: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_384, view_385);  view_384 = view_385 = None
        view_386: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_86, [100, 48, 1, 8]);  bmm_86 = None
        permute_392: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_386, [0, 1, 3, 2]);  view_386 = None
        view_387: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_392, [100, 48, 8]);  permute_392 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_10: "f32[8]" = torch.ops.aten.exp.default(arg120_1)
        log1p_3: "f32[8]" = torch.ops.aten.log1p.default(exp_10);  exp_10 = None
        gt_3: "b8[8]" = torch.ops.aten.gt.Scalar(arg120_1, 20)
        where_71: "f32[8]" = torch.ops.aten.where.self(gt_3, arg120_1, log1p_3);  gt_3 = arg120_1 = log1p_3 = None
        view_388: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_71, [1, 1, 8]);  where_71 = None
        mul_236: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_388, 0.16666666666666666);  view_388 = None
        div_52: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_236, 2);  mul_236 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_458: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_303, 1);  slice_303 = None
        index_131: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_306, [select_38]);  slice_306 = None
        sub_134: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_458, index_131);  unsqueeze_458 = index_131 = None
        pow_10: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_134, 2);  sub_134 = None
        sum_65: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_10, [-1, -2]);  pow_10 = None
        mul_237: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_52, sum_65);  div_52 = sum_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_132: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_187, [select_38]);  add_187 = None
        unsqueeze_459: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_185, 3);  add_185 = None
        permute_393: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_459, [0, 3, 1, 2]);  unsqueeze_459 = None
        permute_394: "f32[100, 48, 8, 32]" = torch.ops.aten.permute.default(index_132, [0, 1, 2, 3]);  index_132 = None
        permute_395: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_393, [0, 2, 3, 1]);  permute_393 = None
        view_389: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_395, [800, 1, 32]);  permute_395 = None
        permute_396: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(permute_394, [0, 2, 3, 1]);  permute_394 = None
        clone_46: "f32[100, 8, 32, 48]" = torch.ops.aten.clone.default(permute_396, memory_format = torch.contiguous_format);  permute_396 = None
        view_390: "f32[800, 32, 48]" = torch.ops.aten.view.default(clone_46, [800, 32, 48]);  clone_46 = None
        bmm_87: "f32[800, 1, 48]" = torch.ops.aten.bmm.default(view_389, view_390);  view_389 = view_390 = None
        view_391: "f32[100, 8, 1, 48]" = torch.ops.aten.view.default(bmm_87, [100, 8, 1, 48]);  bmm_87 = None
        permute_397: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_391, [0, 3, 1, 2]);  view_391 = None
        view_392: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_397, [100, 48, 8]);  permute_397 = None
        mul_238: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(view_392, 0.1767766952966369);  view_392 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_189: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_238, view_387);  mul_238 = view_387 = None
        sub_135: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_189, mul_237);  add_189 = mul_237 = None
        mul_239: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_135, 0.5773502691896257);  sub_135 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_17: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_38, -1)
        bitwise_and_38: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_40, ne_17);  select_40 = ne_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_460: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_38, 2);  bitwise_and_38 = None
        where_72: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_460, mul_239, full_default_41);  mul_239 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_47: "f32[100, 48, 8]" = torch.ops.aten.clone.default(where_72, memory_format = torch.contiguous_format);  where_72 = None
        amax_3: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_47, [-2], True)
        sub_136: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(clone_47, amax_3);  clone_47 = amax_3 = None
        exp_11: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_136);  sub_136 = None
        sum_66: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_11, [-2], True)
        div_53: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_11, sum_66);  exp_11 = sum_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_73: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_460, div_53, full_default_42);  unsqueeze_460 = div_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_462: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_73, 3);  where_73 = None
        permute_398: "f32[100, 8, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_462, [0, 2, 3, 1])
        permute_399: "f32[100, 1, 64, 48]" = torch.ops.aten.permute.default(unsqueeze_455, [0, 3, 2, 1]);  unsqueeze_455 = None
        permute_400: "f32[100, 8, 48, 1]" = torch.ops.aten.permute.default(permute_398, [0, 1, 3, 2]);  permute_398 = None
        view_393: "f32[100, 8, 48]" = torch.ops.aten.view.default(permute_400, [100, 8, 48])
        permute_401: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_399, [0, 3, 2, 1]);  permute_399 = None
        view_394: "f32[100, 48, 64]" = torch.ops.aten.view.default(permute_401, [100, 48, 64]);  permute_401 = None
        bmm_88: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_393, view_394);  view_393 = view_394 = None
        view_395: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_88, [100, 8, 1, 64]);  bmm_88 = None
        permute_402: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_395, [0, 1, 3, 2]);  view_395 = None
        view_396: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_402, [100, 8, 64]);  permute_402 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_133: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_54, [select_38]);  getitem_54 = None
        permute_404: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(index_133, [0, 2, 3, 1]);  index_133 = None
        clone_48: "f32[100, 8, 48, 1]" = torch.ops.aten.clone.default(permute_400, memory_format = torch.contiguous_format);  permute_400 = None
        view_397: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_48, [800, 1, 48]);  clone_48 = None
        permute_406: "f32[100, 8, 48, 32]" = torch.ops.aten.permute.default(permute_404, [0, 1, 3, 2]);  permute_404 = None
        clone_49: "f32[100, 8, 48, 32]" = torch.ops.aten.clone.default(permute_406, memory_format = torch.contiguous_format);  permute_406 = None
        view_398: "f32[800, 48, 32]" = torch.ops.aten.view.default(clone_49, [800, 48, 32]);  clone_49 = None
        bmm_89: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_397, view_398);  view_397 = view_398 = None
        view_399: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_89, [100, 8, 1, 32]);  bmm_89 = None
        permute_407: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_399, [0, 1, 3, 2]);  view_399 = None
        view_400: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_407, [100, 8, 32]);  permute_407 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_134: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_309, [select_38]);  slice_309 = select_38 = None
        unsqueeze_466: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_462, 4);  unsqueeze_462 = None
        permute_408: "f32[100, 8, 1, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_466, [0, 2, 3, 4, 1]);  unsqueeze_466 = None
        permute_409: "f32[100, 8, 8, 3, 48]" = torch.ops.aten.permute.default(index_134, [0, 2, 3, 4, 1]);  index_134 = None
        permute_410: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.permute.default(permute_408, [0, 1, 4, 2, 3]);  permute_408 = None
        clone_50: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.clone.default(permute_410, memory_format = torch.contiguous_format);  permute_410 = None
        view_401: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_50, [800, 1, 48]);  clone_50 = None
        permute_411: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.permute.default(permute_409, [0, 1, 4, 2, 3]);  permute_409 = None
        clone_51: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.clone.default(permute_411, memory_format = torch.contiguous_format);  permute_411 = None
        view_402: "f32[800, 48, 24]" = torch.ops.aten.view.default(clone_51, [800, 48, 24]);  clone_51 = None
        bmm_90: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_401, view_402);  view_401 = view_402 = None
        view_403: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_90, [100, 8, 1, 8, 3]);  bmm_90 = None
        permute_412: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_403, [0, 1, 3, 4, 2]);  view_403 = None
        view_404: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_412, [100, 8, 8, 3]);  permute_412 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_137: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_404, unsqueeze_284);  view_404 = None
        unsqueeze_471: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_137, 4);  sub_137 = None
        permute_414: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_471, [0, 1, 2, 4, 3]);  unsqueeze_471 = None
        permute_416: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_414, [0, 4, 1, 2, 3]);  permute_414 = None
        view_406: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_416, [100, 3, 64]);  permute_416 = None
        bmm_91: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_194, view_406);  view_406 = None
        view_407: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_91, [100, 3, 1, 8, 8]);  bmm_91 = None
        permute_417: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_407, [0, 3, 4, 1, 2]);  view_407 = None
        view_408: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_417, [100, 8, 8, 3]);  permute_417 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_240: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_408, view_408)
        sum_67: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_240, [-1]);  mul_240 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_53: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_67, 1e-12);  sum_67 = None
        sqrt_44: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_53);  clamp_min_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_409: "f32[100, 512]" = torch.ops.aten.view.default(view_396, [100, -1]);  view_396 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_410: "f32[100, 256]" = torch.ops.aten.view.default(view_400, [100, -1]);  view_400 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_52: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_408, memory_format = torch.contiguous_format);  view_408 = None
        view_411: "f32[100, 192]" = torch.ops.aten.view.default(clone_52, [100, 192]);  clone_52 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_412: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_44, [100, -1]);  sqrt_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_38: "f32[100, 1024]" = torch.ops.aten.cat.default([view_409, view_410, view_411, view_412], -1);  view_409 = view_410 = view_411 = view_412 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_472: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_38, 2);  cat_38 = None
        permute_418: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_472, [0, 2, 1]);  unsqueeze_472 = None
        unsqueeze_473: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg121_1, 2);  arg121_1 = None
        permute_419: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_473, [2, 1, 0]);  unsqueeze_473 = None
        permute_420: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_418, [0, 2, 1]);  permute_418 = None
        view_413: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_420, [1, 100, 1024]);  permute_420 = None
        permute_421: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_419, [2, 1, 0]);  permute_419 = None
        view_414: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_421, [1, 1024, 128]);  permute_421 = None
        bmm_92: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_413, view_414);  view_413 = view_414 = None
        view_415: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_92, [100, 1, 128]);  bmm_92 = None
        permute_422: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_415, [0, 2, 1]);  view_415 = None
        view_416: "f32[100, 128]" = torch.ops.aten.view.default(permute_422, [100, 128]);  permute_422 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_190: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_416, arg122_1);  view_416 = arg122_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_191: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_175, add_190);  add_175 = add_190 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_24: "f32[100, 1]" = torch.ops.aten.mean.dim(add_191, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_24: "f32[100, 1]" = torch.ops.aten.var.correction(add_191, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_138: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_191, mean_24);  mean_24 = None
        add_192: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_24, 1e-05);  var_24 = None
        rsqrt_24: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_192);  add_192 = None
        mul_241: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_138, rsqrt_24);  sub_138 = rsqrt_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_242: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_241, arg123_1);  mul_241 = arg123_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_193: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_242, arg124_1);  mul_242 = arg124_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_143: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_136, unsqueeze_367)
        permute_423: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_366, [0, 1, 3, 2])
        unsqueeze_482: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_143, 3);  sub_143 = None
        permute_424: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_482, [0, 1, 3, 2]);  unsqueeze_482 = None
        permute_425: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_423, [0, 2, 3, 1]);  permute_423 = None
        view_417: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_425, [100, 3, 3]);  permute_425 = None
        permute_426: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_424, [0, 3, 1, 2]);  permute_424 = None
        view_418: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_426, [100, 3, 20]);  permute_426 = None
        bmm_93: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_417, view_418);  view_417 = view_418 = None
        view_419: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_93, [100, 3, 1, 20]);  bmm_93 = None
        permute_427: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_419, [0, 3, 1, 2]);  view_419 = None
        view_420: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_427, [100, 20, 3]);  permute_427 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        clone_53: "f32[100, 20, 3]" = torch.ops.aten.clone.default(view_420, memory_format = torch.contiguous_format)
        view_421: "f32[100, 60]" = torch.ops.aten.view.default(clone_53, [100, 60]);  clone_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_484: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg125_1, 2);  arg125_1 = None
        permute_429: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_484, [2, 1, 0]);  unsqueeze_484 = None
        permute_431: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_429, [2, 1, 0]);  permute_429 = None
        view_423: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_431, [1, 128, 128]);  permute_431 = None
        bmm_94: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_211, view_423);  view_423 = None
        view_424: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_94, [100, 1, 128]);  bmm_94 = None
        permute_432: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_424, [0, 2, 1]);  view_424 = None
        view_425: "f32[100, 128]" = torch.ops.aten.view.default(permute_432, [100, 128]);  permute_432 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_198: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_193, view_425);  add_193 = view_425 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_485: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_421, 2);  view_421 = None
        permute_433: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_485, [0, 2, 1]);  unsqueeze_485 = None
        unsqueeze_486: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg126_1, 2);  arg126_1 = None
        permute_434: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_486, [2, 1, 0]);  unsqueeze_486 = None
        permute_435: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_433, [0, 2, 1]);  permute_433 = None
        view_426: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_435, [1, 100, 60]);  permute_435 = None
        permute_436: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_434, [2, 1, 0]);  permute_434 = None
        view_427: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_436, [1, 60, 256]);  permute_436 = None
        bmm_95: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_426, view_427);  view_426 = view_427 = None
        view_428: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_95, [100, 1, 256]);  bmm_95 = None
        permute_437: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_428, [0, 2, 1]);  view_428 = None
        view_429: "f32[100, 256]" = torch.ops.aten.view.default(permute_437, [100, 256]);  permute_437 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_199: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_429, arg127_1);  view_429 = arg127_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_249: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_199, add_199)
        mul_250: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_249, add_199);  mul_249 = None
        mul_251: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_250, 0.044715);  mul_250 = None
        add_200: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_199, mul_251);  mul_251 = None
        mul_252: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_200, 0.7978845608028654);  add_200 = None
        mul_253: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_199, 0.5);  add_199 = None
        tanh_8: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_252);  mul_252 = None
        add_201: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_8, 1);  tanh_8 = None
        mul_254: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_253, add_201);  mul_253 = add_201 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_487: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_254, 2);  mul_254 = None
        permute_438: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_487, [0, 2, 1]);  unsqueeze_487 = None
        unsqueeze_488: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg128_1, 2);  arg128_1 = None
        permute_439: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_488, [2, 1, 0]);  unsqueeze_488 = None
        permute_440: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_438, [0, 2, 1]);  permute_438 = None
        view_430: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_440, [1, 100, 256]);  permute_440 = None
        permute_441: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_439, [2, 1, 0]);  permute_439 = None
        view_431: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_441, [1, 256, 128]);  permute_441 = None
        bmm_96: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_430, view_431);  view_430 = view_431 = None
        view_432: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_96, [100, 1, 128]);  bmm_96 = None
        permute_442: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_432, [0, 2, 1]);  view_432 = None
        view_433: "f32[100, 128]" = torch.ops.aten.view.default(permute_442, [100, 128]);  permute_442 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_202: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_433, arg129_1);  view_433 = arg129_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_203: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_198, add_202);  add_198 = add_202 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_489: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_203, 2);  add_203 = None
        permute_443: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_489, [0, 2, 1]);  unsqueeze_489 = None
        unsqueeze_490: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg130_1, 2);  arg130_1 = None
        permute_444: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_490, [2, 1, 0]);  unsqueeze_490 = None
        permute_445: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_443, [0, 2, 1]);  permute_443 = None
        view_434: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_445, [1, 100, 128]);  permute_445 = None
        permute_446: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_444, [2, 1, 0]);  permute_444 = None
        view_435: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_446, [1, 128, 512]);  permute_446 = None
        bmm_97: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_434, view_435);  view_435 = None
        view_436: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_97, [100, 1, 512]);  bmm_97 = None
        permute_447: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_436, [0, 2, 1]);  view_436 = None
        view_437: "f32[100, 512]" = torch.ops.aten.view.default(permute_447, [100, 512]);  permute_447 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_492: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg131_1, 2);  arg131_1 = None
        permute_449: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_492, [2, 1, 0]);  unsqueeze_492 = None
        permute_451: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_449, [2, 1, 0]);  permute_449 = None
        view_439: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_451, [1, 128, 512]);  permute_451 = None
        bmm_98: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_434, view_439);  view_439 = None
        view_440: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_98, [100, 1, 512]);  bmm_98 = None
        permute_452: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_440, [0, 2, 1]);  view_440 = None
        view_441: "f32[100, 512]" = torch.ops.aten.view.default(permute_452, [100, 512]);  permute_452 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_255: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_441, view_441)
        mul_256: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_255, view_441);  mul_255 = None
        mul_257: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_256, 0.044715);  mul_256 = None
        add_204: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_441, mul_257);  mul_257 = None
        mul_258: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_204, 0.7978845608028654);  add_204 = None
        mul_259: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_441, 0.5);  view_441 = None
        tanh_9: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_258);  mul_258 = None
        add_205: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_9, 1);  tanh_9 = None
        mul_260: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_259, add_205);  mul_259 = add_205 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_261: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_260, view_437);  mul_260 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_494: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg132_1, 2);  arg132_1 = None
        permute_454: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_494, [2, 1, 0]);  unsqueeze_494 = None
        permute_456: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_454, [2, 1, 0]);  permute_454 = None
        view_443: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_456, [1, 128, 512]);  permute_456 = None
        bmm_99: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_434, view_443);  view_443 = None
        view_444: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_99, [100, 1, 512]);  bmm_99 = None
        permute_457: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_444, [0, 2, 1]);  view_444 = None
        view_445: "f32[100, 512]" = torch.ops.aten.view.default(permute_457, [100, 512]);  permute_457 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_262: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_445, view_445)
        mul_263: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_262, view_445);  mul_262 = None
        mul_264: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_263, 0.044715);  mul_263 = None
        add_206: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_445, mul_264);  mul_264 = None
        mul_265: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_206, 0.7978845608028654);  add_206 = None
        mul_266: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_445, 0.5);  view_445 = None
        tanh_10: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_265);  mul_265 = None
        add_207: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_10, 1);  tanh_10 = None
        mul_267: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_266, add_207);  mul_266 = add_207 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_496: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg133_1, 2);  arg133_1 = None
        permute_459: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_496, [2, 1, 0]);  unsqueeze_496 = None
        permute_461: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_459, [2, 1, 0]);  permute_459 = None
        view_447: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_461, [1, 128, 512]);  permute_461 = None
        bmm_100: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_434, view_447);  view_434 = view_447 = None
        view_448: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_100, [100, 1, 512]);  bmm_100 = None
        permute_462: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_448, [0, 2, 1]);  view_448 = None
        view_449: "f32[100, 512]" = torch.ops.aten.view.default(permute_462, [100, 512]);  permute_462 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_268: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_449, view_449)
        mul_269: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_268, view_449);  mul_268 = None
        mul_270: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_269, 0.044715);  mul_269 = None
        add_208: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_449, mul_270);  mul_270 = None
        mul_271: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_208, 0.7978845608028654);  add_208 = None
        mul_272: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_449, 0.5);  view_449 = None
        tanh_11: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_271);  mul_271 = None
        add_209: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_11, 1);  tanh_11 = None
        mul_273: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_272, add_209);  mul_272 = add_209 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_274: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_273, view_437);  mul_273 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_74: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_274, full_default_44);  mul_274 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_75: "f32[100, 512]" = torch.ops.aten.where.self(view_239, where_74, full_default_44);  where_74 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_4: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_6, where_75);  where_75 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_139: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_4, [clamp_max_2]);  scatter_add_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_56: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_139, clamp_min_33);  index_139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_78: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_56, full_default_44);  div_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_210: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_261, where_78);  mul_261 = where_78 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_276: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_267, view_437);  mul_267 = view_437 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_79: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_276, full_default_44);  mul_276 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_80: "f32[100, 512]" = torch.ops.aten.where.self(view_243, where_79, full_default_44);  where_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_6: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_8, where_80);  where_80 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_141: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_6, [clamp_max_4]);  scatter_add_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_57: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_141, clamp_min_36);  index_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_83: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_57, full_default_44);  div_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_211: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_210, where_83);  add_210 = where_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_498: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_211, 2);  add_211 = None
        permute_463: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_498, [0, 2, 1]);  unsqueeze_498 = None
        unsqueeze_499: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg134_1, 2);  arg134_1 = None
        permute_464: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_499, [2, 1, 0]);  unsqueeze_499 = None
        permute_465: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_463, [0, 2, 1]);  permute_463 = None
        view_458: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_465, [1, 100, 512]);  permute_465 = None
        permute_466: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_464, [2, 1, 0]);  permute_464 = None
        view_459: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_466, [1, 512, 128]);  permute_466 = None
        bmm_101: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_458, view_459);  view_458 = view_459 = None
        view_460: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_101, [100, 1, 128]);  bmm_101 = None
        permute_467: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_460, [0, 2, 1]);  view_460 = None
        view_461: "f32[100, 128]" = torch.ops.aten.view.default(permute_467, [100, 128]);  permute_467 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_212: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_461, arg135_1);  view_461 = arg135_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_213: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_191, add_212);  add_191 = add_212 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_25: "f32[100, 1]" = torch.ops.aten.mean.dim(add_213, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_25: "f32[100, 1]" = torch.ops.aten.var.correction(add_213, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_144: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_213, mean_25);  mean_25 = None
        add_214: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_25, 1e-05);  var_25 = None
        rsqrt_25: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_214);  add_214 = None
        mul_278: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_144, rsqrt_25);  sub_144 = rsqrt_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_279: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_278, arg136_1);  arg136_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_215: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_279, arg137_1);  mul_279 = arg137_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_509: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_215, 2);  add_215 = None
        permute_473: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_509, [0, 2, 1]);  unsqueeze_509 = None
        unsqueeze_510: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg138_1, 2);  arg138_1 = None
        permute_474: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_510, [2, 1, 0]);  unsqueeze_510 = None
        permute_475: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_473, [0, 2, 1]);  permute_473 = None
        view_466: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_475, [1, 100, 128]);  permute_475 = None
        permute_476: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_474, [2, 1, 0]);  permute_474 = None
        view_467: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_476, [1, 128, 60]);  permute_476 = None
        bmm_103: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_466, view_467);  view_466 = view_467 = None
        view_468: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_103, [100, 1, 60]);  bmm_103 = None
        permute_477: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_468, [0, 2, 1]);  view_468 = None
        view_469: "f32[100, 60]" = torch.ops.aten.view.default(permute_477, [100, 60]);  permute_477 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_286: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_469, 10.0);  view_469 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_470: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_286, [100, 20, 3]);  mul_286 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_220: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_420, view_470);  view_420 = view_470 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_478: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_366, [0, 1, 2, 3]);  unsqueeze_366 = None
        unsqueeze_513: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(add_220, 3);  add_220 = None
        permute_479: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_513, [0, 1, 3, 2]);  unsqueeze_513 = None
        permute_480: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_478, [0, 2, 3, 1]);  permute_478 = None
        view_471: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_480, [100, 3, 3]);  permute_480 = None
        permute_481: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_479, [0, 3, 1, 2]);  permute_479 = None
        view_472: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_481, [100, 3, 20]);  permute_481 = None
        bmm_104: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_471, view_472);  view_471 = view_472 = None
        view_473: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_104, [100, 3, 1, 20]);  bmm_104 = None
        permute_482: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_473, [0, 3, 1, 2]);  view_473 = None
        view_474: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_482, [100, 20, 3]);  permute_482 = None
        add_221: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_474, unsqueeze_367);  view_474 = unsqueeze_367 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_59: "f32[100, 3]" = torch.ops.aten.select.int(add_221, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_514: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_59, 1)
        unsqueeze_515: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_59, 0)
        sub_150: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_514, unsqueeze_515);  unsqueeze_514 = unsqueeze_515 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_287: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_150, sub_150);  sub_150 = None
        sum_74: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_287, [-1]);  mul_287 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_64: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_74, 1e-12);  sum_74 = None
        sqrt_49: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_64);  clamp_min_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_84: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_49, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_85: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_84, full_default);  where_84 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_148: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_85, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_86: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_148);  index_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_11: "f32[100, 100]" = torch.ops.aten.index_put.default(where_85, [unsqueeze_24, where_1], where_86);  where_85 = where_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_12 = torch.ops.aten.sort.stable(index_put_11, stable = True)
        getitem_56: "i64[100, 100]" = sort_12[1];  sort_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_337: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_56, 1, 0, 16);  getitem_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_149: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_11, [unsqueeze_24, slice_337]);  index_put_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_20: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_149, inf);  index_149 = None
        where_87: "i64[100, 16]" = torch.ops.aten.where.self(lt_20, slice_337, full_default_1);  lt_20 = slice_337 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_41: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_87], -1);  where_87 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_222: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_49, 1e-06);  sqrt_49 = None
        log_24: "f32[100, 100]" = torch.ops.aten.log.default(add_222);  add_222 = None
        mul_288: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_24, -3.0);  log_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_25: "f32[100, 100]" = torch.ops.aten.log.default(getitem_7)
        neg_20: "f32[100, 100]" = torch.ops.aten.neg.default(log_25);  log_25 = None
        log_26: "f32[100, 100]" = torch.ops.aten.log.default(neg_20);  neg_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_151: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_288, log_26);  mul_288 = log_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_21: "f32[100, 100]" = torch.ops.aten.neg.default(sub_151);  sub_151 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_88: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_21, full_default);  neg_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_89: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_88, full_default);  where_88 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_19: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_41, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_151: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_89, [unsqueeze_24, cat_41])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_90: "f32[100, 32]" = torch.ops.aten.where.self(ne_19, full_default_7, index_151);  ne_19 = index_151 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_12: "f32[100, 100]" = torch.ops.aten.index_put.default(where_89, [unsqueeze_24, cat_41], where_90);  where_89 = where_90 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_13 = torch.ops.aten.sort.stable(index_put_12, stable = True)
        getitem_58: "i64[100, 100]" = sort_13[1];  sort_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_346: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_58, 1, 0, 32);  getitem_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_152: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_12, [unsqueeze_24, slice_346]);  index_put_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_21: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_152, inf);  index_152 = None
        where_91: "i64[100, 32]" = torch.ops.aten.where.self(lt_21, slice_346, full_default_37);  lt_21 = slice_346 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_42: "i64[100, 64]" = torch.ops.aten.cat.default([cat_41, where_91], -1);  cat_41 = where_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_60: "i64[100, 48]" = torch.ops.aten.select.int(view_14, 0, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_61: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_52, 0, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_62: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_153: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_42])
        bitwise_and_47: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_153);  index_153 = None
        ne_20: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_42, -1)
        bitwise_and_48: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_47, ne_20);  bitwise_and_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_154: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_42])
        eq_21: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_154);  index_154 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_155: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_42])
        eq_22: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_155);  index_155 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_156: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_42])
        sub_152: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_156);  index_156 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_65: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_152, -32);  sub_152 = None
        clamp_max_11: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_65, 32);  clamp_min_65 = None
        add_223: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_11, 32);  clamp_max_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_92: "i64[100, 64]" = torch.ops.aten.where.self(eq_21, add_223, full_default_38);  eq_21 = add_223 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_93: "i64[100, 64]" = torch.ops.aten.where.self(eq_22, where_92, full_default_38);  eq_22 = where_92 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_157: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg139_1, [where_93]);  arg139_1 = where_93 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_536: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_221, 1)
        slice_353: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_536, 2, 0, 5)
        unsqueeze_537: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_353, 3);  slice_353 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_158: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_221, [cat_42])
        unsqueeze_538: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_158, 2)
        slice_357: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_538, 3, 0, 5);  unsqueeze_538 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_153: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_537, slice_357);  unsqueeze_537 = slice_357 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_289: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_153, sub_153);  sub_153 = None
        sum_75: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_289, [-1]);  mul_289 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_66: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_75, 1e-12);  sum_75 = None
        sqrt_50: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_66);  clamp_min_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_475: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_50, [100, 64, 25]);  sqrt_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_539: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_475, 3);  view_475 = None
        sub_154: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_539, add_29);  unsqueeze_539 = None
        pow_11: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_154, 2);  sub_154 = None
        neg_22: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_11);  pow_11 = None
        div_60: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_22, 1.890625);  neg_22 = None
        exp_12: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_60);  div_60 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_476: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_12, [100, 64, 400]);  exp_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_540: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_476, 3);  view_476 = None
        permute_483: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_540, [0, 1, 3, 2]);  unsqueeze_540 = None
        unsqueeze_541: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg140_1, 2);  arg140_1 = None
        unsqueeze_542: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_541, 3);  unsqueeze_541 = None
        permute_484: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_542, [2, 3, 1, 0]);  unsqueeze_542 = None
        permute_485: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_483, [0, 1, 3, 2]);  permute_483 = None
        view_477: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_485, [1, 6400, 400]);  permute_485 = None
        permute_486: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_484, [3, 2, 0, 1]);  permute_484 = None
        view_478: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_486, [1, 400, 64]);  permute_486 = None
        bmm_105: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_477, view_478);  view_477 = view_478 = None
        view_479: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_105, [100, 64, 1, 64]);  bmm_105 = None
        permute_487: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_479, [0, 1, 3, 2]);  view_479 = None
        view_480: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_487, [100, 64, 64]);  permute_487 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_227: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_157, view_480);  index_157 = view_480 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_63: "f32[100, 3]" = torch.ops.aten.select.int(add_221, 1, 0)
        select_65: "f32[100, 3]" = torch.ops.aten.select.int(add_221, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_155: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_65, select_59);  select_65 = None
        sub_156: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_63, select_59);  select_63 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_292: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_155, sub_155)
        sum_76: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_292, [-1]);  mul_292 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_67: "f32[100]" = torch.ops.aten.clamp_min.default(sum_76, 1e-12);  sum_76 = None
        sqrt_51: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_67);  clamp_min_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_543: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_51, -1);  sqrt_51 = None
        div_61: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_155, unsqueeze_543);  sub_155 = unsqueeze_543 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_293: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_156, div_61)
        sum_77: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_293, [-1]);  mul_293 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_544: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_77, -1);  sum_77 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_294: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_544, div_61);  unsqueeze_544 = None
        sub_157: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_156, mul_294);  sub_156 = mul_294 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_295: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_157, sub_157)
        sum_78: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_295, [-1]);  mul_295 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_68: "f32[100]" = torch.ops.aten.clamp_min.default(sum_78, 1e-12);  sum_78 = None
        sqrt_52: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_68);  clamp_min_68 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_545: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_52, -1);  sqrt_52 = None
        div_62: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_157, unsqueeze_545);  sub_157 = unsqueeze_545 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_159: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_61, [None, remainder])
        index_160: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_62, [None, remainder_1])
        mul_296: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_159, index_160);  index_159 = index_160 = None
        index_161: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_61, [None, remainder_1])
        index_162: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_62, [None, remainder])
        mul_297: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_161, index_162);  index_161 = index_162 = None
        sub_158: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_296, mul_297);  mul_296 = mul_297 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_546: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_61, 2);  div_61 = None
        unsqueeze_547: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_62, 2);  div_62 = None
        unsqueeze_548: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_158, 2);  sub_158 = None
        cat_43: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_546, unsqueeze_547, unsqueeze_548], -1);  unsqueeze_546 = unsqueeze_547 = unsqueeze_548 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_552: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_43, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_553: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_59, -2);  select_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_554: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_552, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_555: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_553, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_160: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_158, unsqueeze_555)
        permute_493: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_554, [0, 1, 2, 4, 3]);  unsqueeze_554 = None
        unsqueeze_556: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_160, 4);  sub_160 = None
        permute_494: "f32[100, 64, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_556, [0, 1, 2, 4, 3]);  unsqueeze_556 = None
        permute_495: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_493, [0, 3, 4, 1, 2]);  permute_493 = None
        view_485: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_495, [100, 3, 3]);  permute_495 = None
        permute_496: "f32[100, 3, 64, 20, 1]" = torch.ops.aten.permute.default(permute_494, [0, 4, 1, 2, 3]);  permute_494 = None
        view_486: "f32[100, 3, 1280]" = torch.ops.aten.view.default(permute_496, [100, 3, 1280]);  permute_496 = None
        bmm_107: "f32[100, 3, 1280]" = torch.ops.aten.bmm.default(view_485, view_486);  view_486 = None
        view_487: "f32[100, 3, 1, 64, 20]" = torch.ops.aten.view.default(bmm_107, [100, 3, 1, 64, 20]);  bmm_107 = None
        permute_497: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.permute.default(view_487, [0, 3, 4, 1, 2]);  view_487 = None
        view_488: "f32[100, 64, 20, 3]" = torch.ops.aten.view.default(permute_497, [100, 64, 20, 3]);  permute_497 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_298: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(view_488, view_488)
        sum_79: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_298, [-1]);  mul_298 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_69: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_79, 1e-12);  sum_79 = None
        sqrt_53: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_69);  clamp_min_69 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_557: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_53, -1);  sqrt_53 = None
        div_63: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(view_488, unsqueeze_557);  view_488 = unsqueeze_557 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        clone_56: "f32[100, 64, 20, 3]" = torch.ops.aten.clone.default(div_63, memory_format = torch.contiguous_format);  div_63 = None
        view_489: "f32[100, 64, 60]" = torch.ops.aten.view.default(clone_56, [100, 64, 60]);  clone_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_17: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_536, [100, 64, 20, 3]);  unsqueeze_536 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_44: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_17, index_158], -2);  expand_17 = index_158 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_161: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_44, unsqueeze_555);  cat_44 = unsqueeze_555 = None
        unsqueeze_563: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_161, 4);  sub_161 = None
        permute_499: "f32[100, 64, 40, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_563, [0, 1, 2, 4, 3]);  unsqueeze_563 = None
        permute_501: "f32[100, 3, 64, 40, 1]" = torch.ops.aten.permute.default(permute_499, [0, 4, 1, 2, 3]);  permute_499 = None
        view_491: "f32[100, 3, 2560]" = torch.ops.aten.view.default(permute_501, [100, 3, 2560]);  permute_501 = None
        bmm_108: "f32[100, 3, 2560]" = torch.ops.aten.bmm.default(view_485, view_491);  view_485 = view_491 = None
        view_492: "f32[100, 3, 1, 64, 40]" = torch.ops.aten.view.default(bmm_108, [100, 3, 1, 64, 40]);  bmm_108 = None
        permute_502: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.permute.default(view_492, [0, 3, 4, 1, 2]);  view_492 = None
        view_493: "f32[100, 64, 40, 3]" = torch.ops.aten.view.default(permute_502, [100, 64, 40, 3]);  permute_502 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_299: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_493, view_493)
        sum_80: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_299, [-1]);  mul_299 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_70: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_80, 1e-12);  sum_80 = None
        sqrt_54: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_70);  clamp_min_70 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_564: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_54, -1);  sqrt_54 = None
        div_64: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(view_493, unsqueeze_564);  unsqueeze_564 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        clone_57: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(div_64, memory_format = torch.contiguous_format);  div_64 = None
        view_494: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_57, [100, 64, 120]);  clone_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_300: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_493, 0.1);  view_493 = None
        clone_58: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(mul_300, memory_format = torch.contiguous_format);  mul_300 = None
        view_495: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_58, [100, 64, 120]);  clone_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_45: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_494, view_495], -1);  view_494 = view_495 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_565: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_489, 3);  view_489 = None
        permute_503: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_565, [0, 1, 3, 2]);  unsqueeze_565 = None
        unsqueeze_566: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg141_1, 2);  arg141_1 = None
        unsqueeze_567: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_566, 3);  unsqueeze_566 = None
        permute_504: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_567, [2, 3, 1, 0]);  unsqueeze_567 = None
        permute_505: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_503, [0, 1, 3, 2]);  permute_503 = None
        view_496: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_505, [1, 6400, 60]);  permute_505 = None
        permute_506: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_504, [3, 2, 0, 1]);  permute_504 = None
        view_497: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_506, [1, 60, 64]);  permute_506 = None
        bmm_109: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_496, view_497);  view_496 = view_497 = None
        view_498: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_109, [100, 64, 1, 64]);  bmm_109 = None
        permute_507: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_498, [0, 1, 3, 2]);  view_498 = None
        view_499: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_507, [100, 64, 64]);  permute_507 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_232: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_227, view_499);  add_227 = view_499 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_577: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_43, 1)
        permute_513: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_577, [0, 1, 3, 2]);  unsqueeze_577 = None
        index_168: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_43, [cat_42]);  cat_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:78 in rot_compose, code: return a @ b
        expand_18: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(permute_513, [100, 64, 3, 3]);  permute_513 = None
        clone_59: "f32[100, 64, 3, 3]" = torch.ops.aten.clone.default(expand_18, memory_format = torch.contiguous_format);  expand_18 = None
        view_504: "f32[6400, 3, 3]" = torch.ops.aten.view.default(clone_59, [6400, 3, 3]);  clone_59 = None
        expand_19: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(index_168, [100, 64, 3, 3]);  index_168 = None
        view_505: "f32[6400, 3, 3]" = torch.ops.aten.view.default(expand_19, [6400, 3, 3]);  expand_19 = None
        bmm_111: "f32[6400, 3, 3]" = torch.ops.aten.bmm.default(view_504, view_505);  view_504 = view_505 = None
        view_506: "f32[100, 64, 3, 3]" = torch.ops.aten.view.default(bmm_111, [100, 64, 3, 3]);  bmm_111 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_507: "f32[100, 64, 9]" = torch.ops.aten.view.default(view_506, [100, 64, 9]);  view_506 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_578: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_507, 3);  view_507 = None
        permute_514: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_578, [0, 1, 3, 2]);  unsqueeze_578 = None
        unsqueeze_579: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg142_1, 2);  arg142_1 = None
        unsqueeze_580: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_579, 3);  unsqueeze_579 = None
        permute_515: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_580, [2, 3, 1, 0]);  unsqueeze_580 = None
        permute_516: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_514, [0, 1, 3, 2]);  permute_514 = None
        view_508: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_516, [1, 6400, 9]);  permute_516 = None
        permute_517: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_515, [3, 2, 0, 1]);  permute_515 = None
        view_509: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_517, [1, 9, 64]);  permute_517 = None
        bmm_112: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_508, view_509);  view_508 = view_509 = None
        view_510: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_112, [100, 64, 1, 64]);  bmm_112 = None
        permute_518: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_510, [0, 1, 3, 2]);  view_510 = None
        view_511: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_518, [100, 64, 64]);  permute_518 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_237: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_232, view_511);  add_232 = view_511 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_581: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_45, 3);  cat_45 = None
        permute_519: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_581, [0, 1, 3, 2]);  unsqueeze_581 = None
        unsqueeze_582: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg143_1, 2);  arg143_1 = None
        unsqueeze_583: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_582, 3);  unsqueeze_582 = None
        permute_520: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_583, [2, 3, 1, 0]);  unsqueeze_583 = None
        permute_521: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_519, [0, 1, 3, 2]);  permute_519 = None
        view_512: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_521, [1, 6400, 240]);  permute_521 = None
        permute_522: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_520, [3, 2, 0, 1]);  permute_520 = None
        view_513: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_522, [1, 240, 64]);  permute_522 = None
        bmm_113: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_512, view_513);  view_512 = view_513 = None
        view_514: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_113, [100, 64, 1, 64]);  bmm_113 = None
        permute_523: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_514, [0, 1, 3, 2]);  view_514 = None
        view_515: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_523, [100, 64, 64]);  permute_523 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_238: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_237, view_515);  add_237 = view_515 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_26: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_238, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_26: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_238, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_167: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_238, mean_26);  add_238 = mean_26 = None
        add_239: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_26, 1e-05);  var_26 = None
        rsqrt_26: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_239);  add_239 = None
        mul_307: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_167, rsqrt_26);  sub_167 = rsqrt_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_308: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_307, arg144_1);  mul_307 = arg144_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_240: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_308, arg145_1);  mul_308 = arg145_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_584: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_240, 3);  add_240 = None
        permute_524: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_584, [0, 1, 3, 2]);  unsqueeze_584 = None
        unsqueeze_585: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg146_1, 2);  arg146_1 = None
        unsqueeze_586: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_585, 3);  unsqueeze_585 = None
        permute_525: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_586, [2, 3, 1, 0]);  unsqueeze_586 = None
        permute_526: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_524, [0, 1, 3, 2]);  permute_524 = None
        view_516: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_526, [1, 6400, 64]);  permute_526 = None
        permute_527: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_525, [3, 2, 0, 1]);  permute_525 = None
        view_517: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_527, [1, 64, 128]);  permute_527 = None
        bmm_114: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_516, view_517);  view_516 = view_517 = None
        view_518: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_114, [100, 64, 1, 128]);  bmm_114 = None
        permute_528: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_518, [0, 1, 3, 2]);  view_518 = None
        view_519: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_528, [100, 64, 128]);  permute_528 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_241: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_519, arg147_1);  view_519 = arg147_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_309: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_241, add_241)
        mul_310: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_309, add_241);  mul_309 = None
        mul_311: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_310, 0.044715);  mul_310 = None
        add_242: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_241, mul_311);  mul_311 = None
        mul_312: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_242, 0.7978845608028654);  add_242 = None
        mul_313: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_241, 0.5);  add_241 = None
        tanh_12: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_312);  mul_312 = None
        add_243: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_12, 1);  tanh_12 = None
        mul_314: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_313, add_243);  mul_313 = add_243 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_587: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_314, 3);  mul_314 = None
        permute_529: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_587, [0, 1, 3, 2]);  unsqueeze_587 = None
        unsqueeze_588: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg148_1, 2);  arg148_1 = None
        unsqueeze_589: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_588, 3);  unsqueeze_588 = None
        permute_530: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_589, [2, 3, 1, 0]);  unsqueeze_589 = None
        permute_531: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_529, [0, 1, 3, 2]);  permute_529 = None
        view_520: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_531, [1, 6400, 128]);  permute_531 = None
        permute_532: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_530, [3, 2, 0, 1]);  permute_530 = None
        view_521: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_532, [1, 128, 64]);  permute_532 = None
        bmm_115: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_520, view_521);  view_520 = view_521 = None
        view_522: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_115, [100, 64, 1, 64]);  bmm_115 = None
        permute_533: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_522, [0, 1, 3, 2]);  view_522 = None
        view_523: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_533, [100, 64, 64]);  permute_533 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_244: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_523, arg149_1);  view_523 = arg149_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_316: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_278, arg150_1);  mul_278 = arg150_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_246: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_316, arg151_1);  mul_316 = arg151_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_67: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_221, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_69: "f32[100, 3]" = torch.ops.aten.select.int(div_67, 1, 0)
        select_70: "f32[100, 3]" = torch.ops.aten.select.int(div_67, 1, 1)
        select_71: "f32[100, 3]" = torch.ops.aten.select.int(div_67, 1, 2);  div_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_169: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_71, select_70);  select_71 = None
        sub_170: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_69, select_70);  select_69 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_317: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_169, sub_169)
        sum_84: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_317, [-1]);  mul_317 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_73: "f32[100]" = torch.ops.aten.clamp_min.default(sum_84, 1e-12);  sum_84 = None
        sqrt_57: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_73);  clamp_min_73 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_590: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_57, -1);  sqrt_57 = None
        div_68: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_169, unsqueeze_590);  sub_169 = unsqueeze_590 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_318: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_170, div_68)
        sum_85: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_318, [-1]);  mul_318 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_591: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_85, -1);  sum_85 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_319: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_591, div_68);  unsqueeze_591 = None
        sub_171: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_170, mul_319);  sub_170 = mul_319 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_320: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_171, sub_171)
        sum_86: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_320, [-1]);  mul_320 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_74: "f32[100]" = torch.ops.aten.clamp_min.default(sum_86, 1e-12);  sum_86 = None
        sqrt_58: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_74);  clamp_min_74 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_592: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_58, -1);  sqrt_58 = None
        div_69: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_171, unsqueeze_592);  sub_171 = unsqueeze_592 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_169: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_68, [None, remainder])
        index_170: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_69, [None, remainder_1])
        mul_321: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_169, index_170);  index_169 = index_170 = None
        index_171: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_68, [None, remainder_1])
        index_172: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_69, [None, remainder])
        mul_322: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_171, index_172);  index_171 = index_172 = None
        sub_172: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_321, mul_322);  mul_321 = mul_322 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_593: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_68, 2);  div_68 = None
        unsqueeze_594: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_69, 2);  div_69 = None
        unsqueeze_595: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_172, 2);  sub_172 = None
        cat_47: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_593, unsqueeze_594, unsqueeze_595], -1);  unsqueeze_593 = unsqueeze_594 = unsqueeze_595 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_28: "f32[100, 1]" = torch.ops.aten.mean.dim(add_246, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_28: "f32[100, 1]" = torch.ops.aten.var.correction(add_246, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_174: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_246, mean_28);  add_246 = mean_28 = None
        add_251: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_28, 1e-05);  var_28 = None
        rsqrt_28: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_251);  add_251 = None
        mul_323: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_174, rsqrt_28);  sub_174 = rsqrt_28 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_324: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_323, arg152_1);  mul_323 = arg152_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_252: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_324, arg153_1);  mul_324 = arg153_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_599: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_252, 2);  add_252 = None
        permute_539: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_599, [0, 2, 1]);  unsqueeze_599 = None
        unsqueeze_600: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg154_1, 2);  arg154_1 = None
        permute_540: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_600, [2, 1, 0]);  unsqueeze_600 = None
        permute_541: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_539, [0, 2, 1]);  permute_539 = None
        view_528: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_541, [1, 100, 128]);  permute_541 = None
        permute_542: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_540, [2, 1, 0]);  permute_540 = None
        view_529: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_542, [1, 128, 768]);  permute_542 = None
        bmm_117: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_528, view_529);  view_529 = None
        view_530: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_117, [100, 1, 768]);  bmm_117 = None
        permute_543: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_530, [0, 2, 1]);  view_530 = None
        view_531: "f32[100, 768]" = torch.ops.aten.view.default(permute_543, [100, 768]);  permute_543 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_532: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_531, [100, 8, 96]);  view_531 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_4 = torch.ops.aten.split.Tensor(view_532, 32, -1);  view_532 = None
        getitem_59: "f32[100, 8, 32]" = split_4[0]
        getitem_60: "f32[100, 8, 32]" = split_4[1]
        getitem_61: "f32[100, 8, 32]" = split_4[2];  split_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_29: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_59, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_29: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_59, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_175: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_59, mean_29);  getitem_59 = mean_29 = None
        add_253: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_29, 1e-05);  var_29 = None
        rsqrt_29: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_253);  add_253 = None
        mul_325: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_175, rsqrt_29);  sub_175 = rsqrt_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_326: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_325, arg155_1);  mul_325 = arg155_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_254: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_326, arg156_1);  mul_326 = arg156_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_30: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_60, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_30: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_60, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_176: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_60, mean_30);  getitem_60 = mean_30 = None
        add_255: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_30, 1e-05);  var_30 = None
        rsqrt_30: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_255);  add_255 = None
        mul_327: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_176, rsqrt_30);  sub_176 = rsqrt_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_328: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_327, arg157_1);  mul_327 = arg157_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_256: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_328, arg158_1);  mul_328 = arg158_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_602: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg159_1, 2);  arg159_1 = None
        permute_545: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_602, [2, 1, 0]);  unsqueeze_602 = None
        permute_547: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_545, [2, 1, 0]);  permute_545 = None
        view_534: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_547, [1, 128, 576]);  permute_547 = None
        bmm_118: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_528, view_534);  view_528 = view_534 = None
        view_535: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_118, [100, 1, 576]);  bmm_118 = None
        permute_548: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_535, [0, 2, 1]);  view_535 = None
        view_536: "f32[100, 576]" = torch.ops.aten.view.default(permute_548, [100, 576]);  permute_548 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_537: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_536, [100, 192, 3]);  view_536 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_603: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_47, -3);  cat_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_604: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_70, -2);  select_70 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_549: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_603, [0, 1, 2, 3])
        unsqueeze_605: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_537, 3);  view_537 = None
        permute_550: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_605, [0, 1, 3, 2]);  unsqueeze_605 = None
        permute_551: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_549, [0, 2, 3, 1]);  permute_549 = None
        view_538: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_551, [100, 3, 3]);  permute_551 = None
        permute_552: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_550, [0, 3, 1, 2]);  permute_550 = None
        view_539: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_552, [100, 3, 192]);  permute_552 = None
        bmm_119: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_538, view_539);  view_538 = view_539 = None
        view_540: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_119, [100, 3, 1, 192]);  bmm_119 = None
        permute_553: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_540, [0, 3, 1, 2]);  view_540 = None
        view_541: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_553, [100, 192, 3]);  permute_553 = None
        add_257: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_541, unsqueeze_604);  view_541 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_542: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_257, [100, 8, 24, 3]);  add_257 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_384: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_542, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_387: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_542, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_390: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_542, 2, 16, 9223372036854775807);  view_542 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_606: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_244, 3);  add_244 = None
        permute_554: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_606, [0, 1, 3, 2])
        unsqueeze_607: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg160_1, 2);  arg160_1 = None
        unsqueeze_608: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_607, 3);  unsqueeze_607 = None
        permute_555: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_608, [2, 3, 1, 0]);  unsqueeze_608 = None
        permute_556: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_554, [0, 1, 3, 2]);  permute_554 = None
        view_543: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_556, [1, 6400, 64]);  permute_556 = None
        permute_557: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_555, [3, 2, 0, 1]);  permute_555 = None
        view_544: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_557, [1, 64, 8]);  permute_557 = None
        bmm_120: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_543, view_544);  view_543 = view_544 = None
        view_545: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_120, [100, 64, 1, 8]);  bmm_120 = None
        permute_558: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_545, [0, 1, 3, 2]);  view_545 = None
        view_546: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_558, [100, 64, 8]);  permute_558 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_13: "f32[8]" = torch.ops.aten.exp.default(arg161_1)
        log1p_4: "f32[8]" = torch.ops.aten.log1p.default(exp_13);  exp_13 = None
        gt_4: "b8[8]" = torch.ops.aten.gt.Scalar(arg161_1, 20)
        where_94: "f32[8]" = torch.ops.aten.where.self(gt_4, arg161_1, log1p_4);  gt_4 = arg161_1 = log1p_4 = None
        view_547: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_94, [1, 1, 8]);  where_94 = None
        mul_329: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_547, 0.16666666666666666);  view_547 = None
        div_70: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_329, 2);  mul_329 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_609: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_384, 1);  slice_384 = None
        index_173: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_387, [cat_42]);  slice_387 = None
        sub_177: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_609, index_173);  unsqueeze_609 = index_173 = None
        pow_12: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_177, 2);  sub_177 = None
        sum_87: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_12, [-1, -2]);  pow_12 = None
        mul_330: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_70, sum_87);  div_70 = sum_87 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_174: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_256, [cat_42]);  add_256 = None
        unsqueeze_610: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_254, 3);  add_254 = None
        permute_559: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_610, [0, 3, 1, 2]);  unsqueeze_610 = None
        permute_560: "f32[100, 64, 8, 32]" = torch.ops.aten.permute.default(index_174, [0, 1, 2, 3]);  index_174 = None
        permute_561: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_559, [0, 2, 3, 1]);  permute_559 = None
        view_548: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_561, [800, 1, 32]);  permute_561 = None
        permute_562: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(permute_560, [0, 2, 3, 1]);  permute_560 = None
        clone_60: "f32[100, 8, 32, 64]" = torch.ops.aten.clone.default(permute_562, memory_format = torch.contiguous_format);  permute_562 = None
        view_549: "f32[800, 32, 64]" = torch.ops.aten.view.default(clone_60, [800, 32, 64]);  clone_60 = None
        bmm_121: "f32[800, 1, 64]" = torch.ops.aten.bmm.default(view_548, view_549);  view_548 = view_549 = None
        view_550: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_121, [100, 8, 1, 64]);  bmm_121 = None
        permute_563: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_550, [0, 3, 1, 2]);  view_550 = None
        view_551: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_563, [100, 64, 8]);  permute_563 = None
        mul_331: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(view_551, 0.1767766952966369);  view_551 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_258: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_331, view_546);  mul_331 = view_546 = None
        sub_178: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_258, mul_330);  add_258 = mul_330 = None
        mul_332: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_178, 0.5773502691896257);  sub_178 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_49: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_48, ne_20);  bitwise_and_48 = ne_20 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_611: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_49, 2);  bitwise_and_49 = None
        where_95: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_611, mul_332, full_default_39);  mul_332 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_61: "f32[100, 64, 8]" = torch.ops.aten.clone.default(where_95, memory_format = torch.contiguous_format);  where_95 = None
        amax_4: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_61, [-2], True)
        sub_179: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(clone_61, amax_4);  clone_61 = amax_4 = None
        exp_14: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_179);  sub_179 = None
        sum_88: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_14, [-2], True)
        div_71: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_14, sum_88);  exp_14 = sum_88 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_96: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_611, div_71, full_default_40);  unsqueeze_611 = div_71 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_613: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_96, 3);  where_96 = None
        permute_564: "f32[100, 8, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_613, [0, 2, 3, 1])
        permute_565: "f32[100, 1, 64, 64]" = torch.ops.aten.permute.default(unsqueeze_606, [0, 3, 2, 1]);  unsqueeze_606 = None
        permute_566: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(permute_564, [0, 1, 3, 2]);  permute_564 = None
        view_552: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_566, [100, 8, 64])
        permute_567: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_565, [0, 3, 2, 1]);  permute_565 = None
        view_553: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_567, [100, 64, 64]);  permute_567 = None
        bmm_122: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_552, view_553);  view_552 = view_553 = None
        view_554: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_122, [100, 8, 1, 64]);  bmm_122 = None
        permute_568: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_554, [0, 1, 3, 2]);  view_554 = None
        view_555: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_568, [100, 8, 64]);  permute_568 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_175: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_61, [cat_42]);  getitem_61 = None
        permute_570: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(index_175, [0, 2, 3, 1]);  index_175 = None
        clone_62: "f32[100, 8, 64, 1]" = torch.ops.aten.clone.default(permute_566, memory_format = torch.contiguous_format);  permute_566 = None
        view_556: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_62, [800, 1, 64]);  clone_62 = None
        permute_572: "f32[100, 8, 64, 32]" = torch.ops.aten.permute.default(permute_570, [0, 1, 3, 2]);  permute_570 = None
        clone_63: "f32[100, 8, 64, 32]" = torch.ops.aten.clone.default(permute_572, memory_format = torch.contiguous_format);  permute_572 = None
        view_557: "f32[800, 64, 32]" = torch.ops.aten.view.default(clone_63, [800, 64, 32]);  clone_63 = None
        bmm_123: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_556, view_557);  view_556 = view_557 = None
        view_558: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_123, [100, 8, 1, 32]);  bmm_123 = None
        permute_573: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_558, [0, 1, 3, 2]);  view_558 = None
        view_559: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_573, [100, 8, 32]);  permute_573 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_176: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_390, [cat_42]);  slice_390 = cat_42 = None
        unsqueeze_617: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_613, 4);  unsqueeze_613 = None
        permute_574: "f32[100, 8, 1, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_617, [0, 2, 3, 4, 1]);  unsqueeze_617 = None
        permute_575: "f32[100, 8, 8, 3, 64]" = torch.ops.aten.permute.default(index_176, [0, 2, 3, 4, 1]);  index_176 = None
        permute_576: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.permute.default(permute_574, [0, 1, 4, 2, 3]);  permute_574 = None
        clone_64: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.clone.default(permute_576, memory_format = torch.contiguous_format);  permute_576 = None
        view_560: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_64, [800, 1, 64]);  clone_64 = None
        permute_577: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.permute.default(permute_575, [0, 1, 4, 2, 3]);  permute_575 = None
        clone_65: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.clone.default(permute_577, memory_format = torch.contiguous_format);  permute_577 = None
        view_561: "f32[800, 64, 24]" = torch.ops.aten.view.default(clone_65, [800, 64, 24]);  clone_65 = None
        bmm_124: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_560, view_561);  view_560 = view_561 = None
        view_562: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_124, [100, 8, 1, 8, 3]);  bmm_124 = None
        permute_578: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_562, [0, 1, 3, 4, 2]);  view_562 = None
        view_563: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_578, [100, 8, 8, 3]);  permute_578 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_620: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_603, -3);  unsqueeze_603 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_621: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_604, -2);  unsqueeze_604 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_180: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_563, unsqueeze_621);  view_563 = unsqueeze_621 = None
        permute_579: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_620, [0, 1, 2, 4, 3]);  unsqueeze_620 = None
        unsqueeze_622: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_180, 4);  sub_180 = None
        permute_580: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_622, [0, 1, 2, 4, 3]);  unsqueeze_622 = None
        permute_581: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_579, [0, 3, 4, 1, 2]);  permute_579 = None
        view_564: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_581, [100, 3, 3]);  permute_581 = None
        permute_582: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_580, [0, 4, 1, 2, 3]);  permute_580 = None
        view_565: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_582, [100, 3, 64]);  permute_582 = None
        bmm_125: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_564, view_565);  view_564 = view_565 = None
        view_566: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_125, [100, 3, 1, 8, 8]);  bmm_125 = None
        permute_583: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_566, [0, 3, 4, 1, 2]);  view_566 = None
        view_567: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_583, [100, 8, 8, 3]);  permute_583 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_333: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_567, view_567)
        sum_89: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_333, [-1]);  mul_333 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_75: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_89, 1e-12);  sum_89 = None
        sqrt_59: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_75);  clamp_min_75 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_568: "f32[100, 512]" = torch.ops.aten.view.default(view_555, [100, -1]);  view_555 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_569: "f32[100, 256]" = torch.ops.aten.view.default(view_559, [100, -1]);  view_559 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_66: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_567, memory_format = torch.contiguous_format);  view_567 = None
        view_570: "f32[100, 192]" = torch.ops.aten.view.default(clone_66, [100, 192]);  clone_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_571: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_59, [100, -1]);  sqrt_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_48: "f32[100, 1024]" = torch.ops.aten.cat.default([view_568, view_569, view_570, view_571], -1);  view_568 = view_569 = view_570 = view_571 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_623: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_48, 2);  cat_48 = None
        permute_584: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_623, [0, 2, 1]);  unsqueeze_623 = None
        unsqueeze_624: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg162_1, 2);  arg162_1 = None
        permute_585: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_624, [2, 1, 0]);  unsqueeze_624 = None
        permute_586: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_584, [0, 2, 1]);  permute_584 = None
        view_572: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_586, [1, 100, 1024]);  permute_586 = None
        permute_587: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_585, [2, 1, 0]);  permute_585 = None
        view_573: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_587, [1, 1024, 128]);  permute_587 = None
        bmm_126: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_572, view_573);  view_572 = view_573 = None
        view_574: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_126, [100, 1, 128]);  bmm_126 = None
        permute_588: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_574, [0, 2, 1]);  view_574 = None
        view_575: "f32[100, 128]" = torch.ops.aten.view.default(permute_588, [100, 128]);  permute_588 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_259: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_575, arg163_1);  view_575 = arg163_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_260: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_213, add_259);  add_213 = add_259 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_31: "f32[100, 1]" = torch.ops.aten.mean.dim(add_260, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_31: "f32[100, 1]" = torch.ops.aten.var.correction(add_260, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_181: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_260, mean_31);  mean_31 = None
        add_261: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_31, 1e-05);  var_31 = None
        rsqrt_31: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_261);  add_261 = None
        mul_334: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_181, rsqrt_31);  sub_181 = rsqrt_31 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_335: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_334, arg164_1);  mul_334 = arg164_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_262: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_335, arg165_1);  mul_335 = arg165_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_32: "f32[100, 1]" = torch.ops.aten.mean.dim(add_262, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_32: "f32[100, 1]" = torch.ops.aten.var.correction(add_262, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_187: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_262, mean_32);  add_262 = mean_32 = None
        add_267: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_32, 1e-05);  var_32 = None
        rsqrt_32: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_267);  add_267 = None
        mul_342: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_187, rsqrt_32);  sub_187 = rsqrt_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_343: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_342, arg166_1);  mul_342 = arg166_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_268: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_343, arg167_1);  mul_343 = arg167_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_634: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_268, 2);  add_268 = None
        permute_594: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_634, [0, 2, 1]);  unsqueeze_634 = None
        unsqueeze_635: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg168_1, 2);  arg168_1 = None
        permute_595: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_635, [2, 1, 0]);  unsqueeze_635 = None
        permute_596: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_594, [0, 2, 1]);  permute_594 = None
        view_580: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_596, [1, 100, 128]);  permute_596 = None
        permute_597: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_595, [2, 1, 0]);  permute_595 = None
        view_581: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_597, [1, 128, 768]);  permute_597 = None
        bmm_128: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_580, view_581);  view_581 = None
        view_582: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_128, [100, 1, 768]);  bmm_128 = None
        permute_598: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_582, [0, 2, 1]);  view_582 = None
        view_583: "f32[100, 768]" = torch.ops.aten.view.default(permute_598, [100, 768]);  permute_598 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_584: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_583, [100, 8, 96]);  view_583 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_5 = torch.ops.aten.split.Tensor(view_584, 32, -1);  view_584 = None
        getitem_62: "f32[100, 8, 32]" = split_5[0]
        getitem_63: "f32[100, 8, 32]" = split_5[1]
        getitem_64: "f32[100, 8, 32]" = split_5[2];  split_5 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_33: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_62, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_33: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_62, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_188: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_62, mean_33);  getitem_62 = mean_33 = None
        add_269: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_33, 1e-05);  var_33 = None
        rsqrt_33: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_269);  add_269 = None
        mul_344: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_188, rsqrt_33);  sub_188 = rsqrt_33 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_345: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_344, arg169_1);  mul_344 = arg169_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_270: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_345, arg170_1);  mul_345 = arg170_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_34: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_63, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_34: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_63, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_189: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_63, mean_34);  getitem_63 = mean_34 = None
        add_271: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_34, 1e-05);  var_34 = None
        rsqrt_34: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_271);  add_271 = None
        mul_346: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_189, rsqrt_34);  sub_189 = rsqrt_34 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_347: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_346, arg171_1);  mul_346 = arg171_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_272: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_347, arg172_1);  mul_347 = arg172_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_637: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg173_1, 2);  arg173_1 = None
        permute_600: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_637, [2, 1, 0]);  unsqueeze_637 = None
        permute_602: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_600, [2, 1, 0]);  permute_600 = None
        view_586: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_602, [1, 128, 576]);  permute_602 = None
        bmm_129: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_580, view_586);  view_580 = view_586 = None
        view_587: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_129, [100, 1, 576]);  bmm_129 = None
        permute_603: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_587, [0, 2, 1]);  view_587 = None
        view_588: "f32[100, 576]" = torch.ops.aten.view.default(permute_603, [100, 576]);  permute_603 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_589: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_588, [100, 192, 3]);  view_588 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        unsqueeze_640: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_589, 3);  view_589 = None
        permute_605: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_640, [0, 1, 3, 2]);  unsqueeze_640 = None
        permute_607: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_605, [0, 3, 1, 2]);  permute_605 = None
        view_591: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_607, [100, 3, 192]);  permute_607 = None
        bmm_130: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_168, view_591);  view_591 = None
        view_592: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_130, [100, 3, 1, 192]);  bmm_130 = None
        permute_608: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_592, [0, 3, 1, 2]);  view_592 = None
        view_593: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_608, [100, 192, 3]);  permute_608 = None
        add_273: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_593, unsqueeze_267);  view_593 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_594: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_273, [100, 8, 24, 3]);  add_273 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_401: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_594, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_404: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_594, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_407: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_594, 2, 16, 9223372036854775807);  view_594 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_641: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_61, 3);  select_61 = None
        permute_609: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_641, [0, 1, 3, 2])
        unsqueeze_642: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg174_1, 2);  arg174_1 = None
        unsqueeze_643: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_642, 3);  unsqueeze_642 = None
        permute_610: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_643, [2, 3, 1, 0]);  unsqueeze_643 = None
        permute_611: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_609, [0, 1, 3, 2]);  permute_609 = None
        view_595: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_611, [1, 4800, 64]);  permute_611 = None
        permute_612: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_610, [3, 2, 0, 1]);  permute_610 = None
        view_596: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_612, [1, 64, 8]);  permute_612 = None
        bmm_131: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_595, view_596);  view_595 = view_596 = None
        view_597: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_131, [100, 48, 1, 8]);  bmm_131 = None
        permute_613: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_597, [0, 1, 3, 2]);  view_597 = None
        view_598: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_613, [100, 48, 8]);  permute_613 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_15: "f32[8]" = torch.ops.aten.exp.default(arg175_1)
        log1p_5: "f32[8]" = torch.ops.aten.log1p.default(exp_15);  exp_15 = None
        gt_5: "b8[8]" = torch.ops.aten.gt.Scalar(arg175_1, 20)
        where_97: "f32[8]" = torch.ops.aten.where.self(gt_5, arg175_1, log1p_5);  gt_5 = arg175_1 = log1p_5 = None
        view_599: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_97, [1, 1, 8]);  where_97 = None
        mul_348: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_599, 0.16666666666666666);  view_599 = None
        div_75: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_348, 2);  mul_348 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_644: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_401, 1);  slice_401 = None
        index_181: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_404, [select_60]);  slice_404 = None
        sub_190: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_644, index_181);  unsqueeze_644 = index_181 = None
        pow_13: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_190, 2);  sub_190 = None
        sum_93: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_13, [-1, -2]);  pow_13 = None
        mul_349: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_75, sum_93);  div_75 = sum_93 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_182: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_272, [select_60]);  add_272 = None
        unsqueeze_645: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_270, 3);  add_270 = None
        permute_614: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_645, [0, 3, 1, 2]);  unsqueeze_645 = None
        permute_615: "f32[100, 48, 8, 32]" = torch.ops.aten.permute.default(index_182, [0, 1, 2, 3]);  index_182 = None
        permute_616: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_614, [0, 2, 3, 1]);  permute_614 = None
        view_600: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_616, [800, 1, 32]);  permute_616 = None
        permute_617: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(permute_615, [0, 2, 3, 1]);  permute_615 = None
        clone_67: "f32[100, 8, 32, 48]" = torch.ops.aten.clone.default(permute_617, memory_format = torch.contiguous_format);  permute_617 = None
        view_601: "f32[800, 32, 48]" = torch.ops.aten.view.default(clone_67, [800, 32, 48]);  clone_67 = None
        bmm_132: "f32[800, 1, 48]" = torch.ops.aten.bmm.default(view_600, view_601);  view_600 = view_601 = None
        view_602: "f32[100, 8, 1, 48]" = torch.ops.aten.view.default(bmm_132, [100, 8, 1, 48]);  bmm_132 = None
        permute_618: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_602, [0, 3, 1, 2]);  view_602 = None
        view_603: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_618, [100, 48, 8]);  permute_618 = None
        mul_350: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(view_603, 0.1767766952966369);  view_603 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_274: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_350, view_598);  mul_350 = view_598 = None
        sub_191: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_274, mul_349);  add_274 = mul_349 = None
        mul_351: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_191, 0.5773502691896257);  sub_191 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_22: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_60, -1)
        bitwise_and_50: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_62, ne_22);  select_62 = ne_22 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_646: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_50, 2);  bitwise_and_50 = None
        where_98: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_646, mul_351, full_default_41);  mul_351 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_68: "f32[100, 48, 8]" = torch.ops.aten.clone.default(where_98, memory_format = torch.contiguous_format);  where_98 = None
        amax_5: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_68, [-2], True)
        sub_192: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(clone_68, amax_5);  clone_68 = amax_5 = None
        exp_16: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_192);  sub_192 = None
        sum_94: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_16, [-2], True)
        div_76: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_16, sum_94);  exp_16 = sum_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_99: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_646, div_76, full_default_42);  unsqueeze_646 = div_76 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_648: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_99, 3);  where_99 = None
        permute_619: "f32[100, 8, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_648, [0, 2, 3, 1])
        permute_620: "f32[100, 1, 64, 48]" = torch.ops.aten.permute.default(unsqueeze_641, [0, 3, 2, 1]);  unsqueeze_641 = None
        permute_621: "f32[100, 8, 48, 1]" = torch.ops.aten.permute.default(permute_619, [0, 1, 3, 2]);  permute_619 = None
        view_604: "f32[100, 8, 48]" = torch.ops.aten.view.default(permute_621, [100, 8, 48])
        permute_622: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_620, [0, 3, 2, 1]);  permute_620 = None
        view_605: "f32[100, 48, 64]" = torch.ops.aten.view.default(permute_622, [100, 48, 64]);  permute_622 = None
        bmm_133: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_604, view_605);  view_604 = view_605 = None
        view_606: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_133, [100, 8, 1, 64]);  bmm_133 = None
        permute_623: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_606, [0, 1, 3, 2]);  view_606 = None
        view_607: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_623, [100, 8, 64]);  permute_623 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_183: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_64, [select_60]);  getitem_64 = None
        permute_625: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(index_183, [0, 2, 3, 1]);  index_183 = None
        clone_69: "f32[100, 8, 48, 1]" = torch.ops.aten.clone.default(permute_621, memory_format = torch.contiguous_format);  permute_621 = None
        view_608: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_69, [800, 1, 48]);  clone_69 = None
        permute_627: "f32[100, 8, 48, 32]" = torch.ops.aten.permute.default(permute_625, [0, 1, 3, 2]);  permute_625 = None
        clone_70: "f32[100, 8, 48, 32]" = torch.ops.aten.clone.default(permute_627, memory_format = torch.contiguous_format);  permute_627 = None
        view_609: "f32[800, 48, 32]" = torch.ops.aten.view.default(clone_70, [800, 48, 32]);  clone_70 = None
        bmm_134: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_608, view_609);  view_608 = view_609 = None
        view_610: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_134, [100, 8, 1, 32]);  bmm_134 = None
        permute_628: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_610, [0, 1, 3, 2]);  view_610 = None
        view_611: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_628, [100, 8, 32]);  permute_628 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_184: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_407, [select_60]);  slice_407 = select_60 = None
        unsqueeze_652: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_648, 4);  unsqueeze_648 = None
        permute_629: "f32[100, 8, 1, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_652, [0, 2, 3, 4, 1]);  unsqueeze_652 = None
        permute_630: "f32[100, 8, 8, 3, 48]" = torch.ops.aten.permute.default(index_184, [0, 2, 3, 4, 1]);  index_184 = None
        permute_631: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.permute.default(permute_629, [0, 1, 4, 2, 3]);  permute_629 = None
        clone_71: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.clone.default(permute_631, memory_format = torch.contiguous_format);  permute_631 = None
        view_612: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_71, [800, 1, 48]);  clone_71 = None
        permute_632: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.permute.default(permute_630, [0, 1, 4, 2, 3]);  permute_630 = None
        clone_72: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.clone.default(permute_632, memory_format = torch.contiguous_format);  permute_632 = None
        view_613: "f32[800, 48, 24]" = torch.ops.aten.view.default(clone_72, [800, 48, 24]);  clone_72 = None
        bmm_135: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_612, view_613);  view_612 = view_613 = None
        view_614: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_135, [100, 8, 1, 8, 3]);  bmm_135 = None
        permute_633: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_614, [0, 1, 3, 4, 2]);  view_614 = None
        view_615: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_633, [100, 8, 8, 3]);  permute_633 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_193: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_615, unsqueeze_284);  view_615 = None
        unsqueeze_657: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_193, 4);  sub_193 = None
        permute_635: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_657, [0, 1, 2, 4, 3]);  unsqueeze_657 = None
        permute_637: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_635, [0, 4, 1, 2, 3]);  permute_635 = None
        view_617: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_637, [100, 3, 64]);  permute_637 = None
        bmm_136: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_194, view_617);  view_617 = None
        view_618: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_136, [100, 3, 1, 8, 8]);  bmm_136 = None
        permute_638: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_618, [0, 3, 4, 1, 2]);  view_618 = None
        view_619: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_638, [100, 8, 8, 3]);  permute_638 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_352: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_619, view_619)
        sum_95: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_352, [-1]);  mul_352 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_78: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_95, 1e-12);  sum_95 = None
        sqrt_62: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_78);  clamp_min_78 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_620: "f32[100, 512]" = torch.ops.aten.view.default(view_607, [100, -1]);  view_607 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_621: "f32[100, 256]" = torch.ops.aten.view.default(view_611, [100, -1]);  view_611 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_73: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_619, memory_format = torch.contiguous_format);  view_619 = None
        view_622: "f32[100, 192]" = torch.ops.aten.view.default(clone_73, [100, 192]);  clone_73 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_623: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_62, [100, -1]);  sqrt_62 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_50: "f32[100, 1024]" = torch.ops.aten.cat.default([view_620, view_621, view_622, view_623], -1);  view_620 = view_621 = view_622 = view_623 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_658: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_50, 2);  cat_50 = None
        permute_639: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_658, [0, 2, 1]);  unsqueeze_658 = None
        unsqueeze_659: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg176_1, 2);  arg176_1 = None
        permute_640: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_659, [2, 1, 0]);  unsqueeze_659 = None
        permute_641: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_639, [0, 2, 1]);  permute_639 = None
        view_624: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_641, [1, 100, 1024]);  permute_641 = None
        permute_642: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_640, [2, 1, 0]);  permute_640 = None
        view_625: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_642, [1, 1024, 128]);  permute_642 = None
        bmm_137: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_624, view_625);  view_624 = view_625 = None
        view_626: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_137, [100, 1, 128]);  bmm_137 = None
        permute_643: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_626, [0, 2, 1]);  view_626 = None
        view_627: "f32[100, 128]" = torch.ops.aten.view.default(permute_643, [100, 128]);  permute_643 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_275: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_627, arg177_1);  view_627 = arg177_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_276: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_260, add_275);  add_260 = add_275 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_35: "f32[100, 1]" = torch.ops.aten.mean.dim(add_276, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_35: "f32[100, 1]" = torch.ops.aten.var.correction(add_276, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_194: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_276, mean_35);  mean_35 = None
        add_277: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_35, 1e-05);  var_35 = None
        rsqrt_35: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_277);  add_277 = None
        mul_353: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_194, rsqrt_35);  sub_194 = rsqrt_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_354: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_353, arg178_1);  mul_353 = arg178_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_278: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_354, arg179_1);  mul_354 = arg179_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_199: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_221, unsqueeze_553)
        permute_644: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_552, [0, 1, 3, 2])
        unsqueeze_668: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_199, 3);  sub_199 = None
        permute_645: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_668, [0, 1, 3, 2]);  unsqueeze_668 = None
        permute_646: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_644, [0, 2, 3, 1]);  permute_644 = None
        view_628: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_646, [100, 3, 3]);  permute_646 = None
        permute_647: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_645, [0, 3, 1, 2]);  permute_645 = None
        view_629: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_647, [100, 3, 20]);  permute_647 = None
        bmm_138: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_628, view_629);  view_628 = view_629 = None
        view_630: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_138, [100, 3, 1, 20]);  bmm_138 = None
        permute_648: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_630, [0, 3, 1, 2]);  view_630 = None
        view_631: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_648, [100, 20, 3]);  permute_648 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        clone_74: "f32[100, 20, 3]" = torch.ops.aten.clone.default(view_631, memory_format = torch.contiguous_format)
        view_632: "f32[100, 60]" = torch.ops.aten.view.default(clone_74, [100, 60]);  clone_74 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_670: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg180_1, 2);  arg180_1 = None
        permute_650: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_670, [2, 1, 0]);  unsqueeze_670 = None
        permute_652: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_650, [2, 1, 0]);  permute_650 = None
        view_634: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_652, [1, 128, 128]);  permute_652 = None
        bmm_139: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_211, view_634);  view_634 = None
        view_635: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_139, [100, 1, 128]);  bmm_139 = None
        permute_653: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_635, [0, 2, 1]);  view_635 = None
        view_636: "f32[100, 128]" = torch.ops.aten.view.default(permute_653, [100, 128]);  permute_653 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_283: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_278, view_636);  add_278 = view_636 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_671: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_632, 2);  view_632 = None
        permute_654: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_671, [0, 2, 1]);  unsqueeze_671 = None
        unsqueeze_672: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg181_1, 2);  arg181_1 = None
        permute_655: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_672, [2, 1, 0]);  unsqueeze_672 = None
        permute_656: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_654, [0, 2, 1]);  permute_654 = None
        view_637: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_656, [1, 100, 60]);  permute_656 = None
        permute_657: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_655, [2, 1, 0]);  permute_655 = None
        view_638: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_657, [1, 60, 256]);  permute_657 = None
        bmm_140: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_637, view_638);  view_637 = view_638 = None
        view_639: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_140, [100, 1, 256]);  bmm_140 = None
        permute_658: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_639, [0, 2, 1]);  view_639 = None
        view_640: "f32[100, 256]" = torch.ops.aten.view.default(permute_658, [100, 256]);  permute_658 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_284: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_640, arg182_1);  view_640 = arg182_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_361: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_284, add_284)
        mul_362: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_361, add_284);  mul_361 = None
        mul_363: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_362, 0.044715);  mul_362 = None
        add_285: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_284, mul_363);  mul_363 = None
        mul_364: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_285, 0.7978845608028654);  add_285 = None
        mul_365: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_284, 0.5);  add_284 = None
        tanh_13: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_364);  mul_364 = None
        add_286: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_13, 1);  tanh_13 = None
        mul_366: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_365, add_286);  mul_365 = add_286 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_673: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_366, 2);  mul_366 = None
        permute_659: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_673, [0, 2, 1]);  unsqueeze_673 = None
        unsqueeze_674: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg183_1, 2);  arg183_1 = None
        permute_660: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_674, [2, 1, 0]);  unsqueeze_674 = None
        permute_661: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_659, [0, 2, 1]);  permute_659 = None
        view_641: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_661, [1, 100, 256]);  permute_661 = None
        permute_662: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_660, [2, 1, 0]);  permute_660 = None
        view_642: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_662, [1, 256, 128]);  permute_662 = None
        bmm_141: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_641, view_642);  view_641 = view_642 = None
        view_643: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_141, [100, 1, 128]);  bmm_141 = None
        permute_663: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_643, [0, 2, 1]);  view_643 = None
        view_644: "f32[100, 128]" = torch.ops.aten.view.default(permute_663, [100, 128]);  permute_663 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_287: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_644, arg184_1);  view_644 = arg184_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_288: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_283, add_287);  add_283 = add_287 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_675: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_288, 2);  add_288 = None
        permute_664: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_675, [0, 2, 1]);  unsqueeze_675 = None
        unsqueeze_676: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg185_1, 2);  arg185_1 = None
        permute_665: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_676, [2, 1, 0]);  unsqueeze_676 = None
        permute_666: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_664, [0, 2, 1]);  permute_664 = None
        view_645: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_666, [1, 100, 128]);  permute_666 = None
        permute_667: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_665, [2, 1, 0]);  permute_665 = None
        view_646: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_667, [1, 128, 512]);  permute_667 = None
        bmm_142: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_645, view_646);  view_646 = None
        view_647: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_142, [100, 1, 512]);  bmm_142 = None
        permute_668: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_647, [0, 2, 1]);  view_647 = None
        view_648: "f32[100, 512]" = torch.ops.aten.view.default(permute_668, [100, 512]);  permute_668 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_678: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg186_1, 2);  arg186_1 = None
        permute_670: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_678, [2, 1, 0]);  unsqueeze_678 = None
        permute_672: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_670, [2, 1, 0]);  permute_670 = None
        view_650: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_672, [1, 128, 512]);  permute_672 = None
        bmm_143: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_645, view_650);  view_650 = None
        view_651: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_143, [100, 1, 512]);  bmm_143 = None
        permute_673: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_651, [0, 2, 1]);  view_651 = None
        view_652: "f32[100, 512]" = torch.ops.aten.view.default(permute_673, [100, 512]);  permute_673 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_367: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_652, view_652)
        mul_368: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_367, view_652);  mul_367 = None
        mul_369: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_368, 0.044715);  mul_368 = None
        add_289: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_652, mul_369);  mul_369 = None
        mul_370: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_289, 0.7978845608028654);  add_289 = None
        mul_371: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_652, 0.5);  view_652 = None
        tanh_14: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_370);  mul_370 = None
        add_290: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_14, 1);  tanh_14 = None
        mul_372: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_371, add_290);  mul_371 = add_290 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_373: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_372, view_648);  mul_372 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_680: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg187_1, 2);  arg187_1 = None
        permute_675: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_680, [2, 1, 0]);  unsqueeze_680 = None
        permute_677: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_675, [2, 1, 0]);  permute_675 = None
        view_654: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_677, [1, 128, 512]);  permute_677 = None
        bmm_144: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_645, view_654);  view_654 = None
        view_655: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_144, [100, 1, 512]);  bmm_144 = None
        permute_678: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_655, [0, 2, 1]);  view_655 = None
        view_656: "f32[100, 512]" = torch.ops.aten.view.default(permute_678, [100, 512]);  permute_678 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_374: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_656, view_656)
        mul_375: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_374, view_656);  mul_374 = None
        mul_376: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_375, 0.044715);  mul_375 = None
        add_291: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_656, mul_376);  mul_376 = None
        mul_377: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_291, 0.7978845608028654);  add_291 = None
        mul_378: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_656, 0.5);  view_656 = None
        tanh_15: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_377);  mul_377 = None
        add_292: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_15, 1);  tanh_15 = None
        mul_379: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_378, add_292);  mul_378 = add_292 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_682: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg188_1, 2);  arg188_1 = None
        permute_680: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_682, [2, 1, 0]);  unsqueeze_682 = None
        permute_682: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_680, [2, 1, 0]);  permute_680 = None
        view_658: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_682, [1, 128, 512]);  permute_682 = None
        bmm_145: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_645, view_658);  view_645 = view_658 = None
        view_659: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_145, [100, 1, 512]);  bmm_145 = None
        permute_683: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_659, [0, 2, 1]);  view_659 = None
        view_660: "f32[100, 512]" = torch.ops.aten.view.default(permute_683, [100, 512]);  permute_683 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_380: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_660, view_660)
        mul_381: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_380, view_660);  mul_380 = None
        mul_382: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_381, 0.044715);  mul_381 = None
        add_293: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_660, mul_382);  mul_382 = None
        mul_383: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_293, 0.7978845608028654);  add_293 = None
        mul_384: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_660, 0.5);  view_660 = None
        tanh_16: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_383);  mul_383 = None
        add_294: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_16, 1);  tanh_16 = None
        mul_385: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_384, add_294);  mul_384 = add_294 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_386: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_385, view_648);  mul_385 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_100: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_386, full_default_44);  mul_386 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_101: "f32[100, 512]" = torch.ops.aten.where.self(view_239, where_100, full_default_44);  where_100 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_8: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_6, where_101);  where_101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_189: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_8, [clamp_max_2]);  scatter_add_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_79: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_189, clamp_min_33);  index_189 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_104: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_79, full_default_44);  div_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_295: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_373, where_104);  mul_373 = where_104 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_388: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_379, view_648);  mul_379 = view_648 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_105: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_388, full_default_44);  mul_388 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_106: "f32[100, 512]" = torch.ops.aten.where.self(view_243, where_105, full_default_44);  where_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_10: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_8, where_106);  where_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_191: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_10, [clamp_max_4]);  scatter_add_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_80: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_191, clamp_min_36);  index_191 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_109: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_80, full_default_44);  div_80 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_296: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_295, where_109);  add_295 = where_109 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_684: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_296, 2);  add_296 = None
        permute_684: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_684, [0, 2, 1]);  unsqueeze_684 = None
        unsqueeze_685: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg189_1, 2);  arg189_1 = None
        permute_685: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_685, [2, 1, 0]);  unsqueeze_685 = None
        permute_686: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_684, [0, 2, 1]);  permute_684 = None
        view_669: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_686, [1, 100, 512]);  permute_686 = None
        permute_687: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_685, [2, 1, 0]);  permute_685 = None
        view_670: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_687, [1, 512, 128]);  permute_687 = None
        bmm_146: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_669, view_670);  view_669 = view_670 = None
        view_671: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_146, [100, 1, 128]);  bmm_146 = None
        permute_688: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_671, [0, 2, 1]);  view_671 = None
        view_672: "f32[100, 128]" = torch.ops.aten.view.default(permute_688, [100, 128]);  permute_688 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_297: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_672, arg190_1);  view_672 = arg190_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_298: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_276, add_297);  add_276 = add_297 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_36: "f32[100, 1]" = torch.ops.aten.mean.dim(add_298, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_36: "f32[100, 1]" = torch.ops.aten.var.correction(add_298, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_200: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_298, mean_36);  mean_36 = None
        add_299: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_36, 1e-05);  var_36 = None
        rsqrt_36: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_299);  add_299 = None
        mul_390: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_200, rsqrt_36);  sub_200 = rsqrt_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_391: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_390, arg191_1);  arg191_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_300: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_391, arg192_1);  mul_391 = arg192_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_695: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_300, 2);  add_300 = None
        permute_694: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_695, [0, 2, 1]);  unsqueeze_695 = None
        unsqueeze_696: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg193_1, 2);  arg193_1 = None
        permute_695: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_696, [2, 1, 0]);  unsqueeze_696 = None
        permute_696: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_694, [0, 2, 1]);  permute_694 = None
        view_677: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_696, [1, 100, 128]);  permute_696 = None
        permute_697: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_695, [2, 1, 0]);  permute_695 = None
        view_678: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_697, [1, 128, 60]);  permute_697 = None
        bmm_148: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_677, view_678);  view_677 = view_678 = None
        view_679: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_148, [100, 1, 60]);  bmm_148 = None
        permute_698: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_679, [0, 2, 1]);  view_679 = None
        view_680: "f32[100, 60]" = torch.ops.aten.view.default(permute_698, [100, 60]);  permute_698 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_398: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_680, 10.0);  view_680 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_681: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_398, [100, 20, 3]);  mul_398 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_305: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_631, view_681);  view_631 = view_681 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_699: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_552, [0, 1, 2, 3]);  unsqueeze_552 = None
        unsqueeze_699: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(add_305, 3);  add_305 = None
        permute_700: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_699, [0, 1, 3, 2]);  unsqueeze_699 = None
        permute_701: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_699, [0, 2, 3, 1]);  permute_699 = None
        view_682: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_701, [100, 3, 3]);  permute_701 = None
        permute_702: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_700, [0, 3, 1, 2]);  permute_700 = None
        view_683: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_702, [100, 3, 20]);  permute_702 = None
        bmm_149: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_682, view_683);  view_682 = view_683 = None
        view_684: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_149, [100, 3, 1, 20]);  bmm_149 = None
        permute_703: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_684, [0, 3, 1, 2]);  view_684 = None
        view_685: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_703, [100, 20, 3]);  permute_703 = None
        add_306: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_685, unsqueeze_553);  view_685 = unsqueeze_553 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_81: "f32[100, 3]" = torch.ops.aten.select.int(add_306, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_700: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_81, 1)
        unsqueeze_701: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_81, 0)
        sub_206: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_700, unsqueeze_701);  unsqueeze_700 = unsqueeze_701 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_399: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_206, sub_206);  sub_206 = None
        sum_102: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_399, [-1]);  mul_399 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_89: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_102, 1e-12);  sum_102 = None
        sqrt_67: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_89);  clamp_min_89 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_110: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_67, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_111: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_110, full_default);  where_110 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_198: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_111, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_112: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_198);  index_198 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_13: "f32[100, 100]" = torch.ops.aten.index_put.default(where_111, [unsqueeze_24, where_1], where_112);  where_111 = where_112 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_14 = torch.ops.aten.sort.stable(index_put_13, stable = True)
        getitem_66: "i64[100, 100]" = sort_14[1];  sort_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_435: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_66, 1, 0, 16);  getitem_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_199: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_13, [unsqueeze_24, slice_435]);  index_put_13 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_26: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_199, inf);  index_199 = None
        where_113: "i64[100, 16]" = torch.ops.aten.where.self(lt_26, slice_435, full_default_1);  lt_26 = slice_435 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_53: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_113], -1);  where_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_307: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_67, 1e-06);  sqrt_67 = None
        log_27: "f32[100, 100]" = torch.ops.aten.log.default(add_307);  add_307 = None
        mul_400: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_27, -3.0);  log_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_28: "f32[100, 100]" = torch.ops.aten.log.default(getitem_10)
        neg_23: "f32[100, 100]" = torch.ops.aten.neg.default(log_28);  log_28 = None
        log_29: "f32[100, 100]" = torch.ops.aten.log.default(neg_23);  neg_23 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_207: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_400, log_29);  mul_400 = log_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_24: "f32[100, 100]" = torch.ops.aten.neg.default(sub_207);  sub_207 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_114: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_24, full_default);  neg_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_115: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_114, full_default);  where_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_24: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_53, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_201: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_115, [unsqueeze_24, cat_53])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_116: "f32[100, 32]" = torch.ops.aten.where.self(ne_24, full_default_7, index_201);  ne_24 = index_201 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_14: "f32[100, 100]" = torch.ops.aten.index_put.default(where_115, [unsqueeze_24, cat_53], where_116);  where_115 = where_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_15 = torch.ops.aten.sort.stable(index_put_14, stable = True)
        getitem_68: "i64[100, 100]" = sort_15[1];  sort_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_444: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_68, 1, 0, 32);  getitem_68 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_202: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_14, [unsqueeze_24, slice_444]);  index_put_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_27: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_202, inf);  index_202 = None
        where_117: "i64[100, 32]" = torch.ops.aten.where.self(lt_27, slice_444, full_default_37);  lt_27 = slice_444 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_54: "i64[100, 64]" = torch.ops.aten.cat.default([cat_53, where_117], -1);  cat_53 = where_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_82: "i64[100, 48]" = torch.ops.aten.select.int(view_14, 0, 3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_83: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_52, 0, 3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_84: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_203: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_54])
        bitwise_and_59: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_203);  index_203 = None
        ne_25: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_54, -1)
        bitwise_and_60: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_59, ne_25);  bitwise_and_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_204: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_54])
        eq_25: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_204);  index_204 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_205: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_54])
        eq_26: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_205);  index_205 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_206: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_54])
        sub_208: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_206);  index_206 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_90: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_208, -32);  sub_208 = None
        clamp_max_16: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_90, 32);  clamp_min_90 = None
        add_308: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_16, 32);  clamp_max_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_118: "i64[100, 64]" = torch.ops.aten.where.self(eq_25, add_308, full_default_38);  eq_25 = add_308 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_119: "i64[100, 64]" = torch.ops.aten.where.self(eq_26, where_118, full_default_38);  eq_26 = where_118 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_207: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg194_1, [where_119]);  arg194_1 = where_119 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_722: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_306, 1)
        slice_451: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_722, 2, 0, 5)
        unsqueeze_723: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_451, 3);  slice_451 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_208: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_306, [cat_54])
        unsqueeze_724: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_208, 2)
        slice_455: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_724, 3, 0, 5);  unsqueeze_724 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_209: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_723, slice_455);  unsqueeze_723 = slice_455 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_401: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_209, sub_209);  sub_209 = None
        sum_103: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_401, [-1]);  mul_401 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_91: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_103, 1e-12);  sum_103 = None
        sqrt_68: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_91);  clamp_min_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_686: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_68, [100, 64, 25]);  sqrt_68 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_725: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_686, 3);  view_686 = None
        sub_210: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_725, add_29);  unsqueeze_725 = None
        pow_14: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_210, 2);  sub_210 = None
        neg_25: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_14);  pow_14 = None
        div_83: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_25, 1.890625);  neg_25 = None
        exp_17: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_83);  div_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_687: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_17, [100, 64, 400]);  exp_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_726: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_687, 3);  view_687 = None
        permute_704: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_726, [0, 1, 3, 2]);  unsqueeze_726 = None
        unsqueeze_727: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg195_1, 2);  arg195_1 = None
        unsqueeze_728: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_727, 3);  unsqueeze_727 = None
        permute_705: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_728, [2, 3, 1, 0]);  unsqueeze_728 = None
        permute_706: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_704, [0, 1, 3, 2]);  permute_704 = None
        view_688: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_706, [1, 6400, 400]);  permute_706 = None
        permute_707: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_705, [3, 2, 0, 1]);  permute_705 = None
        view_689: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_707, [1, 400, 64]);  permute_707 = None
        bmm_150: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_688, view_689);  view_688 = view_689 = None
        view_690: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_150, [100, 64, 1, 64]);  bmm_150 = None
        permute_708: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_690, [0, 1, 3, 2]);  view_690 = None
        view_691: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_708, [100, 64, 64]);  permute_708 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_312: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_207, view_691);  index_207 = view_691 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_85: "f32[100, 3]" = torch.ops.aten.select.int(add_306, 1, 0)
        select_87: "f32[100, 3]" = torch.ops.aten.select.int(add_306, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_211: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_87, select_81);  select_87 = None
        sub_212: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_85, select_81);  select_85 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_404: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_211, sub_211)
        sum_104: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_404, [-1]);  mul_404 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_92: "f32[100]" = torch.ops.aten.clamp_min.default(sum_104, 1e-12);  sum_104 = None
        sqrt_69: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_92);  clamp_min_92 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_729: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_69, -1);  sqrt_69 = None
        div_84: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_211, unsqueeze_729);  sub_211 = unsqueeze_729 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_405: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_212, div_84)
        sum_105: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_405, [-1]);  mul_405 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_730: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_105, -1);  sum_105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_406: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_730, div_84);  unsqueeze_730 = None
        sub_213: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_212, mul_406);  sub_212 = mul_406 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_407: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_213, sub_213)
        sum_106: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_407, [-1]);  mul_407 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_93: "f32[100]" = torch.ops.aten.clamp_min.default(sum_106, 1e-12);  sum_106 = None
        sqrt_70: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_93);  clamp_min_93 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_731: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_70, -1);  sqrt_70 = None
        div_85: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_213, unsqueeze_731);  sub_213 = unsqueeze_731 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_209: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_84, [None, remainder])
        index_210: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_85, [None, remainder_1])
        mul_408: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_209, index_210);  index_209 = index_210 = None
        index_211: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_84, [None, remainder_1])
        index_212: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_85, [None, remainder])
        mul_409: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_211, index_212);  index_211 = index_212 = None
        sub_214: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_408, mul_409);  mul_408 = mul_409 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_732: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_84, 2);  div_84 = None
        unsqueeze_733: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_85, 2);  div_85 = None
        unsqueeze_734: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_214, 2);  sub_214 = None
        cat_55: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_732, unsqueeze_733, unsqueeze_734], -1);  unsqueeze_732 = unsqueeze_733 = unsqueeze_734 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_738: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_55, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_739: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_81, -2);  select_81 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_740: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_738, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_741: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_739, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_216: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_208, unsqueeze_741)
        permute_714: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_740, [0, 1, 2, 4, 3]);  unsqueeze_740 = None
        unsqueeze_742: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_216, 4);  sub_216 = None
        permute_715: "f32[100, 64, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_742, [0, 1, 2, 4, 3]);  unsqueeze_742 = None
        permute_716: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_714, [0, 3, 4, 1, 2]);  permute_714 = None
        view_696: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_716, [100, 3, 3]);  permute_716 = None
        permute_717: "f32[100, 3, 64, 20, 1]" = torch.ops.aten.permute.default(permute_715, [0, 4, 1, 2, 3]);  permute_715 = None
        view_697: "f32[100, 3, 1280]" = torch.ops.aten.view.default(permute_717, [100, 3, 1280]);  permute_717 = None
        bmm_152: "f32[100, 3, 1280]" = torch.ops.aten.bmm.default(view_696, view_697);  view_697 = None
        view_698: "f32[100, 3, 1, 64, 20]" = torch.ops.aten.view.default(bmm_152, [100, 3, 1, 64, 20]);  bmm_152 = None
        permute_718: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.permute.default(view_698, [0, 3, 4, 1, 2]);  view_698 = None
        view_699: "f32[100, 64, 20, 3]" = torch.ops.aten.view.default(permute_718, [100, 64, 20, 3]);  permute_718 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_410: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(view_699, view_699)
        sum_107: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_410, [-1]);  mul_410 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_94: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_107, 1e-12);  sum_107 = None
        sqrt_71: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_94);  clamp_min_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_743: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_71, -1);  sqrt_71 = None
        div_86: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(view_699, unsqueeze_743);  view_699 = unsqueeze_743 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        clone_77: "f32[100, 64, 20, 3]" = torch.ops.aten.clone.default(div_86, memory_format = torch.contiguous_format);  div_86 = None
        view_700: "f32[100, 64, 60]" = torch.ops.aten.view.default(clone_77, [100, 64, 60]);  clone_77 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_24: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_722, [100, 64, 20, 3]);  unsqueeze_722 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_56: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_24, index_208], -2);  expand_24 = index_208 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_217: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_56, unsqueeze_741);  cat_56 = unsqueeze_741 = None
        unsqueeze_749: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_217, 4);  sub_217 = None
        permute_720: "f32[100, 64, 40, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_749, [0, 1, 2, 4, 3]);  unsqueeze_749 = None
        permute_722: "f32[100, 3, 64, 40, 1]" = torch.ops.aten.permute.default(permute_720, [0, 4, 1, 2, 3]);  permute_720 = None
        view_702: "f32[100, 3, 2560]" = torch.ops.aten.view.default(permute_722, [100, 3, 2560]);  permute_722 = None
        bmm_153: "f32[100, 3, 2560]" = torch.ops.aten.bmm.default(view_696, view_702);  view_696 = view_702 = None
        view_703: "f32[100, 3, 1, 64, 40]" = torch.ops.aten.view.default(bmm_153, [100, 3, 1, 64, 40]);  bmm_153 = None
        permute_723: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.permute.default(view_703, [0, 3, 4, 1, 2]);  view_703 = None
        view_704: "f32[100, 64, 40, 3]" = torch.ops.aten.view.default(permute_723, [100, 64, 40, 3]);  permute_723 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_411: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_704, view_704)
        sum_108: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_411, [-1]);  mul_411 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_95: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_108, 1e-12);  sum_108 = None
        sqrt_72: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_95);  clamp_min_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_750: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_72, -1);  sqrt_72 = None
        div_87: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(view_704, unsqueeze_750);  unsqueeze_750 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        clone_78: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(div_87, memory_format = torch.contiguous_format);  div_87 = None
        view_705: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_78, [100, 64, 120]);  clone_78 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_412: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_704, 0.1);  view_704 = None
        clone_79: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(mul_412, memory_format = torch.contiguous_format);  mul_412 = None
        view_706: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_79, [100, 64, 120]);  clone_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_57: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_705, view_706], -1);  view_705 = view_706 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_751: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_700, 3);  view_700 = None
        permute_724: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_751, [0, 1, 3, 2]);  unsqueeze_751 = None
        unsqueeze_752: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg196_1, 2);  arg196_1 = None
        unsqueeze_753: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_752, 3);  unsqueeze_752 = None
        permute_725: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_753, [2, 3, 1, 0]);  unsqueeze_753 = None
        permute_726: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_724, [0, 1, 3, 2]);  permute_724 = None
        view_707: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_726, [1, 6400, 60]);  permute_726 = None
        permute_727: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_725, [3, 2, 0, 1]);  permute_725 = None
        view_708: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_727, [1, 60, 64]);  permute_727 = None
        bmm_154: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_707, view_708);  view_707 = view_708 = None
        view_709: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_154, [100, 64, 1, 64]);  bmm_154 = None
        permute_728: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_709, [0, 1, 3, 2]);  view_709 = None
        view_710: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_728, [100, 64, 64]);  permute_728 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_317: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_312, view_710);  add_312 = view_710 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_763: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_55, 1)
        permute_734: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_763, [0, 1, 3, 2]);  unsqueeze_763 = None
        index_218: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_55, [cat_54]);  cat_55 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:78 in rot_compose, code: return a @ b
        expand_25: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(permute_734, [100, 64, 3, 3]);  permute_734 = None
        clone_80: "f32[100, 64, 3, 3]" = torch.ops.aten.clone.default(expand_25, memory_format = torch.contiguous_format);  expand_25 = None
        view_715: "f32[6400, 3, 3]" = torch.ops.aten.view.default(clone_80, [6400, 3, 3]);  clone_80 = None
        expand_26: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(index_218, [100, 64, 3, 3]);  index_218 = None
        view_716: "f32[6400, 3, 3]" = torch.ops.aten.view.default(expand_26, [6400, 3, 3]);  expand_26 = None
        bmm_156: "f32[6400, 3, 3]" = torch.ops.aten.bmm.default(view_715, view_716);  view_715 = view_716 = None
        view_717: "f32[100, 64, 3, 3]" = torch.ops.aten.view.default(bmm_156, [100, 64, 3, 3]);  bmm_156 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_718: "f32[100, 64, 9]" = torch.ops.aten.view.default(view_717, [100, 64, 9]);  view_717 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_764: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_718, 3);  view_718 = None
        permute_735: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_764, [0, 1, 3, 2]);  unsqueeze_764 = None
        unsqueeze_765: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg197_1, 2);  arg197_1 = None
        unsqueeze_766: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_765, 3);  unsqueeze_765 = None
        permute_736: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_766, [2, 3, 1, 0]);  unsqueeze_766 = None
        permute_737: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_735, [0, 1, 3, 2]);  permute_735 = None
        view_719: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_737, [1, 6400, 9]);  permute_737 = None
        permute_738: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_736, [3, 2, 0, 1]);  permute_736 = None
        view_720: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_738, [1, 9, 64]);  permute_738 = None
        bmm_157: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_719, view_720);  view_719 = view_720 = None
        view_721: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_157, [100, 64, 1, 64]);  bmm_157 = None
        permute_739: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_721, [0, 1, 3, 2]);  view_721 = None
        view_722: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_739, [100, 64, 64]);  permute_739 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_322: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_317, view_722);  add_317 = view_722 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_767: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_57, 3);  cat_57 = None
        permute_740: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_767, [0, 1, 3, 2]);  unsqueeze_767 = None
        unsqueeze_768: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg198_1, 2);  arg198_1 = None
        unsqueeze_769: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_768, 3);  unsqueeze_768 = None
        permute_741: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_769, [2, 3, 1, 0]);  unsqueeze_769 = None
        permute_742: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_740, [0, 1, 3, 2]);  permute_740 = None
        view_723: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_742, [1, 6400, 240]);  permute_742 = None
        permute_743: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_741, [3, 2, 0, 1]);  permute_741 = None
        view_724: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_743, [1, 240, 64]);  permute_743 = None
        bmm_158: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_723, view_724);  view_723 = view_724 = None
        view_725: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_158, [100, 64, 1, 64]);  bmm_158 = None
        permute_744: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_725, [0, 1, 3, 2]);  view_725 = None
        view_726: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_744, [100, 64, 64]);  permute_744 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_323: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_322, view_726);  add_322 = view_726 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_37: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_323, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_37: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_323, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_223: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_323, mean_37);  add_323 = mean_37 = None
        add_324: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_37, 1e-05);  var_37 = None
        rsqrt_37: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_324);  add_324 = None
        mul_419: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_223, rsqrt_37);  sub_223 = rsqrt_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_420: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_419, arg199_1);  mul_419 = arg199_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_325: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_420, arg200_1);  mul_420 = arg200_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_770: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_325, 3);  add_325 = None
        permute_745: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_770, [0, 1, 3, 2]);  unsqueeze_770 = None
        unsqueeze_771: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg201_1, 2);  arg201_1 = None
        unsqueeze_772: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_771, 3);  unsqueeze_771 = None
        permute_746: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_772, [2, 3, 1, 0]);  unsqueeze_772 = None
        permute_747: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_745, [0, 1, 3, 2]);  permute_745 = None
        view_727: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_747, [1, 6400, 64]);  permute_747 = None
        permute_748: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_746, [3, 2, 0, 1]);  permute_746 = None
        view_728: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_748, [1, 64, 128]);  permute_748 = None
        bmm_159: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_727, view_728);  view_727 = view_728 = None
        view_729: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_159, [100, 64, 1, 128]);  bmm_159 = None
        permute_749: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_729, [0, 1, 3, 2]);  view_729 = None
        view_730: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_749, [100, 64, 128]);  permute_749 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_326: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_730, arg202_1);  view_730 = arg202_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_421: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_326, add_326)
        mul_422: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_421, add_326);  mul_421 = None
        mul_423: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_422, 0.044715);  mul_422 = None
        add_327: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_326, mul_423);  mul_423 = None
        mul_424: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_327, 0.7978845608028654);  add_327 = None
        mul_425: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_326, 0.5);  add_326 = None
        tanh_17: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_424);  mul_424 = None
        add_328: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_17, 1);  tanh_17 = None
        mul_426: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_425, add_328);  mul_425 = add_328 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_773: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_426, 3);  mul_426 = None
        permute_750: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_773, [0, 1, 3, 2]);  unsqueeze_773 = None
        unsqueeze_774: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg203_1, 2);  arg203_1 = None
        unsqueeze_775: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_774, 3);  unsqueeze_774 = None
        permute_751: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_775, [2, 3, 1, 0]);  unsqueeze_775 = None
        permute_752: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_750, [0, 1, 3, 2]);  permute_750 = None
        view_731: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_752, [1, 6400, 128]);  permute_752 = None
        permute_753: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_751, [3, 2, 0, 1]);  permute_751 = None
        view_732: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_753, [1, 128, 64]);  permute_753 = None
        bmm_160: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_731, view_732);  view_731 = view_732 = None
        view_733: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_160, [100, 64, 1, 64]);  bmm_160 = None
        permute_754: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_733, [0, 1, 3, 2]);  view_733 = None
        view_734: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_754, [100, 64, 64]);  permute_754 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_329: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_734, arg204_1);  view_734 = arg204_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_428: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_390, arg205_1);  mul_390 = arg205_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_331: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_428, arg206_1);  mul_428 = arg206_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_90: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_306, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_91: "f32[100, 3]" = torch.ops.aten.select.int(div_90, 1, 0)
        select_92: "f32[100, 3]" = torch.ops.aten.select.int(div_90, 1, 1)
        select_93: "f32[100, 3]" = torch.ops.aten.select.int(div_90, 1, 2);  div_90 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_225: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_93, select_92);  select_93 = None
        sub_226: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_91, select_92);  select_91 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_429: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_225, sub_225)
        sum_112: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_429, [-1]);  mul_429 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_98: "f32[100]" = torch.ops.aten.clamp_min.default(sum_112, 1e-12);  sum_112 = None
        sqrt_75: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_98);  clamp_min_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_776: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_75, -1);  sqrt_75 = None
        div_91: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_225, unsqueeze_776);  sub_225 = unsqueeze_776 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_430: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_226, div_91)
        sum_113: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_430, [-1]);  mul_430 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_777: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_113, -1);  sum_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_431: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_777, div_91);  unsqueeze_777 = None
        sub_227: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_226, mul_431);  sub_226 = mul_431 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_432: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_227, sub_227)
        sum_114: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_432, [-1]);  mul_432 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_99: "f32[100]" = torch.ops.aten.clamp_min.default(sum_114, 1e-12);  sum_114 = None
        sqrt_76: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_99);  clamp_min_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_778: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_76, -1);  sqrt_76 = None
        div_92: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_227, unsqueeze_778);  sub_227 = unsqueeze_778 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_219: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_91, [None, remainder])
        index_220: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_92, [None, remainder_1])
        mul_433: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_219, index_220);  index_219 = index_220 = None
        index_221: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_91, [None, remainder_1])
        index_222: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_92, [None, remainder])
        mul_434: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_221, index_222);  index_221 = index_222 = None
        sub_228: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_433, mul_434);  mul_433 = mul_434 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_779: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_91, 2);  div_91 = None
        unsqueeze_780: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_92, 2);  div_92 = None
        unsqueeze_781: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_228, 2);  sub_228 = None
        cat_59: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_779, unsqueeze_780, unsqueeze_781], -1);  unsqueeze_779 = unsqueeze_780 = unsqueeze_781 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_39: "f32[100, 1]" = torch.ops.aten.mean.dim(add_331, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_39: "f32[100, 1]" = torch.ops.aten.var.correction(add_331, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_230: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_331, mean_39);  add_331 = mean_39 = None
        add_336: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_39, 1e-05);  var_39 = None
        rsqrt_39: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_336);  add_336 = None
        mul_435: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_230, rsqrt_39);  sub_230 = rsqrt_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_436: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_435, arg207_1);  mul_435 = arg207_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_337: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_436, arg208_1);  mul_436 = arg208_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_785: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_337, 2);  add_337 = None
        permute_760: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_785, [0, 2, 1]);  unsqueeze_785 = None
        unsqueeze_786: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg209_1, 2);  arg209_1 = None
        permute_761: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_786, [2, 1, 0]);  unsqueeze_786 = None
        permute_762: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_760, [0, 2, 1]);  permute_760 = None
        view_739: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_762, [1, 100, 128]);  permute_762 = None
        permute_763: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_761, [2, 1, 0]);  permute_761 = None
        view_740: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_763, [1, 128, 768]);  permute_763 = None
        bmm_162: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_739, view_740);  view_740 = None
        view_741: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_162, [100, 1, 768]);  bmm_162 = None
        permute_764: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_741, [0, 2, 1]);  view_741 = None
        view_742: "f32[100, 768]" = torch.ops.aten.view.default(permute_764, [100, 768]);  permute_764 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_743: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_742, [100, 8, 96]);  view_742 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_6 = torch.ops.aten.split.Tensor(view_743, 32, -1);  view_743 = None
        getitem_69: "f32[100, 8, 32]" = split_6[0]
        getitem_70: "f32[100, 8, 32]" = split_6[1]
        getitem_71: "f32[100, 8, 32]" = split_6[2];  split_6 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_40: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_69, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_40: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_69, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_231: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_69, mean_40);  getitem_69 = mean_40 = None
        add_338: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_40, 1e-05);  var_40 = None
        rsqrt_40: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_338);  add_338 = None
        mul_437: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_231, rsqrt_40);  sub_231 = rsqrt_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_438: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_437, arg210_1);  mul_437 = arg210_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_339: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_438, arg211_1);  mul_438 = arg211_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_41: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_70, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_41: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_70, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_232: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_70, mean_41);  getitem_70 = mean_41 = None
        add_340: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_41, 1e-05);  var_41 = None
        rsqrt_41: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_340);  add_340 = None
        mul_439: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_232, rsqrt_41);  sub_232 = rsqrt_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_440: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_439, arg212_1);  mul_439 = arg212_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_341: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_440, arg213_1);  mul_440 = arg213_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_788: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg214_1, 2);  arg214_1 = None
        permute_766: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_788, [2, 1, 0]);  unsqueeze_788 = None
        permute_768: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_766, [2, 1, 0]);  permute_766 = None
        view_745: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_768, [1, 128, 576]);  permute_768 = None
        bmm_163: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_739, view_745);  view_739 = view_745 = None
        view_746: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_163, [100, 1, 576]);  bmm_163 = None
        permute_769: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_746, [0, 2, 1]);  view_746 = None
        view_747: "f32[100, 576]" = torch.ops.aten.view.default(permute_769, [100, 576]);  permute_769 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_748: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_747, [100, 192, 3]);  view_747 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_789: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_59, -3);  cat_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_790: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_92, -2);  select_92 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_770: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_789, [0, 1, 2, 3])
        unsqueeze_791: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_748, 3);  view_748 = None
        permute_771: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_791, [0, 1, 3, 2]);  unsqueeze_791 = None
        permute_772: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_770, [0, 2, 3, 1]);  permute_770 = None
        view_749: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_772, [100, 3, 3]);  permute_772 = None
        permute_773: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_771, [0, 3, 1, 2]);  permute_771 = None
        view_750: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_773, [100, 3, 192]);  permute_773 = None
        bmm_164: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_749, view_750);  view_749 = view_750 = None
        view_751: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_164, [100, 3, 1, 192]);  bmm_164 = None
        permute_774: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_751, [0, 3, 1, 2]);  view_751 = None
        view_752: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_774, [100, 192, 3]);  permute_774 = None
        add_342: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_752, unsqueeze_790);  view_752 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_753: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_342, [100, 8, 24, 3]);  add_342 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_482: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_753, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_485: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_753, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_488: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_753, 2, 16, 9223372036854775807);  view_753 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_792: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_329, 3);  add_329 = None
        permute_775: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_792, [0, 1, 3, 2])
        unsqueeze_793: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg215_1, 2);  arg215_1 = None
        unsqueeze_794: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_793, 3);  unsqueeze_793 = None
        permute_776: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_794, [2, 3, 1, 0]);  unsqueeze_794 = None
        permute_777: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_775, [0, 1, 3, 2]);  permute_775 = None
        view_754: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_777, [1, 6400, 64]);  permute_777 = None
        permute_778: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_776, [3, 2, 0, 1]);  permute_776 = None
        view_755: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_778, [1, 64, 8]);  permute_778 = None
        bmm_165: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_754, view_755);  view_754 = view_755 = None
        view_756: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_165, [100, 64, 1, 8]);  bmm_165 = None
        permute_779: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_756, [0, 1, 3, 2]);  view_756 = None
        view_757: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_779, [100, 64, 8]);  permute_779 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_18: "f32[8]" = torch.ops.aten.exp.default(arg216_1)
        log1p_6: "f32[8]" = torch.ops.aten.log1p.default(exp_18);  exp_18 = None
        gt_6: "b8[8]" = torch.ops.aten.gt.Scalar(arg216_1, 20)
        where_120: "f32[8]" = torch.ops.aten.where.self(gt_6, arg216_1, log1p_6);  gt_6 = arg216_1 = log1p_6 = None
        view_758: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_120, [1, 1, 8]);  where_120 = None
        mul_441: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_758, 0.16666666666666666);  view_758 = None
        div_93: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_441, 2);  mul_441 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_795: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_482, 1);  slice_482 = None
        index_223: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_485, [cat_54]);  slice_485 = None
        sub_233: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_795, index_223);  unsqueeze_795 = index_223 = None
        pow_15: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_233, 2);  sub_233 = None
        sum_115: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_15, [-1, -2]);  pow_15 = None
        mul_442: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_93, sum_115);  div_93 = sum_115 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_224: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_341, [cat_54]);  add_341 = None
        unsqueeze_796: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_339, 3);  add_339 = None
        permute_780: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_796, [0, 3, 1, 2]);  unsqueeze_796 = None
        permute_781: "f32[100, 64, 8, 32]" = torch.ops.aten.permute.default(index_224, [0, 1, 2, 3]);  index_224 = None
        permute_782: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_780, [0, 2, 3, 1]);  permute_780 = None
        view_759: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_782, [800, 1, 32]);  permute_782 = None
        permute_783: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(permute_781, [0, 2, 3, 1]);  permute_781 = None
        clone_81: "f32[100, 8, 32, 64]" = torch.ops.aten.clone.default(permute_783, memory_format = torch.contiguous_format);  permute_783 = None
        view_760: "f32[800, 32, 64]" = torch.ops.aten.view.default(clone_81, [800, 32, 64]);  clone_81 = None
        bmm_166: "f32[800, 1, 64]" = torch.ops.aten.bmm.default(view_759, view_760);  view_759 = view_760 = None
        view_761: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_166, [100, 8, 1, 64]);  bmm_166 = None
        permute_784: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_761, [0, 3, 1, 2]);  view_761 = None
        view_762: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_784, [100, 64, 8]);  permute_784 = None
        mul_443: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(view_762, 0.1767766952966369);  view_762 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_343: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_443, view_757);  mul_443 = view_757 = None
        sub_234: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_343, mul_442);  add_343 = mul_442 = None
        mul_444: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_234, 0.5773502691896257);  sub_234 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_61: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_60, ne_25);  bitwise_and_60 = ne_25 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_797: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_61, 2);  bitwise_and_61 = None
        where_121: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_797, mul_444, full_default_39);  mul_444 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_82: "f32[100, 64, 8]" = torch.ops.aten.clone.default(where_121, memory_format = torch.contiguous_format);  where_121 = None
        amax_6: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_82, [-2], True)
        sub_235: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(clone_82, amax_6);  clone_82 = amax_6 = None
        exp_19: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_235);  sub_235 = None
        sum_116: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_19, [-2], True)
        div_94: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_19, sum_116);  exp_19 = sum_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_122: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_797, div_94, full_default_40);  unsqueeze_797 = div_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_799: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_122, 3);  where_122 = None
        permute_785: "f32[100, 8, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_799, [0, 2, 3, 1])
        permute_786: "f32[100, 1, 64, 64]" = torch.ops.aten.permute.default(unsqueeze_792, [0, 3, 2, 1]);  unsqueeze_792 = None
        permute_787: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(permute_785, [0, 1, 3, 2]);  permute_785 = None
        view_763: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_787, [100, 8, 64])
        permute_788: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_786, [0, 3, 2, 1]);  permute_786 = None
        view_764: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_788, [100, 64, 64]);  permute_788 = None
        bmm_167: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_763, view_764);  view_763 = view_764 = None
        view_765: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_167, [100, 8, 1, 64]);  bmm_167 = None
        permute_789: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_765, [0, 1, 3, 2]);  view_765 = None
        view_766: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_789, [100, 8, 64]);  permute_789 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_225: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_71, [cat_54]);  getitem_71 = None
        permute_791: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(index_225, [0, 2, 3, 1]);  index_225 = None
        clone_83: "f32[100, 8, 64, 1]" = torch.ops.aten.clone.default(permute_787, memory_format = torch.contiguous_format);  permute_787 = None
        view_767: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_83, [800, 1, 64]);  clone_83 = None
        permute_793: "f32[100, 8, 64, 32]" = torch.ops.aten.permute.default(permute_791, [0, 1, 3, 2]);  permute_791 = None
        clone_84: "f32[100, 8, 64, 32]" = torch.ops.aten.clone.default(permute_793, memory_format = torch.contiguous_format);  permute_793 = None
        view_768: "f32[800, 64, 32]" = torch.ops.aten.view.default(clone_84, [800, 64, 32]);  clone_84 = None
        bmm_168: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_767, view_768);  view_767 = view_768 = None
        view_769: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_168, [100, 8, 1, 32]);  bmm_168 = None
        permute_794: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_769, [0, 1, 3, 2]);  view_769 = None
        view_770: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_794, [100, 8, 32]);  permute_794 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_226: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_488, [cat_54]);  slice_488 = cat_54 = None
        unsqueeze_803: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_799, 4);  unsqueeze_799 = None
        permute_795: "f32[100, 8, 1, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_803, [0, 2, 3, 4, 1]);  unsqueeze_803 = None
        permute_796: "f32[100, 8, 8, 3, 64]" = torch.ops.aten.permute.default(index_226, [0, 2, 3, 4, 1]);  index_226 = None
        permute_797: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.permute.default(permute_795, [0, 1, 4, 2, 3]);  permute_795 = None
        clone_85: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.clone.default(permute_797, memory_format = torch.contiguous_format);  permute_797 = None
        view_771: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_85, [800, 1, 64]);  clone_85 = None
        permute_798: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.permute.default(permute_796, [0, 1, 4, 2, 3]);  permute_796 = None
        clone_86: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.clone.default(permute_798, memory_format = torch.contiguous_format);  permute_798 = None
        view_772: "f32[800, 64, 24]" = torch.ops.aten.view.default(clone_86, [800, 64, 24]);  clone_86 = None
        bmm_169: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_771, view_772);  view_771 = view_772 = None
        view_773: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_169, [100, 8, 1, 8, 3]);  bmm_169 = None
        permute_799: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_773, [0, 1, 3, 4, 2]);  view_773 = None
        view_774: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_799, [100, 8, 8, 3]);  permute_799 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_806: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_789, -3);  unsqueeze_789 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_807: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_790, -2);  unsqueeze_790 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_236: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_774, unsqueeze_807);  view_774 = unsqueeze_807 = None
        permute_800: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_806, [0, 1, 2, 4, 3]);  unsqueeze_806 = None
        unsqueeze_808: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_236, 4);  sub_236 = None
        permute_801: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_808, [0, 1, 2, 4, 3]);  unsqueeze_808 = None
        permute_802: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_800, [0, 3, 4, 1, 2]);  permute_800 = None
        view_775: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_802, [100, 3, 3]);  permute_802 = None
        permute_803: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_801, [0, 4, 1, 2, 3]);  permute_801 = None
        view_776: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_803, [100, 3, 64]);  permute_803 = None
        bmm_170: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_775, view_776);  view_775 = view_776 = None
        view_777: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_170, [100, 3, 1, 8, 8]);  bmm_170 = None
        permute_804: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_777, [0, 3, 4, 1, 2]);  view_777 = None
        view_778: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_804, [100, 8, 8, 3]);  permute_804 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_445: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_778, view_778)
        sum_117: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_445, [-1]);  mul_445 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_100: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_117, 1e-12);  sum_117 = None
        sqrt_77: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_100);  clamp_min_100 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_779: "f32[100, 512]" = torch.ops.aten.view.default(view_766, [100, -1]);  view_766 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_780: "f32[100, 256]" = torch.ops.aten.view.default(view_770, [100, -1]);  view_770 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_87: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_778, memory_format = torch.contiguous_format);  view_778 = None
        view_781: "f32[100, 192]" = torch.ops.aten.view.default(clone_87, [100, 192]);  clone_87 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_782: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_77, [100, -1]);  sqrt_77 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_60: "f32[100, 1024]" = torch.ops.aten.cat.default([view_779, view_780, view_781, view_782], -1);  view_779 = view_780 = view_781 = view_782 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_809: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_60, 2);  cat_60 = None
        permute_805: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_809, [0, 2, 1]);  unsqueeze_809 = None
        unsqueeze_810: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg217_1, 2);  arg217_1 = None
        permute_806: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_810, [2, 1, 0]);  unsqueeze_810 = None
        permute_807: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_805, [0, 2, 1]);  permute_805 = None
        view_783: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_807, [1, 100, 1024]);  permute_807 = None
        permute_808: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_806, [2, 1, 0]);  permute_806 = None
        view_784: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_808, [1, 1024, 128]);  permute_808 = None
        bmm_171: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_783, view_784);  view_783 = view_784 = None
        view_785: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_171, [100, 1, 128]);  bmm_171 = None
        permute_809: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_785, [0, 2, 1]);  view_785 = None
        view_786: "f32[100, 128]" = torch.ops.aten.view.default(permute_809, [100, 128]);  permute_809 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_344: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_786, arg218_1);  view_786 = arg218_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_345: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_298, add_344);  add_298 = add_344 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_42: "f32[100, 1]" = torch.ops.aten.mean.dim(add_345, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_42: "f32[100, 1]" = torch.ops.aten.var.correction(add_345, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_237: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_345, mean_42);  mean_42 = None
        add_346: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_42, 1e-05);  var_42 = None
        rsqrt_42: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_346);  add_346 = None
        mul_446: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_237, rsqrt_42);  sub_237 = rsqrt_42 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_447: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_446, arg219_1);  mul_446 = arg219_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_347: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_447, arg220_1);  mul_447 = arg220_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_43: "f32[100, 1]" = torch.ops.aten.mean.dim(add_347, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_43: "f32[100, 1]" = torch.ops.aten.var.correction(add_347, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_243: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_347, mean_43);  add_347 = mean_43 = None
        add_352: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_43, 1e-05);  var_43 = None
        rsqrt_43: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_352);  add_352 = None
        mul_454: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_243, rsqrt_43);  sub_243 = rsqrt_43 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_455: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_454, arg221_1);  mul_454 = arg221_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_353: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_455, arg222_1);  mul_455 = arg222_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_820: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_353, 2);  add_353 = None
        permute_815: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_820, [0, 2, 1]);  unsqueeze_820 = None
        unsqueeze_821: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg223_1, 2);  arg223_1 = None
        permute_816: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_821, [2, 1, 0]);  unsqueeze_821 = None
        permute_817: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_815, [0, 2, 1]);  permute_815 = None
        view_791: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_817, [1, 100, 128]);  permute_817 = None
        permute_818: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_816, [2, 1, 0]);  permute_816 = None
        view_792: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_818, [1, 128, 768]);  permute_818 = None
        bmm_173: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_791, view_792);  view_792 = None
        view_793: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_173, [100, 1, 768]);  bmm_173 = None
        permute_819: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_793, [0, 2, 1]);  view_793 = None
        view_794: "f32[100, 768]" = torch.ops.aten.view.default(permute_819, [100, 768]);  permute_819 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_795: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_794, [100, 8, 96]);  view_794 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_7 = torch.ops.aten.split.Tensor(view_795, 32, -1);  view_795 = None
        getitem_72: "f32[100, 8, 32]" = split_7[0]
        getitem_73: "f32[100, 8, 32]" = split_7[1]
        getitem_74: "f32[100, 8, 32]" = split_7[2];  split_7 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_44: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_72, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_44: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_72, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_244: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_72, mean_44);  getitem_72 = mean_44 = None
        add_354: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_44, 1e-05);  var_44 = None
        rsqrt_44: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_354);  add_354 = None
        mul_456: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_244, rsqrt_44);  sub_244 = rsqrt_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_457: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_456, arg224_1);  mul_456 = arg224_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_355: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_457, arg225_1);  mul_457 = arg225_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_45: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_73, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_45: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_73, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_245: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_73, mean_45);  getitem_73 = mean_45 = None
        add_356: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_45, 1e-05);  var_45 = None
        rsqrt_45: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_356);  add_356 = None
        mul_458: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_245, rsqrt_45);  sub_245 = rsqrt_45 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_459: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_458, arg226_1);  mul_458 = arg226_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_357: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_459, arg227_1);  mul_459 = arg227_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_823: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg228_1, 2);  arg228_1 = None
        permute_821: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_823, [2, 1, 0]);  unsqueeze_823 = None
        permute_823: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_821, [2, 1, 0]);  permute_821 = None
        view_797: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_823, [1, 128, 576]);  permute_823 = None
        bmm_174: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_791, view_797);  view_791 = view_797 = None
        view_798: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_174, [100, 1, 576]);  bmm_174 = None
        permute_824: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_798, [0, 2, 1]);  view_798 = None
        view_799: "f32[100, 576]" = torch.ops.aten.view.default(permute_824, [100, 576]);  permute_824 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_800: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_799, [100, 192, 3]);  view_799 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        unsqueeze_826: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_800, 3);  view_800 = None
        permute_826: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_826, [0, 1, 3, 2]);  unsqueeze_826 = None
        permute_828: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_826, [0, 3, 1, 2]);  permute_826 = None
        view_802: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_828, [100, 3, 192]);  permute_828 = None
        bmm_175: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_168, view_802);  view_802 = None
        view_803: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_175, [100, 3, 1, 192]);  bmm_175 = None
        permute_829: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_803, [0, 3, 1, 2]);  view_803 = None
        view_804: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_829, [100, 192, 3]);  permute_829 = None
        add_358: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_804, unsqueeze_267);  view_804 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_805: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_358, [100, 8, 24, 3]);  add_358 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_499: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_805, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_502: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_805, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_505: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_805, 2, 16, 9223372036854775807);  view_805 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_827: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_83, 3);  select_83 = None
        permute_830: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_827, [0, 1, 3, 2])
        unsqueeze_828: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg229_1, 2);  arg229_1 = None
        unsqueeze_829: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_828, 3);  unsqueeze_828 = None
        permute_831: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_829, [2, 3, 1, 0]);  unsqueeze_829 = None
        permute_832: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_830, [0, 1, 3, 2]);  permute_830 = None
        view_806: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_832, [1, 4800, 64]);  permute_832 = None
        permute_833: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_831, [3, 2, 0, 1]);  permute_831 = None
        view_807: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_833, [1, 64, 8]);  permute_833 = None
        bmm_176: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_806, view_807);  view_806 = view_807 = None
        view_808: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_176, [100, 48, 1, 8]);  bmm_176 = None
        permute_834: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_808, [0, 1, 3, 2]);  view_808 = None
        view_809: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_834, [100, 48, 8]);  permute_834 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_20: "f32[8]" = torch.ops.aten.exp.default(arg230_1)
        log1p_7: "f32[8]" = torch.ops.aten.log1p.default(exp_20);  exp_20 = None
        gt_7: "b8[8]" = torch.ops.aten.gt.Scalar(arg230_1, 20)
        where_123: "f32[8]" = torch.ops.aten.where.self(gt_7, arg230_1, log1p_7);  gt_7 = arg230_1 = log1p_7 = None
        view_810: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_123, [1, 1, 8]);  where_123 = None
        mul_460: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_810, 0.16666666666666666);  view_810 = None
        div_98: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_460, 2);  mul_460 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_830: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_499, 1);  slice_499 = None
        index_231: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_502, [select_82]);  slice_502 = None
        sub_246: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_830, index_231);  unsqueeze_830 = index_231 = None
        pow_16: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_246, 2);  sub_246 = None
        sum_121: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_16, [-1, -2]);  pow_16 = None
        mul_461: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_98, sum_121);  div_98 = sum_121 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_232: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_357, [select_82]);  add_357 = None
        unsqueeze_831: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_355, 3);  add_355 = None
        permute_835: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_831, [0, 3, 1, 2]);  unsqueeze_831 = None
        permute_836: "f32[100, 48, 8, 32]" = torch.ops.aten.permute.default(index_232, [0, 1, 2, 3]);  index_232 = None
        permute_837: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_835, [0, 2, 3, 1]);  permute_835 = None
        view_811: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_837, [800, 1, 32]);  permute_837 = None
        permute_838: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(permute_836, [0, 2, 3, 1]);  permute_836 = None
        clone_88: "f32[100, 8, 32, 48]" = torch.ops.aten.clone.default(permute_838, memory_format = torch.contiguous_format);  permute_838 = None
        view_812: "f32[800, 32, 48]" = torch.ops.aten.view.default(clone_88, [800, 32, 48]);  clone_88 = None
        bmm_177: "f32[800, 1, 48]" = torch.ops.aten.bmm.default(view_811, view_812);  view_811 = view_812 = None
        view_813: "f32[100, 8, 1, 48]" = torch.ops.aten.view.default(bmm_177, [100, 8, 1, 48]);  bmm_177 = None
        permute_839: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_813, [0, 3, 1, 2]);  view_813 = None
        view_814: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_839, [100, 48, 8]);  permute_839 = None
        mul_462: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(view_814, 0.1767766952966369);  view_814 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_359: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_462, view_809);  mul_462 = view_809 = None
        sub_247: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_359, mul_461);  add_359 = mul_461 = None
        mul_463: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_247, 0.5773502691896257);  sub_247 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_27: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_82, -1)
        bitwise_and_62: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_84, ne_27);  select_84 = ne_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_832: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_62, 2);  bitwise_and_62 = None
        where_124: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_832, mul_463, full_default_41);  mul_463 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_89: "f32[100, 48, 8]" = torch.ops.aten.clone.default(where_124, memory_format = torch.contiguous_format);  where_124 = None
        amax_7: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_89, [-2], True)
        sub_248: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(clone_89, amax_7);  clone_89 = amax_7 = None
        exp_21: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_248);  sub_248 = None
        sum_122: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_21, [-2], True)
        div_99: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_21, sum_122);  exp_21 = sum_122 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_125: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_832, div_99, full_default_42);  unsqueeze_832 = div_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_834: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_125, 3);  where_125 = None
        permute_840: "f32[100, 8, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_834, [0, 2, 3, 1])
        permute_841: "f32[100, 1, 64, 48]" = torch.ops.aten.permute.default(unsqueeze_827, [0, 3, 2, 1]);  unsqueeze_827 = None
        permute_842: "f32[100, 8, 48, 1]" = torch.ops.aten.permute.default(permute_840, [0, 1, 3, 2]);  permute_840 = None
        view_815: "f32[100, 8, 48]" = torch.ops.aten.view.default(permute_842, [100, 8, 48])
        permute_843: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_841, [0, 3, 2, 1]);  permute_841 = None
        view_816: "f32[100, 48, 64]" = torch.ops.aten.view.default(permute_843, [100, 48, 64]);  permute_843 = None
        bmm_178: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_815, view_816);  view_815 = view_816 = None
        view_817: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_178, [100, 8, 1, 64]);  bmm_178 = None
        permute_844: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_817, [0, 1, 3, 2]);  view_817 = None
        view_818: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_844, [100, 8, 64]);  permute_844 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_233: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_74, [select_82]);  getitem_74 = None
        permute_846: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(index_233, [0, 2, 3, 1]);  index_233 = None
        clone_90: "f32[100, 8, 48, 1]" = torch.ops.aten.clone.default(permute_842, memory_format = torch.contiguous_format);  permute_842 = None
        view_819: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_90, [800, 1, 48]);  clone_90 = None
        permute_848: "f32[100, 8, 48, 32]" = torch.ops.aten.permute.default(permute_846, [0, 1, 3, 2]);  permute_846 = None
        clone_91: "f32[100, 8, 48, 32]" = torch.ops.aten.clone.default(permute_848, memory_format = torch.contiguous_format);  permute_848 = None
        view_820: "f32[800, 48, 32]" = torch.ops.aten.view.default(clone_91, [800, 48, 32]);  clone_91 = None
        bmm_179: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_819, view_820);  view_819 = view_820 = None
        view_821: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_179, [100, 8, 1, 32]);  bmm_179 = None
        permute_849: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_821, [0, 1, 3, 2]);  view_821 = None
        view_822: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_849, [100, 8, 32]);  permute_849 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_234: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_505, [select_82]);  slice_505 = select_82 = None
        unsqueeze_838: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_834, 4);  unsqueeze_834 = None
        permute_850: "f32[100, 8, 1, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_838, [0, 2, 3, 4, 1]);  unsqueeze_838 = None
        permute_851: "f32[100, 8, 8, 3, 48]" = torch.ops.aten.permute.default(index_234, [0, 2, 3, 4, 1]);  index_234 = None
        permute_852: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.permute.default(permute_850, [0, 1, 4, 2, 3]);  permute_850 = None
        clone_92: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.clone.default(permute_852, memory_format = torch.contiguous_format);  permute_852 = None
        view_823: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_92, [800, 1, 48]);  clone_92 = None
        permute_853: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.permute.default(permute_851, [0, 1, 4, 2, 3]);  permute_851 = None
        clone_93: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.clone.default(permute_853, memory_format = torch.contiguous_format);  permute_853 = None
        view_824: "f32[800, 48, 24]" = torch.ops.aten.view.default(clone_93, [800, 48, 24]);  clone_93 = None
        bmm_180: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_823, view_824);  view_823 = view_824 = None
        view_825: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_180, [100, 8, 1, 8, 3]);  bmm_180 = None
        permute_854: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_825, [0, 1, 3, 4, 2]);  view_825 = None
        view_826: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_854, [100, 8, 8, 3]);  permute_854 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_249: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_826, unsqueeze_284);  view_826 = None
        unsqueeze_843: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_249, 4);  sub_249 = None
        permute_856: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_843, [0, 1, 2, 4, 3]);  unsqueeze_843 = None
        permute_858: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_856, [0, 4, 1, 2, 3]);  permute_856 = None
        view_828: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_858, [100, 3, 64]);  permute_858 = None
        bmm_181: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_194, view_828);  view_828 = None
        view_829: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_181, [100, 3, 1, 8, 8]);  bmm_181 = None
        permute_859: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_829, [0, 3, 4, 1, 2]);  view_829 = None
        view_830: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_859, [100, 8, 8, 3]);  permute_859 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_464: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_830, view_830)
        sum_123: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_464, [-1]);  mul_464 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_103: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_123, 1e-12);  sum_123 = None
        sqrt_80: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_103);  clamp_min_103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_831: "f32[100, 512]" = torch.ops.aten.view.default(view_818, [100, -1]);  view_818 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_832: "f32[100, 256]" = torch.ops.aten.view.default(view_822, [100, -1]);  view_822 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_94: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_830, memory_format = torch.contiguous_format);  view_830 = None
        view_833: "f32[100, 192]" = torch.ops.aten.view.default(clone_94, [100, 192]);  clone_94 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_834: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_80, [100, -1]);  sqrt_80 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_62: "f32[100, 1024]" = torch.ops.aten.cat.default([view_831, view_832, view_833, view_834], -1);  view_831 = view_832 = view_833 = view_834 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_844: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_62, 2);  cat_62 = None
        permute_860: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_844, [0, 2, 1]);  unsqueeze_844 = None
        unsqueeze_845: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg231_1, 2);  arg231_1 = None
        permute_861: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_845, [2, 1, 0]);  unsqueeze_845 = None
        permute_862: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_860, [0, 2, 1]);  permute_860 = None
        view_835: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_862, [1, 100, 1024]);  permute_862 = None
        permute_863: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_861, [2, 1, 0]);  permute_861 = None
        view_836: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_863, [1, 1024, 128]);  permute_863 = None
        bmm_182: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_835, view_836);  view_835 = view_836 = None
        view_837: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_182, [100, 1, 128]);  bmm_182 = None
        permute_864: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_837, [0, 2, 1]);  view_837 = None
        view_838: "f32[100, 128]" = torch.ops.aten.view.default(permute_864, [100, 128]);  permute_864 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_360: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_838, arg232_1);  view_838 = arg232_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_361: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_345, add_360);  add_345 = add_360 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_46: "f32[100, 1]" = torch.ops.aten.mean.dim(add_361, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_46: "f32[100, 1]" = torch.ops.aten.var.correction(add_361, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_250: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_361, mean_46);  mean_46 = None
        add_362: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_46, 1e-05);  var_46 = None
        rsqrt_46: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_362);  add_362 = None
        mul_465: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_250, rsqrt_46);  sub_250 = rsqrt_46 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_466: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_465, arg233_1);  mul_465 = arg233_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_363: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_466, arg234_1);  mul_466 = arg234_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_255: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_306, unsqueeze_739)
        permute_865: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_738, [0, 1, 3, 2])
        unsqueeze_854: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_255, 3);  sub_255 = None
        permute_866: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_854, [0, 1, 3, 2]);  unsqueeze_854 = None
        permute_867: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_865, [0, 2, 3, 1]);  permute_865 = None
        view_839: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_867, [100, 3, 3]);  permute_867 = None
        permute_868: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_866, [0, 3, 1, 2]);  permute_866 = None
        view_840: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_868, [100, 3, 20]);  permute_868 = None
        bmm_183: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_839, view_840);  view_839 = view_840 = None
        view_841: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_183, [100, 3, 1, 20]);  bmm_183 = None
        permute_869: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_841, [0, 3, 1, 2]);  view_841 = None
        view_842: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_869, [100, 20, 3]);  permute_869 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        clone_95: "f32[100, 20, 3]" = torch.ops.aten.clone.default(view_842, memory_format = torch.contiguous_format)
        view_843: "f32[100, 60]" = torch.ops.aten.view.default(clone_95, [100, 60]);  clone_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_856: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg235_1, 2);  arg235_1 = None
        permute_871: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_856, [2, 1, 0]);  unsqueeze_856 = None
        permute_873: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_871, [2, 1, 0]);  permute_871 = None
        view_845: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_873, [1, 128, 128]);  permute_873 = None
        bmm_184: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_211, view_845);  view_845 = None
        view_846: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_184, [100, 1, 128]);  bmm_184 = None
        permute_874: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_846, [0, 2, 1]);  view_846 = None
        view_847: "f32[100, 128]" = torch.ops.aten.view.default(permute_874, [100, 128]);  permute_874 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_368: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_363, view_847);  add_363 = view_847 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_857: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_843, 2);  view_843 = None
        permute_875: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_857, [0, 2, 1]);  unsqueeze_857 = None
        unsqueeze_858: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg236_1, 2);  arg236_1 = None
        permute_876: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_858, [2, 1, 0]);  unsqueeze_858 = None
        permute_877: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_875, [0, 2, 1]);  permute_875 = None
        view_848: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_877, [1, 100, 60]);  permute_877 = None
        permute_878: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_876, [2, 1, 0]);  permute_876 = None
        view_849: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_878, [1, 60, 256]);  permute_878 = None
        bmm_185: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_848, view_849);  view_848 = view_849 = None
        view_850: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_185, [100, 1, 256]);  bmm_185 = None
        permute_879: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_850, [0, 2, 1]);  view_850 = None
        view_851: "f32[100, 256]" = torch.ops.aten.view.default(permute_879, [100, 256]);  permute_879 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_369: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_851, arg237_1);  view_851 = arg237_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_473: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_369, add_369)
        mul_474: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_473, add_369);  mul_473 = None
        mul_475: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_474, 0.044715);  mul_474 = None
        add_370: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_369, mul_475);  mul_475 = None
        mul_476: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_370, 0.7978845608028654);  add_370 = None
        mul_477: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_369, 0.5);  add_369 = None
        tanh_18: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_476);  mul_476 = None
        add_371: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_18, 1);  tanh_18 = None
        mul_478: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_477, add_371);  mul_477 = add_371 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_859: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_478, 2);  mul_478 = None
        permute_880: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_859, [0, 2, 1]);  unsqueeze_859 = None
        unsqueeze_860: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg238_1, 2);  arg238_1 = None
        permute_881: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_860, [2, 1, 0]);  unsqueeze_860 = None
        permute_882: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_880, [0, 2, 1]);  permute_880 = None
        view_852: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_882, [1, 100, 256]);  permute_882 = None
        permute_883: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_881, [2, 1, 0]);  permute_881 = None
        view_853: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_883, [1, 256, 128]);  permute_883 = None
        bmm_186: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_852, view_853);  view_852 = view_853 = None
        view_854: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_186, [100, 1, 128]);  bmm_186 = None
        permute_884: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_854, [0, 2, 1]);  view_854 = None
        view_855: "f32[100, 128]" = torch.ops.aten.view.default(permute_884, [100, 128]);  permute_884 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_372: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_855, arg239_1);  view_855 = arg239_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_373: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_368, add_372);  add_368 = add_372 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_861: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_373, 2);  add_373 = None
        permute_885: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_861, [0, 2, 1]);  unsqueeze_861 = None
        unsqueeze_862: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg240_1, 2);  arg240_1 = None
        permute_886: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_862, [2, 1, 0]);  unsqueeze_862 = None
        permute_887: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_885, [0, 2, 1]);  permute_885 = None
        view_856: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_887, [1, 100, 128]);  permute_887 = None
        permute_888: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_886, [2, 1, 0]);  permute_886 = None
        view_857: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_888, [1, 128, 512]);  permute_888 = None
        bmm_187: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_856, view_857);  view_857 = None
        view_858: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_187, [100, 1, 512]);  bmm_187 = None
        permute_889: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_858, [0, 2, 1]);  view_858 = None
        view_859: "f32[100, 512]" = torch.ops.aten.view.default(permute_889, [100, 512]);  permute_889 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_864: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg241_1, 2);  arg241_1 = None
        permute_891: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_864, [2, 1, 0]);  unsqueeze_864 = None
        permute_893: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_891, [2, 1, 0]);  permute_891 = None
        view_861: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_893, [1, 128, 512]);  permute_893 = None
        bmm_188: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_856, view_861);  view_861 = None
        view_862: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_188, [100, 1, 512]);  bmm_188 = None
        permute_894: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_862, [0, 2, 1]);  view_862 = None
        view_863: "f32[100, 512]" = torch.ops.aten.view.default(permute_894, [100, 512]);  permute_894 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_479: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_863, view_863)
        mul_480: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_479, view_863);  mul_479 = None
        mul_481: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_480, 0.044715);  mul_480 = None
        add_374: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_863, mul_481);  mul_481 = None
        mul_482: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_374, 0.7978845608028654);  add_374 = None
        mul_483: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_863, 0.5);  view_863 = None
        tanh_19: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_482);  mul_482 = None
        add_375: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_19, 1);  tanh_19 = None
        mul_484: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_483, add_375);  mul_483 = add_375 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_485: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_484, view_859);  mul_484 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_866: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg242_1, 2);  arg242_1 = None
        permute_896: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_866, [2, 1, 0]);  unsqueeze_866 = None
        permute_898: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_896, [2, 1, 0]);  permute_896 = None
        view_865: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_898, [1, 128, 512]);  permute_898 = None
        bmm_189: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_856, view_865);  view_865 = None
        view_866: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_189, [100, 1, 512]);  bmm_189 = None
        permute_899: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_866, [0, 2, 1]);  view_866 = None
        view_867: "f32[100, 512]" = torch.ops.aten.view.default(permute_899, [100, 512]);  permute_899 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_486: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_867, view_867)
        mul_487: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_486, view_867);  mul_486 = None
        mul_488: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_487, 0.044715);  mul_487 = None
        add_376: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_867, mul_488);  mul_488 = None
        mul_489: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_376, 0.7978845608028654);  add_376 = None
        mul_490: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_867, 0.5);  view_867 = None
        tanh_20: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_489);  mul_489 = None
        add_377: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_20, 1);  tanh_20 = None
        mul_491: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_490, add_377);  mul_490 = add_377 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_868: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg243_1, 2);  arg243_1 = None
        permute_901: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_868, [2, 1, 0]);  unsqueeze_868 = None
        permute_903: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_901, [2, 1, 0]);  permute_901 = None
        view_869: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_903, [1, 128, 512]);  permute_903 = None
        bmm_190: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_856, view_869);  view_856 = view_869 = None
        view_870: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_190, [100, 1, 512]);  bmm_190 = None
        permute_904: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_870, [0, 2, 1]);  view_870 = None
        view_871: "f32[100, 512]" = torch.ops.aten.view.default(permute_904, [100, 512]);  permute_904 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_492: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_871, view_871)
        mul_493: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_492, view_871);  mul_492 = None
        mul_494: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_493, 0.044715);  mul_493 = None
        add_378: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_871, mul_494);  mul_494 = None
        mul_495: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_378, 0.7978845608028654);  add_378 = None
        mul_496: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_871, 0.5);  view_871 = None
        tanh_21: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_495);  mul_495 = None
        add_379: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_21, 1);  tanh_21 = None
        mul_497: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_496, add_379);  mul_496 = add_379 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_498: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_497, view_859);  mul_497 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_126: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_498, full_default_44);  mul_498 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_127: "f32[100, 512]" = torch.ops.aten.where.self(view_239, where_126, full_default_44);  where_126 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_12: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_6, where_127);  where_127 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_239: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_12, [clamp_max_2]);  scatter_add_12 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_102: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_239, clamp_min_33);  index_239 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_130: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_102, full_default_44);  div_102 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_380: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_485, where_130);  mul_485 = where_130 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_500: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_491, view_859);  mul_491 = view_859 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_131: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_500, full_default_44);  mul_500 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_132: "f32[100, 512]" = torch.ops.aten.where.self(view_243, where_131, full_default_44);  where_131 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_14: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_8, where_132);  where_132 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_241: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_14, [clamp_max_4]);  scatter_add_14 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_103: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_241, clamp_min_36);  index_241 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_135: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_103, full_default_44);  div_103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_381: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_380, where_135);  add_380 = where_135 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_870: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_381, 2);  add_381 = None
        permute_905: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_870, [0, 2, 1]);  unsqueeze_870 = None
        unsqueeze_871: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg244_1, 2);  arg244_1 = None
        permute_906: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_871, [2, 1, 0]);  unsqueeze_871 = None
        permute_907: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_905, [0, 2, 1]);  permute_905 = None
        view_880: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_907, [1, 100, 512]);  permute_907 = None
        permute_908: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_906, [2, 1, 0]);  permute_906 = None
        view_881: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_908, [1, 512, 128]);  permute_908 = None
        bmm_191: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_880, view_881);  view_880 = view_881 = None
        view_882: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_191, [100, 1, 128]);  bmm_191 = None
        permute_909: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_882, [0, 2, 1]);  view_882 = None
        view_883: "f32[100, 128]" = torch.ops.aten.view.default(permute_909, [100, 128]);  permute_909 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_382: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_883, arg245_1);  view_883 = arg245_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_383: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_361, add_382);  add_361 = add_382 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_47: "f32[100, 1]" = torch.ops.aten.mean.dim(add_383, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_47: "f32[100, 1]" = torch.ops.aten.var.correction(add_383, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_256: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_383, mean_47);  mean_47 = None
        add_384: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_47, 1e-05);  var_47 = None
        rsqrt_47: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_384);  add_384 = None
        mul_502: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_256, rsqrt_47);  sub_256 = rsqrt_47 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_503: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_502, arg246_1);  arg246_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_385: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_503, arg247_1);  mul_503 = arg247_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_881: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_385, 2);  add_385 = None
        permute_915: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_881, [0, 2, 1]);  unsqueeze_881 = None
        unsqueeze_882: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg248_1, 2);  arg248_1 = None
        permute_916: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_882, [2, 1, 0]);  unsqueeze_882 = None
        permute_917: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_915, [0, 2, 1]);  permute_915 = None
        view_888: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_917, [1, 100, 128]);  permute_917 = None
        permute_918: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_916, [2, 1, 0]);  permute_916 = None
        view_889: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_918, [1, 128, 60]);  permute_918 = None
        bmm_193: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_888, view_889);  view_888 = view_889 = None
        view_890: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_193, [100, 1, 60]);  bmm_193 = None
        permute_919: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_890, [0, 2, 1]);  view_890 = None
        view_891: "f32[100, 60]" = torch.ops.aten.view.default(permute_919, [100, 60]);  permute_919 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_510: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_891, 10.0);  view_891 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_892: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_510, [100, 20, 3]);  mul_510 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_390: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_842, view_892);  view_842 = view_892 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_920: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_738, [0, 1, 2, 3]);  unsqueeze_738 = None
        unsqueeze_885: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(add_390, 3);  add_390 = None
        permute_921: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_885, [0, 1, 3, 2]);  unsqueeze_885 = None
        permute_922: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_920, [0, 2, 3, 1]);  permute_920 = None
        view_893: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_922, [100, 3, 3]);  permute_922 = None
        permute_923: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_921, [0, 3, 1, 2]);  permute_921 = None
        view_894: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_923, [100, 3, 20]);  permute_923 = None
        bmm_194: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_893, view_894);  view_893 = view_894 = None
        view_895: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_194, [100, 3, 1, 20]);  bmm_194 = None
        permute_924: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_895, [0, 3, 1, 2]);  view_895 = None
        view_896: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_924, [100, 20, 3]);  permute_924 = None
        add_391: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_896, unsqueeze_739);  view_896 = unsqueeze_739 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_103: "f32[100, 3]" = torch.ops.aten.select.int(add_391, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_886: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_103, 1)
        unsqueeze_887: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_103, 0)
        sub_262: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_886, unsqueeze_887);  unsqueeze_886 = unsqueeze_887 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_511: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_262, sub_262);  sub_262 = None
        sum_130: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_511, [-1]);  mul_511 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_114: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_130, 1e-12);  sum_130 = None
        sqrt_85: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_114);  clamp_min_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_136: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_85, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_137: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_136, full_default);  where_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_248: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_137, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_138: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_248);  index_248 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_15: "f32[100, 100]" = torch.ops.aten.index_put.default(where_137, [unsqueeze_24, where_1], where_138);  where_137 = where_138 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_16 = torch.ops.aten.sort.stable(index_put_15, stable = True)
        getitem_76: "i64[100, 100]" = sort_16[1];  sort_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_533: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_76, 1, 0, 16);  getitem_76 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_249: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_15, [unsqueeze_24, slice_533]);  index_put_15 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_32: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_249, inf);  index_249 = None
        where_139: "i64[100, 16]" = torch.ops.aten.where.self(lt_32, slice_533, full_default_1);  lt_32 = slice_533 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_65: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_139], -1);  where_139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_392: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_85, 1e-06);  sqrt_85 = None
        log_30: "f32[100, 100]" = torch.ops.aten.log.default(add_392);  add_392 = None
        mul_512: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_30, -3.0);  log_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_31: "f32[100, 100]" = torch.ops.aten.log.default(getitem_13)
        neg_26: "f32[100, 100]" = torch.ops.aten.neg.default(log_31);  log_31 = None
        log_32: "f32[100, 100]" = torch.ops.aten.log.default(neg_26);  neg_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_263: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_512, log_32);  mul_512 = log_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_27: "f32[100, 100]" = torch.ops.aten.neg.default(sub_263);  sub_263 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_140: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_27, full_default);  neg_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_141: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_140, full_default);  where_140 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_29: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_65, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_251: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_141, [unsqueeze_24, cat_65])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_142: "f32[100, 32]" = torch.ops.aten.where.self(ne_29, full_default_7, index_251);  ne_29 = index_251 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_16: "f32[100, 100]" = torch.ops.aten.index_put.default(where_141, [unsqueeze_24, cat_65], where_142);  where_141 = where_142 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_17 = torch.ops.aten.sort.stable(index_put_16, stable = True)
        getitem_78: "i64[100, 100]" = sort_17[1];  sort_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_542: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_78, 1, 0, 32);  getitem_78 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_252: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_16, [unsqueeze_24, slice_542]);  index_put_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_33: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_252, inf);  index_252 = None
        where_143: "i64[100, 32]" = torch.ops.aten.where.self(lt_33, slice_542, full_default_37);  lt_33 = slice_542 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_66: "i64[100, 64]" = torch.ops.aten.cat.default([cat_65, where_143], -1);  cat_65 = where_143 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_104: "i64[100, 48]" = torch.ops.aten.select.int(view_14, 0, 4)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_105: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_52, 0, 4)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_106: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 4)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_253: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_66])
        bitwise_and_71: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_253);  index_253 = None
        ne_30: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_66, -1)
        bitwise_and_72: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_71, ne_30);  bitwise_and_71 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_254: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_66])
        eq_29: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_254);  index_254 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_255: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_66])
        eq_30: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_255);  index_255 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_256: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_66])
        sub_264: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_256);  index_256 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_115: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_264, -32);  sub_264 = None
        clamp_max_21: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_115, 32);  clamp_min_115 = None
        add_393: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_21, 32);  clamp_max_21 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_144: "i64[100, 64]" = torch.ops.aten.where.self(eq_29, add_393, full_default_38);  eq_29 = add_393 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_145: "i64[100, 64]" = torch.ops.aten.where.self(eq_30, where_144, full_default_38);  eq_30 = where_144 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_257: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg249_1, [where_145]);  arg249_1 = where_145 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_908: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_391, 1)
        slice_549: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_908, 2, 0, 5)
        unsqueeze_909: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_549, 3);  slice_549 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_258: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_391, [cat_66])
        unsqueeze_910: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_258, 2)
        slice_553: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_910, 3, 0, 5);  unsqueeze_910 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_265: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_909, slice_553);  unsqueeze_909 = slice_553 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_513: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_265, sub_265);  sub_265 = None
        sum_131: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_513, [-1]);  mul_513 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_116: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_131, 1e-12);  sum_131 = None
        sqrt_86: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_116);  clamp_min_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_897: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_86, [100, 64, 25]);  sqrt_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_911: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_897, 3);  view_897 = None
        sub_266: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_911, add_29);  unsqueeze_911 = None
        pow_17: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_266, 2);  sub_266 = None
        neg_28: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_17);  pow_17 = None
        div_106: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_28, 1.890625);  neg_28 = None
        exp_22: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_106);  div_106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_898: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_22, [100, 64, 400]);  exp_22 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_912: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_898, 3);  view_898 = None
        permute_925: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_912, [0, 1, 3, 2]);  unsqueeze_912 = None
        unsqueeze_913: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg250_1, 2);  arg250_1 = None
        unsqueeze_914: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_913, 3);  unsqueeze_913 = None
        permute_926: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_914, [2, 3, 1, 0]);  unsqueeze_914 = None
        permute_927: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_925, [0, 1, 3, 2]);  permute_925 = None
        view_899: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_927, [1, 6400, 400]);  permute_927 = None
        permute_928: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_926, [3, 2, 0, 1]);  permute_926 = None
        view_900: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_928, [1, 400, 64]);  permute_928 = None
        bmm_195: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_899, view_900);  view_899 = view_900 = None
        view_901: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_195, [100, 64, 1, 64]);  bmm_195 = None
        permute_929: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_901, [0, 1, 3, 2]);  view_901 = None
        view_902: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_929, [100, 64, 64]);  permute_929 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_397: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_257, view_902);  index_257 = view_902 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_107: "f32[100, 3]" = torch.ops.aten.select.int(add_391, 1, 0)
        select_109: "f32[100, 3]" = torch.ops.aten.select.int(add_391, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_267: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_109, select_103);  select_109 = None
        sub_268: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_107, select_103);  select_107 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_516: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_267, sub_267)
        sum_132: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_516, [-1]);  mul_516 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_117: "f32[100]" = torch.ops.aten.clamp_min.default(sum_132, 1e-12);  sum_132 = None
        sqrt_87: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_117);  clamp_min_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_915: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_87, -1);  sqrt_87 = None
        div_107: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_267, unsqueeze_915);  sub_267 = unsqueeze_915 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_517: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_268, div_107)
        sum_133: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_517, [-1]);  mul_517 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_916: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_133, -1);  sum_133 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_518: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_916, div_107);  unsqueeze_916 = None
        sub_269: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_268, mul_518);  sub_268 = mul_518 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_519: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_269, sub_269)
        sum_134: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_519, [-1]);  mul_519 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_118: "f32[100]" = torch.ops.aten.clamp_min.default(sum_134, 1e-12);  sum_134 = None
        sqrt_88: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_118);  clamp_min_118 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_917: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_88, -1);  sqrt_88 = None
        div_108: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_269, unsqueeze_917);  sub_269 = unsqueeze_917 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_259: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_107, [None, remainder])
        index_260: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_108, [None, remainder_1])
        mul_520: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_259, index_260);  index_259 = index_260 = None
        index_261: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_107, [None, remainder_1])
        index_262: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_108, [None, remainder])
        mul_521: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_261, index_262);  index_261 = index_262 = None
        sub_270: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_520, mul_521);  mul_520 = mul_521 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_918: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_107, 2);  div_107 = None
        unsqueeze_919: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_108, 2);  div_108 = None
        unsqueeze_920: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_270, 2);  sub_270 = None
        cat_67: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_918, unsqueeze_919, unsqueeze_920], -1);  unsqueeze_918 = unsqueeze_919 = unsqueeze_920 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_924: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_67, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_925: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_103, -2);  select_103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_926: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_924, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_927: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_925, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_272: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_258, unsqueeze_927)
        permute_935: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_926, [0, 1, 2, 4, 3]);  unsqueeze_926 = None
        unsqueeze_928: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_272, 4);  sub_272 = None
        permute_936: "f32[100, 64, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_928, [0, 1, 2, 4, 3]);  unsqueeze_928 = None
        permute_937: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_935, [0, 3, 4, 1, 2]);  permute_935 = None
        view_907: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_937, [100, 3, 3]);  permute_937 = None
        permute_938: "f32[100, 3, 64, 20, 1]" = torch.ops.aten.permute.default(permute_936, [0, 4, 1, 2, 3]);  permute_936 = None
        view_908: "f32[100, 3, 1280]" = torch.ops.aten.view.default(permute_938, [100, 3, 1280]);  permute_938 = None
        bmm_197: "f32[100, 3, 1280]" = torch.ops.aten.bmm.default(view_907, view_908);  view_908 = None
        view_909: "f32[100, 3, 1, 64, 20]" = torch.ops.aten.view.default(bmm_197, [100, 3, 1, 64, 20]);  bmm_197 = None
        permute_939: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.permute.default(view_909, [0, 3, 4, 1, 2]);  view_909 = None
        view_910: "f32[100, 64, 20, 3]" = torch.ops.aten.view.default(permute_939, [100, 64, 20, 3]);  permute_939 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_522: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(view_910, view_910)
        sum_135: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_522, [-1]);  mul_522 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_119: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_135, 1e-12);  sum_135 = None
        sqrt_89: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_119);  clamp_min_119 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_929: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_89, -1);  sqrt_89 = None
        div_109: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(view_910, unsqueeze_929);  view_910 = unsqueeze_929 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        clone_98: "f32[100, 64, 20, 3]" = torch.ops.aten.clone.default(div_109, memory_format = torch.contiguous_format);  div_109 = None
        view_911: "f32[100, 64, 60]" = torch.ops.aten.view.default(clone_98, [100, 64, 60]);  clone_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_31: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_908, [100, 64, 20, 3]);  unsqueeze_908 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_68: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_31, index_258], -2);  expand_31 = index_258 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_273: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_68, unsqueeze_927);  cat_68 = unsqueeze_927 = None
        unsqueeze_935: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_273, 4);  sub_273 = None
        permute_941: "f32[100, 64, 40, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_935, [0, 1, 2, 4, 3]);  unsqueeze_935 = None
        permute_943: "f32[100, 3, 64, 40, 1]" = torch.ops.aten.permute.default(permute_941, [0, 4, 1, 2, 3]);  permute_941 = None
        view_913: "f32[100, 3, 2560]" = torch.ops.aten.view.default(permute_943, [100, 3, 2560]);  permute_943 = None
        bmm_198: "f32[100, 3, 2560]" = torch.ops.aten.bmm.default(view_907, view_913);  view_907 = view_913 = None
        view_914: "f32[100, 3, 1, 64, 40]" = torch.ops.aten.view.default(bmm_198, [100, 3, 1, 64, 40]);  bmm_198 = None
        permute_944: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.permute.default(view_914, [0, 3, 4, 1, 2]);  view_914 = None
        view_915: "f32[100, 64, 40, 3]" = torch.ops.aten.view.default(permute_944, [100, 64, 40, 3]);  permute_944 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_523: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_915, view_915)
        sum_136: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_523, [-1]);  mul_523 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_120: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_136, 1e-12);  sum_136 = None
        sqrt_90: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_120);  clamp_min_120 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_936: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_90, -1);  sqrt_90 = None
        div_110: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(view_915, unsqueeze_936);  unsqueeze_936 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        clone_99: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(div_110, memory_format = torch.contiguous_format);  div_110 = None
        view_916: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_99, [100, 64, 120]);  clone_99 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_524: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_915, 0.1);  view_915 = None
        clone_100: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(mul_524, memory_format = torch.contiguous_format);  mul_524 = None
        view_917: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_100, [100, 64, 120]);  clone_100 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_69: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_916, view_917], -1);  view_916 = view_917 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_937: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_911, 3);  view_911 = None
        permute_945: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_937, [0, 1, 3, 2]);  unsqueeze_937 = None
        unsqueeze_938: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg251_1, 2);  arg251_1 = None
        unsqueeze_939: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_938, 3);  unsqueeze_938 = None
        permute_946: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_939, [2, 3, 1, 0]);  unsqueeze_939 = None
        permute_947: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_945, [0, 1, 3, 2]);  permute_945 = None
        view_918: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_947, [1, 6400, 60]);  permute_947 = None
        permute_948: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_946, [3, 2, 0, 1]);  permute_946 = None
        view_919: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_948, [1, 60, 64]);  permute_948 = None
        bmm_199: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_918, view_919);  view_918 = view_919 = None
        view_920: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_199, [100, 64, 1, 64]);  bmm_199 = None
        permute_949: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_920, [0, 1, 3, 2]);  view_920 = None
        view_921: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_949, [100, 64, 64]);  permute_949 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_402: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_397, view_921);  add_397 = view_921 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_949: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_67, 1)
        permute_955: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_949, [0, 1, 3, 2]);  unsqueeze_949 = None
        index_268: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_67, [cat_66]);  cat_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:78 in rot_compose, code: return a @ b
        expand_32: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(permute_955, [100, 64, 3, 3]);  permute_955 = None
        clone_101: "f32[100, 64, 3, 3]" = torch.ops.aten.clone.default(expand_32, memory_format = torch.contiguous_format);  expand_32 = None
        view_926: "f32[6400, 3, 3]" = torch.ops.aten.view.default(clone_101, [6400, 3, 3]);  clone_101 = None
        expand_33: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(index_268, [100, 64, 3, 3]);  index_268 = None
        view_927: "f32[6400, 3, 3]" = torch.ops.aten.view.default(expand_33, [6400, 3, 3]);  expand_33 = None
        bmm_201: "f32[6400, 3, 3]" = torch.ops.aten.bmm.default(view_926, view_927);  view_926 = view_927 = None
        view_928: "f32[100, 64, 3, 3]" = torch.ops.aten.view.default(bmm_201, [100, 64, 3, 3]);  bmm_201 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_929: "f32[100, 64, 9]" = torch.ops.aten.view.default(view_928, [100, 64, 9]);  view_928 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_950: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_929, 3);  view_929 = None
        permute_956: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_950, [0, 1, 3, 2]);  unsqueeze_950 = None
        unsqueeze_951: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg252_1, 2);  arg252_1 = None
        unsqueeze_952: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_951, 3);  unsqueeze_951 = None
        permute_957: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_952, [2, 3, 1, 0]);  unsqueeze_952 = None
        permute_958: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_956, [0, 1, 3, 2]);  permute_956 = None
        view_930: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_958, [1, 6400, 9]);  permute_958 = None
        permute_959: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_957, [3, 2, 0, 1]);  permute_957 = None
        view_931: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_959, [1, 9, 64]);  permute_959 = None
        bmm_202: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_930, view_931);  view_930 = view_931 = None
        view_932: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_202, [100, 64, 1, 64]);  bmm_202 = None
        permute_960: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_932, [0, 1, 3, 2]);  view_932 = None
        view_933: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_960, [100, 64, 64]);  permute_960 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_407: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_402, view_933);  add_402 = view_933 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_953: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_69, 3);  cat_69 = None
        permute_961: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_953, [0, 1, 3, 2]);  unsqueeze_953 = None
        unsqueeze_954: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg253_1, 2);  arg253_1 = None
        unsqueeze_955: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_954, 3);  unsqueeze_954 = None
        permute_962: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_955, [2, 3, 1, 0]);  unsqueeze_955 = None
        permute_963: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_961, [0, 1, 3, 2]);  permute_961 = None
        view_934: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_963, [1, 6400, 240]);  permute_963 = None
        permute_964: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_962, [3, 2, 0, 1]);  permute_962 = None
        view_935: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_964, [1, 240, 64]);  permute_964 = None
        bmm_203: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_934, view_935);  view_934 = view_935 = None
        view_936: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_203, [100, 64, 1, 64]);  bmm_203 = None
        permute_965: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_936, [0, 1, 3, 2]);  view_936 = None
        view_937: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_965, [100, 64, 64]);  permute_965 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_408: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_407, view_937);  add_407 = view_937 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_48: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_408, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_48: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_408, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_279: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_408, mean_48);  add_408 = mean_48 = None
        add_409: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_48, 1e-05);  var_48 = None
        rsqrt_48: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_409);  add_409 = None
        mul_531: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_279, rsqrt_48);  sub_279 = rsqrt_48 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_532: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_531, arg254_1);  mul_531 = arg254_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_410: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_532, arg255_1);  mul_532 = arg255_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_956: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_410, 3);  add_410 = None
        permute_966: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_956, [0, 1, 3, 2]);  unsqueeze_956 = None
        unsqueeze_957: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg256_1, 2);  arg256_1 = None
        unsqueeze_958: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_957, 3);  unsqueeze_957 = None
        permute_967: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_958, [2, 3, 1, 0]);  unsqueeze_958 = None
        permute_968: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_966, [0, 1, 3, 2]);  permute_966 = None
        view_938: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_968, [1, 6400, 64]);  permute_968 = None
        permute_969: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_967, [3, 2, 0, 1]);  permute_967 = None
        view_939: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_969, [1, 64, 128]);  permute_969 = None
        bmm_204: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_938, view_939);  view_938 = view_939 = None
        view_940: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_204, [100, 64, 1, 128]);  bmm_204 = None
        permute_970: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_940, [0, 1, 3, 2]);  view_940 = None
        view_941: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_970, [100, 64, 128]);  permute_970 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_411: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_941, arg257_1);  view_941 = arg257_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_533: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_411, add_411)
        mul_534: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_533, add_411);  mul_533 = None
        mul_535: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_534, 0.044715);  mul_534 = None
        add_412: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_411, mul_535);  mul_535 = None
        mul_536: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_412, 0.7978845608028654);  add_412 = None
        mul_537: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_411, 0.5);  add_411 = None
        tanh_22: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_536);  mul_536 = None
        add_413: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_22, 1);  tanh_22 = None
        mul_538: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_537, add_413);  mul_537 = add_413 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_959: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_538, 3);  mul_538 = None
        permute_971: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_959, [0, 1, 3, 2]);  unsqueeze_959 = None
        unsqueeze_960: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg258_1, 2);  arg258_1 = None
        unsqueeze_961: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_960, 3);  unsqueeze_960 = None
        permute_972: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_961, [2, 3, 1, 0]);  unsqueeze_961 = None
        permute_973: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_971, [0, 1, 3, 2]);  permute_971 = None
        view_942: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_973, [1, 6400, 128]);  permute_973 = None
        permute_974: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_972, [3, 2, 0, 1]);  permute_972 = None
        view_943: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_974, [1, 128, 64]);  permute_974 = None
        bmm_205: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_942, view_943);  view_942 = view_943 = None
        view_944: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_205, [100, 64, 1, 64]);  bmm_205 = None
        permute_975: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_944, [0, 1, 3, 2]);  view_944 = None
        view_945: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_975, [100, 64, 64]);  permute_975 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_414: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_945, arg259_1);  view_945 = arg259_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_540: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_502, arg260_1);  mul_502 = arg260_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_416: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_540, arg261_1);  mul_540 = arg261_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_113: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_391, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_113: "f32[100, 3]" = torch.ops.aten.select.int(div_113, 1, 0)
        select_114: "f32[100, 3]" = torch.ops.aten.select.int(div_113, 1, 1)
        select_115: "f32[100, 3]" = torch.ops.aten.select.int(div_113, 1, 2);  div_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_281: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_115, select_114);  select_115 = None
        sub_282: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_113, select_114);  select_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_541: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_281, sub_281)
        sum_140: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_541, [-1]);  mul_541 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_123: "f32[100]" = torch.ops.aten.clamp_min.default(sum_140, 1e-12);  sum_140 = None
        sqrt_93: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_123);  clamp_min_123 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_962: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_93, -1);  sqrt_93 = None
        div_114: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_281, unsqueeze_962);  sub_281 = unsqueeze_962 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_542: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_282, div_114)
        sum_141: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_542, [-1]);  mul_542 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_963: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_141, -1);  sum_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_543: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_963, div_114);  unsqueeze_963 = None
        sub_283: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_282, mul_543);  sub_282 = mul_543 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_544: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_283, sub_283)
        sum_142: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_544, [-1]);  mul_544 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_124: "f32[100]" = torch.ops.aten.clamp_min.default(sum_142, 1e-12);  sum_142 = None
        sqrt_94: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_124);  clamp_min_124 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_964: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_94, -1);  sqrt_94 = None
        div_115: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_283, unsqueeze_964);  sub_283 = unsqueeze_964 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_269: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_114, [None, remainder])
        index_270: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_115, [None, remainder_1])
        mul_545: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_269, index_270);  index_269 = index_270 = None
        index_271: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_114, [None, remainder_1])
        index_272: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_115, [None, remainder])
        mul_546: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_271, index_272);  index_271 = index_272 = None
        sub_284: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_545, mul_546);  mul_545 = mul_546 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_965: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_114, 2);  div_114 = None
        unsqueeze_966: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_115, 2);  div_115 = None
        unsqueeze_967: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_284, 2);  sub_284 = None
        cat_71: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_965, unsqueeze_966, unsqueeze_967], -1);  unsqueeze_965 = unsqueeze_966 = unsqueeze_967 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_50: "f32[100, 1]" = torch.ops.aten.mean.dim(add_416, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_50: "f32[100, 1]" = torch.ops.aten.var.correction(add_416, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_286: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_416, mean_50);  add_416 = mean_50 = None
        add_421: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_50, 1e-05);  var_50 = None
        rsqrt_50: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_421);  add_421 = None
        mul_547: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_286, rsqrt_50);  sub_286 = rsqrt_50 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_548: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_547, arg262_1);  mul_547 = arg262_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_422: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_548, arg263_1);  mul_548 = arg263_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_971: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_422, 2);  add_422 = None
        permute_981: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_971, [0, 2, 1]);  unsqueeze_971 = None
        unsqueeze_972: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg264_1, 2);  arg264_1 = None
        permute_982: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_972, [2, 1, 0]);  unsqueeze_972 = None
        permute_983: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_981, [0, 2, 1]);  permute_981 = None
        view_950: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_983, [1, 100, 128]);  permute_983 = None
        permute_984: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_982, [2, 1, 0]);  permute_982 = None
        view_951: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_984, [1, 128, 768]);  permute_984 = None
        bmm_207: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_950, view_951);  view_951 = None
        view_952: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_207, [100, 1, 768]);  bmm_207 = None
        permute_985: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_952, [0, 2, 1]);  view_952 = None
        view_953: "f32[100, 768]" = torch.ops.aten.view.default(permute_985, [100, 768]);  permute_985 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_954: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_953, [100, 8, 96]);  view_953 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_8 = torch.ops.aten.split.Tensor(view_954, 32, -1);  view_954 = None
        getitem_79: "f32[100, 8, 32]" = split_8[0]
        getitem_80: "f32[100, 8, 32]" = split_8[1]
        getitem_81: "f32[100, 8, 32]" = split_8[2];  split_8 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_51: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_79, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_51: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_79, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_287: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_79, mean_51);  getitem_79 = mean_51 = None
        add_423: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_51, 1e-05);  var_51 = None
        rsqrt_51: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_423);  add_423 = None
        mul_549: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_287, rsqrt_51);  sub_287 = rsqrt_51 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_550: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_549, arg265_1);  mul_549 = arg265_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_424: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_550, arg266_1);  mul_550 = arg266_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_52: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_80, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_52: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_80, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_288: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_80, mean_52);  getitem_80 = mean_52 = None
        add_425: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_52, 1e-05);  var_52 = None
        rsqrt_52: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_425);  add_425 = None
        mul_551: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_288, rsqrt_52);  sub_288 = rsqrt_52 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_552: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_551, arg267_1);  mul_551 = arg267_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_426: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_552, arg268_1);  mul_552 = arg268_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_974: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg269_1, 2);  arg269_1 = None
        permute_987: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_974, [2, 1, 0]);  unsqueeze_974 = None
        permute_989: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_987, [2, 1, 0]);  permute_987 = None
        view_956: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_989, [1, 128, 576]);  permute_989 = None
        bmm_208: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_950, view_956);  view_950 = view_956 = None
        view_957: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_208, [100, 1, 576]);  bmm_208 = None
        permute_990: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_957, [0, 2, 1]);  view_957 = None
        view_958: "f32[100, 576]" = torch.ops.aten.view.default(permute_990, [100, 576]);  permute_990 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_959: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_958, [100, 192, 3]);  view_958 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_975: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_71, -3);  cat_71 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_976: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_114, -2);  select_114 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_991: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_975, [0, 1, 2, 3])
        unsqueeze_977: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_959, 3);  view_959 = None
        permute_992: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_977, [0, 1, 3, 2]);  unsqueeze_977 = None
        permute_993: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_991, [0, 2, 3, 1]);  permute_991 = None
        view_960: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_993, [100, 3, 3]);  permute_993 = None
        permute_994: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_992, [0, 3, 1, 2]);  permute_992 = None
        view_961: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_994, [100, 3, 192]);  permute_994 = None
        bmm_209: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_960, view_961);  view_960 = view_961 = None
        view_962: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_209, [100, 3, 1, 192]);  bmm_209 = None
        permute_995: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_962, [0, 3, 1, 2]);  view_962 = None
        view_963: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_995, [100, 192, 3]);  permute_995 = None
        add_427: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_963, unsqueeze_976);  view_963 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_964: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_427, [100, 8, 24, 3]);  add_427 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_580: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_964, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_583: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_964, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_586: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_964, 2, 16, 9223372036854775807);  view_964 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_978: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_414, 3);  add_414 = None
        permute_996: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_978, [0, 1, 3, 2])
        unsqueeze_979: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg270_1, 2);  arg270_1 = None
        unsqueeze_980: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_979, 3);  unsqueeze_979 = None
        permute_997: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_980, [2, 3, 1, 0]);  unsqueeze_980 = None
        permute_998: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_996, [0, 1, 3, 2]);  permute_996 = None
        view_965: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_998, [1, 6400, 64]);  permute_998 = None
        permute_999: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_997, [3, 2, 0, 1]);  permute_997 = None
        view_966: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_999, [1, 64, 8]);  permute_999 = None
        bmm_210: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_965, view_966);  view_965 = view_966 = None
        view_967: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_210, [100, 64, 1, 8]);  bmm_210 = None
        permute_1000: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_967, [0, 1, 3, 2]);  view_967 = None
        view_968: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_1000, [100, 64, 8]);  permute_1000 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_23: "f32[8]" = torch.ops.aten.exp.default(arg271_1)
        log1p_8: "f32[8]" = torch.ops.aten.log1p.default(exp_23);  exp_23 = None
        gt_8: "b8[8]" = torch.ops.aten.gt.Scalar(arg271_1, 20)
        where_146: "f32[8]" = torch.ops.aten.where.self(gt_8, arg271_1, log1p_8);  gt_8 = arg271_1 = log1p_8 = None
        view_969: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_146, [1, 1, 8]);  where_146 = None
        mul_553: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_969, 0.16666666666666666);  view_969 = None
        div_116: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_553, 2);  mul_553 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_981: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_580, 1);  slice_580 = None
        index_273: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_583, [cat_66]);  slice_583 = None
        sub_289: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_981, index_273);  unsqueeze_981 = index_273 = None
        pow_18: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_289, 2);  sub_289 = None
        sum_143: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_18, [-1, -2]);  pow_18 = None
        mul_554: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_116, sum_143);  div_116 = sum_143 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_274: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_426, [cat_66]);  add_426 = None
        unsqueeze_982: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_424, 3);  add_424 = None
        permute_1001: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_982, [0, 3, 1, 2]);  unsqueeze_982 = None
        permute_1002: "f32[100, 64, 8, 32]" = torch.ops.aten.permute.default(index_274, [0, 1, 2, 3]);  index_274 = None
        permute_1003: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_1001, [0, 2, 3, 1]);  permute_1001 = None
        view_970: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_1003, [800, 1, 32]);  permute_1003 = None
        permute_1004: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(permute_1002, [0, 2, 3, 1]);  permute_1002 = None
        clone_102: "f32[100, 8, 32, 64]" = torch.ops.aten.clone.default(permute_1004, memory_format = torch.contiguous_format);  permute_1004 = None
        view_971: "f32[800, 32, 64]" = torch.ops.aten.view.default(clone_102, [800, 32, 64]);  clone_102 = None
        bmm_211: "f32[800, 1, 64]" = torch.ops.aten.bmm.default(view_970, view_971);  view_970 = view_971 = None
        view_972: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_211, [100, 8, 1, 64]);  bmm_211 = None
        permute_1005: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_972, [0, 3, 1, 2]);  view_972 = None
        view_973: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_1005, [100, 64, 8]);  permute_1005 = None
        mul_555: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(view_973, 0.1767766952966369);  view_973 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_428: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_555, view_968);  mul_555 = view_968 = None
        sub_290: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_428, mul_554);  add_428 = mul_554 = None
        mul_556: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_290, 0.5773502691896257);  sub_290 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_73: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_72, ne_30);  bitwise_and_72 = ne_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_983: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_73, 2);  bitwise_and_73 = None
        where_147: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_983, mul_556, full_default_39);  mul_556 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_103: "f32[100, 64, 8]" = torch.ops.aten.clone.default(where_147, memory_format = torch.contiguous_format);  where_147 = None
        amax_8: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_103, [-2], True)
        sub_291: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(clone_103, amax_8);  clone_103 = amax_8 = None
        exp_24: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_291);  sub_291 = None
        sum_144: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_24, [-2], True)
        div_117: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_24, sum_144);  exp_24 = sum_144 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_148: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_983, div_117, full_default_40);  unsqueeze_983 = div_117 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_985: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_148, 3);  where_148 = None
        permute_1006: "f32[100, 8, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_985, [0, 2, 3, 1])
        permute_1007: "f32[100, 1, 64, 64]" = torch.ops.aten.permute.default(unsqueeze_978, [0, 3, 2, 1]);  unsqueeze_978 = None
        permute_1008: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(permute_1006, [0, 1, 3, 2]);  permute_1006 = None
        view_974: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_1008, [100, 8, 64])
        permute_1009: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_1007, [0, 3, 2, 1]);  permute_1007 = None
        view_975: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_1009, [100, 64, 64]);  permute_1009 = None
        bmm_212: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_974, view_975);  view_974 = view_975 = None
        view_976: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_212, [100, 8, 1, 64]);  bmm_212 = None
        permute_1010: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_976, [0, 1, 3, 2]);  view_976 = None
        view_977: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_1010, [100, 8, 64]);  permute_1010 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_275: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_81, [cat_66]);  getitem_81 = None
        permute_1012: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(index_275, [0, 2, 3, 1]);  index_275 = None
        clone_104: "f32[100, 8, 64, 1]" = torch.ops.aten.clone.default(permute_1008, memory_format = torch.contiguous_format);  permute_1008 = None
        view_978: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_104, [800, 1, 64]);  clone_104 = None
        permute_1014: "f32[100, 8, 64, 32]" = torch.ops.aten.permute.default(permute_1012, [0, 1, 3, 2]);  permute_1012 = None
        clone_105: "f32[100, 8, 64, 32]" = torch.ops.aten.clone.default(permute_1014, memory_format = torch.contiguous_format);  permute_1014 = None
        view_979: "f32[800, 64, 32]" = torch.ops.aten.view.default(clone_105, [800, 64, 32]);  clone_105 = None
        bmm_213: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_978, view_979);  view_978 = view_979 = None
        view_980: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_213, [100, 8, 1, 32]);  bmm_213 = None
        permute_1015: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_980, [0, 1, 3, 2]);  view_980 = None
        view_981: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_1015, [100, 8, 32]);  permute_1015 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_276: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_586, [cat_66]);  slice_586 = cat_66 = None
        unsqueeze_989: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_985, 4);  unsqueeze_985 = None
        permute_1016: "f32[100, 8, 1, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_989, [0, 2, 3, 4, 1]);  unsqueeze_989 = None
        permute_1017: "f32[100, 8, 8, 3, 64]" = torch.ops.aten.permute.default(index_276, [0, 2, 3, 4, 1]);  index_276 = None
        permute_1018: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.permute.default(permute_1016, [0, 1, 4, 2, 3]);  permute_1016 = None
        clone_106: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.clone.default(permute_1018, memory_format = torch.contiguous_format);  permute_1018 = None
        view_982: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_106, [800, 1, 64]);  clone_106 = None
        permute_1019: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.permute.default(permute_1017, [0, 1, 4, 2, 3]);  permute_1017 = None
        clone_107: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.clone.default(permute_1019, memory_format = torch.contiguous_format);  permute_1019 = None
        view_983: "f32[800, 64, 24]" = torch.ops.aten.view.default(clone_107, [800, 64, 24]);  clone_107 = None
        bmm_214: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_982, view_983);  view_982 = view_983 = None
        view_984: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_214, [100, 8, 1, 8, 3]);  bmm_214 = None
        permute_1020: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_984, [0, 1, 3, 4, 2]);  view_984 = None
        view_985: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_1020, [100, 8, 8, 3]);  permute_1020 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_992: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_975, -3);  unsqueeze_975 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_993: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_976, -2);  unsqueeze_976 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_292: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_985, unsqueeze_993);  view_985 = unsqueeze_993 = None
        permute_1021: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_992, [0, 1, 2, 4, 3]);  unsqueeze_992 = None
        unsqueeze_994: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_292, 4);  sub_292 = None
        permute_1022: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_994, [0, 1, 2, 4, 3]);  unsqueeze_994 = None
        permute_1023: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_1021, [0, 3, 4, 1, 2]);  permute_1021 = None
        view_986: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_1023, [100, 3, 3]);  permute_1023 = None
        permute_1024: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_1022, [0, 4, 1, 2, 3]);  permute_1022 = None
        view_987: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_1024, [100, 3, 64]);  permute_1024 = None
        bmm_215: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_986, view_987);  view_986 = view_987 = None
        view_988: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_215, [100, 3, 1, 8, 8]);  bmm_215 = None
        permute_1025: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_988, [0, 3, 4, 1, 2]);  view_988 = None
        view_989: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_1025, [100, 8, 8, 3]);  permute_1025 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_557: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_989, view_989)
        sum_145: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_557, [-1]);  mul_557 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_125: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_145, 1e-12);  sum_145 = None
        sqrt_95: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_125);  clamp_min_125 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_990: "f32[100, 512]" = torch.ops.aten.view.default(view_977, [100, -1]);  view_977 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_991: "f32[100, 256]" = torch.ops.aten.view.default(view_981, [100, -1]);  view_981 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_108: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_989, memory_format = torch.contiguous_format);  view_989 = None
        view_992: "f32[100, 192]" = torch.ops.aten.view.default(clone_108, [100, 192]);  clone_108 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_993: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_95, [100, -1]);  sqrt_95 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_72: "f32[100, 1024]" = torch.ops.aten.cat.default([view_990, view_991, view_992, view_993], -1);  view_990 = view_991 = view_992 = view_993 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_995: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_72, 2);  cat_72 = None
        permute_1026: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_995, [0, 2, 1]);  unsqueeze_995 = None
        unsqueeze_996: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg272_1, 2);  arg272_1 = None
        permute_1027: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_996, [2, 1, 0]);  unsqueeze_996 = None
        permute_1028: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_1026, [0, 2, 1]);  permute_1026 = None
        view_994: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_1028, [1, 100, 1024]);  permute_1028 = None
        permute_1029: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_1027, [2, 1, 0]);  permute_1027 = None
        view_995: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_1029, [1, 1024, 128]);  permute_1029 = None
        bmm_216: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_994, view_995);  view_994 = view_995 = None
        view_996: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_216, [100, 1, 128]);  bmm_216 = None
        permute_1030: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_996, [0, 2, 1]);  view_996 = None
        view_997: "f32[100, 128]" = torch.ops.aten.view.default(permute_1030, [100, 128]);  permute_1030 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_429: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_997, arg273_1);  view_997 = arg273_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_430: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_383, add_429);  add_383 = add_429 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_53: "f32[100, 1]" = torch.ops.aten.mean.dim(add_430, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_53: "f32[100, 1]" = torch.ops.aten.var.correction(add_430, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_293: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_430, mean_53);  mean_53 = None
        add_431: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_53, 1e-05);  var_53 = None
        rsqrt_53: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_431);  add_431 = None
        mul_558: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_293, rsqrt_53);  sub_293 = rsqrt_53 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_559: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_558, arg274_1);  mul_558 = arg274_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_432: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_559, arg275_1);  mul_559 = arg275_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_54: "f32[100, 1]" = torch.ops.aten.mean.dim(add_432, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_54: "f32[100, 1]" = torch.ops.aten.var.correction(add_432, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_299: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_432, mean_54);  add_432 = mean_54 = None
        add_437: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_54, 1e-05);  var_54 = None
        rsqrt_54: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_437);  add_437 = None
        mul_566: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_299, rsqrt_54);  sub_299 = rsqrt_54 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_567: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_566, arg276_1);  mul_566 = arg276_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_438: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_567, arg277_1);  mul_567 = arg277_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1006: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_438, 2);  add_438 = None
        permute_1036: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1006, [0, 2, 1]);  unsqueeze_1006 = None
        unsqueeze_1007: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg278_1, 2);  arg278_1 = None
        permute_1037: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_1007, [2, 1, 0]);  unsqueeze_1007 = None
        permute_1038: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_1036, [0, 2, 1]);  permute_1036 = None
        view_1002: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_1038, [1, 100, 128]);  permute_1038 = None
        permute_1039: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_1037, [2, 1, 0]);  permute_1037 = None
        view_1003: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_1039, [1, 128, 768]);  permute_1039 = None
        bmm_218: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_1002, view_1003);  view_1003 = None
        view_1004: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_218, [100, 1, 768]);  bmm_218 = None
        permute_1040: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_1004, [0, 2, 1]);  view_1004 = None
        view_1005: "f32[100, 768]" = torch.ops.aten.view.default(permute_1040, [100, 768]);  permute_1040 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_1006: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_1005, [100, 8, 96]);  view_1005 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_9 = torch.ops.aten.split.Tensor(view_1006, 32, -1);  view_1006 = None
        getitem_82: "f32[100, 8, 32]" = split_9[0]
        getitem_83: "f32[100, 8, 32]" = split_9[1]
        getitem_84: "f32[100, 8, 32]" = split_9[2];  split_9 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_55: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_82, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_55: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_82, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_300: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_82, mean_55);  getitem_82 = mean_55 = None
        add_439: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_55, 1e-05);  var_55 = None
        rsqrt_55: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_439);  add_439 = None
        mul_568: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_300, rsqrt_55);  sub_300 = rsqrt_55 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_569: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_568, arg279_1);  mul_568 = arg279_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_440: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_569, arg280_1);  mul_569 = arg280_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_56: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_83, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_56: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_83, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_301: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_83, mean_56);  getitem_83 = mean_56 = None
        add_441: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_56, 1e-05);  var_56 = None
        rsqrt_56: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_441);  add_441 = None
        mul_570: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_301, rsqrt_56);  sub_301 = rsqrt_56 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_571: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_570, arg281_1);  mul_570 = arg281_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_442: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_571, arg282_1);  mul_571 = arg282_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1009: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg283_1, 2);  arg283_1 = None
        permute_1042: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_1009, [2, 1, 0]);  unsqueeze_1009 = None
        permute_1044: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_1042, [2, 1, 0]);  permute_1042 = None
        view_1008: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_1044, [1, 128, 576]);  permute_1044 = None
        bmm_219: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_1002, view_1008);  view_1002 = view_1008 = None
        view_1009: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_219, [100, 1, 576]);  bmm_219 = None
        permute_1045: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_1009, [0, 2, 1]);  view_1009 = None
        view_1010: "f32[100, 576]" = torch.ops.aten.view.default(permute_1045, [100, 576]);  permute_1045 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_1011: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_1010, [100, 192, 3]);  view_1010 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        unsqueeze_1012: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_1011, 3);  view_1011 = None
        permute_1047: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1012, [0, 1, 3, 2]);  unsqueeze_1012 = None
        permute_1049: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_1047, [0, 3, 1, 2]);  permute_1047 = None
        view_1013: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_1049, [100, 3, 192]);  permute_1049 = None
        bmm_220: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_168, view_1013);  view_1013 = None
        view_1014: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_220, [100, 3, 1, 192]);  bmm_220 = None
        permute_1050: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_1014, [0, 3, 1, 2]);  view_1014 = None
        view_1015: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_1050, [100, 192, 3]);  permute_1050 = None
        add_443: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_1015, unsqueeze_267);  view_1015 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_1016: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_443, [100, 8, 24, 3]);  add_443 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_597: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1016, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_600: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1016, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_603: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1016, 2, 16, 9223372036854775807);  view_1016 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1013: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_105, 3);  select_105 = None
        permute_1051: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1013, [0, 1, 3, 2])
        unsqueeze_1014: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg284_1, 2);  arg284_1 = None
        unsqueeze_1015: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1014, 3);  unsqueeze_1014 = None
        permute_1052: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_1015, [2, 3, 1, 0]);  unsqueeze_1015 = None
        permute_1053: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_1051, [0, 1, 3, 2]);  permute_1051 = None
        view_1017: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_1053, [1, 4800, 64]);  permute_1053 = None
        permute_1054: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_1052, [3, 2, 0, 1]);  permute_1052 = None
        view_1018: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_1054, [1, 64, 8]);  permute_1054 = None
        bmm_221: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_1017, view_1018);  view_1017 = view_1018 = None
        view_1019: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_221, [100, 48, 1, 8]);  bmm_221 = None
        permute_1055: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_1019, [0, 1, 3, 2]);  view_1019 = None
        view_1020: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_1055, [100, 48, 8]);  permute_1055 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_25: "f32[8]" = torch.ops.aten.exp.default(arg285_1)
        log1p_9: "f32[8]" = torch.ops.aten.log1p.default(exp_25);  exp_25 = None
        gt_9: "b8[8]" = torch.ops.aten.gt.Scalar(arg285_1, 20)
        where_149: "f32[8]" = torch.ops.aten.where.self(gt_9, arg285_1, log1p_9);  gt_9 = arg285_1 = log1p_9 = None
        view_1021: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_149, [1, 1, 8]);  where_149 = None
        mul_572: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_1021, 0.16666666666666666);  view_1021 = None
        div_121: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_572, 2);  mul_572 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_1016: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_597, 1);  slice_597 = None
        index_281: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_600, [select_104]);  slice_600 = None
        sub_302: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1016, index_281);  unsqueeze_1016 = index_281 = None
        pow_19: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_302, 2);  sub_302 = None
        sum_149: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_19, [-1, -2]);  pow_19 = None
        mul_573: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_121, sum_149);  div_121 = sum_149 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_282: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_442, [select_104]);  add_442 = None
        unsqueeze_1017: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_440, 3);  add_440 = None
        permute_1056: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_1017, [0, 3, 1, 2]);  unsqueeze_1017 = None
        permute_1057: "f32[100, 48, 8, 32]" = torch.ops.aten.permute.default(index_282, [0, 1, 2, 3]);  index_282 = None
        permute_1058: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_1056, [0, 2, 3, 1]);  permute_1056 = None
        view_1022: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_1058, [800, 1, 32]);  permute_1058 = None
        permute_1059: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(permute_1057, [0, 2, 3, 1]);  permute_1057 = None
        clone_109: "f32[100, 8, 32, 48]" = torch.ops.aten.clone.default(permute_1059, memory_format = torch.contiguous_format);  permute_1059 = None
        view_1023: "f32[800, 32, 48]" = torch.ops.aten.view.default(clone_109, [800, 32, 48]);  clone_109 = None
        bmm_222: "f32[800, 1, 48]" = torch.ops.aten.bmm.default(view_1022, view_1023);  view_1022 = view_1023 = None
        view_1024: "f32[100, 8, 1, 48]" = torch.ops.aten.view.default(bmm_222, [100, 8, 1, 48]);  bmm_222 = None
        permute_1060: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_1024, [0, 3, 1, 2]);  view_1024 = None
        view_1025: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_1060, [100, 48, 8]);  permute_1060 = None
        mul_574: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(view_1025, 0.1767766952966369);  view_1025 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_444: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_574, view_1020);  mul_574 = view_1020 = None
        sub_303: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_444, mul_573);  add_444 = mul_573 = None
        mul_575: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_303, 0.5773502691896257);  sub_303 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_32: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_104, -1)
        bitwise_and_74: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_106, ne_32);  select_106 = ne_32 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_1018: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_74, 2);  bitwise_and_74 = None
        where_150: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_1018, mul_575, full_default_41);  mul_575 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_110: "f32[100, 48, 8]" = torch.ops.aten.clone.default(where_150, memory_format = torch.contiguous_format);  where_150 = None
        amax_9: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_110, [-2], True)
        sub_304: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(clone_110, amax_9);  clone_110 = amax_9 = None
        exp_26: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_304);  sub_304 = None
        sum_150: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_26, [-2], True)
        div_122: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_26, sum_150);  exp_26 = sum_150 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_151: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_1018, div_122, full_default_42);  unsqueeze_1018 = div_122 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_1020: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_151, 3);  where_151 = None
        permute_1061: "f32[100, 8, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_1020, [0, 2, 3, 1])
        permute_1062: "f32[100, 1, 64, 48]" = torch.ops.aten.permute.default(unsqueeze_1013, [0, 3, 2, 1]);  unsqueeze_1013 = None
        permute_1063: "f32[100, 8, 48, 1]" = torch.ops.aten.permute.default(permute_1061, [0, 1, 3, 2]);  permute_1061 = None
        view_1026: "f32[100, 8, 48]" = torch.ops.aten.view.default(permute_1063, [100, 8, 48])
        permute_1064: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_1062, [0, 3, 2, 1]);  permute_1062 = None
        view_1027: "f32[100, 48, 64]" = torch.ops.aten.view.default(permute_1064, [100, 48, 64]);  permute_1064 = None
        bmm_223: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_1026, view_1027);  view_1026 = view_1027 = None
        view_1028: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_223, [100, 8, 1, 64]);  bmm_223 = None
        permute_1065: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_1028, [0, 1, 3, 2]);  view_1028 = None
        view_1029: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_1065, [100, 8, 64]);  permute_1065 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_283: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_84, [select_104]);  getitem_84 = None
        permute_1067: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(index_283, [0, 2, 3, 1]);  index_283 = None
        clone_111: "f32[100, 8, 48, 1]" = torch.ops.aten.clone.default(permute_1063, memory_format = torch.contiguous_format);  permute_1063 = None
        view_1030: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_111, [800, 1, 48]);  clone_111 = None
        permute_1069: "f32[100, 8, 48, 32]" = torch.ops.aten.permute.default(permute_1067, [0, 1, 3, 2]);  permute_1067 = None
        clone_112: "f32[100, 8, 48, 32]" = torch.ops.aten.clone.default(permute_1069, memory_format = torch.contiguous_format);  permute_1069 = None
        view_1031: "f32[800, 48, 32]" = torch.ops.aten.view.default(clone_112, [800, 48, 32]);  clone_112 = None
        bmm_224: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_1030, view_1031);  view_1030 = view_1031 = None
        view_1032: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_224, [100, 8, 1, 32]);  bmm_224 = None
        permute_1070: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_1032, [0, 1, 3, 2]);  view_1032 = None
        view_1033: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_1070, [100, 8, 32]);  permute_1070 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_284: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_603, [select_104]);  slice_603 = select_104 = None
        unsqueeze_1024: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1020, 4);  unsqueeze_1020 = None
        permute_1071: "f32[100, 8, 1, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_1024, [0, 2, 3, 4, 1]);  unsqueeze_1024 = None
        permute_1072: "f32[100, 8, 8, 3, 48]" = torch.ops.aten.permute.default(index_284, [0, 2, 3, 4, 1]);  index_284 = None
        permute_1073: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.permute.default(permute_1071, [0, 1, 4, 2, 3]);  permute_1071 = None
        clone_113: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.clone.default(permute_1073, memory_format = torch.contiguous_format);  permute_1073 = None
        view_1034: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_113, [800, 1, 48]);  clone_113 = None
        permute_1074: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.permute.default(permute_1072, [0, 1, 4, 2, 3]);  permute_1072 = None
        clone_114: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.clone.default(permute_1074, memory_format = torch.contiguous_format);  permute_1074 = None
        view_1035: "f32[800, 48, 24]" = torch.ops.aten.view.default(clone_114, [800, 48, 24]);  clone_114 = None
        bmm_225: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_1034, view_1035);  view_1034 = view_1035 = None
        view_1036: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_225, [100, 8, 1, 8, 3]);  bmm_225 = None
        permute_1075: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_1036, [0, 1, 3, 4, 2]);  view_1036 = None
        view_1037: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_1075, [100, 8, 8, 3]);  permute_1075 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_305: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_1037, unsqueeze_284);  view_1037 = None
        unsqueeze_1029: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_305, 4);  sub_305 = None
        permute_1077: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1029, [0, 1, 2, 4, 3]);  unsqueeze_1029 = None
        permute_1079: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_1077, [0, 4, 1, 2, 3]);  permute_1077 = None
        view_1039: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_1079, [100, 3, 64]);  permute_1079 = None
        bmm_226: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_194, view_1039);  view_1039 = None
        view_1040: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_226, [100, 3, 1, 8, 8]);  bmm_226 = None
        permute_1080: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_1040, [0, 3, 4, 1, 2]);  view_1040 = None
        view_1041: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_1080, [100, 8, 8, 3]);  permute_1080 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_576: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_1041, view_1041)
        sum_151: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_576, [-1]);  mul_576 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_128: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_151, 1e-12);  sum_151 = None
        sqrt_98: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_128);  clamp_min_128 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_1042: "f32[100, 512]" = torch.ops.aten.view.default(view_1029, [100, -1]);  view_1029 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_1043: "f32[100, 256]" = torch.ops.aten.view.default(view_1033, [100, -1]);  view_1033 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_115: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_1041, memory_format = torch.contiguous_format);  view_1041 = None
        view_1044: "f32[100, 192]" = torch.ops.aten.view.default(clone_115, [100, 192]);  clone_115 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_1045: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_98, [100, -1]);  sqrt_98 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_74: "f32[100, 1024]" = torch.ops.aten.cat.default([view_1042, view_1043, view_1044, view_1045], -1);  view_1042 = view_1043 = view_1044 = view_1045 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1030: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_74, 2);  cat_74 = None
        permute_1081: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_1030, [0, 2, 1]);  unsqueeze_1030 = None
        unsqueeze_1031: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg286_1, 2);  arg286_1 = None
        permute_1082: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_1031, [2, 1, 0]);  unsqueeze_1031 = None
        permute_1083: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_1081, [0, 2, 1]);  permute_1081 = None
        view_1046: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_1083, [1, 100, 1024]);  permute_1083 = None
        permute_1084: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_1082, [2, 1, 0]);  permute_1082 = None
        view_1047: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_1084, [1, 1024, 128]);  permute_1084 = None
        bmm_227: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_1046, view_1047);  view_1046 = view_1047 = None
        view_1048: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_227, [100, 1, 128]);  bmm_227 = None
        permute_1085: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1048, [0, 2, 1]);  view_1048 = None
        view_1049: "f32[100, 128]" = torch.ops.aten.view.default(permute_1085, [100, 128]);  permute_1085 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_445: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_1049, arg287_1);  view_1049 = arg287_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_446: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_430, add_445);  add_430 = add_445 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_57: "f32[100, 1]" = torch.ops.aten.mean.dim(add_446, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_57: "f32[100, 1]" = torch.ops.aten.var.correction(add_446, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_306: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_446, mean_57);  mean_57 = None
        add_447: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_57, 1e-05);  var_57 = None
        rsqrt_57: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_447);  add_447 = None
        mul_577: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_306, rsqrt_57);  sub_306 = rsqrt_57 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_578: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_577, arg288_1);  mul_577 = arg288_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_448: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_578, arg289_1);  mul_578 = arg289_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_311: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_391, unsqueeze_925)
        permute_1086: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_924, [0, 1, 3, 2])
        unsqueeze_1040: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_311, 3);  sub_311 = None
        permute_1087: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1040, [0, 1, 3, 2]);  unsqueeze_1040 = None
        permute_1088: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_1086, [0, 2, 3, 1]);  permute_1086 = None
        view_1050: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_1088, [100, 3, 3]);  permute_1088 = None
        permute_1089: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_1087, [0, 3, 1, 2]);  permute_1087 = None
        view_1051: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_1089, [100, 3, 20]);  permute_1089 = None
        bmm_228: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_1050, view_1051);  view_1050 = view_1051 = None
        view_1052: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_228, [100, 3, 1, 20]);  bmm_228 = None
        permute_1090: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_1052, [0, 3, 1, 2]);  view_1052 = None
        view_1053: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_1090, [100, 20, 3]);  permute_1090 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        clone_116: "f32[100, 20, 3]" = torch.ops.aten.clone.default(view_1053, memory_format = torch.contiguous_format)
        view_1054: "f32[100, 60]" = torch.ops.aten.view.default(clone_116, [100, 60]);  clone_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1042: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg290_1, 2);  arg290_1 = None
        permute_1092: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_1042, [2, 1, 0]);  unsqueeze_1042 = None
        permute_1094: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_1092, [2, 1, 0]);  permute_1092 = None
        view_1056: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_1094, [1, 128, 128]);  permute_1094 = None
        bmm_229: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_211, view_1056);  view_1056 = None
        view_1057: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_229, [100, 1, 128]);  bmm_229 = None
        permute_1095: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1057, [0, 2, 1]);  view_1057 = None
        view_1058: "f32[100, 128]" = torch.ops.aten.view.default(permute_1095, [100, 128]);  permute_1095 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_453: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_448, view_1058);  add_448 = view_1058 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1043: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_1054, 2);  view_1054 = None
        permute_1096: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_1043, [0, 2, 1]);  unsqueeze_1043 = None
        unsqueeze_1044: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg291_1, 2);  arg291_1 = None
        permute_1097: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_1044, [2, 1, 0]);  unsqueeze_1044 = None
        permute_1098: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_1096, [0, 2, 1]);  permute_1096 = None
        view_1059: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_1098, [1, 100, 60]);  permute_1098 = None
        permute_1099: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_1097, [2, 1, 0]);  permute_1097 = None
        view_1060: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_1099, [1, 60, 256]);  permute_1099 = None
        bmm_230: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_1059, view_1060);  view_1059 = view_1060 = None
        view_1061: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_230, [100, 1, 256]);  bmm_230 = None
        permute_1100: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_1061, [0, 2, 1]);  view_1061 = None
        view_1062: "f32[100, 256]" = torch.ops.aten.view.default(permute_1100, [100, 256]);  permute_1100 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_454: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_1062, arg292_1);  view_1062 = arg292_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_585: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_454, add_454)
        mul_586: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_585, add_454);  mul_585 = None
        mul_587: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_586, 0.044715);  mul_586 = None
        add_455: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_454, mul_587);  mul_587 = None
        mul_588: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_455, 0.7978845608028654);  add_455 = None
        mul_589: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_454, 0.5);  add_454 = None
        tanh_23: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_588);  mul_588 = None
        add_456: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_23, 1);  tanh_23 = None
        mul_590: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_589, add_456);  mul_589 = add_456 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1045: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_590, 2);  mul_590 = None
        permute_1101: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_1045, [0, 2, 1]);  unsqueeze_1045 = None
        unsqueeze_1046: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg293_1, 2);  arg293_1 = None
        permute_1102: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_1046, [2, 1, 0]);  unsqueeze_1046 = None
        permute_1103: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_1101, [0, 2, 1]);  permute_1101 = None
        view_1063: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_1103, [1, 100, 256]);  permute_1103 = None
        permute_1104: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_1102, [2, 1, 0]);  permute_1102 = None
        view_1064: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_1104, [1, 256, 128]);  permute_1104 = None
        bmm_231: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_1063, view_1064);  view_1063 = view_1064 = None
        view_1065: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_231, [100, 1, 128]);  bmm_231 = None
        permute_1105: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1065, [0, 2, 1]);  view_1065 = None
        view_1066: "f32[100, 128]" = torch.ops.aten.view.default(permute_1105, [100, 128]);  permute_1105 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_457: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_1066, arg294_1);  view_1066 = arg294_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_458: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_453, add_457);  add_453 = add_457 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1047: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_458, 2);  add_458 = None
        permute_1106: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1047, [0, 2, 1]);  unsqueeze_1047 = None
        unsqueeze_1048: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg295_1, 2);  arg295_1 = None
        permute_1107: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1048, [2, 1, 0]);  unsqueeze_1048 = None
        permute_1108: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_1106, [0, 2, 1]);  permute_1106 = None
        view_1067: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_1108, [1, 100, 128]);  permute_1108 = None
        permute_1109: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_1107, [2, 1, 0]);  permute_1107 = None
        view_1068: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_1109, [1, 128, 512]);  permute_1109 = None
        bmm_232: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_1067, view_1068);  view_1068 = None
        view_1069: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_232, [100, 1, 512]);  bmm_232 = None
        permute_1110: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_1069, [0, 2, 1]);  view_1069 = None
        view_1070: "f32[100, 512]" = torch.ops.aten.view.default(permute_1110, [100, 512]);  permute_1110 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1050: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg296_1, 2);  arg296_1 = None
        permute_1112: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1050, [2, 1, 0]);  unsqueeze_1050 = None
        permute_1114: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_1112, [2, 1, 0]);  permute_1112 = None
        view_1072: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_1114, [1, 128, 512]);  permute_1114 = None
        bmm_233: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_1067, view_1072);  view_1072 = None
        view_1073: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_233, [100, 1, 512]);  bmm_233 = None
        permute_1115: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_1073, [0, 2, 1]);  view_1073 = None
        view_1074: "f32[100, 512]" = torch.ops.aten.view.default(permute_1115, [100, 512]);  permute_1115 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_591: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1074, view_1074)
        mul_592: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_591, view_1074);  mul_591 = None
        mul_593: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_592, 0.044715);  mul_592 = None
        add_459: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_1074, mul_593);  mul_593 = None
        mul_594: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_459, 0.7978845608028654);  add_459 = None
        mul_595: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1074, 0.5);  view_1074 = None
        tanh_24: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_594);  mul_594 = None
        add_460: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_24, 1);  tanh_24 = None
        mul_596: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_595, add_460);  mul_595 = add_460 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_597: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_596, view_1070);  mul_596 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1052: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg297_1, 2);  arg297_1 = None
        permute_1117: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1052, [2, 1, 0]);  unsqueeze_1052 = None
        permute_1119: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_1117, [2, 1, 0]);  permute_1117 = None
        view_1076: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_1119, [1, 128, 512]);  permute_1119 = None
        bmm_234: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_1067, view_1076);  view_1076 = None
        view_1077: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_234, [100, 1, 512]);  bmm_234 = None
        permute_1120: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_1077, [0, 2, 1]);  view_1077 = None
        view_1078: "f32[100, 512]" = torch.ops.aten.view.default(permute_1120, [100, 512]);  permute_1120 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_598: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1078, view_1078)
        mul_599: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_598, view_1078);  mul_598 = None
        mul_600: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_599, 0.044715);  mul_599 = None
        add_461: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_1078, mul_600);  mul_600 = None
        mul_601: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_461, 0.7978845608028654);  add_461 = None
        mul_602: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1078, 0.5);  view_1078 = None
        tanh_25: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_601);  mul_601 = None
        add_462: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_25, 1);  tanh_25 = None
        mul_603: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_602, add_462);  mul_602 = add_462 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1054: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg298_1, 2);  arg298_1 = None
        permute_1122: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1054, [2, 1, 0]);  unsqueeze_1054 = None
        permute_1124: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_1122, [2, 1, 0]);  permute_1122 = None
        view_1080: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_1124, [1, 128, 512]);  permute_1124 = None
        bmm_235: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_1067, view_1080);  view_1067 = view_1080 = None
        view_1081: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_235, [100, 1, 512]);  bmm_235 = None
        permute_1125: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_1081, [0, 2, 1]);  view_1081 = None
        view_1082: "f32[100, 512]" = torch.ops.aten.view.default(permute_1125, [100, 512]);  permute_1125 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_604: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1082, view_1082)
        mul_605: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_604, view_1082);  mul_604 = None
        mul_606: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_605, 0.044715);  mul_605 = None
        add_463: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_1082, mul_606);  mul_606 = None
        mul_607: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_463, 0.7978845608028654);  add_463 = None
        mul_608: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1082, 0.5);  view_1082 = None
        tanh_26: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_607);  mul_607 = None
        add_464: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_26, 1);  tanh_26 = None
        mul_609: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_608, add_464);  mul_608 = add_464 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_610: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_609, view_1070);  mul_609 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_152: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_610, full_default_44);  mul_610 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_153: "f32[100, 512]" = torch.ops.aten.where.self(view_239, where_152, full_default_44);  where_152 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_16: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_6, where_153);  where_153 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_289: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_16, [clamp_max_2]);  scatter_add_16 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_125: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_289, clamp_min_33);  index_289 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_156: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_125, full_default_44);  div_125 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_465: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_597, where_156);  mul_597 = where_156 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_612: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_603, view_1070);  mul_603 = view_1070 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_157: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_612, full_default_44);  mul_612 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_158: "f32[100, 512]" = torch.ops.aten.where.self(view_243, where_157, full_default_44);  where_157 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_18: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_8, where_158);  where_158 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_291: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_18, [clamp_max_4]);  scatter_add_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_126: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_291, clamp_min_36);  index_291 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_161: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_126, full_default_44);  div_126 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_466: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_465, where_161);  add_465 = where_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1056: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_466, 2);  add_466 = None
        permute_1126: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_1056, [0, 2, 1]);  unsqueeze_1056 = None
        unsqueeze_1057: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg299_1, 2);  arg299_1 = None
        permute_1127: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_1057, [2, 1, 0]);  unsqueeze_1057 = None
        permute_1128: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_1126, [0, 2, 1]);  permute_1126 = None
        view_1091: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_1128, [1, 100, 512]);  permute_1128 = None
        permute_1129: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_1127, [2, 1, 0]);  permute_1127 = None
        view_1092: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_1129, [1, 512, 128]);  permute_1129 = None
        bmm_236: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_1091, view_1092);  view_1091 = view_1092 = None
        view_1093: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_236, [100, 1, 128]);  bmm_236 = None
        permute_1130: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1093, [0, 2, 1]);  view_1093 = None
        view_1094: "f32[100, 128]" = torch.ops.aten.view.default(permute_1130, [100, 128]);  permute_1130 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_467: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_1094, arg300_1);  view_1094 = arg300_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_468: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_446, add_467);  add_446 = add_467 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_58: "f32[100, 1]" = torch.ops.aten.mean.dim(add_468, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_58: "f32[100, 1]" = torch.ops.aten.var.correction(add_468, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_312: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_468, mean_58);  mean_58 = None
        add_469: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_58, 1e-05);  var_58 = None
        rsqrt_58: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_469);  add_469 = None
        mul_614: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_312, rsqrt_58);  sub_312 = rsqrt_58 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_615: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_614, arg301_1);  arg301_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_470: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_615, arg302_1);  mul_615 = arg302_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1067: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_470, 2);  add_470 = None
        permute_1136: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1067, [0, 2, 1]);  unsqueeze_1067 = None
        unsqueeze_1068: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg303_1, 2);  arg303_1 = None
        permute_1137: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_1068, [2, 1, 0]);  unsqueeze_1068 = None
        permute_1138: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_1136, [0, 2, 1]);  permute_1136 = None
        view_1099: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_1138, [1, 100, 128]);  permute_1138 = None
        permute_1139: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_1137, [2, 1, 0]);  permute_1137 = None
        view_1100: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_1139, [1, 128, 60]);  permute_1139 = None
        bmm_238: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_1099, view_1100);  view_1099 = view_1100 = None
        view_1101: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_238, [100, 1, 60]);  bmm_238 = None
        permute_1140: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_1101, [0, 2, 1]);  view_1101 = None
        view_1102: "f32[100, 60]" = torch.ops.aten.view.default(permute_1140, [100, 60]);  permute_1140 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_622: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_1102, 10.0);  view_1102 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_1103: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_622, [100, 20, 3]);  mul_622 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_475: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_1053, view_1103);  view_1053 = view_1103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_1141: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_924, [0, 1, 2, 3]);  unsqueeze_924 = None
        unsqueeze_1071: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(add_475, 3);  add_475 = None
        permute_1142: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1071, [0, 1, 3, 2]);  unsqueeze_1071 = None
        permute_1143: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_1141, [0, 2, 3, 1]);  permute_1141 = None
        view_1104: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_1143, [100, 3, 3]);  permute_1143 = None
        permute_1144: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_1142, [0, 3, 1, 2]);  permute_1142 = None
        view_1105: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_1144, [100, 3, 20]);  permute_1144 = None
        bmm_239: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_1104, view_1105);  view_1104 = view_1105 = None
        view_1106: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_239, [100, 3, 1, 20]);  bmm_239 = None
        permute_1145: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_1106, [0, 3, 1, 2]);  view_1106 = None
        view_1107: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_1145, [100, 20, 3]);  permute_1145 = None
        add_476: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_1107, unsqueeze_925);  view_1107 = unsqueeze_925 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:176 in inner, code: distance = pair_distance(pos[:, 1])
        select_125: "f32[100, 3]" = torch.ops.aten.select.int(add_476, 1, 1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:32 in pair_distance, code: return vec_norm(points[:, None, :] - points[None, :, :])
        unsqueeze_1072: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_125, 1)
        unsqueeze_1073: "f32[1, 100, 3]" = torch.ops.aten.unsqueeze.default(select_125, 0)
        sub_318: "f32[100, 100, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1072, unsqueeze_1073);  unsqueeze_1072 = unsqueeze_1073 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_623: "f32[100, 100, 3]" = torch.ops.aten.mul.Tensor(sub_318, sub_318);  sub_318 = None
        sum_158: "f32[100, 100]" = torch.ops.aten.sum.dim_IntList(mul_623, [-1]);  mul_623 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_139: "f32[100, 100]" = torch.ops.aten.clamp_min.default(sum_158, 1e-12);  sum_158 = None
        sqrt_103: "f32[100, 100]" = torch.ops.aten.sqrt.default(clamp_min_139);  clamp_min_139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:113 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_162: "f32[100, 100]" = torch.ops.aten.where.self(eq, sqrt_103, full_default)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_163: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_162, full_default);  where_162 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_298: "f32[100, 16]" = torch.ops.aten.index.Tensor(where_163, [unsqueeze_24, where_1])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_164: "f32[100, 16]" = torch.ops.aten.where.self(ne, full_default_3, index_298);  ne = full_default_3 = index_298 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_17: "f32[100, 100]" = torch.ops.aten.index_put.default(where_163, [unsqueeze_24, where_1], where_164);  where_163 = where_164 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_18 = torch.ops.aten.sort.stable(index_put_17, stable = True)
        getitem_86: "i64[100, 100]" = sort_18[1];  sort_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_631: "i64[100, 16]" = torch.ops.aten.slice.Tensor(getitem_86, 1, 0, 16);  getitem_86 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_299: "f32[100, 16]" = torch.ops.aten.index.Tensor(index_put_17, [unsqueeze_24, slice_631]);  index_put_17 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_38: "b8[100, 16]" = torch.ops.aten.lt.Scalar(index_299, inf);  index_299 = None
        where_165: "i64[100, 16]" = torch.ops.aten.where.self(lt_38, slice_631, full_default_1);  lt_38 = slice_631 = full_default_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_77: "i64[100, 32]" = torch.ops.aten.cat.default([where_1, where_165], -1);  where_165 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:140 in inner, code: weight = -3.0 * torch.log(distance + 1e-6)
        add_477: "f32[100, 100]" = torch.ops.aten.add.Tensor(sqrt_103, 1e-06);  sqrt_103 = None
        log_33: "f32[100, 100]" = torch.ops.aten.log.default(add_477);  add_477 = None
        mul_624: "f32[100, 100]" = torch.ops.aten.mul.Tensor(log_33, -3.0);  log_33 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:147 in inner, code: gumbel = torch.log(-torch.log(uniform))
        log_34: "f32[100, 100]" = torch.ops.aten.log.default(getitem_16)
        neg_29: "f32[100, 100]" = torch.ops.aten.neg.default(log_34);  log_34 = None
        log_35: "f32[100, 100]" = torch.ops.aten.log.default(neg_29);  neg_29 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:148 in inner, code: weight = weight - gumbel
        sub_319: "f32[100, 100]" = torch.ops.aten.sub.Tensor(mul_624, log_35);  mul_624 = log_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:149 in inner, code: distance = -weight
        neg_30: "f32[100, 100]" = torch.ops.aten.neg.default(sub_319);  sub_319 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:150 in inner, code: distance = torch.where(same_item, distance, torch.full_like(distance, _INF))
        where_166: "f32[100, 100]" = torch.ops.aten.where.self(eq, neg_30, full_default);  eq = neg_30 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:54 in inner, code: distance = torch.where(mask.bool(), distance, torch.full_like(distance, _INF))
        where_167: "f32[100, 100]" = torch.ops.aten.where.self(bitwise_and_1, where_166, full_default);  bitwise_and_1 = where_166 = full_default = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:58 in inner, code: neighbours != -1,
        ne_34: "b8[100, 32]" = torch.ops.aten.ne.Scalar(cat_77, -1)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:60 in inner, code: distance[index[:, None], neighbours],
        index_301: "f32[100, 32]" = torch.ops.aten.index.Tensor(where_167, [unsqueeze_24, cat_77])
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:57 in inner, code: update = torch.where(
        where_168: "f32[100, 32]" = torch.ops.aten.where.self(ne_34, full_default_7, index_301);  ne_34 = full_default_7 = index_301 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:63 in inner, code: distance[index[:, None], neighbours] = update
        index_put_18: "f32[100, 100]" = torch.ops.aten.index_put.default(where_167, [unsqueeze_24, cat_77], where_168);  where_167 = where_168 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:67 in inner, code: order = torch.argsort(distance, dim=-1, stable=True)
        sort_19 = torch.ops.aten.sort.stable(index_put_18, stable = True)
        getitem_88: "i64[100, 100]" = sort_19[1];  sort_19 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:68 in inner, code: knn = order[..., :count]
        slice_640: "i64[100, 32]" = torch.ops.aten.slice.Tensor(getitem_88, 1, 0, 32);  getitem_88 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:69 in inner, code: picked = distance[index[:, None], knn]
        index_302: "f32[100, 32]" = torch.ops.aten.index.Tensor(index_put_18, [unsqueeze_24, slice_640]);  index_put_18 = unsqueeze_24 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:70 in inner, code: knn = torch.where(picked < _INF, knn, torch.full_like(knn, -1))
        lt_39: "b8[100, 32]" = torch.ops.aten.lt.Scalar(index_302, inf);  index_302 = None
        where_169: "i64[100, 32]" = torch.ops.aten.where.self(lt_39, slice_640, full_default_37);  lt_39 = slice_640 = full_default_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/neighbours.py:72 in inner, code: knn = torch.cat((neighbours, knn), dim=-1)
        cat_78: "i64[100, 64]" = torch.ops.aten.cat.default([cat_77, where_169], -1);  cat_77 = where_169 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/diffusion.py:356 in neighbour_fn, code: cond = (cond_nbr_stack[block_idx] if cond_nbr_stack is not None
        select_126: "i64[100, 48]" = torch.ops.aten.select.int(view_14, 0, 5)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:442 in forward, code: cp = None if cond_pair is None else (cond_pair[0][block_idx],
        select_127: "f32[100, 48, 64]" = torch.ops.aten.select.int(view_52, 0, 5);  view_52 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:443 in forward, code: cond_pair[1][block_idx])
        select_128: "b8[100, 48]" = torch.ops.aten.select.int(bitwise_and_18, 0, 5);  bitwise_and_18 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:166 in forward, code: pair_mask = mask[:, None] & mask[neighbours] & (neighbours != -1)
        index_303: "b8[100, 64]" = torch.ops.aten.index.Tensor(arg16_1, [cat_78]);  arg16_1 = None
        bitwise_and_83: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(unsqueeze_20, index_303);  index_303 = None
        ne_35: "b8[100, 64]" = torch.ops.aten.ne.Scalar(cat_78, -1)
        bitwise_and_84: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_83, ne_35);  bitwise_and_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:133 in inner, code: same_chain = chain[:, None] == chain[neighbours]
        index_304: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg15_1, [cat_78]);  arg15_1 = None
        eq_33: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_18, index_304);  unsqueeze_18 = index_304 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:134 in inner, code: same_batch = batch[:, None] == batch[neighbours]
        index_305: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg14_1, [cat_78]);  arg14_1 = None
        eq_34: "b8[100, 64]" = torch.ops.aten.eq.Tensor(unsqueeze_16, index_305);  unsqueeze_16 = index_305 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:135 in inner, code: rel = resi[:, None] - resi[neighbours]
        index_306: "i64[100, 64]" = torch.ops.aten.index.Tensor(arg13_1, [cat_78]);  arg13_1 = None
        sub_320: "i64[100, 64]" = torch.ops.aten.sub.Tensor(unsqueeze_22, index_306);  unsqueeze_22 = index_306 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:150 in inner, code: binned = rel.clamp(-count, count) + count
        clamp_min_140: "i64[100, 64]" = torch.ops.aten.clamp_min.default(sub_320, -32);  sub_320 = None
        clamp_max_26: "i64[100, 64]" = torch.ops.aten.clamp_max.default(clamp_min_140, 32);  clamp_min_140 = None
        add_478: "i64[100, 64]" = torch.ops.aten.add.Tensor(clamp_max_26, 32);  clamp_max_26 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:152 in inner, code: binned = torch.where(same_chain, binned, other)
        where_170: "i64[100, 64]" = torch.ops.aten.where.self(eq_33, add_478, full_default_38);  eq_33 = add_478 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:153 in inner, code: binned = torch.where(same_batch, binned, other)
        where_171: "i64[100, 64]" = torch.ops.aten.where.self(eq_34, where_170, full_default_38);  eq_34 = where_170 = full_default_38 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:126 in forward_indexed, code: out = self.w[idx]
        index_307: "f32[100, 64, 64]" = torch.ops.aten.index.Tensor(arg304_1, [where_171]);  arg304_1 = where_171 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:168 in distance_features, code: left = pos[:, None, :5, None, :]
        unsqueeze_1094: "f32[100, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(add_476, 1)
        slice_647: "f32[100, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_1094, 2, 0, 5)
        unsqueeze_1095: "f32[100, 1, 5, 1, 3]" = torch.ops.aten.unsqueeze.default(slice_647, 3);  slice_647 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:169 in distance_features, code: right = pos[neighbours][:, :, None, :5, :]
        index_308: "f32[100, 64, 20, 3]" = torch.ops.aten.index.Tensor(add_476, [cat_78])
        unsqueeze_1096: "f32[100, 64, 1, 20, 3]" = torch.ops.aten.unsqueeze.default(index_308, 2)
        slice_651: "f32[100, 64, 1, 5, 3]" = torch.ops.aten.slice.Tensor(unsqueeze_1096, 3, 0, 5);  unsqueeze_1096 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:170 in distance_features, code: dist = vec_norm(left - right)
        sub_321: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1095, slice_651);  unsqueeze_1095 = slice_651 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_625: "f32[100, 64, 5, 5, 3]" = torch.ops.aten.mul.Tensor(sub_321, sub_321);  sub_321 = None
        sum_159: "f32[100, 64, 5, 5]" = torch.ops.aten.sum.dim_IntList(mul_625, [-1]);  mul_625 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_141: "f32[100, 64, 5, 5]" = torch.ops.aten.clamp_min.default(sum_159, 1e-12);  sum_159 = None
        sqrt_104: "f32[100, 64, 5, 5]" = torch.ops.aten.sqrt.default(clamp_min_141);  clamp_min_141 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:172 in distance_features, code: dist = dist.reshape(n, k, 25)
        view_1108: "f32[100, 64, 25]" = torch.ops.aten.view.default(sqrt_104, [100, 64, 25]);  sqrt_104 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:44 in gaussian_rbf, code: return torch.exp(-((x[..., None] - centers) ** 2) / step ** 2)
        unsqueeze_1097: "f32[100, 64, 25, 1]" = torch.ops.aten.unsqueeze.default(view_1108, 3);  view_1108 = None
        sub_322: "f32[100, 64, 25, 16]" = torch.ops.aten.sub.Tensor(unsqueeze_1097, add_29);  unsqueeze_1097 = add_29 = None
        pow_20: "f32[100, 64, 25, 16]" = torch.ops.aten.pow.Tensor_Scalar(sub_322, 2);  sub_322 = None
        neg_31: "f32[100, 64, 25, 16]" = torch.ops.aten.neg.default(pow_20);  pow_20 = None
        div_129: "f32[100, 64, 25, 16]" = torch.ops.aten.div.Tensor(neg_31, 1.890625);  neg_31 = None
        exp_27: "f32[100, 64, 25, 16]" = torch.ops.aten.exp.default(div_129);  div_129 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:173 in distance_features, code: return distance_rbf(dist, d_min, d_max, num_rbf).reshape(n, k, 25 * num_rbf)
        view_1109: "f32[100, 64, 400]" = torch.ops.aten.view.default(exp_27, [100, 64, 400]);  exp_27 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1098: "f32[100, 64, 400, 1]" = torch.ops.aten.unsqueeze.default(view_1109, 3);  view_1109 = None
        permute_1146: "f32[100, 64, 1, 400]" = torch.ops.aten.permute.default(unsqueeze_1098, [0, 1, 3, 2]);  unsqueeze_1098 = None
        unsqueeze_1099: "f32[400, 64, 1]" = torch.ops.aten.unsqueeze.default(arg305_1, 2);  arg305_1 = None
        unsqueeze_1100: "f32[400, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1099, 3);  unsqueeze_1099 = None
        permute_1147: "f32[1, 1, 64, 400]" = torch.ops.aten.permute.default(unsqueeze_1100, [2, 3, 1, 0]);  unsqueeze_1100 = None
        permute_1148: "f32[100, 64, 400, 1]" = torch.ops.aten.permute.default(permute_1146, [0, 1, 3, 2]);  permute_1146 = None
        view_1110: "f32[1, 6400, 400]" = torch.ops.aten.view.default(permute_1148, [1, 6400, 400]);  permute_1148 = None
        permute_1149: "f32[400, 64, 1, 1]" = torch.ops.aten.permute.default(permute_1147, [3, 2, 0, 1]);  permute_1147 = None
        view_1111: "f32[1, 400, 64]" = torch.ops.aten.view.default(permute_1149, [1, 400, 64]);  permute_1149 = None
        bmm_240: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_1110, view_1111);  view_1110 = view_1111 = None
        view_1112: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_240, [100, 64, 1, 64]);  bmm_240 = None
        permute_1150: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_1112, [0, 1, 3, 2]);  view_1112 = None
        view_1113: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_1150, [100, 64, 64]);  permute_1150 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:209 in forward, code: pair = pair + self.linear_dist(
        add_482: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(index_307, view_1113);  index_307 = view_1113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_129: "f32[100, 3]" = torch.ops.aten.select.int(add_476, 1, 0)
        select_131: "f32[100, 3]" = torch.ops.aten.select.int(add_476, 1, 2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_323: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_131, select_125);  select_131 = None
        sub_324: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_129, select_125);  select_129 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_628: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_323, sub_323)
        sum_160: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_628, [-1]);  mul_628 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_142: "f32[100]" = torch.ops.aten.clamp_min.default(sum_160, 1e-12);  sum_160 = None
        sqrt_105: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_142);  clamp_min_142 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1101: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_105, -1);  sqrt_105 = None
        div_130: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_323, unsqueeze_1101);  sub_323 = unsqueeze_1101 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_629: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_324, div_130)
        sum_161: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_629, [-1]);  mul_629 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_1102: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_161, -1);  sum_161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_630: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1102, div_130);  unsqueeze_1102 = None
        sub_325: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_324, mul_630);  sub_324 = mul_630 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_631: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_325, sub_325)
        sum_162: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_631, [-1]);  mul_631 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_143: "f32[100]" = torch.ops.aten.clamp_min.default(sum_162, 1e-12);  sum_162 = None
        sqrt_106: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_143);  clamp_min_143 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1103: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_106, -1);  sqrt_106 = None
        div_131: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_325, unsqueeze_1103);  sub_325 = unsqueeze_1103 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_309: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_130, [None, remainder])
        index_310: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_131, [None, remainder_1])
        mul_632: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_309, index_310);  index_309 = index_310 = None
        index_311: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_130, [None, remainder_1])
        index_312: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_131, [None, remainder])
        mul_633: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_311, index_312);  index_311 = index_312 = None
        sub_326: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_632, mul_633);  mul_632 = mul_633 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_1104: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_130, 2);  div_130 = None
        unsqueeze_1105: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_131, 2);  div_131 = None
        unsqueeze_1106: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_326, 2);  sub_326 = None
        cat_79: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_1104, unsqueeze_1105, unsqueeze_1106], -1);  unsqueeze_1104 = unsqueeze_1105 = unsqueeze_1106 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1110: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_79, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1111: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_125, -2);  select_125 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1112: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_1110, -3)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1113: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_1111, -2)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_328: "f32[100, 64, 20, 3]" = torch.ops.aten.sub.Tensor(index_308, unsqueeze_1113)
        permute_1156: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_1112, [0, 1, 2, 4, 3]);  unsqueeze_1112 = None
        unsqueeze_1114: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_328, 4);  sub_328 = None
        permute_1157: "f32[100, 64, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1114, [0, 1, 2, 4, 3]);  unsqueeze_1114 = None
        permute_1158: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_1156, [0, 3, 4, 1, 2]);  permute_1156 = None
        view_1118: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_1158, [100, 3, 3]);  permute_1158 = None
        permute_1159: "f32[100, 3, 64, 20, 1]" = torch.ops.aten.permute.default(permute_1157, [0, 4, 1, 2, 3]);  permute_1157 = None
        view_1119: "f32[100, 3, 1280]" = torch.ops.aten.view.default(permute_1159, [100, 3, 1280]);  permute_1159 = None
        bmm_242: "f32[100, 3, 1280]" = torch.ops.aten.bmm.default(view_1118, view_1119);  view_1119 = None
        view_1120: "f32[100, 3, 1, 64, 20]" = torch.ops.aten.view.default(bmm_242, [100, 3, 1, 64, 20]);  bmm_242 = None
        permute_1160: "f32[100, 64, 20, 3, 1]" = torch.ops.aten.permute.default(view_1120, [0, 3, 4, 1, 2]);  view_1120 = None
        view_1121: "f32[100, 64, 20, 3]" = torch.ops.aten.view.default(permute_1160, [100, 64, 20, 3]);  permute_1160 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_634: "f32[100, 64, 20, 3]" = torch.ops.aten.mul.Tensor(view_1121, view_1121)
        sum_163: "f32[100, 64, 20]" = torch.ops.aten.sum.dim_IntList(mul_634, [-1]);  mul_634 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_144: "f32[100, 64, 20]" = torch.ops.aten.clamp_min.default(sum_163, 1e-12);  sum_163 = None
        sqrt_107: "f32[100, 64, 20]" = torch.ops.aten.sqrt.default(clamp_min_144);  clamp_min_144 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1115: "f32[100, 64, 20, 1]" = torch.ops.aten.unsqueeze.default(sqrt_107, -1);  sqrt_107 = None
        div_132: "f32[100, 64, 20, 3]" = torch.ops.aten.div.Tensor(view_1121, unsqueeze_1115);  view_1121 = unsqueeze_1115 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:264 in direction_and_pair_vector_features, code: apply_inverse_t(rot, trans, neigh_pos, k=2)).reshape(n, k, a * 3)
        clone_119: "f32[100, 64, 20, 3]" = torch.ops.aten.clone.default(div_132, memory_format = torch.contiguous_format);  div_132 = None
        view_1122: "f32[100, 64, 60]" = torch.ops.aten.view.default(clone_119, [100, 64, 60]);  clone_119 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:277 in direction_and_pair_vector_features, code: self_pos = pos[:, None].expand(n, k, a, 3)            # (N, K, A, 3)
        expand_38: "f32[100, 64, 20, 3]" = torch.ops.aten.expand.default(unsqueeze_1094, [100, 64, 20, 3]);  unsqueeze_1094 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:278 in direction_and_pair_vector_features, code: both = torch.cat([self_pos, neigh_pos], dim=-2)       # (N, K, 2A, 3)
        cat_80: "f32[100, 64, 40, 3]" = torch.ops.aten.cat.default([expand_38, index_308], -2);  expand_38 = index_308 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_329: "f32[100, 64, 40, 3]" = torch.ops.aten.sub.Tensor(cat_80, unsqueeze_1113);  cat_80 = unsqueeze_1113 = None
        unsqueeze_1121: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_329, 4);  sub_329 = None
        permute_1162: "f32[100, 64, 40, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1121, [0, 1, 2, 4, 3]);  unsqueeze_1121 = None
        permute_1164: "f32[100, 3, 64, 40, 1]" = torch.ops.aten.permute.default(permute_1162, [0, 4, 1, 2, 3]);  permute_1162 = None
        view_1124: "f32[100, 3, 2560]" = torch.ops.aten.view.default(permute_1164, [100, 3, 2560]);  permute_1164 = None
        bmm_243: "f32[100, 3, 2560]" = torch.ops.aten.bmm.default(view_1118, view_1124);  view_1118 = view_1124 = None
        view_1125: "f32[100, 3, 1, 64, 40]" = torch.ops.aten.view.default(bmm_243, [100, 3, 1, 64, 40]);  bmm_243 = None
        permute_1165: "f32[100, 64, 40, 3, 1]" = torch.ops.aten.permute.default(view_1125, [0, 3, 4, 1, 2]);  view_1125 = None
        view_1126: "f32[100, 64, 40, 3]" = torch.ops.aten.view.default(permute_1165, [100, 64, 40, 3]);  permute_1165 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_635: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_1126, view_1126)
        sum_164: "f32[100, 64, 40]" = torch.ops.aten.sum.dim_IntList(mul_635, [-1]);  mul_635 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_145: "f32[100, 64, 40]" = torch.ops.aten.clamp_min.default(sum_164, 1e-12);  sum_164 = None
        sqrt_108: "f32[100, 64, 40]" = torch.ops.aten.sqrt.default(clamp_min_145);  clamp_min_145 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1122: "f32[100, 64, 40, 1]" = torch.ops.aten.unsqueeze.default(sqrt_108, -1);  sqrt_108 = None
        div_133: "f32[100, 64, 40, 3]" = torch.ops.aten.div.Tensor(view_1126, unsqueeze_1122);  unsqueeze_1122 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:280 in direction_and_pair_vector_features, code: directions = vec_normalized(local).reshape(n, k, 2 * a * 3)
        clone_120: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(div_133, memory_format = torch.contiguous_format);  div_133 = None
        view_1127: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_120, [100, 64, 120]);  clone_120 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:281 in direction_and_pair_vector_features, code: coords = (scale * local).reshape(n, k, 2 * a * 3)
        mul_636: "f32[100, 64, 40, 3]" = torch.ops.aten.mul.Tensor(view_1126, 0.1);  view_1126 = None
        clone_121: "f32[100, 64, 40, 3]" = torch.ops.aten.clone.default(mul_636, memory_format = torch.contiguous_format);  mul_636 = None
        view_1128: "f32[100, 64, 120]" = torch.ops.aten.view.default(clone_121, [100, 64, 120]);  clone_121 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:282 in direction_and_pair_vector_features, code: return direction, torch.cat([directions, coords], dim=-1)
        cat_81: "f32[100, 64, 240]" = torch.ops.aten.cat.default([view_1127, view_1128], -1);  view_1127 = view_1128 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1123: "f32[100, 64, 60, 1]" = torch.ops.aten.unsqueeze.default(view_1122, 3);  view_1122 = None
        permute_1166: "f32[100, 64, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_1123, [0, 1, 3, 2]);  unsqueeze_1123 = None
        unsqueeze_1124: "f32[60, 64, 1]" = torch.ops.aten.unsqueeze.default(arg306_1, 2);  arg306_1 = None
        unsqueeze_1125: "f32[60, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1124, 3);  unsqueeze_1124 = None
        permute_1167: "f32[1, 1, 64, 60]" = torch.ops.aten.permute.default(unsqueeze_1125, [2, 3, 1, 0]);  unsqueeze_1125 = None
        permute_1168: "f32[100, 64, 60, 1]" = torch.ops.aten.permute.default(permute_1166, [0, 1, 3, 2]);  permute_1166 = None
        view_1129: "f32[1, 6400, 60]" = torch.ops.aten.view.default(permute_1168, [1, 6400, 60]);  permute_1168 = None
        permute_1169: "f32[60, 64, 1, 1]" = torch.ops.aten.permute.default(permute_1167, [3, 2, 0, 1]);  permute_1167 = None
        view_1130: "f32[1, 60, 64]" = torch.ops.aten.view.default(permute_1169, [1, 60, 64]);  permute_1169 = None
        bmm_244: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_1129, view_1130);  view_1129 = view_1130 = None
        view_1131: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_244, [100, 64, 1, 64]);  bmm_244 = None
        permute_1170: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_1131, [0, 1, 3, 2]);  view_1131 = None
        view_1132: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_1170, [100, 64, 64]);  permute_1170 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:218 in forward, code: pair = pair + self.linear_dir(dir_f)
        add_487: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_482, view_1132);  add_482 = view_1132 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:197 in position_rotation_features, code: rel = rot_compose(rot[:, None].transpose(-1, -2), rot[neighbours])
        unsqueeze_1135: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_79, 1)
        permute_1176: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_1135, [0, 1, 3, 2]);  unsqueeze_1135 = None
        index_318: "f32[100, 64, 3, 3]" = torch.ops.aten.index.Tensor(cat_79, [cat_78]);  cat_79 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:78 in rot_compose, code: return a @ b
        expand_39: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(permute_1176, [100, 64, 3, 3]);  permute_1176 = None
        clone_122: "f32[100, 64, 3, 3]" = torch.ops.aten.clone.default(expand_39, memory_format = torch.contiguous_format);  expand_39 = None
        view_1137: "f32[6400, 3, 3]" = torch.ops.aten.view.default(clone_122, [6400, 3, 3]);  clone_122 = None
        expand_40: "f32[100, 64, 3, 3]" = torch.ops.aten.expand.default(index_318, [100, 64, 3, 3]);  index_318 = None
        view_1138: "f32[6400, 3, 3]" = torch.ops.aten.view.default(expand_40, [6400, 3, 3]);  expand_40 = None
        bmm_246: "f32[6400, 3, 3]" = torch.ops.aten.bmm.default(view_1137, view_1138);  view_1137 = view_1138 = None
        view_1139: "f32[100, 64, 3, 3]" = torch.ops.aten.view.default(bmm_246, [100, 64, 3, 3]);  bmm_246 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/features.py:198 in position_rotation_features, code: return rel.reshape(rel.shape[0], rel.shape[1], 9)
        view_1140: "f32[100, 64, 9]" = torch.ops.aten.view.default(view_1139, [100, 64, 9]);  view_1139 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1136: "f32[100, 64, 9, 1]" = torch.ops.aten.unsqueeze.default(view_1140, 3);  view_1140 = None
        permute_1177: "f32[100, 64, 1, 9]" = torch.ops.aten.permute.default(unsqueeze_1136, [0, 1, 3, 2]);  unsqueeze_1136 = None
        unsqueeze_1137: "f32[9, 64, 1]" = torch.ops.aten.unsqueeze.default(arg307_1, 2);  arg307_1 = None
        unsqueeze_1138: "f32[9, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1137, 3);  unsqueeze_1137 = None
        permute_1178: "f32[1, 1, 64, 9]" = torch.ops.aten.permute.default(unsqueeze_1138, [2, 3, 1, 0]);  unsqueeze_1138 = None
        permute_1179: "f32[100, 64, 9, 1]" = torch.ops.aten.permute.default(permute_1177, [0, 1, 3, 2]);  permute_1177 = None
        view_1141: "f32[1, 6400, 9]" = torch.ops.aten.view.default(permute_1179, [1, 6400, 9]);  permute_1179 = None
        permute_1180: "f32[9, 64, 1, 1]" = torch.ops.aten.permute.default(permute_1178, [3, 2, 0, 1]);  permute_1178 = None
        view_1142: "f32[1, 9, 64]" = torch.ops.aten.view.default(permute_1180, [1, 9, 64]);  permute_1180 = None
        bmm_247: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_1141, view_1142);  view_1141 = view_1142 = None
        view_1143: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_247, [100, 64, 1, 64]);  bmm_247 = None
        permute_1181: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_1143, [0, 1, 3, 2]);  view_1143 = None
        view_1144: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_1181, [100, 64, 64]);  permute_1181 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:219 in forward, code: pair = pair + self.linear_rot(GF.position_rotation_features(pos, neighbours))
        add_492: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_487, view_1144);  add_487 = view_1144 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1139: "f32[100, 64, 240, 1]" = torch.ops.aten.unsqueeze.default(cat_81, 3);  cat_81 = None
        permute_1182: "f32[100, 64, 1, 240]" = torch.ops.aten.permute.default(unsqueeze_1139, [0, 1, 3, 2]);  unsqueeze_1139 = None
        unsqueeze_1140: "f32[240, 64, 1]" = torch.ops.aten.unsqueeze.default(arg308_1, 2);  arg308_1 = None
        unsqueeze_1141: "f32[240, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1140, 3);  unsqueeze_1140 = None
        permute_1183: "f32[1, 1, 64, 240]" = torch.ops.aten.permute.default(unsqueeze_1141, [2, 3, 1, 0]);  unsqueeze_1141 = None
        permute_1184: "f32[100, 64, 240, 1]" = torch.ops.aten.permute.default(permute_1182, [0, 1, 3, 2]);  permute_1182 = None
        view_1145: "f32[1, 6400, 240]" = torch.ops.aten.view.default(permute_1184, [1, 6400, 240]);  permute_1184 = None
        permute_1185: "f32[240, 64, 1, 1]" = torch.ops.aten.permute.default(permute_1183, [3, 2, 0, 1]);  permute_1183 = None
        view_1146: "f32[1, 240, 64]" = torch.ops.aten.view.default(permute_1185, [1, 240, 64]);  permute_1185 = None
        bmm_248: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_1145, view_1146);  view_1145 = view_1146 = None
        view_1147: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_248, [100, 64, 1, 64]);  bmm_248 = None
        permute_1186: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_1147, [0, 1, 3, 2]);  view_1147 = None
        view_1148: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_1186, [100, 64, 64]);  permute_1186 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:220 in forward, code: pair = pair + self.linear_pairvec(pv_f)
        add_493: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(add_492, view_1148);  add_492 = view_1148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_59: "f32[100, 64, 1]" = torch.ops.aten.mean.dim(add_493, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_59: "f32[100, 64, 1]" = torch.ops.aten.var.correction(add_493, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_335: "f32[100, 64, 64]" = torch.ops.aten.sub.Tensor(add_493, mean_59);  add_493 = mean_59 = None
        add_494: "f32[100, 64, 1]" = torch.ops.aten.add.Tensor(var_59, 1e-05);  var_59 = None
        rsqrt_59: "f32[100, 64, 1]" = torch.ops.aten.rsqrt.default(add_494);  add_494 = None
        mul_643: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(sub_335, rsqrt_59);  sub_335 = rsqrt_59 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_644: "f32[100, 64, 64]" = torch.ops.aten.mul.Tensor(mul_643, arg309_1);  mul_643 = arg309_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_495: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(mul_644, arg310_1);  mul_644 = arg310_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1142: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_495, 3);  add_495 = None
        permute_1187: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1142, [0, 1, 3, 2]);  unsqueeze_1142 = None
        unsqueeze_1143: "f32[64, 128, 1]" = torch.ops.aten.unsqueeze.default(arg311_1, 2);  arg311_1 = None
        unsqueeze_1144: "f32[64, 128, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1143, 3);  unsqueeze_1143 = None
        permute_1188: "f32[1, 1, 128, 64]" = torch.ops.aten.permute.default(unsqueeze_1144, [2, 3, 1, 0]);  unsqueeze_1144 = None
        permute_1189: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_1187, [0, 1, 3, 2]);  permute_1187 = None
        view_1149: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_1189, [1, 6400, 64]);  permute_1189 = None
        permute_1190: "f32[64, 128, 1, 1]" = torch.ops.aten.permute.default(permute_1188, [3, 2, 0, 1]);  permute_1188 = None
        view_1150: "f32[1, 64, 128]" = torch.ops.aten.view.default(permute_1190, [1, 64, 128]);  permute_1190 = None
        bmm_249: "f32[1, 6400, 128]" = torch.ops.aten.bmm.default(view_1149, view_1150);  view_1149 = view_1150 = None
        view_1151: "f32[100, 64, 1, 128]" = torch.ops.aten.view.default(bmm_249, [100, 64, 1, 128]);  bmm_249 = None
        permute_1191: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(view_1151, [0, 1, 3, 2]);  view_1151 = None
        view_1152: "f32[100, 64, 128]" = torch.ops.aten.view.default(permute_1191, [100, 64, 128]);  permute_1191 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_496: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(view_1152, arg312_1);  view_1152 = arg312_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_645: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_496, add_496)
        mul_646: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_645, add_496);  mul_645 = None
        mul_647: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_646, 0.044715);  mul_646 = None
        add_497: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(add_496, mul_647);  mul_647 = None
        mul_648: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_497, 0.7978845608028654);  add_497 = None
        mul_649: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(add_496, 0.5);  add_496 = None
        tanh_27: "f32[100, 64, 128]" = torch.ops.aten.tanh.default(mul_648);  mul_648 = None
        add_498: "f32[100, 64, 128]" = torch.ops.aten.add.Tensor(tanh_27, 1);  tanh_27 = None
        mul_650: "f32[100, 64, 128]" = torch.ops.aten.mul.Tensor(mul_649, add_498);  mul_649 = add_498 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1145: "f32[100, 64, 128, 1]" = torch.ops.aten.unsqueeze.default(mul_650, 3);  mul_650 = None
        permute_1192: "f32[100, 64, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1145, [0, 1, 3, 2]);  unsqueeze_1145 = None
        unsqueeze_1146: "f32[128, 64, 1]" = torch.ops.aten.unsqueeze.default(arg313_1, 2);  arg313_1 = None
        unsqueeze_1147: "f32[128, 64, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1146, 3);  unsqueeze_1146 = None
        permute_1193: "f32[1, 1, 64, 128]" = torch.ops.aten.permute.default(unsqueeze_1147, [2, 3, 1, 0]);  unsqueeze_1147 = None
        permute_1194: "f32[100, 64, 128, 1]" = torch.ops.aten.permute.default(permute_1192, [0, 1, 3, 2]);  permute_1192 = None
        view_1153: "f32[1, 6400, 128]" = torch.ops.aten.view.default(permute_1194, [1, 6400, 128]);  permute_1194 = None
        permute_1195: "f32[128, 64, 1, 1]" = torch.ops.aten.permute.default(permute_1193, [3, 2, 0, 1]);  permute_1193 = None
        view_1154: "f32[1, 128, 64]" = torch.ops.aten.view.default(permute_1195, [1, 128, 64]);  permute_1195 = None
        bmm_250: "f32[1, 6400, 64]" = torch.ops.aten.bmm.default(view_1153, view_1154);  view_1153 = view_1154 = None
        view_1155: "f32[100, 64, 1, 64]" = torch.ops.aten.view.default(bmm_250, [100, 64, 1, 64]);  bmm_250 = None
        permute_1196: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(view_1155, [0, 1, 3, 2]);  view_1155 = None
        view_1156: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_1196, [100, 64, 64]);  permute_1196 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_499: "f32[100, 64, 64]" = torch.ops.aten.add.Tensor(view_1156, arg314_1);  view_1156 = arg314_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_652: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_614, arg315_1);  mul_614 = arg315_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_501: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_652, arg316_1);  mul_652 = arg316_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:360 in forward, code: self.layer_norm_1(features), pos / sigma, pair, pair_mask, current_neighbours)
        div_136: "f32[100, 20, 3]" = torch.ops.aten.div.Tensor(add_476, 10.0)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:70 in aa_frames_t, code: n, ca, c = pos[..., 0, :], pos[..., 1, :], pos[..., 2, :]
        select_135: "f32[100, 3]" = torch.ops.aten.select.int(div_136, 1, 0)
        select_136: "f32[100, 3]" = torch.ops.aten.select.int(div_136, 1, 1)
        select_137: "f32[100, 3]" = torch.ops.aten.select.int(div_136, 1, 2);  div_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:71 in aa_frames_t, code: rot = rot_from_two_vectors(c - ca, n - ca)
        sub_337: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_137, select_136);  select_137 = None
        sub_338: "f32[100, 3]" = torch.ops.aten.sub.Tensor(select_135, select_136);  select_135 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_653: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_337, sub_337)
        sum_168: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_653, [-1]);  mul_653 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_148: "f32[100]" = torch.ops.aten.clamp_min.default(sum_168, 1e-12);  sum_168 = None
        sqrt_111: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_148);  clamp_min_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1148: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_111, -1);  sqrt_111 = None
        div_137: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_337, unsqueeze_1148);  sub_337 = unsqueeze_1148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:40 in vec_dot, code: return (a * b).sum(-1)
        mul_654: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_338, div_137)
        sum_169: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_654, [-1]);  mul_654 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:90 in rot_from_two_vectors, code: c = vec_dot(e1_unnormalized, e0).unsqueeze(-1)
        unsqueeze_1149: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sum_169, -1);  sum_169 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:91 in rot_from_two_vectors, code: e1 = vec_normalized(e1_unnormalized - c * e0)
        mul_655: "f32[100, 3]" = torch.ops.aten.mul.Tensor(unsqueeze_1149, div_137);  unsqueeze_1149 = None
        sub_339: "f32[100, 3]" = torch.ops.aten.sub.Tensor(sub_338, mul_655);  sub_338 = mul_655 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_656: "f32[100, 3]" = torch.ops.aten.mul.Tensor(sub_339, sub_339)
        sum_170: "f32[100]" = torch.ops.aten.sum.dim_IntList(mul_656, [-1]);  mul_656 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_149: "f32[100]" = torch.ops.aten.clamp_min.default(sum_170, 1e-12);  sum_170 = None
        sqrt_112: "f32[100]" = torch.ops.aten.sqrt.default(clamp_min_149);  clamp_min_149 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:54 in vec_normalized, code: return a / vec_norm(a, eps).unsqueeze(-1)
        unsqueeze_1150: "f32[100, 1]" = torch.ops.aten.unsqueeze.default(sqrt_112, -1);  sqrt_112 = None
        div_138: "f32[100, 3]" = torch.ops.aten.div.Tensor(sub_339, unsqueeze_1150);  sub_339 = unsqueeze_1150 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:58 in vec_cross, code: return torch.cross(a, b, dim=-1)
        index_319: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_137, [None, remainder])
        index_320: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_138, [None, remainder_1])
        mul_657: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_319, index_320);  index_319 = index_320 = None
        index_321: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_137, [None, remainder_1]);  remainder_1 = None
        index_322: "f32[100, 3]" = torch.ops.aten.index.Tensor(div_138, [None, remainder]);  remainder = None
        mul_658: "f32[100, 3]" = torch.ops.aten.mul.Tensor(index_321, index_322);  index_321 = index_322 = None
        sub_340: "f32[100, 3]" = torch.ops.aten.sub.Tensor(mul_657, mul_658);  mul_657 = mul_658 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:94 in rot_from_two_vectors, code: return torch.stack([e0, e1, e2], dim=-1)
        unsqueeze_1151: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_137, 2);  div_137 = None
        unsqueeze_1152: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(div_138, 2);  div_138 = None
        unsqueeze_1153: "f32[100, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_340, 2);  sub_340 = None
        cat_83: "f32[100, 3, 3]" = torch.ops.aten.cat.default([unsqueeze_1151, unsqueeze_1152, unsqueeze_1153], -1);  unsqueeze_1151 = unsqueeze_1152 = unsqueeze_1153 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_61: "f32[100, 1]" = torch.ops.aten.mean.dim(add_501, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_61: "f32[100, 1]" = torch.ops.aten.var.correction(add_501, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_342: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_501, mean_61);  add_501 = mean_61 = None
        add_506: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_61, 1e-05);  var_61 = None
        rsqrt_61: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_506);  add_506 = None
        mul_659: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_342, rsqrt_61);  sub_342 = rsqrt_61 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_660: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_659, arg317_1);  mul_659 = arg317_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_507: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_660, arg318_1);  mul_660 = arg318_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1157: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_507, 2);  add_507 = None
        permute_1202: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1157, [0, 2, 1]);  unsqueeze_1157 = None
        unsqueeze_1158: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg319_1, 2);  arg319_1 = None
        permute_1203: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_1158, [2, 1, 0]);  unsqueeze_1158 = None
        permute_1204: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_1202, [0, 2, 1]);  permute_1202 = None
        view_1161: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_1204, [1, 100, 128]);  permute_1204 = None
        permute_1205: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_1203, [2, 1, 0]);  permute_1203 = None
        view_1162: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_1205, [1, 128, 768]);  permute_1205 = None
        bmm_252: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_1161, view_1162);  view_1162 = None
        view_1163: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_252, [100, 1, 768]);  bmm_252 = None
        permute_1206: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_1163, [0, 2, 1]);  view_1163 = None
        view_1164: "f32[100, 768]" = torch.ops.aten.view.default(permute_1206, [100, 768]);  permute_1206 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_1165: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_1164, [100, 8, 96]);  view_1164 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_10 = torch.ops.aten.split.Tensor(view_1165, 32, -1);  view_1165 = None
        getitem_89: "f32[100, 8, 32]" = split_10[0]
        getitem_90: "f32[100, 8, 32]" = split_10[1]
        getitem_91: "f32[100, 8, 32]" = split_10[2];  split_10 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_62: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_89, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_62: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_89, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_343: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_89, mean_62);  getitem_89 = mean_62 = None
        add_508: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_62, 1e-05);  var_62 = None
        rsqrt_62: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_508);  add_508 = None
        mul_661: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_343, rsqrt_62);  sub_343 = rsqrt_62 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_662: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_661, arg320_1);  mul_661 = arg320_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_509: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_662, arg321_1);  mul_662 = arg321_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_63: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_90, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_63: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_90, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_344: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_90, mean_63);  getitem_90 = mean_63 = None
        add_510: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_63, 1e-05);  var_63 = None
        rsqrt_63: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_510);  add_510 = None
        mul_663: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_344, rsqrt_63);  sub_344 = rsqrt_63 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_664: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_663, arg322_1);  mul_663 = arg322_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_511: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_664, arg323_1);  mul_664 = arg323_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1160: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg324_1, 2);  arg324_1 = None
        permute_1208: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_1160, [2, 1, 0]);  unsqueeze_1160 = None
        permute_1210: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_1208, [2, 1, 0]);  permute_1208 = None
        view_1167: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_1210, [1, 128, 576]);  permute_1210 = None
        bmm_253: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_1161, view_1167);  view_1161 = view_1167 = None
        view_1168: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_253, [100, 1, 576]);  bmm_253 = None
        permute_1211: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_1168, [0, 2, 1]);  view_1168 = None
        view_1169: "f32[100, 576]" = torch.ops.aten.view.default(permute_1211, [100, 576]);  permute_1211 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_1170: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_1169, [100, 192, 3]);  view_1169 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1161: "f32[100, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(cat_83, -3);  cat_83 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1162: "f32[100, 1, 3]" = torch.ops.aten.unsqueeze.default(select_136, -2);  select_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_1212: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_1161, [0, 1, 2, 3])
        unsqueeze_1163: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_1170, 3);  view_1170 = None
        permute_1213: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1163, [0, 1, 3, 2]);  unsqueeze_1163 = None
        permute_1214: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_1212, [0, 2, 3, 1]);  permute_1212 = None
        view_1171: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_1214, [100, 3, 3]);  permute_1214 = None
        permute_1215: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_1213, [0, 3, 1, 2]);  permute_1213 = None
        view_1172: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_1215, [100, 3, 192]);  permute_1215 = None
        bmm_254: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_1171, view_1172);  view_1171 = view_1172 = None
        view_1173: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_254, [100, 3, 1, 192]);  bmm_254 = None
        permute_1216: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_1173, [0, 3, 1, 2]);  view_1173 = None
        view_1174: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_1216, [100, 192, 3]);  permute_1216 = None
        add_512: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_1174, unsqueeze_1162);  view_1174 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_1175: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_512, [100, 8, 24, 3]);  add_512 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_678: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1175, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_681: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1175, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_684: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1175, 2, 16, 9223372036854775807);  view_1175 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1164: "f32[100, 64, 64, 1]" = torch.ops.aten.unsqueeze.default(add_499, 3);  add_499 = None
        permute_1217: "f32[100, 64, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1164, [0, 1, 3, 2])
        unsqueeze_1165: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg325_1, 2);  arg325_1 = None
        unsqueeze_1166: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1165, 3);  unsqueeze_1165 = None
        permute_1218: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_1166, [2, 3, 1, 0]);  unsqueeze_1166 = None
        permute_1219: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_1217, [0, 1, 3, 2]);  permute_1217 = None
        view_1176: "f32[1, 6400, 64]" = torch.ops.aten.view.default(permute_1219, [1, 6400, 64]);  permute_1219 = None
        permute_1220: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_1218, [3, 2, 0, 1]);  permute_1218 = None
        view_1177: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_1220, [1, 64, 8]);  permute_1220 = None
        bmm_255: "f32[1, 6400, 8]" = torch.ops.aten.bmm.default(view_1176, view_1177);  view_1176 = view_1177 = None
        view_1178: "f32[100, 64, 1, 8]" = torch.ops.aten.view.default(bmm_255, [100, 64, 1, 8]);  bmm_255 = None
        permute_1221: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_1178, [0, 1, 3, 2]);  view_1178 = None
        view_1179: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_1221, [100, 64, 8]);  permute_1221 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_28: "f32[8]" = torch.ops.aten.exp.default(arg326_1)
        log1p_10: "f32[8]" = torch.ops.aten.log1p.default(exp_28);  exp_28 = None
        gt_10: "b8[8]" = torch.ops.aten.gt.Scalar(arg326_1, 20)
        where_172: "f32[8]" = torch.ops.aten.where.self(gt_10, arg326_1, log1p_10);  gt_10 = arg326_1 = log1p_10 = None
        view_1180: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_172, [1, 1, 8]);  where_172 = None
        mul_665: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_1180, 0.16666666666666666);  view_1180 = None
        div_139: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_665, 2);  mul_665 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_1167: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_678, 1);  slice_678 = None
        index_323: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_681, [cat_78]);  slice_681 = None
        sub_345: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1167, index_323);  unsqueeze_1167 = index_323 = None
        pow_21: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_345, 2);  sub_345 = None
        sum_171: "f32[100, 64, 8]" = torch.ops.aten.sum.dim_IntList(pow_21, [-1, -2]);  pow_21 = None
        mul_666: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(div_139, sum_171);  div_139 = sum_171 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_324: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(add_511, [cat_78]);  add_511 = None
        unsqueeze_1168: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_509, 3);  add_509 = None
        permute_1222: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_1168, [0, 3, 1, 2]);  unsqueeze_1168 = None
        permute_1223: "f32[100, 64, 8, 32]" = torch.ops.aten.permute.default(index_324, [0, 1, 2, 3]);  index_324 = None
        permute_1224: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_1222, [0, 2, 3, 1]);  permute_1222 = None
        view_1181: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_1224, [800, 1, 32]);  permute_1224 = None
        permute_1225: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(permute_1223, [0, 2, 3, 1]);  permute_1223 = None
        clone_123: "f32[100, 8, 32, 64]" = torch.ops.aten.clone.default(permute_1225, memory_format = torch.contiguous_format);  permute_1225 = None
        view_1182: "f32[800, 32, 64]" = torch.ops.aten.view.default(clone_123, [800, 32, 64]);  clone_123 = None
        bmm_256: "f32[800, 1, 64]" = torch.ops.aten.bmm.default(view_1181, view_1182);  view_1181 = view_1182 = None
        view_1183: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_256, [100, 8, 1, 64]);  bmm_256 = None
        permute_1226: "f32[100, 64, 8, 1]" = torch.ops.aten.permute.default(view_1183, [0, 3, 1, 2]);  view_1183 = None
        view_1184: "f32[100, 64, 8]" = torch.ops.aten.view.default(permute_1226, [100, 64, 8]);  permute_1226 = None
        mul_667: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(view_1184, 0.1767766952966369);  view_1184 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_513: "f32[100, 64, 8]" = torch.ops.aten.add.Tensor(mul_667, view_1179);  mul_667 = view_1179 = None
        sub_346: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(add_513, mul_666);  add_513 = mul_666 = None
        mul_668: "f32[100, 64, 8]" = torch.ops.aten.mul.Tensor(sub_346, 0.5773502691896257);  sub_346 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        bitwise_and_85: "b8[100, 64]" = torch.ops.aten.bitwise_and.Tensor(bitwise_and_84, ne_35);  bitwise_and_84 = ne_35 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_1169: "b8[100, 64, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_85, 2);  bitwise_and_85 = None
        where_173: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_1169, mul_668, full_default_39);  mul_668 = full_default_39 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_124: "f32[100, 64, 8]" = torch.ops.aten.clone.default(where_173, memory_format = torch.contiguous_format);  where_173 = None
        amax_10: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_124, [-2], True)
        sub_347: "f32[100, 64, 8]" = torch.ops.aten.sub.Tensor(clone_124, amax_10);  clone_124 = amax_10 = None
        exp_29: "f32[100, 64, 8]" = torch.ops.aten.exp.default(sub_347);  sub_347 = None
        sum_172: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_29, [-2], True)
        div_140: "f32[100, 64, 8]" = torch.ops.aten.div.Tensor(exp_29, sum_172);  exp_29 = sum_172 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_174: "f32[100, 64, 8]" = torch.ops.aten.where.self(unsqueeze_1169, div_140, full_default_40);  unsqueeze_1169 = div_140 = full_default_40 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_1171: "f32[100, 64, 8, 1]" = torch.ops.aten.unsqueeze.default(where_174, 3);  where_174 = None
        permute_1227: "f32[100, 8, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1171, [0, 2, 3, 1])
        permute_1228: "f32[100, 1, 64, 64]" = torch.ops.aten.permute.default(unsqueeze_1164, [0, 3, 2, 1]);  unsqueeze_1164 = None
        permute_1229: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(permute_1227, [0, 1, 3, 2]);  permute_1227 = None
        view_1185: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_1229, [100, 8, 64])
        permute_1230: "f32[100, 64, 64, 1]" = torch.ops.aten.permute.default(permute_1228, [0, 3, 2, 1]);  permute_1228 = None
        view_1186: "f32[100, 64, 64]" = torch.ops.aten.view.default(permute_1230, [100, 64, 64]);  permute_1230 = None
        bmm_257: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_1185, view_1186);  view_1185 = view_1186 = None
        view_1187: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_257, [100, 8, 1, 64]);  bmm_257 = None
        permute_1231: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_1187, [0, 1, 3, 2]);  view_1187 = None
        view_1188: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_1231, [100, 8, 64]);  permute_1231 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_325: "f32[100, 64, 8, 32]" = torch.ops.aten.index.Tensor(getitem_91, [cat_78]);  getitem_91 = None
        permute_1233: "f32[100, 8, 32, 64]" = torch.ops.aten.permute.default(index_325, [0, 2, 3, 1]);  index_325 = None
        clone_125: "f32[100, 8, 64, 1]" = torch.ops.aten.clone.default(permute_1229, memory_format = torch.contiguous_format);  permute_1229 = None
        view_1189: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_125, [800, 1, 64]);  clone_125 = None
        permute_1235: "f32[100, 8, 64, 32]" = torch.ops.aten.permute.default(permute_1233, [0, 1, 3, 2]);  permute_1233 = None
        clone_126: "f32[100, 8, 64, 32]" = torch.ops.aten.clone.default(permute_1235, memory_format = torch.contiguous_format);  permute_1235 = None
        view_1190: "f32[800, 64, 32]" = torch.ops.aten.view.default(clone_126, [800, 64, 32]);  clone_126 = None
        bmm_258: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_1189, view_1190);  view_1189 = view_1190 = None
        view_1191: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_258, [100, 8, 1, 32]);  bmm_258 = None
        permute_1236: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_1191, [0, 1, 3, 2]);  view_1191 = None
        view_1192: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_1236, [100, 8, 32]);  permute_1236 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_326: "f32[100, 64, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_684, [cat_78]);  slice_684 = cat_78 = None
        unsqueeze_1175: "f32[100, 64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1171, 4);  unsqueeze_1171 = None
        permute_1237: "f32[100, 8, 1, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1175, [0, 2, 3, 4, 1]);  unsqueeze_1175 = None
        permute_1238: "f32[100, 8, 8, 3, 64]" = torch.ops.aten.permute.default(index_326, [0, 2, 3, 4, 1]);  index_326 = None
        permute_1239: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.permute.default(permute_1237, [0, 1, 4, 2, 3]);  permute_1237 = None
        clone_127: "f32[100, 8, 64, 1, 1]" = torch.ops.aten.clone.default(permute_1239, memory_format = torch.contiguous_format);  permute_1239 = None
        view_1193: "f32[800, 1, 64]" = torch.ops.aten.view.default(clone_127, [800, 1, 64]);  clone_127 = None
        permute_1240: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.permute.default(permute_1238, [0, 1, 4, 2, 3]);  permute_1238 = None
        clone_128: "f32[100, 8, 64, 8, 3]" = torch.ops.aten.clone.default(permute_1240, memory_format = torch.contiguous_format);  permute_1240 = None
        view_1194: "f32[800, 64, 24]" = torch.ops.aten.view.default(clone_128, [800, 64, 24]);  clone_128 = None
        bmm_259: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_1193, view_1194);  view_1193 = view_1194 = None
        view_1195: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_259, [100, 8, 1, 8, 3]);  bmm_259 = None
        permute_1241: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_1195, [0, 1, 3, 4, 2]);  view_1195 = None
        view_1196: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_1241, [100, 8, 8, 3]);  permute_1241 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:79 in _lift, code: rot = rot.unsqueeze(-3)
        unsqueeze_1178: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_1161, -3);  unsqueeze_1161 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:80 in _lift, code: trans = trans.unsqueeze(-2)
        unsqueeze_1179: "f32[100, 1, 1, 3]" = torch.ops.aten.unsqueeze.default(unsqueeze_1162, -2);  unsqueeze_1162 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_348: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_1196, unsqueeze_1179);  view_1196 = unsqueeze_1179 = None
        permute_1242: "f32[100, 1, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_1178, [0, 1, 2, 4, 3]);  unsqueeze_1178 = None
        unsqueeze_1180: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_348, 4);  sub_348 = None
        permute_1243: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1180, [0, 1, 2, 4, 3]);  unsqueeze_1180 = None
        permute_1244: "f32[100, 3, 3, 1, 1]" = torch.ops.aten.permute.default(permute_1242, [0, 3, 4, 1, 2]);  permute_1242 = None
        view_1197: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_1244, [100, 3, 3]);  permute_1244 = None
        permute_1245: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_1243, [0, 4, 1, 2, 3]);  permute_1243 = None
        view_1198: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_1245, [100, 3, 64]);  permute_1245 = None
        bmm_260: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_1197, view_1198);  view_1197 = view_1198 = None
        view_1199: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_260, [100, 3, 1, 8, 8]);  bmm_260 = None
        permute_1246: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_1199, [0, 3, 4, 1, 2]);  view_1199 = None
        view_1200: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_1246, [100, 8, 8, 3]);  permute_1246 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_669: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_1200, view_1200)
        sum_173: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_669, [-1]);  mul_669 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_150: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_173, 1e-12);  sum_173 = None
        sqrt_113: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_150);  clamp_min_150 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_1201: "f32[100, 512]" = torch.ops.aten.view.default(view_1188, [100, -1]);  view_1188 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_1202: "f32[100, 256]" = torch.ops.aten.view.default(view_1192, [100, -1]);  view_1192 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_129: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_1200, memory_format = torch.contiguous_format);  view_1200 = None
        view_1203: "f32[100, 192]" = torch.ops.aten.view.default(clone_129, [100, 192]);  clone_129 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_1204: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_113, [100, -1]);  sqrt_113 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_84: "f32[100, 1024]" = torch.ops.aten.cat.default([view_1201, view_1202, view_1203, view_1204], -1);  view_1201 = view_1202 = view_1203 = view_1204 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1181: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_84, 2);  cat_84 = None
        permute_1247: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_1181, [0, 2, 1]);  unsqueeze_1181 = None
        unsqueeze_1182: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg327_1, 2);  arg327_1 = None
        permute_1248: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_1182, [2, 1, 0]);  unsqueeze_1182 = None
        permute_1249: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_1247, [0, 2, 1]);  permute_1247 = None
        view_1205: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_1249, [1, 100, 1024]);  permute_1249 = None
        permute_1250: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_1248, [2, 1, 0]);  permute_1248 = None
        view_1206: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_1250, [1, 1024, 128]);  permute_1250 = None
        bmm_261: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_1205, view_1206);  view_1205 = view_1206 = None
        view_1207: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_261, [100, 1, 128]);  bmm_261 = None
        permute_1251: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1207, [0, 2, 1]);  view_1207 = None
        view_1208: "f32[100, 128]" = torch.ops.aten.view.default(permute_1251, [100, 128]);  permute_1251 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_514: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_1208, arg328_1);  view_1208 = arg328_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:359 in forward, code: features = features + self.attn_1(
        add_515: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_468, add_514);  add_468 = add_514 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_64: "f32[100, 1]" = torch.ops.aten.mean.dim(add_515, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_64: "f32[100, 1]" = torch.ops.aten.var.correction(add_515, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_349: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_515, mean_64);  mean_64 = None
        add_516: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_64, 1e-05);  var_64 = None
        rsqrt_64: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_516);  add_516 = None
        mul_670: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_349, rsqrt_64);  sub_349 = rsqrt_64 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_671: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_670, arg329_1);  mul_670 = arg329_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_517: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_671, arg330_1);  mul_671 = arg330_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_65: "f32[100, 1]" = torch.ops.aten.mean.dim(add_517, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_65: "f32[100, 1]" = torch.ops.aten.var.correction(add_517, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_355: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_517, mean_65);  add_517 = mean_65 = None
        add_522: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_65, 1e-05);  var_65 = None
        rsqrt_65: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_522);  add_522 = None
        mul_678: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_355, rsqrt_65);  sub_355 = rsqrt_65 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_679: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_678, arg331_1);  mul_678 = arg331_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_523: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_679, arg332_1);  mul_679 = arg332_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1192: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_523, 2);  add_523 = None
        permute_1257: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1192, [0, 2, 1]);  unsqueeze_1192 = None
        unsqueeze_1193: "f32[128, 768, 1]" = torch.ops.aten.unsqueeze.default(arg333_1, 2);  arg333_1 = None
        permute_1258: "f32[1, 768, 128]" = torch.ops.aten.permute.default(unsqueeze_1193, [2, 1, 0]);  unsqueeze_1193 = None
        permute_1259: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_1257, [0, 2, 1]);  permute_1257 = None
        view_1213: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_1259, [1, 100, 128]);  permute_1259 = None
        permute_1260: "f32[128, 768, 1]" = torch.ops.aten.permute.default(permute_1258, [2, 1, 0]);  permute_1258 = None
        view_1214: "f32[1, 128, 768]" = torch.ops.aten.view.default(permute_1260, [1, 128, 768]);  permute_1260 = None
        bmm_263: "f32[1, 100, 768]" = torch.ops.aten.bmm.default(view_1213, view_1214);  view_1214 = None
        view_1215: "f32[100, 1, 768]" = torch.ops.aten.view.default(bmm_263, [100, 1, 768]);  bmm_263 = None
        permute_1261: "f32[100, 768, 1]" = torch.ops.aten.permute.default(view_1215, [0, 2, 1]);  view_1215 = None
        view_1216: "f32[100, 768]" = torch.ops.aten.view.default(permute_1261, [100, 768]);  permute_1261 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:91 in forward, code: qkv = self.qkv(local).reshape(n, h, 3 * s)
        view_1217: "f32[100, 8, 96]" = torch.ops.aten.view.default(view_1216, [100, 8, 96]);  view_1216 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:92 in forward, code: q, k, v = torch.split(qkv, s, dim=-1)
        split_11 = torch.ops.aten.split.Tensor(view_1217, 32, -1);  view_1217 = None
        getitem_92: "f32[100, 8, 32]" = split_11[0]
        getitem_93: "f32[100, 8, 32]" = split_11[1]
        getitem_94: "f32[100, 8, 32]" = split_11[2];  split_11 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_66: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_92, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_66: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_92, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_356: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_92, mean_66);  getitem_92 = mean_66 = None
        add_524: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_66, 1e-05);  var_66 = None
        rsqrt_66: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_524);  add_524 = None
        mul_680: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_356, rsqrt_66);  sub_356 = rsqrt_66 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_681: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_680, arg334_1);  mul_680 = arg334_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_525: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_681, arg335_1);  mul_681 = arg335_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_67: "f32[100, 8, 1]" = torch.ops.aten.mean.dim(getitem_93, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_67: "f32[100, 8, 1]" = torch.ops.aten.var.correction(getitem_93, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_357: "f32[100, 8, 32]" = torch.ops.aten.sub.Tensor(getitem_93, mean_67);  getitem_93 = mean_67 = None
        add_526: "f32[100, 8, 1]" = torch.ops.aten.add.Tensor(var_67, 1e-05);  var_67 = None
        rsqrt_67: "f32[100, 8, 1]" = torch.ops.aten.rsqrt.default(add_526);  add_526 = None
        mul_682: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(sub_357, rsqrt_67);  sub_357 = rsqrt_67 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_683: "f32[100, 8, 32]" = torch.ops.aten.mul.Tensor(mul_682, arg336_1);  mul_682 = arg336_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_527: "f32[100, 8, 32]" = torch.ops.aten.add.Tensor(mul_683, arg337_1);  mul_683 = arg337_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1195: "f32[128, 576, 1]" = torch.ops.aten.unsqueeze.default(arg338_1, 2);  arg338_1 = None
        permute_1263: "f32[1, 576, 128]" = torch.ops.aten.permute.default(unsqueeze_1195, [2, 1, 0]);  unsqueeze_1195 = None
        permute_1265: "f32[128, 576, 1]" = torch.ops.aten.permute.default(permute_1263, [2, 1, 0]);  permute_1263 = None
        view_1219: "f32[1, 128, 576]" = torch.ops.aten.view.default(permute_1265, [1, 128, 576]);  permute_1265 = None
        bmm_264: "f32[1, 100, 576]" = torch.ops.aten.bmm.default(view_1213, view_1219);  view_1213 = view_1219 = None
        view_1220: "f32[100, 1, 576]" = torch.ops.aten.view.default(bmm_264, [100, 1, 576]);  bmm_264 = None
        permute_1266: "f32[100, 576, 1]" = torch.ops.aten.permute.default(view_1220, [0, 2, 1]);  view_1220 = None
        view_1221: "f32[100, 576]" = torch.ops.aten.view.default(permute_1266, [100, 576]);  permute_1266 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:41 in forward, code: points = raw.reshape(*raw.shape[:-1], self.size, 3)
        view_1222: "f32[100, 192, 3]" = torch.ops.aten.view.default(view_1221, [100, 192, 3]);  view_1221 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        unsqueeze_1198: "f32[100, 192, 3, 1]" = torch.ops.aten.unsqueeze.default(view_1222, 3);  view_1222 = None
        permute_1268: "f32[100, 192, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1198, [0, 1, 3, 2]);  unsqueeze_1198 = None
        permute_1270: "f32[100, 3, 192, 1]" = torch.ops.aten.permute.default(permute_1268, [0, 3, 1, 2]);  permute_1268 = None
        view_1224: "f32[100, 3, 192]" = torch.ops.aten.view.default(permute_1270, [100, 3, 192]);  permute_1270 = None
        bmm_265: "f32[100, 3, 192]" = torch.ops.aten.bmm.default(view_168, view_1224);  view_168 = view_1224 = None
        view_1225: "f32[100, 3, 1, 192]" = torch.ops.aten.view.default(bmm_265, [100, 3, 1, 192]);  bmm_265 = None
        permute_1271: "f32[100, 192, 3, 1]" = torch.ops.aten.permute.default(view_1225, [0, 3, 1, 2]);  view_1225 = None
        view_1226: "f32[100, 192, 3]" = torch.ops.aten.view.default(permute_1271, [100, 192, 3]);  permute_1271 = None
        add_528: "f32[100, 192, 3]" = torch.ops.aten.add.Tensor(view_1226, unsqueeze_267);  view_1226 = unsqueeze_267 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:97 in forward, code: qkv_g = qkv_g.reshape(n, h, 2 * qp + vp, 3)
        view_1227: "f32[100, 8, 24, 3]" = torch.ops.aten.view.default(add_528, [100, 8, 24, 3]);  add_528 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:98 in forward, code: q_g = qkv_g[:, :, :qp]
        slice_695: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1227, 2, 0, 8)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:99 in forward, code: k_g = qkv_g[:, :, qp:2 * qp]
        slice_698: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1227, 2, 8, 16)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:100 in forward, code: v_g = qkv_g[:, :, 2 * qp:]
        slice_701: "f32[100, 8, 8, 3]" = torch.ops.aten.slice.Tensor(view_1227, 2, 16, 9223372036854775807);  view_1227 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1199: "f32[100, 48, 64, 1]" = torch.ops.aten.unsqueeze.default(select_127, 3);  select_127 = None
        permute_1272: "f32[100, 48, 1, 64]" = torch.ops.aten.permute.default(unsqueeze_1199, [0, 1, 3, 2])
        unsqueeze_1200: "f32[64, 8, 1]" = torch.ops.aten.unsqueeze.default(arg339_1, 2);  arg339_1 = None
        unsqueeze_1201: "f32[64, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1200, 3);  unsqueeze_1200 = None
        permute_1273: "f32[1, 1, 8, 64]" = torch.ops.aten.permute.default(unsqueeze_1201, [2, 3, 1, 0]);  unsqueeze_1201 = None
        permute_1274: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_1272, [0, 1, 3, 2]);  permute_1272 = None
        view_1228: "f32[1, 4800, 64]" = torch.ops.aten.view.default(permute_1274, [1, 4800, 64]);  permute_1274 = None
        permute_1275: "f32[64, 8, 1, 1]" = torch.ops.aten.permute.default(permute_1273, [3, 2, 0, 1]);  permute_1273 = None
        view_1229: "f32[1, 64, 8]" = torch.ops.aten.view.default(permute_1275, [1, 64, 8]);  permute_1275 = None
        bmm_266: "f32[1, 4800, 8]" = torch.ops.aten.bmm.default(view_1228, view_1229);  view_1228 = view_1229 = None
        view_1230: "f32[100, 48, 1, 8]" = torch.ops.aten.view.default(bmm_266, [100, 48, 1, 8]);  bmm_266 = None
        permute_1276: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_1230, [0, 1, 3, 2]);  view_1230 = None
        view_1231: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_1276, [100, 48, 8]);  permute_1276 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:106 in forward, code: dfactor = nn.functional.softplus(self.gamma).reshape(1, 1, h) * w_c / 2
        exp_30: "f32[8]" = torch.ops.aten.exp.default(arg340_1)
        log1p_11: "f32[8]" = torch.ops.aten.log1p.default(exp_30);  exp_30 = None
        gt_11: "b8[8]" = torch.ops.aten.gt.Scalar(arg340_1, 20)
        where_175: "f32[8]" = torch.ops.aten.where.self(gt_11, arg340_1, log1p_11);  gt_11 = arg340_1 = log1p_11 = None
        view_1232: "f32[1, 1, 8]" = torch.ops.aten.view.default(where_175, [1, 1, 8]);  where_175 = None
        mul_684: "f32[1, 1, 8]" = torch.ops.aten.mul.Tensor(view_1232, 0.16666666666666666);  view_1232 = None
        div_144: "f32[1, 1, 8]" = torch.ops.aten.div.Tensor(mul_684, 2);  mul_684 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:109 in forward, code: dist = dfactor * ((q_g[:, None] - k_g[neighbours]) ** 2).sum(dim=(-1, -2))
        unsqueeze_1202: "f32[100, 1, 8, 8, 3]" = torch.ops.aten.unsqueeze.default(slice_695, 1);  slice_695 = None
        index_331: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_698, [select_126]);  slice_698 = None
        sub_358: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.sub.Tensor(unsqueeze_1202, index_331);  unsqueeze_1202 = index_331 = None
        pow_22: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.pow.Tensor_Scalar(sub_358, 2);  sub_358 = None
        sum_177: "f32[100, 48, 8]" = torch.ops.aten.sum.dim_IntList(pow_22, [-1, -2]);  pow_22 = None
        mul_685: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(div_144, sum_177);  div_144 = sum_177 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:115 in forward, code: dot = math.sqrt(1.0 / s) * torch.einsum("ihc,ijhc->ijh", q, k[neighbours])
        index_332: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(add_527, [select_126]);  add_527 = None
        unsqueeze_1203: "f32[100, 8, 32, 1]" = torch.ops.aten.unsqueeze.default(add_525, 3);  add_525 = None
        permute_1277: "f32[100, 1, 8, 32]" = torch.ops.aten.permute.default(unsqueeze_1203, [0, 3, 1, 2]);  unsqueeze_1203 = None
        permute_1278: "f32[100, 48, 8, 32]" = torch.ops.aten.permute.default(index_332, [0, 1, 2, 3]);  index_332 = None
        permute_1279: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(permute_1277, [0, 2, 3, 1]);  permute_1277 = None
        view_1233: "f32[800, 1, 32]" = torch.ops.aten.view.default(permute_1279, [800, 1, 32]);  permute_1279 = None
        permute_1280: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(permute_1278, [0, 2, 3, 1]);  permute_1278 = None
        clone_130: "f32[100, 8, 32, 48]" = torch.ops.aten.clone.default(permute_1280, memory_format = torch.contiguous_format);  permute_1280 = None
        view_1234: "f32[800, 32, 48]" = torch.ops.aten.view.default(clone_130, [800, 32, 48]);  clone_130 = None
        bmm_267: "f32[800, 1, 48]" = torch.ops.aten.bmm.default(view_1233, view_1234);  view_1233 = view_1234 = None
        view_1235: "f32[100, 8, 1, 48]" = torch.ops.aten.view.default(bmm_267, [100, 8, 1, 48]);  bmm_267 = None
        permute_1281: "f32[100, 48, 8, 1]" = torch.ops.aten.permute.default(view_1235, [0, 3, 1, 2]);  view_1235 = None
        view_1236: "f32[100, 48, 8]" = torch.ops.aten.view.default(permute_1281, [100, 48, 8]);  permute_1281 = None
        mul_686: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(view_1236, 0.1767766952966369);  view_1236 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:116 in forward, code: logits = w_l * (dot + bias - dist)
        add_529: "f32[100, 48, 8]" = torch.ops.aten.add.Tensor(mul_686, view_1231);  mul_686 = view_1231 = None
        sub_359: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(add_529, mul_685);  add_529 = mul_685 = None
        mul_687: "f32[100, 48, 8]" = torch.ops.aten.mul.Tensor(sub_359, 0.5773502691896257);  sub_359 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:118 in forward, code: pair_mask = mask.bool() & (neighbours != -1)
        ne_37: "b8[100, 48]" = torch.ops.aten.ne.Scalar(select_126, -1)
        bitwise_and_86: "b8[100, 48]" = torch.ops.aten.bitwise_and.Tensor(select_128, ne_37);  select_128 = ne_37 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:119 in forward, code: logits = torch.where(pair_mask[..., None], logits,
        unsqueeze_1204: "b8[100, 48, 1]" = torch.ops.aten.unsqueeze.default(bitwise_and_86, 2);  bitwise_and_86 = None
        where_176: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_1204, mul_687, full_default_41);  mul_687 = full_default_41 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:121 in forward, code: attn = torch.softmax(logits, dim=-2)               # over K
        clone_131: "f32[100, 48, 8]" = torch.ops.aten.clone.default(where_176, memory_format = torch.contiguous_format);  where_176 = None
        amax_11: "f32[100, 1, 8]" = torch.ops.aten.amax.default(clone_131, [-2], True)
        sub_360: "f32[100, 48, 8]" = torch.ops.aten.sub.Tensor(clone_131, amax_11);  clone_131 = amax_11 = None
        exp_31: "f32[100, 48, 8]" = torch.ops.aten.exp.default(sub_360);  sub_360 = None
        sum_178: "f32[100, 1, 8]" = torch.ops.aten.sum.dim_IntList(exp_31, [-2], True)
        div_145: "f32[100, 48, 8]" = torch.ops.aten.div.Tensor(exp_31, sum_178);  exp_31 = sum_178 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:123 in forward, code: attn = torch.where(pair_mask[..., None], attn, torch.zeros_like(attn))
        where_177: "f32[100, 48, 8]" = torch.ops.aten.where.self(unsqueeze_1204, div_145, full_default_42);  unsqueeze_1204 = div_145 = full_default_42 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:130 in forward, code: out_pair = torch.einsum("ijh,ijc->ihc", attn, pair)
        unsqueeze_1206: "f32[100, 48, 8, 1]" = torch.ops.aten.unsqueeze.default(where_177, 3);  where_177 = None
        permute_1282: "f32[100, 8, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_1206, [0, 2, 3, 1])
        permute_1283: "f32[100, 1, 64, 48]" = torch.ops.aten.permute.default(unsqueeze_1199, [0, 3, 2, 1]);  unsqueeze_1199 = None
        permute_1284: "f32[100, 8, 48, 1]" = torch.ops.aten.permute.default(permute_1282, [0, 1, 3, 2]);  permute_1282 = None
        view_1237: "f32[100, 8, 48]" = torch.ops.aten.view.default(permute_1284, [100, 8, 48])
        permute_1285: "f32[100, 48, 64, 1]" = torch.ops.aten.permute.default(permute_1283, [0, 3, 2, 1]);  permute_1283 = None
        view_1238: "f32[100, 48, 64]" = torch.ops.aten.view.default(permute_1285, [100, 48, 64]);  permute_1285 = None
        bmm_268: "f32[100, 8, 64]" = torch.ops.aten.bmm.default(view_1237, view_1238);  view_1237 = view_1238 = None
        view_1239: "f32[100, 8, 1, 64]" = torch.ops.aten.view.default(bmm_268, [100, 8, 1, 64]);  bmm_268 = None
        permute_1286: "f32[100, 8, 64, 1]" = torch.ops.aten.permute.default(view_1239, [0, 1, 3, 2]);  view_1239 = None
        view_1240: "f32[100, 8, 64]" = torch.ops.aten.view.default(permute_1286, [100, 8, 64]);  permute_1286 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:131 in forward, code: out_scalar = torch.einsum("ijh,ijhc->ihc", attn, v[neighbours])
        index_333: "f32[100, 48, 8, 32]" = torch.ops.aten.index.Tensor(getitem_94, [select_126]);  getitem_94 = None
        permute_1288: "f32[100, 8, 32, 48]" = torch.ops.aten.permute.default(index_333, [0, 2, 3, 1]);  index_333 = None
        clone_132: "f32[100, 8, 48, 1]" = torch.ops.aten.clone.default(permute_1284, memory_format = torch.contiguous_format);  permute_1284 = None
        view_1241: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_132, [800, 1, 48]);  clone_132 = None
        permute_1290: "f32[100, 8, 48, 32]" = torch.ops.aten.permute.default(permute_1288, [0, 1, 3, 2]);  permute_1288 = None
        clone_133: "f32[100, 8, 48, 32]" = torch.ops.aten.clone.default(permute_1290, memory_format = torch.contiguous_format);  permute_1290 = None
        view_1242: "f32[800, 48, 32]" = torch.ops.aten.view.default(clone_133, [800, 48, 32]);  clone_133 = None
        bmm_269: "f32[800, 1, 32]" = torch.ops.aten.bmm.default(view_1241, view_1242);  view_1241 = view_1242 = None
        view_1243: "f32[100, 8, 1, 32]" = torch.ops.aten.view.default(bmm_269, [100, 8, 1, 32]);  bmm_269 = None
        permute_1291: "f32[100, 8, 32, 1]" = torch.ops.aten.permute.default(view_1243, [0, 1, 3, 2]);  view_1243 = None
        view_1244: "f32[100, 8, 32]" = torch.ops.aten.view.default(permute_1291, [100, 8, 32]);  permute_1291 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:132 in forward, code: out_point = torch.einsum("ijh,ijhpc->ihpc", attn, v_g[neighbours])
        index_334: "f32[100, 48, 8, 8, 3]" = torch.ops.aten.index.Tensor(slice_701, [select_126]);  slice_701 = select_126 = None
        unsqueeze_1210: "f32[100, 48, 8, 1, 1]" = torch.ops.aten.unsqueeze.default(unsqueeze_1206, 4);  unsqueeze_1206 = None
        permute_1292: "f32[100, 8, 1, 1, 48]" = torch.ops.aten.permute.default(unsqueeze_1210, [0, 2, 3, 4, 1]);  unsqueeze_1210 = None
        permute_1293: "f32[100, 8, 8, 3, 48]" = torch.ops.aten.permute.default(index_334, [0, 2, 3, 4, 1]);  index_334 = None
        permute_1294: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.permute.default(permute_1292, [0, 1, 4, 2, 3]);  permute_1292 = None
        clone_134: "f32[100, 8, 48, 1, 1]" = torch.ops.aten.clone.default(permute_1294, memory_format = torch.contiguous_format);  permute_1294 = None
        view_1245: "f32[800, 1, 48]" = torch.ops.aten.view.default(clone_134, [800, 1, 48]);  clone_134 = None
        permute_1295: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.permute.default(permute_1293, [0, 1, 4, 2, 3]);  permute_1293 = None
        clone_135: "f32[100, 8, 48, 8, 3]" = torch.ops.aten.clone.default(permute_1295, memory_format = torch.contiguous_format);  permute_1295 = None
        view_1246: "f32[800, 48, 24]" = torch.ops.aten.view.default(clone_135, [800, 48, 24]);  clone_135 = None
        bmm_270: "f32[800, 1, 24]" = torch.ops.aten.bmm.default(view_1245, view_1246);  view_1245 = view_1246 = None
        view_1247: "f32[100, 8, 1, 8, 3]" = torch.ops.aten.view.default(bmm_270, [100, 8, 1, 8, 3]);  bmm_270 = None
        permute_1296: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_1247, [0, 1, 3, 4, 2]);  view_1247 = None
        view_1248: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_1296, [100, 8, 8, 3]);  permute_1296 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_361: "f32[100, 8, 8, 3]" = torch.ops.aten.sub.Tensor(view_1248, unsqueeze_284);  view_1248 = unsqueeze_284 = None
        unsqueeze_1215: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_361, 4);  sub_361 = None
        permute_1298: "f32[100, 8, 8, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1215, [0, 1, 2, 4, 3]);  unsqueeze_1215 = None
        permute_1300: "f32[100, 3, 8, 8, 1]" = torch.ops.aten.permute.default(permute_1298, [0, 4, 1, 2, 3]);  permute_1298 = None
        view_1250: "f32[100, 3, 64]" = torch.ops.aten.view.default(permute_1300, [100, 3, 64]);  permute_1300 = None
        bmm_271: "f32[100, 3, 64]" = torch.ops.aten.bmm.default(view_194, view_1250);  view_194 = view_1250 = None
        view_1251: "f32[100, 3, 1, 8, 8]" = torch.ops.aten.view.default(bmm_271, [100, 3, 1, 8, 8]);  bmm_271 = None
        permute_1301: "f32[100, 8, 8, 3, 1]" = torch.ops.aten.permute.default(view_1251, [0, 3, 4, 1, 2]);  view_1251 = None
        view_1252: "f32[100, 8, 8, 3]" = torch.ops.aten.view.default(permute_1301, [100, 8, 8, 3]);  permute_1301 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:45 in vec_norm2, code: return (a * a).sum(-1)
        mul_688: "f32[100, 8, 8, 3]" = torch.ops.aten.mul.Tensor(view_1252, view_1252)
        sum_179: "f32[100, 8, 8]" = torch.ops.aten.sum.dim_IntList(mul_688, [-1]);  mul_688 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/rigid.py:50 in vec_norm, code: return torch.sqrt(torch.clamp(vec_norm2(a), min=eps * eps))
        clamp_min_153: "f32[100, 8, 8]" = torch.ops.aten.clamp_min.default(sum_179, 1e-12);  sum_179 = None
        sqrt_116: "f32[100, 8, 8]" = torch.ops.aten.sqrt.default(clamp_min_153);  clamp_min_153 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:137 in forward, code: out_pair.reshape(n, -1),
        view_1253: "f32[100, 512]" = torch.ops.aten.view.default(view_1240, [100, -1]);  view_1240 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:138 in forward, code: out_scalar.reshape(n, -1),
        view_1254: "f32[100, 256]" = torch.ops.aten.view.default(view_1244, [100, -1]);  view_1244 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:139 in forward, code: out_point.reshape(n, -1),
        clone_136: "f32[100, 8, 8, 3]" = torch.ops.aten.clone.default(view_1252, memory_format = torch.contiguous_format);  view_1252 = None
        view_1255: "f32[100, 192]" = torch.ops.aten.view.default(clone_136, [100, 192]);  clone_136 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:140 in forward, code: out_norm.reshape(n, -1),
        view_1256: "f32[100, 64]" = torch.ops.aten.view.default(sqrt_116, [100, -1]);  sqrt_116 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/attention.py:136 in forward, code: out = self.project_out(torch.cat((
        cat_86: "f32[100, 1024]" = torch.ops.aten.cat.default([view_1253, view_1254, view_1255, view_1256], -1);  view_1253 = view_1254 = view_1255 = view_1256 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1216: "f32[100, 1024, 1]" = torch.ops.aten.unsqueeze.default(cat_86, 2);  cat_86 = None
        permute_1302: "f32[100, 1, 1024]" = torch.ops.aten.permute.default(unsqueeze_1216, [0, 2, 1]);  unsqueeze_1216 = None
        unsqueeze_1217: "f32[1024, 128, 1]" = torch.ops.aten.unsqueeze.default(arg341_1, 2);  arg341_1 = None
        permute_1303: "f32[1, 128, 1024]" = torch.ops.aten.permute.default(unsqueeze_1217, [2, 1, 0]);  unsqueeze_1217 = None
        permute_1304: "f32[100, 1024, 1]" = torch.ops.aten.permute.default(permute_1302, [0, 2, 1]);  permute_1302 = None
        view_1257: "f32[1, 100, 1024]" = torch.ops.aten.view.default(permute_1304, [1, 100, 1024]);  permute_1304 = None
        permute_1305: "f32[1024, 128, 1]" = torch.ops.aten.permute.default(permute_1303, [2, 1, 0]);  permute_1303 = None
        view_1258: "f32[1, 1024, 128]" = torch.ops.aten.view.default(permute_1305, [1, 1024, 128]);  permute_1305 = None
        bmm_272: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_1257, view_1258);  view_1257 = view_1258 = None
        view_1259: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_272, [100, 1, 128]);  bmm_272 = None
        permute_1306: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1259, [0, 2, 1]);  view_1259 = None
        view_1260: "f32[100, 128]" = torch.ops.aten.view.default(permute_1306, [100, 128]);  permute_1306 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_530: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_1260, arg342_1);  view_1260 = arg342_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:371 in forward, code: features = features + self.attn_2(
        add_531: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_515, add_530);  add_515 = add_530 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_68: "f32[100, 1]" = torch.ops.aten.mean.dim(add_531, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_68: "f32[100, 1]" = torch.ops.aten.var.correction(add_531, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_362: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_531, mean_68);  mean_68 = None
        add_532: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_68, 1e-05);  var_68 = None
        rsqrt_68: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_532);  add_532 = None
        mul_689: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_362, rsqrt_68);  sub_362 = rsqrt_68 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_690: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_689, arg343_1);  mul_689 = arg343_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_533: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_690, arg344_1);  mul_690 = arg344_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:98 in apply_inverse_t, code: return torch.einsum("...ji,...j->...i", rot, points - trans)
        sub_367: "f32[100, 20, 3]" = torch.ops.aten.sub.Tensor(add_476, unsqueeze_1111)
        permute_1307: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_1110, [0, 1, 3, 2])
        unsqueeze_1226: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(sub_367, 3);  sub_367 = None
        permute_1308: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1226, [0, 1, 3, 2]);  unsqueeze_1226 = None
        permute_1309: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_1307, [0, 2, 3, 1]);  permute_1307 = None
        view_1261: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_1309, [100, 3, 3]);  permute_1309 = None
        permute_1310: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_1308, [0, 3, 1, 2]);  permute_1308 = None
        view_1262: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_1310, [100, 3, 20]);  permute_1310 = None
        bmm_273: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_1261, view_1262);  view_1261 = view_1262 = None
        view_1263: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_273, [100, 3, 1, 20]);  bmm_273 = None
        permute_1311: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_1263, [0, 3, 1, 2]);  view_1263 = None
        view_1264: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_1311, [100, 20, 3]);  permute_1311 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:256 in forward, code: local_pos = local_pos.reshape(local_pos.shape[0], -1)
        clone_137: "f32[100, 20, 3]" = torch.ops.aten.clone.default(view_1264, memory_format = torch.contiguous_format)
        view_1265: "f32[100, 60]" = torch.ops.aten.view.default(clone_137, [100, 60]);  clone_137 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1228: "f32[128, 128, 1]" = torch.ops.aten.unsqueeze.default(arg345_1, 2);  arg345_1 = None
        permute_1313: "f32[1, 128, 128]" = torch.ops.aten.permute.default(unsqueeze_1228, [2, 1, 0]);  unsqueeze_1228 = None
        permute_1315: "f32[128, 128, 1]" = torch.ops.aten.permute.default(permute_1313, [2, 1, 0]);  permute_1313 = None
        view_1267: "f32[1, 128, 128]" = torch.ops.aten.view.default(permute_1315, [1, 128, 128]);  permute_1315 = None
        bmm_274: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_211, view_1267);  view_211 = view_1267 = None
        view_1268: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_274, [100, 1, 128]);  bmm_274 = None
        permute_1316: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1268, [0, 2, 1]);  view_1268 = None
        view_1269: "f32[100, 128]" = torch.ops.aten.view.default(permute_1316, [100, 128]);  permute_1316 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:258 in forward, code: local = local + self.linear_condition(condition)
        add_538: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_533, view_1269);  add_533 = view_1269 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1229: "f32[100, 60, 1]" = torch.ops.aten.unsqueeze.default(view_1265, 2);  view_1265 = None
        permute_1317: "f32[100, 1, 60]" = torch.ops.aten.permute.default(unsqueeze_1229, [0, 2, 1]);  unsqueeze_1229 = None
        unsqueeze_1230: "f32[60, 256, 1]" = torch.ops.aten.unsqueeze.default(arg346_1, 2);  arg346_1 = None
        permute_1318: "f32[1, 256, 60]" = torch.ops.aten.permute.default(unsqueeze_1230, [2, 1, 0]);  unsqueeze_1230 = None
        permute_1319: "f32[100, 60, 1]" = torch.ops.aten.permute.default(permute_1317, [0, 2, 1]);  permute_1317 = None
        view_1270: "f32[1, 100, 60]" = torch.ops.aten.view.default(permute_1319, [1, 100, 60]);  permute_1319 = None
        permute_1320: "f32[60, 256, 1]" = torch.ops.aten.permute.default(permute_1318, [2, 1, 0]);  permute_1318 = None
        view_1271: "f32[1, 60, 256]" = torch.ops.aten.view.default(permute_1320, [1, 60, 256]);  permute_1320 = None
        bmm_275: "f32[1, 100, 256]" = torch.ops.aten.bmm.default(view_1270, view_1271);  view_1270 = view_1271 = None
        view_1272: "f32[100, 1, 256]" = torch.ops.aten.view.default(bmm_275, [100, 1, 256]);  bmm_275 = None
        permute_1321: "f32[100, 256, 1]" = torch.ops.aten.permute.default(view_1272, [0, 2, 1]);  view_1272 = None
        view_1273: "f32[100, 256]" = torch.ops.aten.view.default(permute_1321, [100, 256]);  permute_1321 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_539: "f32[100, 256]" = torch.ops.aten.add.Tensor(view_1273, arg347_1);  view_1273 = arg347_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:181 in forward, code: x = self.activation(x)
        mul_697: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_539, add_539)
        mul_698: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_697, add_539);  mul_697 = None
        mul_699: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_698, 0.044715);  mul_698 = None
        add_540: "f32[100, 256]" = torch.ops.aten.add.Tensor(add_539, mul_699);  mul_699 = None
        mul_700: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_540, 0.7978845608028654);  add_540 = None
        mul_701: "f32[100, 256]" = torch.ops.aten.mul.Tensor(add_539, 0.5);  add_539 = None
        tanh_28: "f32[100, 256]" = torch.ops.aten.tanh.default(mul_700);  mul_700 = None
        add_541: "f32[100, 256]" = torch.ops.aten.add.Tensor(tanh_28, 1);  tanh_28 = None
        mul_702: "f32[100, 256]" = torch.ops.aten.mul.Tensor(mul_701, add_541);  mul_701 = add_541 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1231: "f32[100, 256, 1]" = torch.ops.aten.unsqueeze.default(mul_702, 2);  mul_702 = None
        permute_1322: "f32[100, 1, 256]" = torch.ops.aten.permute.default(unsqueeze_1231, [0, 2, 1]);  unsqueeze_1231 = None
        unsqueeze_1232: "f32[256, 128, 1]" = torch.ops.aten.unsqueeze.default(arg348_1, 2);  arg348_1 = None
        permute_1323: "f32[1, 128, 256]" = torch.ops.aten.permute.default(unsqueeze_1232, [2, 1, 0]);  unsqueeze_1232 = None
        permute_1324: "f32[100, 256, 1]" = torch.ops.aten.permute.default(permute_1322, [0, 2, 1]);  permute_1322 = None
        view_1274: "f32[1, 100, 256]" = torch.ops.aten.view.default(permute_1324, [1, 100, 256]);  permute_1324 = None
        permute_1325: "f32[256, 128, 1]" = torch.ops.aten.permute.default(permute_1323, [2, 1, 0]);  permute_1323 = None
        view_1275: "f32[1, 256, 128]" = torch.ops.aten.view.default(permute_1325, [1, 256, 128]);  permute_1325 = None
        bmm_276: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_1274, view_1275);  view_1274 = view_1275 = None
        view_1276: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_276, [100, 1, 128]);  bmm_276 = None
        permute_1326: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1276, [0, 2, 1]);  view_1276 = None
        view_1277: "f32[100, 128]" = torch.ops.aten.view.default(permute_1326, [100, 128]);  permute_1326 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_542: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_1277, arg349_1);  view_1277 = arg349_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:259 in forward, code: local = local + self.mlp(local_pos)
        add_543: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_538, add_542);  add_538 = add_542 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1233: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_543, 2);  add_543 = None
        permute_1327: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1233, [0, 2, 1]);  unsqueeze_1233 = None
        unsqueeze_1234: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg350_1, 2);  arg350_1 = None
        permute_1328: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1234, [2, 1, 0]);  unsqueeze_1234 = None
        permute_1329: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_1327, [0, 2, 1]);  permute_1327 = None
        view_1278: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_1329, [1, 100, 128]);  permute_1329 = None
        permute_1330: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_1328, [2, 1, 0]);  permute_1328 = None
        view_1279: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_1330, [1, 128, 512]);  permute_1330 = None
        bmm_277: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_1278, view_1279);  view_1279 = None
        view_1280: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_277, [100, 1, 512]);  bmm_277 = None
        permute_1331: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_1280, [0, 2, 1]);  view_1280 = None
        view_1281: "f32[100, 512]" = torch.ops.aten.view.default(permute_1331, [100, 512]);  permute_1331 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1236: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg351_1, 2);  arg351_1 = None
        permute_1333: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1236, [2, 1, 0]);  unsqueeze_1236 = None
        permute_1335: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_1333, [2, 1, 0]);  permute_1333 = None
        view_1283: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_1335, [1, 128, 512]);  permute_1335 = None
        bmm_278: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_1278, view_1283);  view_1283 = None
        view_1284: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_278, [100, 1, 512]);  bmm_278 = None
        permute_1336: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_1284, [0, 2, 1]);  view_1284 = None
        view_1285: "f32[100, 512]" = torch.ops.aten.view.default(permute_1336, [100, 512]);  permute_1336 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:262 in forward, code: local_gate = gelu(self.linear_gate(local))
        mul_703: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1285, view_1285)
        mul_704: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_703, view_1285);  mul_703 = None
        mul_705: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_704, 0.044715);  mul_704 = None
        add_544: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_1285, mul_705);  mul_705 = None
        mul_706: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_544, 0.7978845608028654);  add_544 = None
        mul_707: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1285, 0.5);  view_1285 = None
        tanh_29: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_706);  mul_706 = None
        add_545: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_29, 1);  tanh_29 = None
        mul_708: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_707, add_545);  mul_707 = add_545 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:263 in forward, code: hidden = local_gate * local_update
        mul_709: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_708, view_1281);  mul_708 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1238: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg352_1, 2);  arg352_1 = None
        permute_1338: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1238, [2, 1, 0]);  unsqueeze_1238 = None
        permute_1340: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_1338, [2, 1, 0]);  permute_1338 = None
        view_1287: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_1340, [1, 128, 512]);  permute_1340 = None
        bmm_279: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_1278, view_1287);  view_1287 = None
        view_1288: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_279, [100, 1, 512]);  bmm_279 = None
        permute_1341: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_1288, [0, 2, 1]);  view_1288 = None
        view_1289: "f32[100, 512]" = torch.ops.aten.view.default(permute_1341, [100, 512]);  permute_1341 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:265 in forward, code: chain_gate = gelu(self.linear_chain_gate(local))
        mul_710: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1289, view_1289)
        mul_711: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_710, view_1289);  mul_710 = None
        mul_712: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_711, 0.044715);  mul_711 = None
        add_546: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_1289, mul_712);  mul_712 = None
        mul_713: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_546, 0.7978845608028654);  add_546 = None
        mul_714: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1289, 0.5);  view_1289 = None
        tanh_30: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_713);  mul_713 = None
        add_547: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_30, 1);  tanh_30 = None
        mul_715: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_714, add_547);  mul_714 = add_547 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1240: "f32[128, 512, 1]" = torch.ops.aten.unsqueeze.default(arg353_1, 2);  arg353_1 = None
        permute_1343: "f32[1, 512, 128]" = torch.ops.aten.permute.default(unsqueeze_1240, [2, 1, 0]);  unsqueeze_1240 = None
        permute_1345: "f32[128, 512, 1]" = torch.ops.aten.permute.default(permute_1343, [2, 1, 0]);  permute_1343 = None
        view_1291: "f32[1, 128, 512]" = torch.ops.aten.view.default(permute_1345, [1, 128, 512]);  permute_1345 = None
        bmm_280: "f32[1, 100, 512]" = torch.ops.aten.bmm.default(view_1278, view_1291);  view_1278 = view_1291 = None
        view_1292: "f32[100, 1, 512]" = torch.ops.aten.view.default(bmm_280, [100, 1, 512]);  bmm_280 = None
        permute_1346: "f32[100, 512, 1]" = torch.ops.aten.permute.default(view_1292, [0, 2, 1]);  view_1292 = None
        view_1293: "f32[100, 512]" = torch.ops.aten.view.default(permute_1346, [100, 512]);  permute_1346 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:266 in forward, code: batch_gate = gelu(self.linear_batch_gate(local))
        mul_716: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1293, view_1293)
        mul_717: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_716, view_1293);  mul_716 = None
        mul_718: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_717, 0.044715);  mul_717 = None
        add_548: "f32[100, 512]" = torch.ops.aten.add.Tensor(view_1293, mul_718);  mul_718 = None
        mul_719: "f32[100, 512]" = torch.ops.aten.mul.Tensor(add_548, 0.7978845608028654);  add_548 = None
        mul_720: "f32[100, 512]" = torch.ops.aten.mul.Tensor(view_1293, 0.5);  view_1293 = None
        tanh_31: "f32[100, 512]" = torch.ops.aten.tanh.default(mul_719);  mul_719 = None
        add_549: "f32[100, 512]" = torch.ops.aten.add.Tensor(tanh_31, 1);  tanh_31 = None
        mul_721: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_720, add_549);  mul_720 = add_549 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_722: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_721, view_1281);  mul_721 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_178: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_722, full_default_44);  mul_722 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_179: "f32[100, 512]" = torch.ops.aten.where.self(view_239, where_178, full_default_44);  view_239 = where_178 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_20: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_6, where_179);  expand_6 = where_179 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_339: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_20, [clamp_max_2]);  scatter_add_20 = clamp_max_2 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_148: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_339, clamp_min_33);  index_339 = clamp_min_33 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_182: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_148, full_default_44);  div_148 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:268 in forward, code: hidden = hidden + index_mean(batch_gate * local_update, batch, m)
        add_550: "f32[100, 512]" = torch.ops.aten.add.Tensor(mul_709, where_182);  mul_709 = where_182 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:124 in index_mean, code: weighted = data * weight
        mul_724: "f32[100, 512]" = torch.ops.aten.mul.Tensor(mul_715, view_1281);  mul_715 = view_1281 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:79 in index_sum, code: masked = torch.where(mask.bool(), data, torch.zeros_like(data))
        where_183: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, mul_724, full_default_44);  mul_724 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:81 in index_sum, code: masked = torch.where(valid.view(-1, *([1] * (data.dim() - 1))),
        where_184: "f32[100, 512]" = torch.ops.aten.where.self(view_243, where_183, full_default_44);  view_243 = where_183 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:88 in index_sum, code: out = out.scatter_add(0, idx, masked)
        scatter_add_22: "f32[100, 512]" = torch.ops.aten.scatter_add.default(full_default_44, 0, expand_8, where_184);  expand_8 = where_184 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:89 in index_sum, code: result = out[index]
        index_341: "f32[100, 512]" = torch.ops.aten.index.Tensor(scatter_add_22, [clamp_max_4]);  scatter_add_22 = clamp_max_4 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:127 in index_mean, code: result = total / count.clamp(min=1e-6)
        div_149: "f32[100, 512]" = torch.ops.aten.div.Tensor(index_341, clamp_min_36);  index_341 = clamp_min_36 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/segment.py:129 in index_mean, code: result = torch.where(mask_b, result, torch.zeros_like(result))
        where_187: "f32[100, 512]" = torch.ops.aten.where.self(unsqueeze_20, div_149, full_default_44);  unsqueeze_20 = div_149 = full_default_44 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:269 in forward, code: hidden = hidden + index_mean(chain_gate * local_update, chain, m)
        add_551: "f32[100, 512]" = torch.ops.aten.add.Tensor(add_550, where_187);  add_550 = where_187 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1242: "f32[100, 512, 1]" = torch.ops.aten.unsqueeze.default(add_551, 2);  add_551 = None
        permute_1347: "f32[100, 1, 512]" = torch.ops.aten.permute.default(unsqueeze_1242, [0, 2, 1]);  unsqueeze_1242 = None
        unsqueeze_1243: "f32[512, 128, 1]" = torch.ops.aten.unsqueeze.default(arg354_1, 2);  arg354_1 = None
        permute_1348: "f32[1, 128, 512]" = torch.ops.aten.permute.default(unsqueeze_1243, [2, 1, 0]);  unsqueeze_1243 = None
        permute_1349: "f32[100, 512, 1]" = torch.ops.aten.permute.default(permute_1347, [0, 2, 1]);  permute_1347 = None
        view_1302: "f32[1, 100, 512]" = torch.ops.aten.view.default(permute_1349, [1, 100, 512]);  permute_1349 = None
        permute_1350: "f32[512, 128, 1]" = torch.ops.aten.permute.default(permute_1348, [2, 1, 0]);  permute_1348 = None
        view_1303: "f32[1, 512, 128]" = torch.ops.aten.view.default(permute_1350, [1, 512, 128]);  permute_1350 = None
        bmm_281: "f32[1, 100, 128]" = torch.ops.aten.bmm.default(view_1302, view_1303);  view_1302 = view_1303 = None
        view_1304: "f32[100, 1, 128]" = torch.ops.aten.view.default(bmm_281, [100, 1, 128]);  bmm_281 = None
        permute_1351: "f32[100, 128, 1]" = torch.ops.aten.permute.default(view_1304, [0, 2, 1]);  view_1304 = None
        view_1305: "f32[100, 128]" = torch.ops.aten.view.default(permute_1351, [100, 128]);  permute_1351 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:96 in forward, code: out = out + self.b
        add_552: "f32[100, 128]" = torch.ops.aten.add.Tensor(view_1305, arg355_1);  view_1305 = arg355_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:374 in forward, code: features = features + self.update(
        add_553: "f32[100, 128]" = torch.ops.aten.add.Tensor(add_531, add_552);  add_531 = add_552 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:147 in forward, code: mean = x.mean(-1, keepdim=True)
        mean_69: "f32[100, 1]" = torch.ops.aten.mean.dim(add_553, [-1], True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:148 in forward, code: var = x.var(-1, unbiased=False, keepdim=True)
        var_69: "f32[100, 1]" = torch.ops.aten.var.correction(add_553, [-1], correction = 0, keepdim = True)
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:149 in forward, code: out = (x - mean) * torch.rsqrt(var + self.eps)
        sub_368: "f32[100, 128]" = torch.ops.aten.sub.Tensor(add_553, mean_69);  mean_69 = None
        add_554: "f32[100, 1]" = torch.ops.aten.add.Tensor(var_69, 1e-05);  var_69 = None
        rsqrt_69: "f32[100, 1]" = torch.ops.aten.rsqrt.default(add_554);  add_554 = None
        mul_726: "f32[100, 128]" = torch.ops.aten.mul.Tensor(sub_368, rsqrt_69);  sub_368 = rsqrt_69 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:151 in forward, code: out = out * self.scale
        mul_727: "f32[100, 128]" = torch.ops.aten.mul.Tensor(mul_726, arg356_1);  mul_726 = arg356_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:153 in forward, code: out = out + self.offset
        add_555: "f32[100, 128]" = torch.ops.aten.add.Tensor(mul_727, arg357_1);  mul_727 = arg357_1 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/basic.py:94 in forward, code: out = torch.einsum("...k,ki->...i", x, self.w)
        unsqueeze_1253: "f32[100, 128, 1]" = torch.ops.aten.unsqueeze.default(add_555, 2);  add_555 = None
        permute_1357: "f32[100, 1, 128]" = torch.ops.aten.permute.default(unsqueeze_1253, [0, 2, 1]);  unsqueeze_1253 = None
        unsqueeze_1254: "f32[128, 60, 1]" = torch.ops.aten.unsqueeze.default(arg358_1, 2);  arg358_1 = None
        permute_1358: "f32[1, 60, 128]" = torch.ops.aten.permute.default(unsqueeze_1254, [2, 1, 0]);  unsqueeze_1254 = None
        permute_1359: "f32[100, 128, 1]" = torch.ops.aten.permute.default(permute_1357, [0, 2, 1]);  permute_1357 = None
        view_1310: "f32[1, 100, 128]" = torch.ops.aten.view.default(permute_1359, [1, 100, 128]);  permute_1359 = None
        permute_1360: "f32[128, 60, 1]" = torch.ops.aten.permute.default(permute_1358, [2, 1, 0]);  permute_1358 = None
        view_1311: "f32[1, 128, 60]" = torch.ops.aten.view.default(permute_1360, [1, 128, 60]);  permute_1360 = None
        bmm_283: "f32[1, 100, 60]" = torch.ops.aten.bmm.default(view_1310, view_1311);  view_1310 = view_1311 = None
        view_1312: "f32[100, 1, 60]" = torch.ops.aten.view.default(bmm_283, [100, 1, 60]);  bmm_283 = None
        permute_1361: "f32[100, 60, 1]" = torch.ops.aten.permute.default(view_1312, [0, 2, 1]);  view_1312 = None
        view_1313: "f32[100, 60]" = torch.ops.aten.view.default(permute_1361, [100, 60]);  permute_1361 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:311 in forward, code: pos_update = float(scale) * pos_update
        mul_734: "f32[100, 60]" = torch.ops.aten.mul.Tensor(view_1313, 10.0);  view_1313 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:312 in forward, code: pos_update = pos_update.reshape(*pos_update.shape[:-1], self.atom_count, 3)
        view_1314: "f32[100, 20, 3]" = torch.ops.aten.view.default(mul_734, [100, 20, 3]);  mul_734 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:313 in forward, code: local_pos = local_pos + pos_update
        add_560: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_1264, view_1314);  view_1264 = view_1314 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/geometry/frames.py:90 in apply_t, code: return torch.einsum("...ij,...j->...i", rot, points) + trans
        permute_1362: "f32[100, 1, 3, 3]" = torch.ops.aten.permute.default(unsqueeze_1110, [0, 1, 2, 3]);  unsqueeze_1110 = None
        unsqueeze_1257: "f32[100, 20, 3, 1]" = torch.ops.aten.unsqueeze.default(add_560, 3);  add_560 = None
        permute_1363: "f32[100, 20, 1, 3]" = torch.ops.aten.permute.default(unsqueeze_1257, [0, 1, 3, 2]);  unsqueeze_1257 = None
        permute_1364: "f32[100, 3, 3, 1]" = torch.ops.aten.permute.default(permute_1362, [0, 2, 3, 1]);  permute_1362 = None
        view_1315: "f32[100, 3, 3]" = torch.ops.aten.view.default(permute_1364, [100, 3, 3]);  permute_1364 = None
        permute_1365: "f32[100, 3, 20, 1]" = torch.ops.aten.permute.default(permute_1363, [0, 3, 1, 2]);  permute_1363 = None
        view_1316: "f32[100, 3, 20]" = torch.ops.aten.view.default(permute_1365, [100, 3, 20]);  permute_1365 = None
        bmm_284: "f32[100, 3, 20]" = torch.ops.aten.bmm.default(view_1315, view_1316);  view_1315 = view_1316 = None
        view_1317: "f32[100, 3, 1, 20]" = torch.ops.aten.view.default(bmm_284, [100, 3, 1, 20]);  bmm_284 = None
        permute_1366: "f32[100, 20, 3, 1]" = torch.ops.aten.permute.default(view_1317, [0, 3, 1, 2]);  view_1317 = None
        view_1318: "f32[100, 20, 3]" = torch.ops.aten.view.default(permute_1366, [100, 20, 3]);  permute_1366 = None
        add_561: "f32[100, 20, 3]" = torch.ops.aten.add.Tensor(view_1318, unsqueeze_1111);  view_1318 = unsqueeze_1111 = None
        
         # File: /home/hpc/v181bb/v181bb10/SALAD_torch/salad_torch/modules/blocks.py:450 in forward, code: return local, pos, torch.stack(trajectory, dim=0)
        cat_89: "f32[600, 20, 3]" = torch.ops.aten.cat.default([add_136, add_221, add_306, add_391, add_476, add_561]);  add_136 = add_221 = add_306 = add_391 = add_476 = None
        view_1319: "f32[6, 100, 20, 3]" = torch.ops.aten.view.default(cat_89, [6, 100, 20, 3]);  cat_89 = None
        return (add_561, add_553, view_1319, getitem, getitem_1, getitem_2, getitem_3, getitem_4, getitem_5, getitem_6, getitem_7, getitem_8, getitem_9, getitem_10, getitem_11, getitem_12, getitem_13, getitem_14, getitem_15, getitem_16, getitem_17, getitem_18, where_1, sqrt_3, cat_4, view_14)
        